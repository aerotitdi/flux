import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "FLUX 2.0 — Космический ИИ-ассистент",
  description:
    "Десктопный ИИ-ассистент: космические сцены, мост к живому браузеру (вкладки как ссылки-карточки), мост к приложениям, чат с тулзами, голос и скиллы.",
  keywords: ["FLUX", "AI", "assistant", "browser bridge", "cosmic", "chatbot"],
  authors: [{ name: "FLUX Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "FLUX 2.0",
    description: "Космический ИИ-ассистент с мостами к браузеру и приложениям",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning className="dark">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
