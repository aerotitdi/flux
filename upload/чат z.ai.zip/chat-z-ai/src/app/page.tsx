"use client";

import { useEffect, useState } from "react";
import { AnimatePresence } from "framer-motion";
import { useFlux, type ViewName, type SceneName } from "@/components/flux/store";
import { Sidebar } from "@/components/flux/sidebar";
import { Header } from "@/components/flux/header";
import { Footer } from "@/components/flux/footer";
import { PageTransition } from "@/components/flux/motion";
import { HomeView } from "@/components/flux/home-view";
import { BrowserBridgeView } from "@/components/flux/browser-bridge-view";
import { AppsBridgeView } from "@/components/flux/apps-bridge-view";
import { UiaBridgeView } from "@/components/flux/uia-bridge-view";
import { GameMemoryView } from "@/components/flux/game-memory-view";
import { ChatPanel } from "@/components/flux/chat-panel";
import { ToolsCatalogView } from "@/components/flux/tools-catalog-view";
import { SkillsCatalogView } from "@/components/flux/skills-catalog-view";
import { BrainView } from "@/components/flux/brain-view";
import { CodePlaygroundView } from "@/components/flux/code-playground-view";
import { ConnectionsView } from "@/components/flux/connections-view";
import { SelfTestView } from "@/components/flux/self-test-view";
import { CommandPalette } from "@/components/flux/command-palette";
import { ShortcutsHelp } from "@/components/flux/shortcuts-help";
import { SettingsModal } from "@/components/flux/settings-modal";

export default function Home() {
  const {
    view,
    setView,
    setStatusText,
    setAgentState,
    tabs,
    setTabs,
    apps,
    setApps,
    uiaWindows,
    setUiaWindows,
    games,
    setGames,
    tools,
    setTools,
    skills,
    setSkills,
    brain,
    setBrain,
  } = useFlux();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);

  // Cmd+K / Ctrl+K hotkey to open command palette + ? for shortcuts help
  // + 1-9, 0 to jump to views + S for settings + T to cycle scenes
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // Cmd+K / Ctrl+K — command palette
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPaletteOpen((p) => !p);
        return;
      }
      // ignore shortcuts when typing in an input/textarea
      const target = e.target as HTMLElement;
      const isTyping = target?.tagName === "INPUT" || target?.tagName === "TEXTAREA" || target?.isContentEditable;
      if (isTyping) return;
      // ? — shortcuts help
      if (e.key === "?" || (e.shiftKey && e.key === "/")) {
        e.preventDefault();
        setShortcutsOpen((s) => !s);
        return;
      }
      // S — settings
      if (e.key.toLowerCase() === "s" && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        setSettingsOpen((s) => !s);
        return;
      }
      // T — cycle scenes forward
      if (e.key.toLowerCase() === "t" && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        const SCENES: SceneName[] = ["uranus","solar","galaxy","space","aurora","pulsar","nebula","blackhole","supernova","solarflare","quasar","wormhole","binarystar","magnetar","cosmicweb","whitedwarf","nsmerger","accretiondisk","pwn","tde","grb","magnetosphere","hotjupiter","browndwarf","protoplanetary","hypergiant","wolfrayet","ringnebula","crabnebula","solarouter","helix","orion","eagle"];
        const idx = SCENES.indexOf(useFlux.getState().scene);
        useFlux.getState().setScene(SCENES[(idx + 1) % SCENES.length]);
        return;
      }
      // 1-9, 0 — view navigation
      const viewMap: Record<string, ViewName> = {
        "1": "home", "2": "browser", "3": "apps", "4": "uia",
        "5": "memory", "6": "chat", "7": "tools", "8": "skills",
        "9": "brain", "0": "playground",
      };
      if (viewMap[e.key] && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        setView(viewMap[e.key]);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [setView]);

  // preload bridges on mount so home stats are non-zero
  useEffect(() => {
    let active = true;
    (async () => {
      if (tabs.length === 0) {
        try {
          const r = await fetch("/api/browser/tabs");
          const d = await r.json();
          if (active && Array.isArray(d.tabs)) setTabs(d.tabs);
        } catch { /* noop */ }
      }
      if (apps.length === 0) {
        try {
          const r = await fetch("/api/apps");
          const d = await r.json();
          if (active && Array.isArray(d.apps)) setApps(d.apps);
        } catch { /* noop */ }
      }
      if (uiaWindows.length === 0) {
        try {
          const r = await fetch("/api/uia");
          const d = await r.json();
          if (active && Array.isArray(d.windows)) setUiaWindows(d.windows);
        } catch { /* noop */ }
      }
      if (games.length === 0) {
        try {
          const r = await fetch("/api/games");
          const d = await r.json();
          if (active && Array.isArray(d.games)) setGames(d.games);
        } catch { /* noop */ }
      }
      if (tools.length === 0) {
        try {
          const r = await fetch("/api/tools");
          const d = await r.json();
          if (active && Array.isArray(d.tools)) setTools(d.tools);
        } catch { /* noop */ }
      }
      if (skills.length === 0) {
        try {
          const r = await fetch("/api/skills");
          const d = await r.json();
          if (active && Array.isArray(d.skills)) setSkills(d.skills);
        } catch { /* noop */ }
      }
      if (brain.notes.length === 0 && brain.todos.length === 0) {
        try {
          const r = await fetch("/api/memory");
          const d = await r.json();
          if (active && d.notes) setBrain({ notes: d.notes, todos: d.todos, facts: d.facts, kvs: d.kvs, timers: d.timers });
        } catch { /* noop */ }
      }
    })();
    return () => { active = false; };
  }, [tabs.length, apps.length, uiaWindows.length, games.length, tools.length, skills.length, brain.notes.length, brain.todos.length, setTabs, setApps, setUiaWindows, setGames, setTools, setSkills, setBrain]);

  // status rotation demo on home view
  useEffect(() => {
    if (view !== "home") return;
    const phrases = [
      { st: "listen" as const, t: "Слушаю… (микрофон браузерный, WebSpeech)" },
      { st: "think" as const, t: "Думаю… (medium + авто-поиск DuckDuckGo)" },
      { st: "think" as const, t: "🔧 browser_tabs_list — вижу 10 вкладок, uia_tree — 3 окна" },
      { st: "speak" as const, t: "Говорю… голосом Dmitry (RU, wingetgui)" },
      { st: "idle" as const, t: "Готово: вижу Chrome, 3 окна UIA, 5 офлайн-игр в whitelist" },
    ];
    let i = 0;
    const tick = () => {
      const p = phrases[i % phrases.length];
      setAgentState(p.st);
      setStatusText(p.t);
      i++;
    };
    tick();
    const id = setInterval(tick, 3200);
    return () => clearInterval(id);
  }, [view, setAgentState, setStatusText]);

  return (
    <div className="h-screen flex flex-col bg-background text-foreground overflow-hidden">
      <div className="flex flex-1 min-h-0 overflow-hidden">
        <Sidebar onOpenSettings={() => setSettingsOpen(true)} onOpenPalette={() => setPaletteOpen(true)} />
        <div className="flex-1 flex flex-col min-w-0">
          <Header />
          <main className="flex-1 flex flex-col min-h-0" role="main">
            <AnimatePresence mode="wait">
              <PageTransition key={view} viewKey={view}>
                {view === "home" && <HomeView />}
                {view === "browser" && <BrowserBridgeView />}
                {view === "apps" && <AppsBridgeView />}
                {view === "uia" && <UiaBridgeView />}
                {view === "memory" && <GameMemoryView />}
                {view === "chat" && <ChatPanel />}
                {view === "tools" && <ToolsCatalogView />}
                {view === "skills" && <SkillsCatalogView />}
                {view === "brain" && <BrainView />}
                {view === "playground" && <CodePlaygroundView />}
                {view === "connections" && <ConnectionsView />}
                {view === "selftest" && <SelfTestView />}
              </PageTransition>
            </AnimatePresence>
          </main>
          <Footer />
        </div>
      </div>

      <SettingsModal open={settingsOpen} onClose={() => setSettingsOpen(false)} />
      <CommandPalette open={paletteOpen} onOpenChange={setPaletteOpen} onOpenSettings={() => setSettingsOpen(true)} />
      <ShortcutsHelp open={shortcutsOpen} onOpenChange={setShortcutsOpen} />
    </div>
  );
}
