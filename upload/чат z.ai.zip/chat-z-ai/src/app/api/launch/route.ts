import { NextResponse } from "next/server";

// Mock launching an app — real Python app would call os.startfile/subprocess.Popen.
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { id, action } = body;
  if (action === "launch" && id) {
    return NextResponse.json({
      ok: true,
      id,
      pid: Math.floor(Math.random() * 9000 + 1000),
      started_at: new Date().toISOString(),
      message: "Процесс запущен",
    });
  }
  if (action === "kill" && id) {
    return NextResponse.json({ ok: true, id, message: "Процесс завершён" });
  }
  if (action === "focus" && id) {
    return NextResponse.json({ ok: true, id, message: "Окно переведено на передний план" });
  }
  return NextResponse.json({ ok: false, error: "unknown action" }, { status: 400 });
}
