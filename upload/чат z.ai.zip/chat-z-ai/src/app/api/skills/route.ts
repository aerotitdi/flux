import { NextResponse } from "next/server";

interface Skill {
  id: string;
  name: string;
  source: "local" | "nvidia";
  category: string;
  description: string;
  body: string;
  matched?: boolean;
  pinned?: boolean;
}

// Local SKILL.md files from flux-ai-main/skills_bundled/
const LOCAL_SKILLS: Skill[] = [
  {
    id: "web-research",
    name: "web-research",
    source: "local",
    category: "research",
    description: "Веб-исследование: поиск + чтение + суммаризация источников по теме",
    body: "## web-research skill\n\n1. Приняв тему — определи 3-5 ключевых подзапросов\n2. Запусти web_search для каждого\n3. Для топ-результатов вызови page_reader\n4. Суммаризуй ключевые тезисы с цитатами и ссылками\n5. Укажи противоречия и пробелы в данных\n",
  },
  {
    id: "code-run-verify",
    name: "code-run-verify",
    source: "local",
    category: "dev",
    description: "Напиши код → прогони → проверь вывод → исправь → верни финальный",
    body: "## code-run-verify skill\n\n1. Сформулируй задачу и выбери движок\n2. Напиши код в блоке ```{lang}\n3. Прогони через code_test\n4. Если ошибка — проанализируй STDERR, исправь, повтори\n5. Покажи финальный код + результат выполнения\n",
  },
  {
    id: "browser-tabs-work",
    name: "browser-tabs-work",
    source: "local",
    category: "browser",
    description: "Работа с вкладками: browser_tabs_list → выбор нужной → действия по targetId",
    body: "## browser-tabs-work skill\n\n1. browser_tabs_list — получи все вкладки как ссылки {category}:{slug}\n2. Найди нужную по заголовку/url/категории\n3. browser_tab_switch → активируй\n4. browser_tab_screenshot/text/click/type — работай с выбранной\n5. Не закрывай чужие вкладки без подтверждения\n",
  },
  {
    id: "voice-reply-style",
    name: "voice-reply-style",
    source: "local",
    category: "voice",
    description: "Голосовая разметка *-...-* в каждом ответе (1-2 фразы сути)",
    body: "## voice-reply-style skill\n\nКАЖДЫЙ ответ ОБЯЗАН содержать голосовую разметку:\n*-1-2 фразы сути.*-\n\nПравила:\n- Начало маркера: звёздочка-дефис *-\n- Конец маркера: дефис-звёздочка -*\n- НЕ заканчивай на *- (это ошибка, не озвучится)\n- Голосом помечай суть, остальное — только для чата\n",
  },
  {
    id: "fact-check",
    name: "fact-check",
    source: "local",
    category: "research",
    description: "Проверка факта: поиск + кросс-проверка источников + вердикт",
    body: "## fact-check skill\n\n1. Сформулируй утверждение чётко\n2. web_search — найди 3+ независимых источника\n3. Сравни: согласны ли они? есть ли опровержения?\n4. Вердикт: TRUE / FALSE / PARTIALLY_TRUE / UNVERIFIED\n5. Приведи цитаты и ссылки\n",
  },
  {
    id: "data-analysis",
    name: "data-analysis",
    source: "local",
    category: "data",
    description: "Анализ данных: csv/json → статистика → визуализация → выводы",
    body: "## data-analysis skill\n\n1. Определи формат данных (CSV/JSON/XLSX)\n2. Прочитай и покажи схему\n3. math_stats — основные метрики\n4. Найди аномалии/тренды\n5. Сгенерируй визуализацию (matplotlib/chart.js)\n6. Выводы с цифрами\n",
  },
];

// Sample from NVIDIA/skills catalog (build.nvidia.com/skills — 400+ in original)
const NVIDIA_SKILLS: Skill[] = [
  { id: "nv-code-review", name: "code-review", source: "nvidia", category: "dev", description: "Автоматический код-ревью с проверкой уязвимостей и best practices", body: "NVIDIA code-review skill: анализирует код на безопасность, производительность, читаемость." },
  { id: "nv-doc-gen", name: "doc-gen", source: "nvidia", category: "writing", description: "Генерация документации из кода (docstrings, README, API refs)", body: "NVIDIA doc-gen skill: извлекает сигнатуры и комментарии → MD/Sphinx." },
  { id: "nv-sql-optimizer", name: "sql-optimizer", source: "nvidia", category: "data", description: "Оптимизация SQL-запросов + план выполнения", body: "NVIDIA sql-optimizer skill: EXPLAIN → переписывает запрос с индексами." },
  { id: "nv-test-gen", name: "test-gen", source: "nvidia", category: "dev", description: "Генерация unit-тестов по сигнатурам функций", body: "NVIDIA test-gen skill: pytest/JUnit тест-кейсы с покрытием edge-cases." },
  { id: "nv-image-caption", name: "image-caption", source: "nvidia", category: "vision", description: "Описание изображения на естественном языке", body: "NVIDIA image-caption skill: VLM → описание сцены, объектов, эмоций." },
  { id: "nv-ocr-doc", name: "ocr-doc", source: "nvidia", category: "vision", description: "OCR документов с сохранением структуры", body: "NVIDIA ocr-doc skill: tesseract/WinRT → структурированный текст." },
  { id: "nv-translate-pro", name: "translate-pro", source: "nvidia", category: "text", description: "Профессиональный перевод с учётом контекста идиом", body: "NVIDIA translate-pro skill: 100+ языков, сохранение тона и стилистики." },
  { id: "nv-summarize-long", name: "summarize-long", source: "nvidia", category: "text", description: "Суммаризация длинных документов (50+ страниц)", body: "NVIDIA summarize-long skill: chunking + map-reduce суммаризация." },
  { id: "nv-sentiment-pro", name: "sentiment-pro", source: "nvidia", category: "text", description: "Тональность по аспектам (аспект-based sentiment)", body: "NVIDIA sentiment-pro skill: продукт/сервис/доставка — отдельно." },
  { id: "nv-data-clean", name: "data-clean", source: "nvidia", category: "data", description: "Очистка датасета: дубликаты, NaN, выбросы", body: "NVIDIA data-clean skill: pandas pipeline очистки." },
  { id: "nv-flowchart", name: "flowchart", source: "nvidia", category: "vision", description: "Генерация flowchart по описанию процесса", body: "NVIDIA flowchart skill: mermaid/graphviz по текстовому описанию." },
  { id: "nv-resume-parse", name: "resume-parse", source: "nvidia", category: "text", description: "Парсинг резюме в структурированный JSON", body: "NVIDIA resume-parse skill: опыт, навыки, образование → JSON." },
];

export async function GET(req: Request) {
  const url = new URL(req.url);
  const q = url.searchParams.get("q")?.toLowerCase().trim() || "";
  const source = url.searchParams.get("source") || "all";
  const all = [...LOCAL_SKILLS, ...NVIDIA_SKILLS];
  let result = all;
  if (source !== "all") result = result.filter((s) => s.source === source);
  if (q) {
    result = result.filter(
      (s) => s.name.toLowerCase().includes(q) || s.description.toLowerCase().includes(q) || s.category.toLowerCase().includes(q)
    );
  }
  const counts = {
    local: LOCAL_SKILLS.length,
    nvidia: NVIDIA_SKILLS.length,
    total: all.length,
    catalog_total: 400,
  };
  return NextResponse.json({ skills: result, counts });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { action, id } = body;
  if (action === "toggle_pin") {
    const skill = [...LOCAL_SKILLS, ...NVIDIA_SKILLS].find((s) => s.id === id);
    if (skill) {
      skill.pinned = !skill.pinned;
      return NextResponse.json({ ok: true, skill });
    }
  }
  if (action === "auto_match") {
    const { query } = body;
    if (!query) return NextResponse.json({ ok: false, error: "query required" }, { status: 400 });
    const q = String(query).toLowerCase();
    const matched = [...LOCAL_SKILLS, ...NVIDIA_SKILLS]
      .map((s) => ({
        ...s,
        score:
          (s.name.toLowerCase().includes(q) ? 3 : 0) +
          (s.description.toLowerCase().split(/\s+/).some((w) => q.includes(w)) ? 2 : 0) +
          (s.category.toLowerCase().includes(q) ? 1 : 0),
      }))
      .filter((s) => (s as Skill & { score: number }).score > 0)
      .sort((a, b) => (b as Skill & { score: number }).score - (a as Skill & { score: number }).score)
      .slice(0, 3);
    return NextResponse.json({ ok: true, matched, query });
  }
  return NextResponse.json({ ok: false, error: "unknown action" }, { status: 400 });
}
