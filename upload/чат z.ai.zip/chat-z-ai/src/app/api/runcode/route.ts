import { NextResponse } from "next/server";

interface RunBody {
  code: string;
  engine: string;
}

// Mock code execution — in the real FLUX 2.0 Python app this calls
// app/tools/codrun.py which spawns the right interpreter/compiler.
// Here we simulate plausible output per engine so the playground feels live.
const ENGINE_META: Record<string, { label: string; cmd: string; sample: string }> = {
  python: { label: "Python 3.11", cmd: "python -c", sample: '42\n[0, 1, 4, 9, 16, 25, 36, 49, 64, 81]\n' },
  node: { label: "Node.js 20", cmd: "node -e", sample: "42\n[ 0, 1, 4, 9, 16, 25, 36, 49, 64, 81 ]\n" },
  ts: { label: "TypeScript 5", cmd: "bun -e", sample: "42\n[ 0, 1, 4, 9, 16, 25, 36, 49, 64, 81 ]\n" },
  java: { label: "Java 21", cmd: "java -cp /tmp Main", sample: "42\n[0, 1, 4, 9, 16, 25, 36, 49, 64, 81]\n" },
  c: { label: "C (gcc 13)", cmd: "gcc -o /tmp/a.out && /tmp/a.out", sample: "42\n0 1 4 9 16 25 36 49 64 81 \n" },
  cpp: { label: "C++ (g++ 13)", cmd: "g++ -o /tmp/a.out && /tmp/a.out", sample: "42\n0 1 4 9 16 25 36 49 64 81 \n" },
  go: { label: "Go 1.22", cmd: "go run /tmp/main.go", sample: "42\n[0 1 4 9 16 25 36 49 64 81]\n" },
  rust: { label: "Rust 1.75", cmd: "cargo run", sample: "42\n[0, 1, 4, 9, 16, 25, 36, 49, 64, 81]\n" },
  ruby: { label: "Ruby 3.2", cmd: "ruby -e", sample: "42\n[0, 1, 4, 9, 16, 25, 36, 49, 64, 81]\n" },
  php: { label: "PHP 8.2", cmd: "php -r", sample: "42\nArray\n(\n    [0] => 0\n    [1] => 1\n)\n" },
  bash: { label: "Bash", cmd: "bash -c", sample: "42\n0 1 4 9 16 25 36 49 64 81\n" },
  powershell: { label: "PowerShell 7.4", cmd: "pwsh -c", sample: "42\n0 1 4 9 16 25 36 49 64 81\n" },
  sql: { label: "SQLite 3", cmd: "sqlite3 :memory:", sample: "42\n0|1|4|9|16|25|36|49|64|81\n" },
  lua: { label: "Lua 5.4", cmd: "lua -e", sample: "42\n0\t1\t4\t9\t16\t25\t36\t49\t64\t81\n" },
  perl: { label: "Perl 5.38", cmd: "perl -e", sample: "42\n0 1 4 9 16 25 36 49 64 81 \n" },
  kotlin: { label: "Kotlin 1.9", cmd: "kotlinc -script", sample: "42\n[0, 1, 4, 9, 16, 25, 36, 49, 64, 81]\n" },
};

const SAMPLE_SNIPPETS: Record<string, string> = {
  python: `# Python demo
import math
print(6 * 7)
print([i**2 for i in range(10)])
print(f"pi = {math.pi:.4f}")
`,
  node: `// Node demo
const squares = [...Array(10).keys()].map(i => i*i);
console.log(6 * 7);
console.log(squares);
console.log("pi =", Math.PI.toFixed(4));
`,
  ts: `// TypeScript demo
const squares: number[] = [...Array(10).keys()].map(i => i*i);
console.log(6 * 7);
console.log(squares);
console.log("pi =", Math.PI.toFixed(4));
`,
  rust: `// Rust demo
fn main() {
    let squares: Vec<i32> = (0..10).map(|i| i*i).collect();
    println!("{}", 6 * 7);
    println!("{:?}", squares);
    println!("pi = {:.4}", std::f64::consts::PI);
}
`,
  go: `// Go demo
package main
import "fmt"
func main() {
    fmt.Println(6 * 7)
    squares := []int{}
    for i := 0; i < 10; i++ { squares = append(squares, i*i) }
    fmt.Println(squares)
}
`,
};

function simulateRun(code: string, engine: string) {
  const meta = ENGINE_META[engine];
  if (!meta) {
    return { ok: false, rc: 1, stdout: "", stderr: `unknown engine: ${engine}`, time: 0 };
  }
  // Check for obvious syntax issues (very simplified)
  if (!code.trim()) {
    return { ok: false, rc: 1, stdout: "", stderr: "empty code", time: 0 };
  }
  // If code references print/console.log → produce sample output
  const hasPrint = /print|console\.log|println|echo|fmt\.Print|System\.out/i.test(code);
  let stdout = meta.sample;
  if (!hasPrint) {
    stdout = "(no output)\n";
  }
  // simulate execution time 0.05–1.5s
  const time = Math.round((50 + Math.random() * 1450) * 10) / 10;
  return { ok: true, rc: 0, stdout, stderr: "", time, engine: meta.label, cmd: meta.cmd };
}

export async function POST(req: Request) {
  const body = (await req.json()) as RunBody;
  const { code, engine } = body;
  if (!code || !engine) {
    return NextResponse.json({ ok: false, error: "code and engine required" }, { status: 400 });
  }
  // Simulate compilation/execution delay
  await new Promise((r) => setTimeout(r, 300 + Math.random() * 800));
  const result = simulateRun(code, engine);
  return NextResponse.json(result);
}

export async function GET() {
  return NextResponse.json({
    engines: Object.entries(ENGINE_META).map(([k, v]) => ({ id: k, label: v.label, cmd: v.cmd })),
    samples: SAMPLE_SNIPPETS,
  });
}
