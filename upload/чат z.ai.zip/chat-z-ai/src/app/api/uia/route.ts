import { NextResponse } from "next/server";

interface UiaControl {
  id: string;
  type: "button" | "text" | "edit" | "list" | "menu" | "tab" | "image" | "checkbox" | "slider" | "tree";
  name: string;
  value?: string;
  rect: { x: number; y: number; w: number; h: number };
  enabled: boolean;
  visible: boolean;
  aiLink: string;
  aiSummary: string;
  watching?: boolean;
}

interface UiaWindow {
  windowId: number;
  title: string;
  process: string;
  focused: boolean;
  bounds: { x: number; y: number; w: number; h: number };
  controls: UiaControl[];
}

const WINDOWS: UiaWindow[] = [
  {
    windowId: 101,
    title: "FLUX 2.0 — Космический ИИ-ассистент",
    process: "chrome.exe",
    focused: true,
    bounds: { x: 100, y: 80, w: 1280, h: 800 },
    controls: [
      {
        id: "ctrl-1",
        type: "edit",
        name: "Поле ввода сообщения",
        value: "Помоги найти титан в Subnautica",
        rect: { x: 110, y: 740, w: 800, h: 40 },
        enabled: true,
        visible: true,
        aiLink: "uia:101:msg-input",
        aiSummary: "Текстовое поле чата. Внутри: «Помоги найти титан в Subnautica».",
        watching: true,
      },
      {
        id: "ctrl-2",
        type: "button",
        name: "Отправить",
        rect: { x: 920, y: 740, w: 100, h: 40 },
        enabled: true,
        visible: true,
        aiLink: "uia:101:send-btn",
        aiSummary: "Кнопка отправки сообщения в чат.",
      },
      {
        id: "ctrl-3",
        type: "button",
        name: "Микрофон (браузерный)",
        rect: { x: 50, y: 740, w: 40, h: 40 },
        enabled: true,
        visible: true,
        aiLink: "uia:101:mic-btn",
        aiSummary: "Кнопка микрофона. Запись WebSpeech API.",
      },
      {
        id: "ctrl-4",
        type: "tab",
        name: "Главная (сфера)",
        rect: { x: 8, y: 80, w: 40, h: 40 },
        enabled: true,
        visible: true,
        aiLink: "uia:101:tab-home",
        aiSummary: "Вкладка навигации: главная страница (космическая сцена).",
        watching: true,
      },
      {
        id: "ctrl-5",
        type: "tab",
        name: "Браузер-мост",
        rect: { x: 8, y: 130, w: 40, h: 40 },
        enabled: true,
        visible: true,
        aiLink: "uia:101:tab-browser",
        aiSummary: "Вкладка навигации: мост к браузеру (вкладки как карточки).",
      },
    ],
  },
  {
    windowId: 102,
    title: "Subnautica 2",
    process: "Subnautica2.exe",
    focused: false,
    bounds: { x: 200, y: 120, w: 1600, h: 1000 },
    controls: [
      {
        id: "ctrl-10",
        type: "text",
        name: "Индикатор кислорода",
        value: "О₂: 45/60",
        rect: { x: 240, y: 160, w: 120, h: 24 },
        enabled: true,
        visible: true,
        aiLink: "uia:102:o2",
        aiSummary: "Текущий кислород игрока: 45 из 60 секунд.",
        watching: true,
      },
      {
        id: "ctrl-11",
        type: "text",
        name: "Глубина",
        value: "−42 м",
        rect: { x: 240, y: 190, w: 100, h: 24 },
        enabled: true,
        visible: true,
        aiLink: "uia:102:depth",
        aiSummary: "Текущая глубина игрока: −42 метра.",
        watching: true,
      },
      {
        id: "ctrl-12",
        type: "list",
        name: "Инвентарь",
        value: "Титан ×3, Медь ×5, Кварц ×2",
        rect: { x: 1620, y: 200, w: 180, h: 200 },
        enabled: true,
        visible: true,
        aiLink: "uia:102:inventory",
        aiSummary: "Инвентарь: титан ×3, медь ×5, кварц ×2. Полных слотов 8/24.",
        watching: true,
      },
      {
        id: "ctrl-13",
        type: "text",
        name: "Биом",
        value: "Grassy Plateaus",
        rect: { x: 800, y: 950, w: 200, h: 24 },
        enabled: true,
        visible: true,
        aiLink: "uia:102:biome",
        aiSummary: "Текущий биом: Grassy Plateaus (травянистые плато).",
      },
    ],
  },
  {
    windowId: 103,
    title: "Проводник — flux-ai-main",
    process: "explorer.exe",
    focused: false,
    bounds: { x: 1400, y: 100, w: 600, h: 700 },
    controls: [
      {
        id: "ctrl-20",
        type: "tree",
        name: "Дерево папок",
        value: "app/ + ui/ + skills_bundled/",
        rect: { x: 1420, y: 180, w: 560, h: 500 },
        enabled: true,
        visible: true,
        aiLink: "uia:103:file-tree",
        aiSummary: "Дерево файлов проекта flux-ai-main. Открыта папка app/.",
        watching: true,
      },
      {
        id: "ctrl-21",
        type: "edit",
        name: "Адресная строка",
        value: "D:\\Projects\\flux-ai-main",
        rect: { x: 1420, y: 140, w: 560, h: 30 },
        enabled: true,
        visible: true,
        aiLink: "uia:103:addr",
        aiSummary: "Адресная строка проводника: D:\\Projects\\flux-ai-main.",
      },
    ],
  },
];

export async function GET() {
  const totalControls = WINDOWS.reduce((s, w) => s + w.controls.length, 0);
  const watching = WINDOWS.reduce((s, w) => s + w.controls.filter((c) => c.watching).length, 0);
  return NextResponse.json({
    windows: WINDOWS,
    count: WINDOWS.length,
    controls: totalControls,
    watching,
  });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { action, windowId, controlId } = body;
  if (action === "toggle_watch") {
    for (const w of WINDOWS) {
      for (const c of w.controls) {
        if (c.id === controlId) {
          c.watching = !c.watching;
          return NextResponse.json({ ok: true, control: c });
        }
      }
    }
  }
  if (action === "click") {
    return NextResponse.json({ ok: true, windowId, controlId, message: "Клик выполнен" });
  }
  if (action === "focus_window") {
    WINDOWS.forEach((w) => (w.focused = w.windowId === windowId));
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ ok: false, error: "unknown action" }, { status: 400 });
}
