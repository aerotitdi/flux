import { NextResponse } from "next/server";

interface Tool {
  id: string;
  name: string;
  category: string;
  description: string;
  core?: boolean;
  args?: { name: string; desc: string; required?: boolean }[];
}

// Realistic subset of the FLUX 2.0 tool catalog (357 total in original Python app).
// Here we expose ~120 representative tools across all 14 categories so the
// Tools catalog view feels rich. The original counts per category:
// text 50, encode 39, math 33, browser 31, formats 28, agent 28, search 24,
// memory 21, convert 18, datetime 18, code 18, net 17, voice 10, files 22.

const TOOLS: Tool[] = [
  // browser (31 in original — we expose 18)
  { id: "browser_status", name: "browser_status", category: "browser", core: true, description: "Статус подключения к браузеру: мост расширения (живой Chrome) или CDP; версия и число вкладок" },
  { id: "browser_tabs_list", name: "browser_tabs_list", category: "browser", core: true, description: "Список всех ВКЛАДОК живого браузера (id, окно, заголовок, url, активна)" },
  { id: "browser_windows_list", name: "browser_windows_list", category: "browser", core: true, description: "Список ОКОН браузера с их вкладками и границами" },
  { id: "browser_tab_switch", name: "browser_tab_switch", category: "browser", core: true, description: "Переключить (активировать) вкладку по id", args: [{ name: "tab", desc: "id вкладки", required: true }] },
  { id: "browser_tab_open", name: "browser_tab_open", category: "browser", description: "Открыть новую вкладку с URL", args: [{ name: "url", desc: "URL", required: true }] },
  { id: "browser_tab_close", name: "browser_tab_close", category: "browser", description: "Закрыть вкладку по id", args: [{ name: "tab", desc: "id вкладки", required: true }] },
  { id: "browser_tab_navigate", name: "browser_tab_navigate", category: "browser", description: "Перейти по URL в указанной вкладке", args: [{ name: "tab", desc: "id", required: true }, { name: "url", desc: "URL", required: true }] },
  { id: "browser_tab_reload", name: "browser_tab_reload", category: "browser", description: "Перезагрузить вкладку" },
  { id: "browser_tab_screenshot", name: "browser_tab_screenshot", category: "browser", core: true, description: "Скриншот вкладки (PNG, приходит в чат)" },
  { id: "browser_tab_text", name: "browser_tab_text", category: "browser", core: true, description: "Прочитать видимый текст вкладки" },
  { id: "browser_tab_click", name: "browser_tab_click", category: "browser", description: "Кликнуть по селектору в вкладке" },
  { id: "browser_tab_type", name: "browser_tab_type", category: "browser", description: "Ввести текст в поле вкладки" },
  { id: "browser_tab_scroll", name: "browser_tab_scroll", category: "browser", description: "Скроллить вкладку" },
  { id: "browser_tab_eval", name: "browser_tab_eval", category: "browser", description: "Выполнить JS в контексте вкладки" },
  { id: "browser_tab_cookies", name: "browser_tab_cookies", category: "browser", description: "Прочитать cookies вкладки" },
  { id: "browser_tab_pdf", name: "browser_tab_pdf", category: "browser", description: "Сохранить вкладку как PDF" },
  { id: "browser_launch", name: "browser_launch", category: "browser", description: "Запустить браузер с CDP-портом (user/flux/isolated профиль)" },
  { id: "browser_restart_user", name: "browser_restart_user", category: "browser", description: "Форс-рестарт твоего Chrome с вкладками (только если сам попросил)" },

  // apps / OS (computer family — 30 tools)
  { id: "app_launch", name: "app_launch", category: "agent", core: true, description: "Запустить приложение по имени или exe", args: [{ name: "name", desc: "Имя или exe", required: true }] },
  { id: "app_kill", name: "app_kill", category: "agent", description: "Завершить приложение по PID или имени" },
  { id: "os_window_list", name: "os_window_list", category: "agent", description: "Список окон ОС (заголовок, процесс, HWND)" },
  { id: "os_window_focus", name: "os_window_focus", category: "agent", description: "Фокус на окно ОС" },
  { id: "os_window_minimize", name: "os_window_minimize", category: "agent", description: "Свернуть окно ОС" },
  { id: "os_window_maximize", name: "os_window_maximize", category: "agent", description: "Развернуть окно ОС" },
  { id: "os_window_close", name: "os_window_close", category: "agent", description: "Закрыть окно ОС" },
  { id: "os_minimize_all", name: "os_minimize_all", category: "agent", description: "Свернуть все окна (Win+D)" },
  { id: "mouse_click", name: "mouse_click", category: "agent", description: "Клик мыши по координатам" },
  { id: "mouse_move", name: "mouse_move", category: "agent", description: "Переместить курсор" },
  { id: "mouse_drag", name: "mouse_drag", category: "agent", description: "Перетаскивание мыши" },
  { id: "mouse_scroll", name: "mouse_scroll", category: "agent", description: "Скролл колесом мыши" },
  { id: "keyboard_type", name: "keyboard_type", category: "agent", description: "Ввести текст (SendInput)" },
  { id: "keyboard_press", name: "keyboard_press", category: "agent", description: "Нажать клавишу" },
  { id: "keyboard_hotkey", name: "keyboard_hotkey", category: "agent", description: "Горячая клавиша (Ctrl+C и т.п.)" },
  { id: "screen_screenshot", name: "screen_screenshot", category: "agent", description: "Скриншот экрана" },
  { id: "ocr_screen", name: "ocr_screen", category: "agent", description: "OCR экрана (WinRT или tesseract)" },
  { id: "uia_tree", name: "uia_tree", category: "agent", description: "Дерево UI Automation контролов окна" },
  { id: "uia_click", name: "uia_click", category: "agent", description: "Кликнуть UIA контрол" },
  { id: "uia_read", name: "uia_read", category: "agent", description: "Прочитать текст UIA контрола" },
  { id: "proc_list", name: "proc_list", category: "agent", description: "Список процессов ОС" },
  { id: "proc_kill", name: "proc_kill", category: "agent", description: "Убить процесс по PID" },
  { id: "shell_run", name: "shell_run", category: "agent", description: "Выполнить shell-команду ОС" },
  { id: "clipboard_get_set", name: "clipboard_get_set", category: "agent", description: "Чтение/запись буфера обмена" },

  // UIA / game memory (FLUX-specific)
  { id: "game_memory_read", name: "game_memory_read", category: "agent", core: true, description: "Прочитать память ОФЛАЙН-игры (только если пользователь дал доступ; анти-чит = отказ)", args: [{ name: "game", desc: "slug игры", required: true }] },
  { id: "game_whitelist_add", name: "game_whitelist_add", category: "agent", description: "Добавить одиночную офлайн-игру в whitelist (требует подтверждения)" },

  // memory (21 tools — 12 exposed)
  { id: "mem_remember", name: "mem_remember", category: "memory", core: true, description: "Сохранить факт о пользователе", args: [{ name: "key", desc: "Ключ", required: true }, { name: "value", desc: "Значение", required: true }] },
  { id: "mem_recall", name: "mem_recall", category: "memory", core: true, description: "Вспомнить факт о пользователе", args: [{ name: "key", desc: "Ключ", required: true }] },
  { id: "mem_forget", name: "mem_forget", category: "memory", description: "Забыть факт" },
  { id: "mem_list", name: "mem_list", category: "memory", description: "Список всех фактов" },
  { id: "mem_note_add", name: "mem_note_add", category: "memory", description: "Добавить заметку" },
  { id: "mem_note_list", name: "mem_note_list", category: "memory", description: "Список заметок" },
  { id: "mem_todo_add", name: "mem_todo_add", category: "memory", description: "Добавить задачу в todo" },
  { id: "mem_todo_complete", name: "mem_todo_complete", category: "memory", description: "Отметить задачу выполненной" },
  { id: "mem_todo_list", name: "mem_todo_list", category: "memory", description: "Список задач" },
  { id: "mem_kv_set", name: "mem_kv_set", category: "memory", description: "Записать KV-пару" },
  { id: "mem_kv_get", name: "mem_kv_get", category: "memory", description: "Прочитать KV-пару" },
  { id: "mem_timer_set", name: "mem_timer_set", category: "memory", description: "Поставить таймер (срабатывает в чате)" },

  // search (24 — 10 exposed)
  { id: "web_search", name: "web_search", category: "search", core: true, description: "Веб-поиск через выбранный движок (DuckDuckGo/SearXNG/Bing/Google/Wikipedia/Brave)" },
  { id: "wiki_summary", name: "wiki_summary", category: "search", core: true, description: "Краткая сводка из Wikipedia" },
  { id: "wiki_full", name: "wiki_full", category: "search", description: "Полная статья Wikipedia" },
  { id: "weather_now", name: "weather_now", category: "search", core: true, description: "Текущая погода по координатам/городу" },
  { id: "news_today", name: "news_today", category: "search", description: "Топ новости за сегодня" },
  { id: "currency_rate", name: "currency_rate", category: "search", description: "Курс валюты к рублю/доллару" },
  { id: "translate_text", name: "translate_text", category: "search", core: true, description: "Перевод текста" },
  { id: "stock_price", name: "stock_price", category: "search", description: "Цена акции/крипты" },
  { id: "yt_search", name: "yt_search", category: "search", description: "Поиск видео на YouTube" },
  { id: "github_search", name: "github_search", category: "search", description: "Поиск репозиториев на GitHub" },

  // code (18 — 8 exposed)
  { id: "code_test", name: "code_test", category: "code", core: true, description: "Прогнать код на выбранном движке (python/node/java/c/cpp/go/rust/rb/php/bash/pwsh/sql/lua/perl/kt/ts)", args: [{ name: "code", desc: "Код", required: true }, { name: "engine", desc: "Движок", required: true }] },
  { id: "code_format", name: "code_format", category: "code", description: "Форматировать код (prettier/black)" },
  { id: "code_lint", name: "code_lint", category: "code", description: "Линт кода (eslint/ruff)" },
  { id: "code_explain", name: "code_explain", category: "code", description: "Объяснить код построчно" },
  { id: "code_refactor", name: "code_refactor", category: "code", description: "Рефакторинг кода" },
  { id: "regex_test", name: "regex_test", category: "code", description: "Протестировать regex" },
  { id: "json_validate", name: "json_validate", category: "code", description: "Валидация JSON" },
  { id: "json_path", name: "json_path", category: "code", description: "JSONPath-запрос" },

  // text (50 — 14 exposed)
  { id: "text_summarize", name: "text_summarize", category: "text", description: "Краткое содержание текста" },
  { id: "text_sentiment", name: "text_sentiment", category: "text", description: "Анализ тональности" },
  { id: "text_extract_entities", name: "text_extract_entities", category: "text", description: "Извлечение сущностей (NER)" },
  { id: "text_extract_keywords", name: "text_extract_keywords", category: "text", description: "Ключевые слова" },
  { id: "text_language_detect", name: "text_language_detect", category: "text", description: "Определение языка" },
  { id: "text_word_count", name: "text_word_count", category: "text", description: "Подсчёт слов/символов" },
  { id: "text_reading_time", name: "text_reading_time", category: "text", description: "Время чтения" },
  { id: "text_diff", name: "text_diff", category: "text", description: "Сравнение двух текстов" },
  { id: "text_slugify", name: "text_slugify", category: "text", description: "Slugify текста" },
  { id: "text_camel", name: "text_camel", category: "text", description: "camelCase / snake_case / kebab" },
  { id: "text_lorem", name: "text_lorem", category: "text", description: "Генератор lorem ipsum" },
  { id: "text_reverse", name: "text_reverse", category: "text", description: "Развернуть текст" },
  { id: "text_case", name: "text_case", category: "text", description: "Верхний/нижний регистр" },
  { id: "text_redact", name: "text_redact", category: "text", description: "Закрасить PII (email/телефон)" },

  // math (33 — 10 exposed)
  { id: "math_eval", name: "math_eval", category: "math", description: "Безопасное вычисление выражения" },
  { id: "math_solve", name: "math_solve", category: "math", description: "Решить уравнение (символьно)" },
  { id: "math_stats", name: "math_stats", category: "math", description: "Статистика массива (mean/median/std)" },
  { id: "math_linear_regression", name: "math_linear_regression", category: "math", description: "Линейная регрессия" },
  { id: "math_matrix_mul", name: "math_matrix_mul", category: "math", description: "Умножение матриц" },
  { id: "math_matrix_inv", name: "math_matrix_inv", category: "math", description: "Обратная матрица" },
  { id: "math_derivative", name: "math_derivative", category: "math", description: "Производная" },
  { id: "math_integral", name: "math_integral", category: "math", description: "Определённый интеграл" },
  { id: "math_factor", name: "math_factor", category: "math", description: "Разложение на множители" },
  { id: "math_prime", name: "math_prime", category: "math", description: "Проверка простоты" },

  // encode (39 — 10 exposed)
  { id: "encode_b64", name: "encode_b64", category: "encode", description: "Base64 кодирование/декодирование" },
  { id: "encode_url", name: "encode_url", category: "encode", description: "URL encode/decode" },
  { id: "encode_hex", name: "encode_hex", category: "encode", description: "Hex кодирование" },
  { id: "encode_html", name: "encode_html", category: "encode", description: "HTML entities" },
  { id: "encode_jwt", name: "encode_jwt", category: "encode", description: "Декодирование JWT" },
  { id: "encode_hash_md5", name: "encode_hash_md5", category: "encode", description: "MD5 хеш" },
  { id: "encode_hash_sha256", name: "encode_hash_sha256", category: "encode", description: "SHA-256 хеш" },
  { id: "encode_hash_sha512", name: "encode_hash_sha512", category: "encode", description: "SHA-512 хеш" },
  { id: "encode_qr", name: "encode_qr", category: "encode", description: "QR-код (PNG)" },
  { id: "encode_uuid", name: "encode_uuid", category: "encode", description: "Генерация UUID v4" },

  // formats (28 — 8 exposed)
  { id: "fmt_csv_to_json", name: "fmt_csv_to_json", category: "formats", description: "CSV → JSON" },
  { id: "fmt_json_to_csv", name: "fmt_json_to_csv", category: "formats", description: "JSON → CSV" },
  { id: "fmt_yaml_to_json", name: "fmt_yaml_to_json", category: "formats", description: "YAML → JSON" },
  { id: "fmt_toml_to_json", name: "fmt_toml_to_json", category: "formats", description: "TOML → JSON" },
  { id: "fmt_xml_to_json", name: "fmt_xml_to_json", category: "formats", description: "XML → JSON" },
  { id: "fmt_markdown_html", name: "fmt_markdown_html", category: "formats", description: "Markdown ↔ HTML" },
  { id: "fmt_pdf_extract_text", name: "fmt_pdf_extract_text", category: "formats", description: "Извлечь текст из PDF" },
  { id: "fmt_xlsx_to_json", name: "fmt_xlsx_to_json", category: "formats", description: "XLSX → JSON" },

  // convert (18 — 6 exposed)
  { id: "conv_units", name: "conv_units", category: "convert", description: "Конвертация единиц (длина/масса/объём)" },
  { id: "conv_currency", name: "conv_currency", category: "convert", description: "Конвертация валют" },
  { id: "conv_timezone", name: "conv_timezone", category: "convert", description: "Часовые пояса" },
  { id: "conv_temp", name: "conv_temp", category: "convert", description: "°C ↔ °F ↔ K" },
  { id: "conv_color", name: "conv_color", category: "convert", description: "HEX ↔ RGB ↔ HSL" },
  { id: "conv_image_resize", name: "conv_image_resize", category: "convert", description: "Ресайз изображения" },

  // datetime (18 — 6 exposed)
  { id: "dt_now", name: "dt_now", category: "datetime", description: "Текущее время в таймзоне" },
  { id: "dt_parse", name: "dt_parse", category: "datetime", description: "Парсинг даты из строки" },
  { id: "dt_format", name: "dt_format", category: "datetime", description: "Форматирование даты" },
  { id: "dt_diff", name: "dt_diff", category: "datetime", description: "Разница между датами" },
  { id: "dt_add", name: "dt_add", category: "datetime", description: "Прибавить интервал к дате" },
  { id: "dt_weekday", name: "dt_weekday", category: "datetime", description: "День недели даты" },

  // net (17 — 6 exposed)
  { id: "net_ip_info", name: "net_ip_info", category: "net", description: "Геолокация по IP" },
  { id: "net_dns_lookup", name: "net_dns_lookup", category: "net", description: "DNS-запрос" },
  { id: "net_http_get", name: "net_http_get", category: "net", description: "HTTP GET" },
  { id: "net_http_post", name: "net_http_post", category: "net", description: "HTTP POST" },
  { id: "net_ping", name: "net_ping", category: "net", description: "Ping хоста" },
  { id: "net_headers", name: "net_headers", category: "net", description: "HTTP-заголовки URL" },

  // voice (10 — 4 exposed)
  { id: "voice_speak", name: "voice_speak", category: "voice", core: true, description: "Озвучить текст голосом Flux (wingetgui/edge/browser)" },
  { id: "voice_list", name: "voice_list", category: "voice", description: "Список доступных голосов" },
  { id: "voice_stt", name: "voice_stt", category: "voice", description: "Распознать речь из аудиофайла" },
  { id: "voice_tts_file", name: "voice_tts_file", category: "voice", description: "Сохранить TTS в mp3 файл" },

  // files (22 — 8 exposed)
  { id: "file_read", name: "file_read", category: "files", description: "Прочитать файл" },
  { id: "file_write", name: "file_write", category: "files", description: "Записать файл" },
  { id: "file_list", name: "file_list", category: "files", description: "Список файлов в каталоге" },
  { id: "file_search", name: "file_search", category: "files", description: "Поиск файлов по имени" },
  { id: "file_grep", name: "file_grep", category: "files", description: "Поиск содержимого в файлах" },
  { id: "file_mkdir", name: "file_mkdir", category: "files", description: "Создать каталог" },
  { id: "file_copy", name: "file_copy", category: "files", description: "Копировать файл" },
  { id: "file_zip", name: "file_zip", category: "files", description: "Архивировать/разархивировать" },
];

const CATEGORY_META: Record<string, { label: string; icon: string; accent: string }> = {
  browser: { label: "Браузер", icon: "🌐", accent: "#5aa7ff" },
  agent: { label: "Компьютер + UIA + Память игр", icon: "🤖", accent: "#a06bff" },
  memory: { label: "Память/Заметки/TODO", icon: "🧠", accent: "#3ecf8e" },
  search: { label: "Поиск", icon: "🔍", accent: "#ffb454" },
  code: { label: "Код", icon: "📘", accent: "#007acc" },
  text: { label: "Текст", icon: "📝", accent: "#e8c468" },
  math: { label: "Математика", icon: "🔢", accent: "#76b7ff" },
  encode: { label: "Кодирование", icon: "🔐", accent: "#ff7f50" },
  formats: { label: "Форматы", icon: "📊", accent: "#9fe3e0" },
  convert: { label: "Конвертация", icon: "🔄", accent: "#ff78b4" },
  datetime: { label: "Дата/Время", icon: "📅", accent: "#7d8590" },
  net: { label: "Сеть", icon: "📡", accent: "#5865f2" },
  voice: { label: "Голос", icon: "🔊", accent: "#3ecf8e" },
  files: { label: "Файлы", icon: "📁", accent: "#cca54b" },
};

export async function GET(req: Request) {
  const url = new URL(req.url);
  const q = url.searchParams.get("q")?.toLowerCase().trim() || "";
  const cat = url.searchParams.get("cat") || "all";
  let result = TOOLS;
  if (cat !== "all") result = result.filter((t) => t.category === cat);
  if (q) {
    result = result.filter(
      (t) =>
        t.name.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q)
    );
  }
  // counts per category
  const counts: Record<string, number> = {};
  for (const t of TOOLS) counts[t.category] = (counts[t.category] || 0) + 1;
  return NextResponse.json({
    tools: result,
    total: TOOLS.length,
    original_total: 357,
    counts,
    categories: CATEGORY_META,
  });
}
