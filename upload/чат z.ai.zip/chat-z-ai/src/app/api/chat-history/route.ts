import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// Chat history persistence (Phase 9).
// The ChatMessage Prisma model was added in Phase 8 schema.
// This route handles load/save/clear of chat history to SQLite.

export async function GET() {
  try {
    const rows = await db.chatMessage.findMany({
      orderBy: { ts: "asc" },
      take: 100, // last 100 messages
    });
    return NextResponse.json({
      messages: rows.map((r) => ({
        id: r.id,
        role: r.role as "user" | "assistant" | "system" | "tool",
        text: r.text,
        ts: r.ts.getTime(),
        toolCalls: r.toolCalls ? safeParse(r.toolCalls) : undefined,
        thinkMode: r.thinkMode as "off" | "brief" | "medium" | "deep" | undefined,
        searchUsed: r.searchUsed,
        skillUsed: r.skillUsed || undefined,
      })),
      count: rows.length,
    });
  } catch (e: unknown) {
    const err = e as Error;
    return NextResponse.json(
      { ok: false, error: `Chat history DB error: ${err.message}` },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { action } = body;
  try {
    if (action === "save") {
      // save a single message
      const msg = body.message;
      if (!msg || !msg.id || !msg.role || !msg.text) {
        return NextResponse.json({ ok: false, error: "message required" }, { status: 400 });
      }
      await db.chatMessage.create({
        data: {
          id: String(msg.id),
          role: String(msg.role),
          text: String(msg.text),
          ts: new Date(Number(msg.ts) || Date.now()),
          toolCalls: msg.toolCalls ? JSON.stringify(msg.toolCalls) : "",
          thinkMode: msg.thinkMode || null,
          searchUsed: !!msg.searchUsed,
          skillUsed: msg.skillUsed || null,
        },
      });
      return NextResponse.json({ ok: true });
    }
    if (action === "clear") {
      await db.chatMessage.deleteMany({});
      return NextResponse.json({ ok: true, deleted: true });
    }
    return NextResponse.json({ ok: false, error: "unknown action" }, { status: 400 });
  } catch (e: unknown) {
    const err = e as Error;
    return NextResponse.json(
      { ok: false, error: `Chat history DB error: ${err.message}` },
      { status: 500 }
    );
  }
}

function safeParse(s: string): unknown[] | undefined {
  try {
    const v = JSON.parse(s);
    return Array.isArray(v) ? v : undefined;
  } catch {
    return undefined;
  }
}
