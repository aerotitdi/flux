import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// SQLite-backed brain persistence (Phase 8).
// Replaces the in-memory arrays from Phase 3 — now survives server reloads.

interface Note { id: string; text: string; ts: number; tags?: string[] }
interface Todo { id: string; text: string; done: boolean; ts: number; priority: "low" | "medium" | "high" }
interface Fact { key: string; value: string; ts: number }
interface KV { key: string; value: string; ts: number }
interface Timer { id: string; label: string; fireAt: number; fired: boolean }

// seed defaults only on first run (when DB is empty)
async function seedIfEmpty() {
  const noteCount = await db.note.count();
  if (noteCount > 0) return;
  await db.note.createMany({
    data: [
      { id: "n1", text: "Запустить Subnautica 2 перед чтением памяти", tags: '["game","flux"]' },
      { id: "n2", text: "CDP-порт 9222 должен быть активен для моста браузера", tags: '["browser","cdp"]' },
      { id: "n3", text: "Whitelist: только одиночные офлайн-игры, никакой мультиплеер", tags: '["memory","ethics"]' },
    ],
  });
  await db.todo.createMany({
    data: [
      { id: "t1", text: "Добавить ещё 3 космические сцены", done: true, priority: "medium" },
      { id: "t2", text: "Интегрировать z.ai shared chat", done: true, priority: "high" },
      { id: "t3", text: "Реальный чтение памяти через pymem", done: false, priority: "high" },
      { id: "t4", text: "WebSocket mini-service для live UIA", done: false, priority: "medium" },
      { id: "t5", text: "TTS озвучка голосовых меток", done: false, priority: "low" },
    ],
  });
  await db.fact.createMany({
    data: [
      { key: "user_name", value: "пользователь" },
      { key: "user_tz", value: "Asia/Yekaterinburg" },
      { key: "user_browser", value: "Google Chrome 131" },
      { key: "user_os", value: "Windows 11" },
      { key: "favorite_scene", value: "uranus" },
    ],
  });
  await db.kV.createMany({
    data: [
      { key: "flux_version", value: "2.7.0" },
      { key: "cdp_port", value: "9222" },
      { key: "tools_count", value: "357" },
    ],
  });
  await db.timer.createMany({
    data: [
      { id: "tm1", label: "Перерыв 25 мин (Pomodoro)", fireAt: new Date(Date.now() + 1500_000), fired: false },
      { id: "tm2", label: "Проверить вкладки браузера", fireAt: new Date(Date.now() + 600_000), fired: false },
    ],
  });
}

function parseTags(s: string | null): string[] {
  if (!s) return [];
  try { return JSON.parse(s) as string[]; } catch { return []; }
}

export async function GET() {
  try {
    await seedIfEmpty();
    const [notes, todos, facts, kvs, timers] = await Promise.all([
      db.note.findMany({ orderBy: { createdAt: "desc" } }),
      db.todo.findMany({ orderBy: { createdAt: "desc" } }),
      db.fact.findMany({ orderBy: { createdAt: "desc" } }),
      db.kV.findMany({ orderBy: { createdAt: "desc" } }),
      db.timer.findMany({ orderBy: { fireAt: "asc" } }),
    ]);
    return NextResponse.json({
      notes: notes.map((n) => ({ id: n.id, text: n.text, ts: n.createdAt.getTime(), tags: parseTags(n.tags) })),
      todos: todos.map((t) => ({ id: t.id, text: t.text, done: t.done, ts: t.createdAt.getTime(), priority: t.priority as Todo["priority"] })),
      facts: facts.map((f) => ({ key: f.key, value: f.value, ts: f.createdAt.getTime() })),
      kvs: kvs.map((k) => ({ key: k.key, value: k.value, ts: k.createdAt.getTime() })),
      timers: timers.map((t) => ({ id: t.id, label: t.label, fireAt: t.fireAt.getTime(), fired: t.fired })),
      stats: {
        notes: notes.length,
        todos_open: todos.filter((t) => !t.done).length,
        todos_done: todos.filter((t) => t.done).length,
        facts: facts.length,
        kvs: kvs.length,
        timers_active: timers.filter((t) => !t.fired).length,
      },
    });
  } catch (e: unknown) {
    const err = e as Error;
    return NextResponse.json(
      { ok: false, error: `Brain DB error: ${err.message}` },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { action, collection, payload } = body;
  try {
    if (action === "add") {
      if (collection === "notes") {
        await db.note.create({
          data: {
            id: "n" + Date.now().toString(36),
            text: String(payload.text || ""),
            tags: JSON.stringify(payload.tags || []),
          },
        });
      } else if (collection === "todos") {
        await db.todo.create({
          data: {
            id: "t" + Date.now().toString(36),
            text: String(payload.text || ""),
            done: false,
            priority: String(payload.priority || "medium"),
          },
        });
      } else if (collection === "facts") {
        await db.fact.upsert({
          where: { key: String(payload.key) },
          create: { key: String(payload.key), value: String(payload.value) },
          update: { value: String(payload.value) },
        });
      } else if (collection === "kvs") {
        await db.kV.upsert({
          where: { key: String(payload.key) },
          create: { key: String(payload.key), value: String(payload.value) },
          update: { value: String(payload.value) },
        });
      } else if (collection === "timers") {
        await db.timer.create({
          data: {
            id: "tm" + Date.now().toString(36),
            label: String(payload.label || ""),
            fireAt: new Date(Date.now() + (Number(payload.seconds) || 60) * 1000),
            fired: false,
          },
        });
      }
      return NextResponse.json({ ok: true });
    }
    if (action === "complete_todo") {
      const t = await db.todo.findUnique({ where: { id: String(body.id) } });
      if (t) {
        await db.todo.update({ where: { id: t.id }, data: { done: !t.done } });
      }
      return NextResponse.json({ ok: true, todo: t });
    }
    if (action === "delete") {
      const id = String(body.id);
      if (collection === "notes") await db.note.delete({ where: { id } }).catch(() => {});
      else if (collection === "todos") await db.todo.delete({ where: { id } }).catch(() => {});
      else if (collection === "facts") await db.fact.delete({ where: { key: id } }).catch(() => {});
      else if (collection === "kvs") await db.kV.delete({ where: { key: id } }).catch(() => {});
      else if (collection === "timers") await db.timer.delete({ where: { id } }).catch(() => {});
      return NextResponse.json({ ok: true });
    }
    return NextResponse.json({ ok: false, error: "unknown action" }, { status: 400 });
  } catch (e: unknown) {
    const err = e as Error;
    return NextResponse.json(
      { ok: false, error: `Brain DB error: ${err.message}` },
      { status: 500 }
    );
  }
}
