import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// AI provider connections — now backed by Prisma SQLite (Phase 12).
// Replaces the in-memory arrays from Phase 2.

interface Connection {
  id: string;
  name: string;
  type: "external";
  base_url: string;
  auth: "Bearer" | "X-API-Key" | "Basic" | "";
  api_key?: string;
  api_type: "chat_completions";
  provider: string;
  model_ids: string[];
  tags: string[];
  enabled: boolean;
}

function parseArr(s: string | null): string[] {
  if (!s) return [];
  try { const v = JSON.parse(s); return Array.isArray(v) ? v : []; } catch { return []; }
}

async function seedIfEmpty() {
  const count = await db.connection.count();
  if (count > 0) return;
  const defaults = [
    { id: "conn-orca", name: "orcarouter", baseUrl: "https://api.orcarouter.ai/v1", auth: "Bearer", apiKey: "sk-orca-•••••••••••••••", provider: "orcarouter", modelIds: ["flux-pro-1.1","flux-pro-1.0","flux-dev","flux-mini"], tags: ["orcarouter","fast"], enabled: true },
    { id: "conn-openai", name: "openai", baseUrl: "https://api.openai.com/v1", auth: "Bearer", apiKey: "sk-proj-•••••••••••••••", provider: "openai", modelIds: ["gpt-4o","gpt-4o-mini","o1-preview"], tags: ["openai"], enabled: false },
    { id: "conn-ollama", name: "Ollama", baseUrl: "http://127.0.0.1:11434/v1", auth: "", apiKey: "", provider: "ollama", modelIds: ["llama3.1:8b","qwen2.5:7b","mistral-nemo"], tags: ["ollama","local"], enabled: true },
    { id: "conn-openrouter", name: "openrouter", baseUrl: "https://openrouter.ai/api/v1", auth: "Bearer", apiKey: "sk-or-•••••••••••••••", provider: "openrouter", modelIds: ["anthropic/claude-3.5-sonnet","google/gemini-pro-1.5","meta/llama-3.1-70b"], tags: ["openrouter","aggregator"], enabled: false },
  ];
  for (const d of defaults) {
    await db.connection.create({
      data: {
        id: d.id, name: d.name, baseUrl: d.baseUrl, auth: d.auth,
        apiKey: d.apiKey, provider: d.provider,
        modelIds: JSON.stringify(d.modelIds), tags: JSON.stringify(d.tags),
        enabled: d.enabled,
      },
    });
  }
}

function mapRow(r: { id: string; name: string; baseUrl: string; auth: string; apiKey: string; provider: string; modelIds: string; tags: string; enabled: boolean }): Connection {
  return {
    id: r.id, name: r.name, type: "external" as const,
    base_url: r.baseUrl,
    auth: (r.auth || "Bearer") as Connection["auth"],
    api_key: r.apiKey || undefined,
    api_type: "chat_completions" as const,
    provider: r.provider,
    model_ids: parseArr(r.modelIds),
    tags: parseArr(r.tags),
    enabled: r.enabled,
  };
}

export async function GET() {
  try {
    await seedIfEmpty();
    const rows = await db.connection.findMany({ orderBy: { createdAt: "asc" } });
    return NextResponse.json({ connections: rows.map(mapRow) });
  } catch (e: unknown) {
    const err = e as Error;
    return NextResponse.json({ ok: false, error: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { action, id, payload } = body;
  try {
    if (action === "save") {
      const data = {
        name: String(payload?.name || "Новое"),
        baseUrl: String(payload?.base_url || ""),
        auth: String(payload?.auth || "Bearer"),
        apiKey: String(payload?.api_key || ""),
        provider: String(payload?.provider || "default"),
        modelIds: JSON.stringify(payload?.model_ids || []),
        tags: JSON.stringify(payload?.tags || []),
        enabled: payload?.enabled ?? true,
      };
      if (id) {
        await db.connection.update({ where: { id: String(id) }, data }).catch(async () => {
          await db.connection.create({ data: { id: String(id), ...data } });
        });
        return NextResponse.json({ ok: true });
      }
      const newId = "conn-" + Date.now().toString(36);
      await db.connection.create({ data: { id: newId, ...data } });
      const row = await db.connection.findUnique({ where: { id: newId } });
      return NextResponse.json({ ok: true, connection: row ? mapRow(row) : null });
    }
    if (action === "delete") {
      await db.connection.delete({ where: { id: String(id) } }).catch(() => {});
      return NextResponse.json({ ok: true });
    }
    if (action === "toggle") {
      const c = await db.connection.findUnique({ where: { id: String(id) } });
      if (c) await db.connection.update({ where: { id: c.id }, data: { enabled: !c.enabled } });
      return NextResponse.json({ ok: true });
    }
    return NextResponse.json({ ok: false, error: "unknown action" }, { status: 400 });
  } catch (e: unknown) {
    const err = e as Error;
    return NextResponse.json({ ok: false, error: err.message }, { status: 500 });
  }
}
