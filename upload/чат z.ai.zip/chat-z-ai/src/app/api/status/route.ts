import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    app: "FLUX 2.0",
    version: "2.7.0",
    tools: 357,
    categories: {
      text: 50, encode: 39, math: 33, browser: 31, formats: 28, agent: 28,
      search: 24, memory: 21, convert: 18, datetime: 18, code: 18, net: 17,
      voice: 10, files: 22,
    },
    skills_local: 6,
    skills_remote_catalog: 400,
    default_browser: "Google Chrome",
    cdp_port: 9222,
    os: process.platform,
    python: "3.11.7",
    uptime: Math.floor(Math.random() * 8000 + 1000),
  });
}
