import { NextResponse } from "next/server";

/**
 * Game Memory Bridge — OFFLINE single-player ONLY.
 *
 * ETHICS / SAFETY GUARDRAILS (mandatory):
 *   1. memoryAllowed defaults to false — user MUST explicitly opt-in per game.
 *   2. antiCheat.detected=true ALWAYS blocks memory reading, no exceptions.
 *      Detected anti-cheats: VAC, EAC (EasyAntiCheat), BattlEye, Riot Vanguard,
 *      PunkBuster, Faceit AC, etc.
 *   3. networkActivity=true ALWAYS blocks (means online/multiplayer).
 *   4. Only games with offline=true AND in the whitelist can be opted in.
 *   5. The route refuses to attach memory to any game not in the whitelist.
 *
 * Use case (per user request): single-player game help, e.g. Subnautica 2 —
 * read player position + nearest titanium deposit to suggest where to build a base.
 * Comparable to Verity (Minecraft single-player map viewer) — acceptable for
 * offline single-player games.
 */

interface GameNearest {
  name: string;
  distance: number;
  direction: string;
  depth: number;
  coords: { x: number; y: number; z: number };
}

interface GameMemory {
  id: string;
  name: string;
  slug: string;
  exe: string;
  offline: boolean;
  whitelisted: boolean;
  running: boolean;
  memoryAllowed: boolean;
  antiCheat: {
    detected: boolean;
    name?: string;
    processes: string[];
  };
  networkActivity: boolean;
  processId?: number;
  player?: { x: number; y: number; z: number; depth: number };
  biome?: string;
  oxygen?: number;
  inventory?: { item: string; count: number }[];
  nearest?: GameNearest[];
  warningLevel: "safe" | "blocked" | "unknown";
}

// Known single-player games that are safe to assist (no multiplayer, no anti-cheat).
const WHITELIST = [
  { id: "subnautica-2", name: "Subnautica 2", exe: "Subnautica2.exe", slug: "subnautica-2" },
  { id: "subnautica-bz", name: "Subnautica: Below Zero", exe: "SubnauticaBelowZero.exe", slug: "subnautica-bz" },
  { id: "stardew", name: "Stardew Valley", exe: "StardewValley.exe", slug: "stardew" },
  { id: "skyrim-se", name: "Skyrim Special Edition", exe: "TESV.exe", slug: "skyrim-se" },
  { id: "witcher-3", name: "The Witcher 3", exe: "witcher3.exe", slug: "witcher-3" },
  { id: "cyberpunk", name: "Cyberpunk 2077", exe: "Cyberpunk2077.exe", slug: "cyberpunk" },
  { id: "factorio", name: "Factorio", exe: "factorio.exe", slug: "factorio" },
  { id: "satisfactory", name: "Satisfactory", exe: "FactoryGame.exe", slug: "satisfactory" },
  { id: "terraria", name: "Terraria", exe: "tModLoader.exe", slug: "terraria" },
  { id: "dont-starve", name: "Don't Starve Together (Solo)", exe: "dontstarve_steam.exe", slug: "dont-starve" },
];

const GAMES: GameMemory[] = [
  {
    id: "subnautica-2",
    name: "Subnautica 2",
    slug: "subnautica-2",
    exe: "Subnautica2.exe",
    offline: true,
    whitelisted: true,
    running: true,
    memoryAllowed: false,
    antiCheat: { detected: false, processes: [] },
    networkActivity: false,
    processId: 4827,
    player: { x: 124.5, y: -42.3, z: 890.1, depth: -42 },
    biome: "Grassy Plateaus",
    oxygen: 45,
    inventory: [
      { item: "Titanium", count: 3 },
      { item: "Copper Ore", count: 5 },
      { item: "Quartz", count: 2 },
      { item: "Creepvine Seed", count: 4 },
    ],
    nearest: [
      { name: "Titanium Deposit", distance: 80, direction: "Север (N)", depth: -45, coords: { x: 124, y: -45, z: 970 } },
      { name: "Limestone Outcrop", distance: 120, direction: "Северо-восток (NE)", depth: -38, coords: { x: 195, y: -38, z: 950 } },
      { name: "Sandstone Outcrop (Silver/Gold)", distance: 240, direction: "Восток (E)", depth: -55, coords: { x: 360, y: -55, z: 880 } },
      { name: "Cave entrance (Titanium-rich)", distance: 380, direction: "Юго-запад (SW)", depth: -90, coords: { x: -240, y: -90, z: 760 } },
      { name: "Wreck (scan for blueprint)", distance: 540, direction: "Север-северо-запад (NNW)", depth: -120, coords: { x: 60, y: -120, z: 1430 } },
    ],
    warningLevel: "safe",
  },
  {
    id: "stardew",
    name: "Stardew Valley",
    slug: "stardew",
    exe: "StardewValley.exe",
    offline: true,
    whitelisted: true,
    running: false,
    memoryAllowed: false,
    antiCheat: { detected: false, processes: [] },
    networkActivity: false,
    warningLevel: "safe",
  },
  {
    id: "cs2",
    name: "Counter-Strike 2",
    slug: "cs2",
    exe: "cs2.exe",
    offline: false,
    whitelisted: false,
    running: true,
    memoryAllowed: false,
    antiCheat: {
      detected: true,
      name: "VAC (Valve Anti-Cheat)",
      processes: ["steamservice.exe", "hl2.exe"],
    },
    networkActivity: true,
    processId: 9921,
    warningLevel: "blocked",
  },
  {
    id: "valorant",
    name: "Valorant",
    slug: "valorant",
    exe: "VALORANT-Win64-Shipping.exe",
    offline: false,
    whitelisted: false,
    running: false,
    memoryAllowed: false,
    antiCheat: {
      detected: true,
      name: "Riot Vanguard (kernel-level)",
      processes: ["vgc.exe", "vgtray.exe"],
    },
    networkActivity: true,
    warningLevel: "blocked",
  },
  {
    id: "fortnite",
    name: "Fortnite",
    slug: "fortnite",
    exe: "FortniteClient-Win64-Shipping.exe",
    offline: false,
    whitelisted: false,
    running: false,
    memoryAllowed: false,
    antiCheat: {
      detected: true,
      name: "EasyAntiCheat (EAC)",
      processes: ["EasyAntiCheat.exe"],
    },
    networkActivity: true,
    warningLevel: "blocked",
  },
];

export async function GET() {
  return NextResponse.json({
    games: GAMES,
    whitelist: WHITELIST.map((w) => w.name),
    safetyPolicy: {
      offlineOnly: true,
      perGameOptIn: true,
      antiCheatBlocks: true,
      networkActivityBlocks: true,
      whitelistEnforced: true,
    },
  });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { action, id } = body;

  if (action === "request_access") {
    const g = GAMES.find((x) => x.id === id);
    if (!g) return NextResponse.json({ ok: false, error: "Игра не найдена" }, { status: 404 });

    // Hard safety checks — refuse if anything looks online/competitive
    if (g.antiCheat.detected) {
      return NextResponse.json({
        ok: false,
        blocked: true,
        reason: "anti_cheat_detected",
        message: `ОТКАЗ: у ${g.name} обнаружен анти-чит (${g.antiCheat.name}). Чтение памяти онлайн-игр = чит и бан. FLUX никогда не будет этого делать.`,
      });
    }
    if (g.networkActivity) {
      return NextResponse.json({
        ok: false,
        blocked: true,
        reason: "network_activity",
        message: `ОТКАЗ: ${g.name} имеет сетевую активность. Чтение памяти онлайн-игр запрещено.`,
      });
    }
    if (!g.offline) {
      return NextResponse.json({
        ok: false,
        blocked: true,
        reason: "not_offline",
        message: `ОТКАЗ: ${g.name} не отмечена как офлайн-игра.`,
      });
    }
    if (!g.whitelisted) {
      return NextResponse.json({
        ok: false,
        blocked: true,
        reason: "not_whitelisted",
        message: `ОТКАЗ: ${g.name} не в whitelist одиночных игр. Добавлять игры в whitelist может только пользователь через явное подтверждение.`,
      });
    }

    // All checks passed — but we still don't enable until user confirms in modal.
    return NextResponse.json({
      ok: true,
      ready: true,
      game: g,
      message: `Готов дать доступ к памяти ${g.name} — подтвердите в модалке, что это одиночная офлайн-игра.`,
    });
  }

  if (action === "grant_access") {
    const g = GAMES.find((x) => x.id === id);
    if (!g) return NextResponse.json({ ok: false, error: "не найдена" }, { status: 404 });
    if (g.antiCheat.detected || g.networkActivity || !g.offline || !g.whitelisted) {
      return NextResponse.json({
        ok: false,
        blocked: true,
        message: "Отказ: игра не прошла проверки безопасности.",
      });
    }
    g.memoryAllowed = true;
    return NextResponse.json({ ok: true, game: g });
  }

  if (action === "revoke_access") {
    const g = GAMES.find((x) => x.id === id);
    if (g) g.memoryAllowed = false;
    return NextResponse.json({ ok: true, game: g });
  }

  if (action === "read_memory") {
    const g = GAMES.find((x) => x.id === id);
    if (!g) return NextResponse.json({ ok: false, error: "не найдена" }, { status: 404 });
    if (!g.memoryAllowed) {
      return NextResponse.json({
        ok: false,
        blocked: true,
        message: "Доступ к памяти не выдан пользователем.",
      });
    }
    // Return mock live memory snapshot
    return NextResponse.json({
      ok: true,
      snapshot: {
        processId: g.processId,
        player: g.player,
        biome: g.biome,
        oxygen: g.oxygen,
        inventory: g.inventory,
        nearest: g.nearest,
        timestamp: Date.now(),
      },
    });
  }

  return NextResponse.json({ ok: false, error: "unknown action" }, { status: 400 });
}
