import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  // Mock CDP status — in the original Python app this connects to port 9222.
  // Here we simulate a "live Chrome with 10 tabs" connection for the dashboard.
  return NextResponse.json({
    ok: true,
    browser: "Google Chrome 131.0.5773.2",
    tabs: 10,
    endpoint: "127.0.0.1:9222",
    transport: "cdp",
    profile: "user",
    uptime: Math.floor(Math.random() * 3600 + 600),
  });
}

export async function POST() {
  // Simulate "reconnect / launch browser with debug port"
  return NextResponse.json({
    ok: true,
    browser: "Google Chrome 131.0.5773.2",
    tabs: 10,
    endpoint: "127.0.0.1:9222",
    message: "Chrome подключён к CDP-порту 9222",
  });
}
