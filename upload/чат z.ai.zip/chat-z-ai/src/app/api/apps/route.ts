import { NextResponse } from "next/server";
import type { AppItem } from "@/components/flux/store";

const APPS: AppItem[] = [
  // games
  {
    id: "app-steam",
    name: "Steam",
    category: "game",
    exe: "C:\\Program Files (x86)\\Steam\\steam.exe",
    icon: "🎮",
    accent: "#1b2838",
    description: "Лаунчер Steam — 142 игры в библиотеке, 3 обновляются",
    running: true,
    pinned: true,
    launchCount: 247,
  },
  {
    id: "app-epic",
    name: "Epic Games",
    category: "game",
    exe: "C:\\Program Files (x86)\\Epic Games\\Launcher\\Portal\\Binaries\\Win64\\EpicGamesLauncher.exe",
    icon: "🗡",
    accent: "#0071f0",
    description: "Epic Games Store — бесплатные игры недели готовы",
    running: false,
    launchCount: 12,
  },
  {
    id: "app-discord",
    name: "Discord",
    category: "social",
    exe: "%LOCALAPPDATA%\\Discord\\Update.exe --processStart Discord.exe",
    icon: "💬",
    accent: "#5865f2",
    description: "Discord — 4 сервера онлайн, 17 непрочитанных сообщений",
    running: true,
    pinned: true,
    launchCount: 89,
  },
  {
    id: "app-spotify",
    name: "Spotify",
    category: "media",
    exe: "%APPDATA%\\Spotify\\Spotify.exe",
    icon: "🎵",
    accent: "#1db954",
    description: "Spotify — играет «Cosmic Lo-Fi» плейлист, 24 трека в очереди",
    running: true,
    pinned: true,
    launchCount: 156,
  },
  {
    id: "app-vscode",
    name: "VS Code",
    category: "dev",
    exe: "code.exe",
    icon: "📘",
    accent: "#007acc",
    description: "Редактор кода — открыт проект flux-ai-main, 12 файлов в табах",
    running: true,
    pinned: true,
    launchCount: 312,
  },
  {
    id: "app-chrome",
    name: "Google Chrome",
    category: "system",
    exe: "chrome.exe",
    icon: "🌐",
    accent: "#4285f4",
    description: "Браузер Chrome — 3 окна, 10 вкладок, порт CDP 9222 активен",
    running: true,
    pinned: true,
    launchCount: 999,
  },
  {
    id: "app-edge",
    name: "Microsoft Edge",
    category: "system",
    exe: "msedge.exe",
    icon: "🌊",
    accent: "#0c5bb3",
    description: "Edge — недоступен, не запущен",
    running: false,
    launchCount: 3,
  },
  {
    id: "app-terminal",
    name: "Windows Terminal",
    category: "system",
    exe: "wt.exe",
    icon: "💠",
    accent: "#3a4150",
    description: "Терминал — PowerShell 7.4, готов к командам",
    running: false,
    pinned: true,
    launchCount: 78,
  },
  {
    id: "app-notepad",
    name: "Notepad++",
    category: "work",
    exe: "notepad++.exe",
    icon: "📝",
    accent: "#cca54b",
    description: "Текстовый редактор — открыт заметки flux.txt",
    running: false,
    launchCount: 24,
  },
  {
    id: "app-obs",
    name: "OBS Studio",
    category: "media",
    exe: "obs64.exe",
    icon: "🎬",
    accent: "#2b2d3a",
    description: "Запись экрана и стриминга — готов к записи сессии FLUX",
    running: false,
    launchCount: 8,
  },
  {
    id: "app-calc",
    name: "Калькулятор",
    category: "utility",
    exe: "calc.exe",
    icon: "🧮",
    accent: "#5b6472",
    description: "Системный калькулятор Windows",
    running: false,
    launchCount: 41,
  },
  {
    id: "app-explorer",
    name: "Проводник",
    category: "system",
    exe: "explorer.exe",
    icon: "📁",
    accent: "#d4dae4",
    description: "Открывается в последней папке — D:\\Projects\\flux-ai",
    running: true,
    pinned: true,
    launchCount: 134,
  },
  {
    id: "app-paint",
    name: "Paint",
    category: "utility",
    exe: "mspaint.exe",
    icon: "🎨",
    accent: "#e63946",
    description: "Простой графический редактор",
    running: false,
    launchCount: 5,
  },
  {
    id: "app-tasks",
    name: "Диспетчер задач",
    category: "system",
    exe: "taskmgr.exe",
    icon: "📊",
    accent: "#2a2f3a",
    description: "Мониторинг процессов и производительности",
    running: false,
    launchCount: 19,
  },
];

export async function GET() {
  return NextResponse.json({ apps: APPS });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { action, id } = body;
  if (action === "launch") {
    const app = APPS.find((a) => a.id === id);
    if (!app) return NextResponse.json({ ok: false, error: "not found" }, { status: 404 });
    app.running = true;
    app.launchCount = (app.launchCount || 0) + 1;
    return NextResponse.json({ ok: true, app });
  }
  if (action === "kill") {
    const app = APPS.find((a) => a.id === id);
    if (!app) return NextResponse.json({ ok: false, error: "not found" }, { status: 404 });
    app.running = false;
    return NextResponse.json({ ok: true, app });
  }
  if (action === "pin") {
    const app = APPS.find((a) => a.id === id);
    if (!app) return NextResponse.json({ ok: false, error: "not found" }, { status: 404 });
    app.pinned = !app.pinned;
    return NextResponse.json({ ok: true, app });
  }
  return NextResponse.json({ ok: false, error: "unknown action" }, { status: 400 });
}
