import { NextResponse } from "next/server";
import type { BrowserTab } from "@/components/flux/store";

const TABS: BrowserTab[] = [
  {
    id: "tab-001",
    windowId: 1,
    title: "Crazy Games — Bubble Shooter",
    url: "https://crazygames.com/game/bubble-shooter",
    favIconUrl: "🎮",
    active: true,
    audible: true,
    category: "game",
    aiLink: "game:bubble-shooter",
    aiSummary:
      "Аркада-головоломка. Стреляй шариками, собирай группы по 3+ одного цвета, очищай поле. Идеально для короткой сессии 5-10 минут.",
    tags: ["puzzle", "casual", "browser", "no-install"],
    accent: "#ffb454",
    watching: true,
  },
  {
    id: "tab-002",
    windowId: 1,
    title: "Chess.com — Live Blitz",
    url: "https://chess.com/live",
    favIconUrl: "♟",
    category: "game",
    aiLink: "game:chess-blitz",
    aiSummary:
      "Шахматы блиц 5+0. Текущая партия активна, ход белых. ИИ может подсказать лучший ход или проанализировать позицию.",
    tags: ["strategy", "multiplayer", "live", "thinking"],
    accent: "#76b7ff",
    watching: true,
  },
  {
    id: "tab-003",
    windowId: 1,
    title: "Steam — Elden Ring DLC",
    url: "https://store.steampowered.com/app/2358720",
    favIconUrl: "🗡",
    category: "game",
    aiLink: "game:elden-ring-dlc",
    aiSummary:
      "Страница DLC Shadow of the Erdtree в Steam. Цена 1599₽, скидка 20%, рейтинг 9/10. Можно открыть покупку.",
    tags: ["rpg", "open-world", "sale", "wishlist"],
    accent: "#ff78b4",
  },
  {
    id: "tab-004",
    windowId: 2,
    title: "GitHub — flux-ai-main",
    url: "https://github.com/flux/flux-ai-main",
    favIconUrl: "🐙",
    category: "dev",
    aiLink: "dev:github-flux",
    aiSummary:
      "Репозиторий FLUX AI. 247 коммитов, ветка main. Открыт README с описанием 357 инструментов и CDP-моста к браузеру.",
    tags: ["repo", "python", "ai", "browser-cdp"],
    accent: "#7d8590",
    watching: true,
  },
  {
    id: "tab-005",
    windowId: 2,
    title: "YouTube — Lofi Hip Hop Radio",
    url: "https://youtube.com/watch?v=jfKfPfyJRdk",
    favIconUrl: "▶",
    audible: true,
    category: "media",
    aiLink: "media:lofi-radio",
    aiSummary:
      "Lofi Hip Hop Radio, прямой эфир. Играет фоновая музыка для концентрации. 32 тыс. зрителей онлайн.",
    tags: ["music", "live", "focus", "background"],
    accent: "#ff4b4b",
  },
  {
    id: "tab-006",
    windowId: 2,
    title: "MDN — Canvas API Reference",
    url: "https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API",
    favIconUrl: "📚",
    category: "work",
    aiLink: "docs:mdn-canvas",
    aiSummary:
      "Документация Canvas API. Открыт раздел про 2D-контекст, радиальные градиенты и clip. Полезно для космических сцен.",
    tags: ["docs", "canvas", "2d", "reference"],
    accent: "#3ecf8e",
  },
  {
    id: "tab-007",
    windowId: 3,
    title: "Discord — #flux-dev",
    url: "https://discord.com/channels/flux/dev",
    favIconUrl: "💬",
    category: "social",
    aiLink: "social:discord-flux-dev",
    aiSummary:
      "Канал разработки FLUX. 8 новых сообщений, обсуждение интеграции с chrome.debugger.",
    tags: ["chat", "dev", "community"],
    accent: "#5865f2",
  },
  {
    id: "tab-008",
    windowId: 3,
    title: "Ozon — Поиск: механическая клавиатура",
    url: "https://ozon.ru/search/?text=mechanical+keyboard",
    favIconUrl: "🛒",
    category: "shop",
    aiLink: "shop:ozon-keyboard",
    aiSummary:
      "Поиск на Ozon: 247 результатов по механическим клавиатурам. Сортировка по популярности, цена 2-8 тыс. ₽.",
    tags: ["shopping", "tech", "compare"],
    accent: "#005bff",
  },
  {
    id: "tab-009",
    windowId: 3,
    title: "Poki — Subway Surfers",
    url: "https://poki.com/ru/g/subway-surfers",
    favIconUrl: "🚇",
    category: "game",
    aiLink: "game:subway-surfers",
    aiSummary:
      "Бесконечный раннер Subway Surfers. Управление стрелками, цель — собрать монеты и убежать от охранника.",
    tags: ["runner", "casual", "browser", "kid-friendly"],
    accent: "#ffb454",
  },
  {
    id: "tab-010",
    windowId: 1,
    title: "Twitch — Dota 2 TI Grand Final",
    url: "https://twitch.tv/dota2ti",
    favIconUrl: "🎥",
    audible: true,
    category: "media",
    aiLink: "media:twitch-dota-ti",
    aiSummary:
      "Прямая трансляция Grand Final The International. 847 тыс. зрителей, счёт 2-2 в серии до 3 побед.",
    tags: ["esports", "live", "moba", "tournament"],
    accent: "#9146ff",
  },
];

export async function GET() {
  return NextResponse.json({ tabs: TABS, windows: 3, total: TABS.length });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { action, id, url, title } = body;
  if (action === "close") {
    const idx = TABS.findIndex((t) => t.id === id);
    if (idx >= 0) TABS.splice(idx, 1);
    return NextResponse.json({ ok: true, remaining: TABS.length });
  }
  if (action === "open") {
    const newTab: BrowserTab = {
      id: "tab-" + Date.now().toString(36),
      windowId: 1,
      title: title || url,
      url,
      category: "other",
      aiLink: "tab:" + (TABS.length + 1),
      aiSummary: "Вкладка открыта из FLUX.",
      tags: [],
      accent: "#4f8cff",
    };
    TABS.push(newTab);
    return NextResponse.json({ ok: true, tab: newTab });
  }
  if (action === "activate") {
    TABS.forEach((t) => (t.active = t.id === id));
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ ok: false, error: "unknown action" }, { status: 400 });
}
