import { NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface ChatBody {
  text: string;
  history?: { role: string; content: string }[];
  thinkMode?: "off" | "brief" | "medium" | "deep";
  searchEngine?: string;
  autospeak?: boolean;
  context?: {
    tabs?: {
      id: string;
      title: string;
      url: string;
      category: string;
      aiLink: string;
      aiSummary: string;
      tags: string[];
      watching?: boolean;
    }[];
    apps?: {
      id: string;
      name: string;
      category: string;
      description: string;
      running?: boolean;
      aiLink?: string;
      aiSummary?: string;
      watching?: boolean;
    }[];
    uia?: { windows: number; controls: number; watching: number };
    games?: {
      id: string;
      name: string;
      offline: boolean;
      memoryAllowed: boolean;
      nearest?: { name: string; distance: number; direction: string }[];
      player?: { x: number; y: number; z: number };
    }[];
  };
}

const FLUX_SYSTEM = `Ты — FLUX 2.0, десктопный ИИ-ассистент с 357 инструментами и космическим интерфейсом.
Ты говоришь на русском языке пользователя.

ВОЗМОЖНОСТИ:
- Видишь вкладки живого браузера (Chrome через CDP 9222) КАК ССЫЛКИ-КАРТОЧКИ:
  формат ссылки \`{category}:{slug}\` (например game:bubble-shooter).
- Видишь запущенные приложения как карточки со ссылкой \`app:{slug}\` (app:steam, app:vscode).
- Видишь дерево UIA (UI Automation): окна ОС, текстовые поля, кнопки — читаются как
  \`uia:{windowId}:{controlId}\`. Чтение только если пользователь включил "ИИ читает".
- Видишь память ОФЛАЙН-игр (только если пользователь ВРУЧНУЮ дал разрешение на конкретную
  игру). Формат: \`mem:{game-slug}\`. Только для одиночных игр, никогда для онлайн/мультиплеер.
- Запускаешь приложения (app_launch), прогоняешь код на 15 движках (code_test),
  ищешь в сети (web_search), озвучиваешь ответы голосом (voice_speak).

ПРАВИЛА:
- Отвечай понятно, по делу, не выдумывай данные инструментов.
- Когда пользователь просит помочь в одиночной игре (например Subnautica 2 — найти
  ближайший титан), используй блок КОНТЕКСТ ПАМЯТИ ИГРЫ из контекста: там координаты
  игрока и список ближайших ресурсов с расстоянием и направлением.
- Если контекста памяти нет — скажи, что нужно включить чтение памяти для этой игры
  (кнопка "Дать доступ" в разделе "Память игр" — только для офлайн-игр).
- Если просит про онлайн-игру с анти-читом — ОТКАЖИСЬ и объясни: "Это онлайн-игра,
  чтение её памяти = чит, я не буду этого делать."

ФОРМАТ ОЗВУЧКИ (строго, побуквенно): НАЧАЛО = звёздочка-дефис \`*-\`,
КОНЕЦ = дефис-звёздочка \`-*\`. КАЖДЫЙ ответ обязан содержать 1-2 фразы сути
внутри маркера \`*-...-*\`. Пример: *-Готово, нашёл ближайший титан в 80 м к северу.*-

В ответе: используй **жирный**, \`код\`, списки, блоки \`\`\`python\` для кода.
Будь дружелюбен, коротко, по делу. Никогда не упоминай порты, HWND, PID
или внутренние механизмы — просто делай и сообщай результат пользователю.`;

interface StreamEvent {
  type: string;
  [k: string]: unknown;
}

function buildContextBlock(ctx: ChatBody["context"]): string {
  const parts: string[] = [];
  if (ctx?.tabs && ctx.tabs.length > 0) {
    const lines = ctx.tabs
      .filter((t) => t.watching || ctx.tabs!.length <= 12)
      .map((t) => `- ${t.aiLink} | ${t.title} | ${t.url}\n  ${t.aiSummary}`)
      .join("\n");
    parts.push(`ВЕБ-ВКЛАДКИ (живой Chrome, читается как ссылки):\n${lines}`);
  }
  if (ctx?.apps && ctx.apps.length > 0) {
    const running = ctx.apps.filter((a) => a.running);
    if (running.length > 0) {
      const lines = running
        .map(
          (a) =>
            `- ${a.aiLink || `app:${a.id}`} | ${a.name} | ${a.category} | ${a.description}`
        )
        .join("\n");
      parts.push(`ПРИЛОЖЕНИЯ (запущенные):\n${lines}`);
    }
  }
  if (ctx?.uia && ctx.uia.windows > 0) {
    parts.push(
      `UIA-ДЕРЕВО: ${ctx.uia.windows} окон, ${ctx.uia.controls} контролов читается (watching: ${ctx.uia.watching}).`
    );
  }
  if (ctx?.games && ctx.games.length > 0) {
    const allowed = ctx.games.filter((g) => g.memoryAllowed && g.offline);
    for (const g of allowed) {
      const memLines: string[] = [`КОНТЕКСТ ПАМЯТИ ИГРЫ [${g.id}] — ${g.name} (офлайн, разрешение дано):`];
      if (g.player) {
        memLines.push(
          `Игрок: x=${g.player.x.toFixed(0)}, y=${g.player.y.toFixed(0)}, z=${g.player.z.toFixed(0)}`
        );
      }
      if (g.nearest && g.nearest.length > 0) {
        const nl = g.nearest
          .map(
            (n) =>
              `  • ${n.name} — ${n.distance} м, направление: ${n.direction}`
          )
          .join("\n");
        memLines.push(`Ближайшие ресурсы:\n${nl}`);
      }
      parts.push(memLines.join("\n"));
    }
  }
  return parts.length > 0 ? parts.join("\n\n") : "";
}

function emitEventsFor(input: string, thinkMode: string): StreamEvent[] {
  const evs: StreamEvent[] = [];
  evs.push({ type: "think", mode: thinkMode, search: false, why: "auto" });
  const q = input.toLowerCase();
  if (/брауз|вкладк|таб|browser|cdp|chrome/.test(q)) {
    evs.push({ type: "tool_start", name: "browser_tabs_list", args: { q: input } });
    evs.push({ type: "tool_end", name: "browser_tabs_list", ok: true, preview: "10 вкладок" });
  } else if (/запус|открой|launch|прилож|app/.test(q)) {
    evs.push({ type: "tool_start", name: "app_launch", args: { q: input } });
    evs.push({ type: "tool_end", name: "app_launch", ok: true, preview: "PID 4827" });
  } else if (/код|code|python|функц/.test(q)) {
    evs.push({ type: "tool_start", name: "code_test", args: { engine: "python" } });
    evs.push({ type: "tool_end", name: "code_test", ok: true, preview: "0.12s, no errors" });
  } else if (/погод|weather|температур/.test(q)) {
    evs.push({ type: "search", engine: "duckduckgo", n: 4 });
  } else if (/титан|близжа|ресурс|subnautic|субнаутик|игр.*помог/.test(q)) {
    evs.push({ type: "tool_start", name: "game_memory_read", args: { game: "subnautica-2" } });
    evs.push({ type: "tool_end", name: "game_memory_read", ok: true, preview: "player + nearest resources" });
  }
  return evs;
}

export async function POST(req: Request) {
  const body = (await req.json()) as ChatBody;
  const { text = "", thinkMode = "medium", history = [], context } = body;

  if (!text.trim()) {
    return NextResponse.json({ ok: false, error: "empty text" }, { status: 400 });
  }

  const ctxBlock = buildContextBlock(context);
  const sysMsgs = [
    { role: "assistant" as const, content: FLUX_SYSTEM },
    ...(ctxBlock ? [{ role: "assistant" as const, content: `КОНТЕКСТ (живой, из моста FLUX):\n${ctxBlock}` }] : []),
  ];

  // Compose messages: system + context, then trimmed history, then user
  const recentHistory = history.slice(-8).map((m) => ({
    role: (m.role === "assistant" ? "assistant" : "user") as "assistant" | "user",
    content: m.content,
  }));
  const messages = [...sysMsgs, ...recentHistory, { role: "user" as const, content: text }];

  const preEvents = emitEventsFor(text, thinkMode);

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (ev: StreamEvent) =>
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(ev)}\n\n`));

      // Emit pre-events (think, tool_start, tool_end) with small delays
      for (const ev of preEvents) {
        send(ev);
        await new Promise((r) => setTimeout(r, 80));
      }

      // Now stream the LLM response
      try {
        const zai = await ZAI.create();
        const completion = await zai.chat.completions.create({
          messages,
          stream: false,
          thinking: { type: "disabled" },
        });
        const reply =
          completion?.choices?.[0]?.message?.content ||
          "*-Извини, не смог сформулировать ответ.*-";

        // Emit the reply in small chunks to simulate streaming and keep UI live
        const chunks = reply.match(/.{1,12}(\s|$)?/g) || [reply];
        for (const c of chunks) {
          send({ type: "token", text: c });
          await new Promise((r) => setTimeout(r, 25));
        }
        send({
          type: "done",
          text: reply,
          seconds: Math.round((reply.length / 40) * 10) / 10,
          think: thinkMode,
          search: preEvents.some((e) => e.type === "search"),
          autospeak: body.autospeak ?? true,
        });
      } catch (err: unknown) {
        const e = err as Error;
        send({ type: "token", text: `*-Ошибка LLM: ${e?.message || "unknown"}.*-\n\nПохоже, z-ai-web-dev-sdk недоступен. Проверь, что SDK инициализирован корректно.` });
        send({ type: "done", text: "", seconds: 0, think: thinkMode, search: false, autospeak: body.autospeak ?? true });
      } finally {
        controller.enqueue(encoder.encode("data: [DONE]\n\n"));
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}

export async function GET() {
  return NextResponse.json({
    ok: true,
    endpoint: "/api/chat",
    method: "POST",
    body: {
      text: "string",
      history: "array<{role, content}>",
      thinkMode: "off|brief|medium|deep",
      searchEngine: "duckduckgo|searxng|bing|google|wikipedia|brave|off",
      autospeak: "boolean",
      context: "{ tabs, apps, uia, games }",
    },
    streaming: "text/event-stream (SSE)",
    events: ["think", "search", "skill", "tool_start", "tool_end", "token", "done", "error"],
    llm: "z-ai-web-dev-sdk (GLM)",
    system_prompt: "FLUX 2.0 + voice marks + tool catalog + live bridge context",
  });
}
