"use client";

import { useEffect, useMemo, useState } from "react";
import { useFlux, type Tool } from "./store";
import { CosmicCanvas } from "./cosmic-canvas";
import {
  Wrench, Search, Filter, Bot, Sparkles, Star, Zap, Terminal,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { StaggerContainer, StaggerItem } from "./motion";
import { cn } from "@/lib/utils";

interface CategoryMeta { label: string; icon: string; accent: string }

export function ToolsCatalogView() {
  const { tools, setTools, setStatusText, setView } = useFlux();
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState("all");
  const [cats, setCats] = useState<Record<string, CategoryMeta>>({});
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [originalTotal, setOriginalTotal] = useState(357);
  const [selected, setSelected] = useState<Tool | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      try {
        const r = await fetch("/api/tools");
        const d = await r.json();
        if (active && Array.isArray(d.tools)) {
          setTools(d.tools);
          setCats(d.categories || {});
          setCounts(d.counts || {});
          setOriginalTotal(d.original_total || 357);
        }
      } catch { /* noop */ }
      finally { if (active) setLoading(false); }
    })();
    return () => { active = false; };
  }, [setTools]);

  const filtered = useMemo(() => {
    let r = tools;
    if (cat !== "all") r = r.filter((t) => t.category === cat);
    if (query.trim()) {
      const q = query.toLowerCase();
      r = r.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q)
      );
    }
    // core tools first
    return [...r].sort((a, b) => Number(!!b.core) - Number(!!a.core) || a.name.localeCompare(b.name));
  }, [tools, cat, query]);

  const coreCount = tools.filter((t) => t.core).length;

  return (
    <div className="relative flex-1 flex flex-col overflow-hidden">
      <div className="absolute inset-0 opacity-25 pointer-events-none">
        <CosmicCanvas scene="pulsar" agentState="idle" className="w-full h-full" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background pointer-events-none" />

      <div className="relative z-10 flex flex-col h-full">
        {/* toolbar */}
        <div className="px-3 sm:px-5 py-3 border-b border-border bg-card/50 backdrop-blur-md flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 mr-2">
            <Wrench size={18} className="text-amber-400" />
            <h2 className="font-bold text-base sm:text-lg text-shimmer">Каталог тулзов</h2>
            <Badge variant="outline" className="text-[10px] font-mono">
              {tools.length} показано / {originalTotal} всего
            </Badge>
            <Badge className="text-[10px] font-mono bg-amber-500/15 text-amber-300 border-amber-500/30">
              <Star size={9} className="mr-0.5" />
              {coreCount} ядро
            </Badge>
          </div>

          <div className="flex-1" />

          <div className="relative flex-1 min-w-[160px] max-w-[280px]">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Поиск: browser_tabs_list…"
              className="h-8 pl-8 text-xs font-mono"
              aria-label="Поиск инструментов"
            />
          </div>

          <Select value={cat} onValueChange={setCat}>
            <SelectTrigger className="w-[180px] h-8 text-xs" aria-label="Фильтр категорий">
              <Filter size={12} className="mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all" className="text-xs">Все категории</SelectItem>
              {Object.entries(cats).map(([k, v]) => (
                <SelectItem key={k} value={k} className="text-xs">
                  {v.icon} {v.label} ({counts[k] || 0})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* category chips */}
        <div className="px-3 sm:px-5 py-2 flex gap-1.5 overflow-x-auto flux-scroll border-b border-border/50 bg-card/30">
          <button
            onClick={() => setCat("all")}
            className={cn(
              "shrink-0 px-2.5 py-1 rounded-full text-[11px] font-mono transition border flex items-center gap-1",
              cat === "all"
                ? "bg-amber-500/20 border-amber-400/50 text-amber-200"
                : "bg-transparent border-border text-muted-foreground hover:text-foreground hover:bg-accent"
            )}
          >
            <span>◎</span><span>Все</span><span className="opacity-50">{tools.length}</span>
          </button>
          {Object.entries(cats).map(([k, v]) => {
            const active = cat === k;
            return (
              <button
                key={k}
                onClick={() => setCat(k)}
                className={cn(
                  "shrink-0 px-2.5 py-1 rounded-full text-[11px] font-mono transition border flex items-center gap-1",
                  active
                    ? "bg-amber-500/20 border-amber-400/50 text-amber-200"
                    : "bg-transparent border-border text-muted-foreground hover:text-foreground hover:bg-accent"
                )}
              >
                <span>{v.icon}</span><span>{v.label}</span><span className="opacity-50">{counts[k] || 0}</span>
              </button>
            );
          })}
        </div>

        {/* main: grid + detail */}
        <div className="flex-1 flex min-h-0">
          {/* list */}
          <ScrollArea className="flex-1">
            <div className="p-3 sm:p-5">
              {loading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {Array.from({ length: 12 }).map((_, i) => (
                    <div key={i} className="rounded-lg glass-panel p-3 space-y-2">
                      <div className="h-3 w-2/3 rounded shimmer" />
                      <div className="h-2 w-full rounded shimmer" />
                    </div>
                  ))}
                </div>
              ) : (
                <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {filtered.map((t) => {
                    const meta = cats[t.category];
                    return (
                      <StaggerItem key={t.id}>
                      <button
                        onClick={() => setSelected(t)}
                        className={cn(
                          "text-left rounded-lg p-3 border transition game-card-hover card-lift w-full",
                          selected?.id === t.id
                            ? "border-amber-400/60 bg-amber-500/10"
                            : "border-border bg-card/50 hover:border-amber-400/40 hover:bg-accent"
                        )}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm">{meta?.icon}</span>
                          <code className="text-[11px] font-mono text-foreground/90 truncate flex-1">{t.name}</code>
                          {t.core && <Star size={11} className="text-amber-400 fill-amber-400/60 shrink-0" />}
                        </div>
                        <p className="text-[10px] text-muted-foreground line-clamp-2 leading-snug">{t.description}</p>
                        <div className="flex items-center gap-1 mt-1.5">
                          <Badge variant="outline" className="text-[8px] py-0 px-1 font-mono">{t.category}</Badge>
                          {t.args?.length ? (
                            <Badge variant="outline" className="text-[8px] py-0 px-1 font-mono">{t.args.length} args</Badge>
                          ) : null}
                        </div>
                      </button>
                      </StaggerItem>
                    );
                  })}
                </StaggerContainer>
              )}
            </div>
          </ScrollArea>

          {/* detail panel */}
          {selected && (
            <aside className="hidden lg:flex w-80 xl:w-96 border-l border-border bg-card/60 backdrop-blur-md flex-col">
              <div className="p-4 border-b border-border">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg">{cats[selected.category]?.icon}</span>
                  <code className="text-sm font-mono text-amber-300">{selected.name}</code>
                  {selected.core && (
                    <Badge className="text-[9px] font-mono bg-amber-500/15 text-amber-300 border-amber-500/30">
                      <Star size={9} className="mr-0.5 fill-current" /> CORE
                    </Badge>
                  )}
                </div>
                <Badge variant="outline" className="text-[10px] font-mono">
                  {cats[selected.category]?.label}
                </Badge>
              </div>
              <ScrollArea className="flex-1">
                <div className="p-4 space-y-3">
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Описание</div>
                    <p className="text-xs leading-relaxed">{selected.description}</p>
                  </div>
                  {selected.args && selected.args.length > 0 && (
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">Аргументы</div>
                      <div className="space-y-1.5">
                        {selected.args.map((a) => (
                          <div key={a.name} className="p-2 rounded-md bg-muted/40 border border-border/50">
                            <div className="flex items-center gap-2">
                              <code className="text-[11px] font-mono text-cyan-300">{a.name}</code>
                              {a.required && (
                                <Badge variant="outline" className="text-[8px] py-0 px-1 font-mono border-red-500/40 text-red-300">
                                  required
                                </Badge>
                              )}
                            </div>
                            <p className="text-[10px] text-muted-foreground mt-0.5">{a.desc}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  <div className="pt-2 border-t border-border/50">
                    <button
                      onClick={() => {
                        setView("chat");
                        setStatusText(`ИИ вызовет ${selected.name} — задайте вопрос`);
                      }}
                      className="w-full h-8 rounded-md text-xs bg-cyan-500/15 text-cyan-200 border border-cyan-400/30 hover:bg-cyan-500/25 flex items-center justify-center gap-1.5"
                    >
                      <Bot size={12} />
                      Использовать в чате
                    </button>
                  </div>
                </div>
              </ScrollArea>
            </aside>
          )}
        </div>

        {/* footer */}
        <div className="px-3 sm:px-5 py-2 border-t border-border bg-card/60 backdrop-blur-md flex flex-wrap items-center gap-2 text-[11px] font-mono text-muted-foreground">
          <span className="flex items-center gap-1">
            <Zap size={12} className="text-amber-400" />
            retrieval top-14 релевантных запросу уходит модели
          </span>
          <span className="opacity-30">·</span>
          <span className="flex items-center gap-1">
            <Terminal size={12} className="text-cyan-400" />
            core: web_search, code_test, browser_tabs_list, mem_remember/recall, voice_speak
          </span>
        </div>
      </div>
    </div>
  );
}
