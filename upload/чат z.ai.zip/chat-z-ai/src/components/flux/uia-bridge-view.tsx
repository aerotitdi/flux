"use client";

import { useEffect, useMemo, useState } from "react";
import { useFlux, type UiaWindow, type UiaControl } from "./store";
import { CosmicCanvas } from "./cosmic-canvas";
import {
  Cpu, Search, Eye, EyeOff, Bot, Sparkles, Link2,
  AppWindow, MousePointerClick, Focus,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

const TYPE_ICONS: Record<UiaControl["type"], string> = {
  button: "🔘",
  text: "📄",
  edit: "✏",
  list: "📋",
  menu: "🍴",
  tab: "📑",
  image: "🖼",
  checkbox: "☑",
  slider: "🎚",
  tree: "🌳",
};

export function UiaBridgeView() {
  const { uiaWindows, setUiaWindows, toggleUiaControlWatch, setStatusText, setView } = useFlux();
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [activeWindow, setActiveWindow] = useState<number | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      try {
        const r = await fetch("/api/uia");
        const d = await r.json();
        if (active && Array.isArray(d.windows)) {
          setUiaWindows(d.windows);
          if (d.windows.length > 0 && activeWindow === null) {
            const focused = d.windows.find((w: UiaWindow) => w.focused);
            setActiveWindow(focused ? focused.windowId : d.windows[0].windowId);
          }
        }
      } catch { /* noop */ }
      finally { if (active) setLoading(false); }
    })();
    return () => { active = false; };
  }, [setUiaWindows]);

  const current = useMemo(
    () => uiaWindows.find((w) => w.windowId === activeWindow) || null,
    [uiaWindows, activeWindow]
  );

  const filteredControls = useMemo(() => {
    if (!current) return [];
    if (!query.trim()) return current.controls;
    const q = query.toLowerCase();
    return current.controls.filter(
      (c) => c.name.toLowerCase().includes(q) || c.aiLink.toLowerCase().includes(q) || (c.value || "").toLowerCase().includes(q)
    );
  }, [current, query]);

  const watchingCount = uiaWindows.reduce(
    (s, w) => s + w.controls.filter((c) => c.watching).length,
    0
  );
  const totalControls = uiaWindows.reduce((s, w) => s + w.controls.length, 0);

  const focusWindow = async (id: number) => {
    setActiveWindow(id);
    try {
      await fetch("/api/uia", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "focus_window", windowId: id }),
      });
    } catch { /* noop */ }
    const w = uiaWindows.find((x) => x.windowId === id);
    if (w) setStatusText(`🔧 os_window_focus → ${w.title}`);
  };

  const clickControl = async (c: UiaControl) => {
    setStatusText(`🔧 uia_click → ${c.aiLink} (${c.name})`);
    try {
      await fetch("/api/uia", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "click", controlId: c.id }),
      });
    } catch { /* noop */ }
  };

  return (
    <div className="relative flex-1 flex flex-col overflow-hidden">
      <div className="absolute inset-0 opacity-30 pointer-events-none">
        <CosmicCanvas scene="nebula" agentState="idle" className="w-full h-full" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background pointer-events-none" />

      <div className="relative z-10 flex flex-col h-full">
        {/* toolbar */}
        <div className="px-3 sm:px-5 py-3 border-b border-border bg-card/50 backdrop-blur-md flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 mr-2">
            <Cpu size={18} className="text-cyan-400" />
            <h2 className="font-bold text-base sm:text-lg text-shimmer">UIA-мост</h2>
            <Badge variant="outline" className="text-[10px] font-mono">{uiaWindows.length} окон</Badge>
            <Badge variant="outline" className="text-[10px] font-mono">{totalControls} контролов</Badge>
            <Badge className="text-[10px] font-mono bg-teal-500/15 text-teal-300 border-teal-500/30">
              {watchingCount} читается
            </Badge>
          </div>

          <div className="flex-1" />

          <div className="relative flex-1 min-w-[160px] max-w-[280px]">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Поиск по контролам…"
              className="h-8 pl-8 text-xs"
              aria-label="Поиск по контролам"
            />
          </div>
        </div>

        {/* window tabs */}
        <div className="px-3 sm:px-5 py-2 flex gap-1.5 overflow-x-auto flux-scroll border-b border-border/50 bg-card/30">
          {uiaWindows.map((w) => {
            const active = w.windowId === activeWindow;
            return (
              <button
                key={w.windowId}
                onClick={() => focusWindow(w.windowId)}
                className={cn(
                  "shrink-0 px-3 py-1.5 rounded-lg text-xs transition border flex items-center gap-1.5",
                  active
                    ? "bg-cyan-500/20 border-cyan-400/50 text-cyan-200"
                    : "bg-transparent border-border text-muted-foreground hover:text-foreground hover:bg-accent"
                )}
                title={w.title}
              >
                <AppWindow size={12} />
                <span className="truncate max-w-[140px]">{w.title}</span>
                {w.focused && (
                  <span className="text-[9px] px-1 rounded bg-emerald-500/30 text-emerald-200">focus</span>
                )}
              </button>
            );
          })}
        </div>

        {/* main split: window info + controls grid */}
        <ScrollArea className="flex-1">
          <div className="p-3 sm:p-5">
            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="rounded-xl glass-panel p-3 space-y-2">
                    <div className="h-3 w-2/3 rounded shimmer" />
                    <div className="h-2 w-full rounded shimmer" />
                  </div>
                ))}
              </div>
            ) : !current ? (
              <div className="flex flex-col items-center justify-center py-16 text-center text-muted-foreground">
                <Cpu size={48} className="opacity-40 mb-3" />
                <p className="text-sm">Окно не выбрано</p>
              </div>
            ) : (
              <>
                {/* window header */}
                <div className="mb-4 p-3 rounded-lg glass-panel border-gradient-cosmic">
                  <div className="flex items-center gap-2 flex-wrap">
                    <AppWindow size={14} className="text-cyan-400" />
                    <span className="font-mono text-xs text-cyan-300">window #{current.windowId}</span>
                    <span className="font-semibold text-sm">{current.title}</span>
                    {current.focused && (
                      <Badge className="text-[9px] font-mono bg-emerald-500/15 text-emerald-300 border-emerald-500/30">
                        <Focus size={9} className="mr-0.5" /> в фокусе
                      </Badge>
                    )}
                  </div>
                  <div className="mt-1.5 flex items-center gap-3 text-[10px] font-mono text-muted-foreground">
                    <span>process: <span className="text-foreground/80">{current.process}</span></span>
                    <span className="opacity-30">·</span>
                    <span>bounds: {current.bounds.x},{current.bounds.y} {current.bounds.w}×{current.bounds.h}</span>
                    <span className="opacity-30">·</span>
                    <span>controls: {current.controls.length}</span>
                  </div>
                </div>

                {/* controls as readable cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                  {filteredControls.map((c) => (
                    <ControlCard
                      key={c.id}
                      control={c}
                      onWatch={() => {
                        toggleUiaControlWatch(c.id);
                        setStatusText(
                          c.watching
                            ? `Перестал читать ${c.aiLink}`
                            : `Готово: ИИ читает ${c.aiLink} (${c.name})`
                        );
                      }}
                      onClick={() => clickControl(c)}
                      onAsk={() => {
                        setView("chat");
                        setStatusText(`ИИ переключился на ${c.aiLink}`);
                      }}
                    />
                  ))}
                </div>
              </>
            )}
          </div>
        </ScrollArea>

        {/* footer */}
        <div className="px-3 sm:px-5 py-2 border-t border-border bg-card/60 backdrop-blur-md flex flex-wrap items-center gap-2 text-[11px] font-mono text-muted-foreground">
          <span className="flex items-center gap-1">
            <Eye size={12} className="text-teal-400" />
            ИИ читает: <span className="text-teal-300">{watchingCount}</span> из {totalControls}
          </span>
          <span className="opacity-30">·</span>
          <span className="flex items-center gap-1">
            <Link2 size={12} className="text-purple-400" />
            каждый контрол = <code className="text-purple-300">uia:{`{windowId}:{controlId}`}</code>
          </span>
          <span className="opacity-30">·</span>
          <span className="flex items-center gap-1">
            <MousePointerClick size={12} className="text-amber-400" />
            ИИ может кликать: <code className="text-amber-300">uia_click</code>
          </span>
        </div>
      </div>
    </div>
  );
}

function ControlCard({
  control,
  onWatch,
  onClick,
  onAsk,
}: {
  control: UiaControl;
  onWatch: () => void;
  onClick: () => void;
  onAsk: () => void;
}) {
  return (
    <article
      className={cn(
        "game-card-hover card-lift relative rounded-xl overflow-hidden glass-panel border-gradient-cosmic",
        control.watching && "ring-1 ring-teal-400/60 glow-teal",
        !control.visible && "opacity-50",
        !control.enabled && "opacity-60"
      )}
    >
      <div className="p-3 flex flex-col gap-2">
        <div className="flex items-start gap-2">
          <span className="text-xl leading-none mt-0.5">{TYPE_ICONS[control.type]}</span>
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-semibold leading-tight truncate" title={control.name}>
              {control.name}
            </h3>
            <div className="flex items-center gap-1.5 mt-0.5">
              <Badge variant="outline" className="text-[9px] py-0 px-1.5 font-mono">{control.type}</Badge>
              {control.watching && (
                <Badge className="text-[9px] py-0 px-1.5 font-mono bg-teal-500/15 text-teal-300 border-teal-500/30">
                  <Eye size={9} className="mr-0.5" /> ИИ читает
                </Badge>
              )}
              {!control.enabled && <Badge variant="outline" className="text-[9px]">disabled</Badge>}
              {!control.visible && <Badge variant="outline" className="text-[9px]">hidden</Badge>}
            </div>
          </div>
        </div>

        {/* value */}
        {control.value && (
          <div className="px-2 py-1.5 rounded-md bg-muted/50 border border-border/50">
            <span className="text-[9px] uppercase tracking-wider text-muted-foreground">value</span>
            <code className="text-[11px] text-foreground/90 font-mono block truncate" title={control.value}>
              {control.value}
            </code>
          </div>
        )}

        {/* AI-readable link */}
        <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-purple-500/10 border border-purple-400/30">
          <Link2 size={11} className="text-purple-300 shrink-0" />
          <code className="text-[10px] text-purple-200 font-mono truncate flex-1">{control.aiLink}</code>
          <span className="text-[9px] text-purple-300/70 font-mono shrink-0">ссылка</span>
        </div>

        {/* AI summary */}
        <p className="text-[11px] text-foreground/75 leading-snug line-clamp-2" title={control.aiSummary}>
          <Sparkles size={9} className="inline mr-1 text-cyan-400" />
          {control.aiSummary}
        </p>

        {/* rect */}
        <div className="text-[9px] font-mono text-muted-foreground/80">
          rect: {control.rect.x},{control.rect.y} → {control.rect.w}×{control.rect.h}
        </div>

        {/* actions */}
        <div className="flex items-center gap-1 mt-1 pt-2 border-t border-border/50">
          <button
            onClick={onWatch}
            className={cn(
              "flex-1 h-7 rounded-md text-[10px] font-medium flex items-center justify-center gap-1 transition border",
              control.watching
                ? "bg-teal-500/20 text-teal-200 border-teal-400/40 hover:bg-teal-500/30"
                : "bg-muted/60 text-muted-foreground border-border hover:bg-accent"
            )}
            aria-pressed={control.watching}
          >
            {control.watching ? <EyeOff size={12} /> : <Eye size={12} />}
            {control.watching ? "Не читать" : "Читать ИИ"}
          </button>
          <button
            onClick={onClick}
            className="h-7 px-2 rounded-md text-[10px] font-medium bg-amber-500/15 text-amber-200 border border-amber-400/30 hover:bg-amber-500/25 flex items-center gap-1"
            title="Кликнуть (uia_click)"
            disabled={!control.enabled}
          >
            <MousePointerClick size={12} />
            <span className="hidden sm:inline">Клик</span>
          </button>
          <button
            onClick={onAsk}
            className="h-7 px-2 rounded-md text-[10px] font-medium bg-cyan-500/15 text-cyan-200 border border-cyan-400/30 hover:bg-cyan-500/25 flex items-center gap-1"
            title="Спросить ИИ"
          >
            <Bot size={12} />
            <span className="hidden sm:inline">Спросить</span>
          </button>
        </div>
      </div>
    </article>
  );
}
