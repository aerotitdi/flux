"use client";

import { useEffect, useState } from "react";
import { useFlux } from "./store";
import { CosmicCanvas } from "./cosmic-canvas";
import {
  Play, Square, Copy, Check, Trash2, Terminal, Cpu, Clock, Zap, AlertCircle, CheckCircle2,
} from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface Engine { id: string; label: string; cmd: string }
interface RunResult { ok: boolean; rc: number; stdout: string; stderr: string; time: number; engine?: string; cmd?: string }
interface HistoryItem { id: string; engine: string; code: string; result: RunResult; ts: number }

const DEFAULT_CODE: Record<string, string> = {
  python: `# FLUX Code Playground — Python
# Попробуй: выведи квадраты чисел от 0 до 9

def squares(n):
    return [i**2 for i in range(n)]

print(6 * 7)
print(squares(10))

import math
print(f"pi = {math.pi:.4f}")
`,
  node: `// FLUX Code Playground — Node.js
const squares = [...Array(10).keys()].map(i => i*i);
console.log(6 * 7);
console.log(squares);
console.log("pi =", Math.PI.toFixed(4));
`,
  rust: `// FLUX Code Playground — Rust
fn main() {
    let squares: Vec<i32> = (0..10).map(|i| i*i).collect();
    println!("{}", 6 * 7);
    println!("{:?}", squares);
    println!("pi = {:.4}", std::f64::consts::PI);
}
`,
};

export function CodePlaygroundView() {
  const { setStatusText, setAgentState } = useFlux();
  const [engines, setEngines] = useState<Engine[]>([]);
  const [engine, setEngine] = useState("python");
  const [code, setCode] = useState(DEFAULT_CODE.python);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<RunResult | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch("/api/runcode");
        const d = await r.json();
        if (Array.isArray(d.engines)) setEngines(d.engines);
      } catch { /* noop */ }
    })();
  }, []);

  const run = async () => {
    if (running || !code.trim()) return;
    setRunning(true);
    setAgentState("think");
    setStatusText(`🔧 code_test → engine: ${engine}`);
    setResult(null);
    try {
      const r = await fetch("/api/runcode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, engine }),
      });
      const d: RunResult = await r.json();
      setResult(d);
      setHistory((h) => [
        { id: "h" + Date.now(), engine, code: code.slice(0, 200), result: d, ts: Date.now() },
        ...h,
      ].slice(0, 8));
      setAgentState("speak");
      setStatusText(d.ok ? `Готово: code_test ${engine} → rc=${d.rc} за ${d.time}мс` : `Ошибка: ${d.stderr}`);
    } catch (e: unknown) {
      const err = e as Error;
      setResult({ ok: false, rc: 1, stdout: "", stderr: err.message, time: 0 });
      setStatusText(`Ошибка: ${err.message}`);
    } finally {
      setRunning(false);
      setTimeout(() => setAgentState("idle"), 1500);
    }
  };

  const stop = () => {
    setRunning(false);
    setAgentState("idle");
    setStatusText("Остановлено");
  };

  const switchEngine = (e: string) => {
    setEngine(e);
    if (DEFAULT_CODE[e]) setCode(DEFAULT_CODE[e]);
    setResult(null);
  };

  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="relative flex-1 flex flex-col overflow-hidden">
      <div className="absolute inset-0 opacity-25 pointer-events-none">
        <CosmicCanvas scene="supernova" agentState="idle" className="w-full h-full" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background pointer-events-none" />

      <div className="relative z-10 flex flex-col h-full">
        {/* toolbar */}
        <div className="px-3 sm:px-5 py-3 border-b border-border bg-card/50 backdrop-blur-md flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 mr-2">
            <Terminal size={18} className="text-emerald-400" />
            <h2 className="font-bold text-base sm:text-lg text-shimmer">Code Playground</h2>
            <Badge variant="outline" className="text-[10px] font-mono">{engines.length} движков</Badge>
          </div>
          <div className="flex-1" />
          <Select value={engine} onValueChange={switchEngine}>
            <SelectTrigger className="w-[180px] h-8 text-xs" aria-label="Движок">
              <Cpu size={12} className="mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {engines.map((e) => (
                <SelectItem key={e.id} value={e.id} className="text-xs font-mono">
                  {e.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="ghost" size="sm" onClick={copy} className="h-8 text-xs gap-1 text-muted-foreground hover:text-foreground">
            {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
            {copied ? "Скопировано" : "Копировать"}
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setCode(DEFAULT_CODE[engine] || "// ваш код\n")} className="h-8 text-xs gap-1 text-muted-foreground hover:text-foreground">
            <Trash2 size={12} />
            Сброс
          </Button>
          {running ? (
            <Button size="sm" variant="destructive" onClick={stop} className="h-8 px-4 text-xs gap-1.5">
              <Square size={12} className="fill-current" />
              Стоп
            </Button>
          ) : (
            <Button
              size="sm"
              onClick={run}
              disabled={!code.trim()}
              className="h-8 px-4 text-xs gap-1.5 bg-gradient-to-r from-emerald-500/80 to-cyan-500/80 hover:from-emerald-500 hover:to-cyan-500 text-white border-0"
            >
              <Play size={12} className="fill-current" />
              Запустить
            </Button>
          )}
        </div>

        {/* main split: editor + output */}
        <div className="flex-1 flex min-h-0 flex-col lg:flex-row">
          {/* editor */}
          <div className="flex-1 flex flex-col min-h-0 border-b lg:border-b-0 lg:border-r border-border">
            <div className="px-3 py-1.5 border-b border-border/50 bg-muted/30 flex items-center justify-between">
              <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-muted-foreground">
                <span className="flex gap-1">
                  <span className="w-2 h-2 rounded-full bg-red-400/70" />
                  <span className="w-2 h-2 rounded-full bg-amber-400/70" />
                  <span className="w-2 h-2 rounded-full bg-emerald-400/70" />
                </span>
                <code className="font-mono">main.{engine === "ts" ? "ts" : engine === "node" ? "js" : engine === "python" ? "py" : engine === "rust" ? "rs" : engine === "go" ? "go" : engine === "java" ? "java" : engine === "c" ? "c" : engine === "cpp" ? "cpp" : engine === "ruby" ? "rb" : engine === "php" ? "php" : engine === "bash" ? "sh" : engine === "powershell" ? "ps1" : engine === "sql" ? "sql" : engine === "lua" ? "lua" : engine === "perl" ? "pl" : engine === "kotlin" ? "kt" : "txt"}</code>
              </div>
              <span className="text-[10px] font-mono text-muted-foreground">{code.split("\n").length} строк · {code.length} симв.</span>
            </div>
            <Textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="flex-1 min-h-0 resize-none rounded-none border-0 bg-[#0b0d11] text-emerald-100/90 font-mono text-[12px] leading-relaxed focus-visible:ring-0"
              spellCheck={false}
              aria-label="Редактор кода"
              onKeyDown={(e) => {
                if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
                  e.preventDefault();
                  run();
                }
              }}
            />
          </div>

          {/* output */}
          <div className="lg:w-[420px] xl:w-[480px] flex flex-col min-h-0 bg-[#0b0d11]">
            <div className="px-3 py-1.5 border-b border-border/50 bg-muted/30 flex items-center gap-2">
              {result?.ok ? (
                <CheckCircle2 size={12} className="text-emerald-400" />
              ) : result ? (
                <AlertCircle size={12} className="text-red-400" />
              ) : (
                <Terminal size={12} className="text-muted-foreground" />
              )}
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                {running ? "выполняется…" : result ? "результат" : "вывод"}
              </span>
              <div className="flex-1" />
              {result && (
                <>
                  {result.engine && (
                    <Badge variant="outline" className="text-[9px] py-0 px-1.5 font-mono">{result.engine}</Badge>
                  )}
                  {result.rc !== undefined && (
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[9px] py-0 px-1.5 font-mono",
                        result.rc === 0 ? "border-emerald-500/40 text-emerald-300" : "border-red-500/40 text-red-300"
                      )}
                    >
                      rc={result.rc}
                    </Badge>
                  )}
                  {result.time > 0 && (
                    <Badge variant="outline" className="text-[9px] py-0 px-1.5 font-mono">
                      <Clock size={9} className="mr-0.5" />
                      {result.time}мс
                    </Badge>
                  )}
                </>
              )}
            </div>
            <ScrollArea className="flex-1">
              <div className="p-3 font-mono text-[11px] leading-relaxed">
                {running && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                    <span>компиляция и запуск…</span>
                  </div>
                )}
                {!running && !result && (
                  <div className="text-muted-foreground text-center py-8">
                    <Terminal size={32} className="opacity-30 mx-auto mb-2" />
                    <p className="text-xs">Нажми «Запустить» или Ctrl+Enter</p>
                    <p className="text-[10px] mt-1">вывод появится здесь</p>
                  </div>
                )}
                {result && result.stdout && (
                  <pre className="text-emerald-200/90 whitespace-pre-wrap break-words">{result.stdout}</pre>
                )}
                {result && result.stderr && (
                  <pre className="text-red-300 whitespace-pre-wrap break-words mt-2">{result.stderr}</pre>
                )}
              </div>
            </ScrollArea>

            {/* history */}
            {history.length > 0 && (
              <div className="border-t border-border/50 max-h-40 overflow-y-auto flux-scroll">
                <div className="px-3 py-1.5 text-[10px] uppercase tracking-wider text-muted-foreground sticky top-0 bg-[#0b0d11]/90 backdrop-blur">
                  История ({history.length})
                </div>
                <div className="px-3 pb-2 space-y-1">
                  {history.map((h) => (
                    <div key={h.id} className="p-2 rounded-md bg-muted/30 border border-border/50 text-[10px]">
                      <div className="flex items-center gap-2 mb-0.5">
                        <code className="font-mono text-cyan-300">{h.engine}</code>
                        <Badge
                          variant="outline"
                          className={cn("text-[8px] py-0 px-1 font-mono", h.result.ok ? "border-emerald-500/40 text-emerald-300" : "border-red-500/40 text-red-300")}
                        >
                          {h.result.rc}
                        </Badge>
                        <span className="text-muted-foreground ml-auto">{new Date(h.ts).toLocaleTimeString("ru-RU")}</span>
                      </div>
                      <code className="font-mono text-muted-foreground line-clamp-1">{h.code.split("\n")[0]}</code>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* footer */}
        <div className="px-3 sm:px-5 py-2 border-t border-border bg-card/60 backdrop-blur-md flex flex-wrap items-center gap-2 text-[11px] font-mono text-muted-foreground">
          <span className="flex items-center gap-1">
            <Zap size={12} className="text-amber-400" />
            agent вызывает <code className="text-amber-300">code_test</code> с выбранным движком
          </span>
          <span className="opacity-30">·</span>
          <span>Ctrl+Enter — быстрый запуск</span>
          <span className="opacity-30">·</span>
          <span>15+ языков: python/node/ts/java/c/cpp/go/rust/ruby/php/bash/pwsh/sql/lua/perl/kt</span>
        </div>
      </div>
    </div>
  );
}
