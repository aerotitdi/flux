"use client";

import { Keyboard, X } from "lucide-react";
import {
  Dialog, DialogContent, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";

interface ShortcutGroup {
  label: string;
  items: { keys: string[]; description: string }[];
}

const GROUPS: ShortcutGroup[] = [
  {
    label: "Глобальные",
    items: [
      { keys: ["Cmd", "K"], description: "Открыть командную палитру" },
      { keys: ["?"], description: "Показать это окно горячих клавиш" },
      { keys: ["Esc"], description: "Закрыть модалку / палитру" },
    ],
  },
  {
    label: "Навигация",
    items: [
      { keys: ["1"], description: "Главная (сфера)" },
      { keys: ["2"], description: "Браузер-мост" },
      { keys: ["3"], description: "Приложения-мост" },
      { keys: ["4"], description: "UIA-мост (окна ОС)" },
      { keys: ["5"], description: "Память игр (офлайн)" },
      { keys: ["6"], description: "Чат" },
      { keys: ["7"], description: "Каталог тулзов" },
      { keys: ["8"], description: "Скиллы" },
      { keys: ["9"], description: "Память/Заметки/TODO" },
      { keys: ["0"], description: "Code Playground" },
    ],
  },
  {
    label: "Чат",
    items: [
      { keys: ["Enter"], description: "Отправить сообщение" },
      { keys: ["Shift", "Enter"], description: "Перенос строки" },
      { keys: ["Ctrl", "Enter"], description: "Отправить (из любого поля)" },
    ],
  },
  {
    label: "Code Playground",
    items: [
      { keys: ["Ctrl", "Enter"], description: "Запустить код" },
    ],
  },
  {
    label: "Командная палитра",
    items: [
      { keys: ["↑", "↓"], description: "Навигация по командам" },
      { keys: ["Enter"], description: "Выбрать команду" },
      { keys: ["Esc"], description: "Закрыть палитру" },
    ],
  },
  {
    label: "Действия",
    items: [
      { keys: ["S"], description: "Открыть настройки" },
      { keys: ["T"], description: "Цикл космических сцен (вперёд)" },
    ],
  },
];

export function ShortcutsHelp({ open, onOpenChange }: { open: boolean; onOpenChange: (b: boolean) => void }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden p-0 gap-0" aria-describedby={undefined}>
        <DialogTitle className="sr-only">Горячие клавиши</DialogTitle>
        <DialogDescription className="sr-only">
          Список всех горячих клавиш FLUX для навигации и действий.
        </DialogDescription>
        <div className="px-5 py-3 border-b border-border flex items-center gap-2">
          <Keyboard size={18} className="text-cyan-400" />
          <h2 className="font-bold text-base flex-1">Горячие клавиши</h2>
          <button
            onClick={() => onOpenChange(false)}
            className="w-7 h-7 rounded-md flex items-center justify-center text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Закрыть"
          >
            <X size={14} />
          </button>
        </div>
        <div className="overflow-y-auto flux-scroll max-h-[70vh]">
          <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
            {GROUPS.map((g) => (
              <div key={g.label}>
                <h3 className="text-[10px] uppercase tracking-wider text-muted-foreground font-mono mb-2 border-b border-border/50 pb-1">
                  {g.label}
                </h3>
                <div className="space-y-1.5">
                  {g.items.map((item) => (
                    <div key={item.description} className="flex items-center gap-2 text-xs">
                      <div className="flex items-center gap-0.5 shrink-0 min-w-[100px]">
                        {item.keys.map((k, i) => (
                          <span key={i} className="flex items-center gap-0.5">
                            {i > 0 && <span className="text-muted-foreground text-[10px]">+</span>}
                            <kbd className="px-1.5 py-0.5 rounded border border-border bg-muted/40 text-[10px] font-mono text-foreground/80">
                              {k}
                            </kbd>
                          </span>
                        ))}
                      </div>
                      <span className="text-foreground/75 truncate">{item.description}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="px-5 py-3 border-t border-border bg-muted/30 text-[10px] font-mono text-muted-foreground">
            <Badge variant="outline" className="text-[9px] mr-2">подсказка</Badge>
            Нажми <kbd className="px-1 py-0.5 rounded border border-border bg-muted/60 text-[10px]">?</kbd> в любом месте, чтобы открыть это окно снова.
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
