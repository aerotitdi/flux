"use client";

import { useEffect } from "react";
import { Activity, RefreshCw, Sparkles } from "lucide-react";
import { useFlux } from "./store";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const MODELS = [
  { value: "orca::flux-pro-1.1", label: "Flux Pro 1.1 · orca" },
  { value: "orca::flux-dev", label: "Flux Dev · orca" },
  { value: "openai::gpt-4o", label: "GPT-4o · openai" },
  { value: "ollama::llama3.1:8b", label: "Llama 3.1 8B · ollama" },
  { value: "ollama::qwen2.5:7b", label: "Qwen 2.5 7B · ollama" },
  { value: "openrouter::claude-3.5", label: "Claude 3.5 · openrouter" },
];

const SEARCHES = [
  { value: "duckduckgo", label: "DuckDuckGo" },
  { value: "searxng", label: "SearXNG" },
  { value: "bing", label: "Bing" },
  { value: "google", label: "Google" },
  { value: "wikipedia", label: "Wikipedia" },
  { value: "brave", label: "Brave" },
  { value: "off", label: "Без поиска" },
];

export function Header() {
  const {
    cdpOnline,
    cdpBrowser,
    cdpTabs,
    setCdp,
    modelRef,
    setModelRef,
    searchEngine,
    setSearchEngine,
  } = useFlux();

  // poll CDP status every 8s
  useEffect(() => {
    let active = true;
    const ping = async () => {
      try {
        const r = await fetch("/api/cdp");
        const d = await r.json();
        if (active) setCdp(!!d.ok, d.browser || "—", d.tabs || 0);
      } catch {
        if (active) setCdp(false, "—", 0);
      }
    };
    ping();
    const id = setInterval(ping, 8000);
    return () => {
      active = false;
      clearInterval(id);
    };
  }, [setCdp]);

  const reconnect = async () => {
    setCdp(false, "Подключение…", 0);
    try {
      await fetch("/api/cdp", { method: "POST" });
    } catch {
      /* noop */
    }
    setTimeout(async () => {
      try {
        const r = await fetch("/api/cdp");
        const d = await r.json();
        setCdp(!!d.ok, d.browser || "—", d.tabs || 0);
      } catch {
        setCdp(false, "—", 0);
      }
    }, 800);
  };

  return (
    <header
      className="flex items-center gap-2 sm:gap-3 px-3 sm:px-4 py-2 border-b border-border bg-card/60 backdrop-blur-md"
      role="banner"
    >
      <div className="flex items-center gap-2 font-bold tracking-tight whitespace-nowrap">
        <span className="text-gradient-cosmic text-lg sm:text-xl">FLUX</span>
        <span className="text-xs sm:text-sm text-muted-foreground font-mono">2.0</span>
      </div>

      <div className="hidden md:flex items-center gap-1 text-[11px] text-muted-foreground font-mono">
        <Sparkles size={12} className="text-cyan-400" />
        <span>357 тулзов · 6 скиллов</span>
      </div>

      <div className="flex-1" />

      {/* search selector */}
      <Select value={searchEngine} onValueChange={setSearchEngine}>
        <SelectTrigger className="w-[140px] sm:w-[180px] h-8 text-xs" aria-label="Поиск">
          <SelectValue placeholder="Поиск" />
        </SelectTrigger>
        <SelectContent>
          {SEARCHES.map((s) => (
            <SelectItem key={s.value} value={s.value} className="text-xs">
              Поиск: {s.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* model selector */}
      <Select value={modelRef} onValueChange={setModelRef}>
        <SelectTrigger className="w-[180px] sm:w-[260px] h-8 text-xs" aria-label="ИИ для чата">
          <SelectValue placeholder="Модель" />
        </SelectTrigger>
        <SelectContent>
          {MODELS.map((m) => (
            <SelectItem key={m.value} value={m.value} className="text-xs">
              {m.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* CDP indicator */}
      <button
        onClick={reconnect}
        className={cn(
          "group relative flex items-center gap-1.5 px-2.5 h-8 rounded-lg border transition",
          cdpOnline
            ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20"
            : "border-red-500/40 bg-red-500/10 text-red-300 hover:bg-red-500/20"
        )}
        title={
          cdpOnline
            ? `CDP 9222 OK: ${cdpBrowser} · вкладок: ${cdpTabs} (клик — переподключить)`
            : "CDP 9222 не подключён (клик — подключить к твоему Chrome)"
        }
        aria-label="Статус CDP-моста к браузеру"
      >
        <span className="relative flex h-2 w-2">
          {cdpOnline && (
            <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping" />
          )}
          <span
            className={cn(
              "relative inline-flex rounded-full h-2 w-2",
              cdpOnline ? "bg-emerald-400" : "bg-red-400"
            )}
          />
        </span>
        <Activity size={14} className="hidden sm:inline" />
        <span className="text-[11px] font-mono hidden sm:inline">
          {cdpOnline ? `${cdpTabs} вкладок` : "CDP"}
        </span>
        <RefreshCw size={12} className="opacity-0 group-hover:opacity-60 transition" />
      </button>
    </header>
  );
}
