"use client";

import { useFlux } from "./store";
import { CosmicCanvas, type SceneName } from "./cosmic-canvas";
import { Radio, Brain, Volume2, Moon, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { useEffect, useRef } from "react";

const SCENES: { id: SceneName; icon: string; label: string }[] = [
  { id: "uranus", icon: "🪐", label: "Уран — высший разум" },
  { id: "solar", icon: "☀", label: "Солнечная система" },
  { id: "galaxy", icon: "🌀", label: "Галактика Млечный Путь" },
  { id: "space", icon: "🌌", label: "Космос: туманности + чёрная дыра" },
  { id: "aurora", icon: "🌠", label: "Аврора — полярное сияние" },
  { id: "pulsar", icon: "✦", label: "Пульсар — нейтронная звезда" },
  { id: "nebula", icon: "☁", label: "Туманность — облако газа" },
  { id: "blackhole", icon: "⚫", label: "Чёрная дыра крупным планом" },
  { id: "supernova", icon: "💥", label: "Сверхновая — взрыв звезды" },
  { id: "solarflare", icon: "🌞", label: "Солнечная вспышка — протуберанцы" },
  { id: "quasar", icon: "🎯", label: "Квазар — джеты из чёрной дыры" },
  { id: "wormhole", icon: "🕳", label: "Кротовая нора — туннель света" },
  { id: "binarystar", icon: "💫", label: "Двойная звезда — аккреционный поток" },
  { id: "magnetar", icon: "🧲", label: "Магнетар — магнитное поле + джеты" },
  { id: "cosmicweb", icon: "🕸", label: "Космическая паутина — филаменты" },
  { id: "whitedwarf", icon: "⚪", label: "Белый карлик — кристаллизация" },
  { id: "nsmerger", icon: "🌠", label: "Слияние нейтронных звёзд — килонова" },
  { id: "accretiondisk", icon: "💿", label: "Аккреционный диск — спиральные волны" },
  { id: "pwn", icon: "🌟", label: "Туманность ветра пульсара — синхротрон" },
  { id: "tde", icon: "💥", label: "Приливное разрушение звезды" },
  { id: "grb", icon: "⚡", label: "Гамма-всплеск — релятивистские джеты" },
  { id: "magnetosphere", icon: "🌍", label: "Магнитосфера — поле + солнечный ветер" },
  { id: "hotjupiter", icon: "🪐", label: "Горячий юпитер — испаряющиеся полосы" },
  { id: "browndwarf", icon: "🌑", label: "Коричневый карлик — провалившаяся звезда" },
  { id: "protoplanetary", icon: "💿", label: "Протопланетный диск — формирующаяся планета" },
  { id: "hypergiant", icon: "🌟", label: "Гипергигант — чудовищная звезда" },
  { id: "wolfrayet", icon: "✦", label: "Wolf-Rayet — звёздный ветер + оболочка" },
  { id: "ringnebula", icon: "💍", label: "Кольцевая туманность — планетарная" },
  { id: "crabnebula", icon: "🦀", label: "Туманность Краба — остаток сверхновой" },
  { id: "solarouter", icon: "🪐", label: "Внешняя солнечная система" },
  { id: "helix", icon: "👁", label: "Туманность Геликс — глаз" },
  { id: "orion", icon: "⚔", label: "Туманность Ориона — колыбель звёзд" },
  { id: "eagle", icon: "🦅", label: "Туманность Орёл — столпы творения" },
];

const STATE_INFO: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  idle: { label: "Покой", color: "text-cyan-300", icon: <Moon size={14} /> },
  listen: { label: "Слушаю", color: "text-teal-300", icon: <Radio size={14} /> },
  think: { label: "Думаю", color: "text-purple-300", icon: <Brain size={14} /> },
  speak: { label: "Говорю", color: "text-emerald-300", icon: <Volume2 size={14} /> },
};

export function HomeView() {
  const { scene, setScene, agentState, statusText, tabs, apps } = useFlux();

  // demo: cycle agent state to show the scene reacts
  const idxRef = useRef(0);
  useEffect(() => {
    const states: ("idle" | "listen" | "think" | "speak")[] = ["idle", "listen", "think", "speak"];
    const id = setInterval(() => {
      idxRef.current = (idxRef.current + 1) % states.length;
    }, 4000);
    return () => clearInterval(id);
  }, []);

  const watchingTabs = tabs.filter((t) => t.watching).length;
  const runningApps = apps.filter((a) => a.running).length;
  const sInfo = STATE_INFO[agentState];

  return (
    <div className="relative flex-1 flex flex-col items-center justify-center overflow-hidden min-h-0">
      {/* cosmic canvas as the menu background */}
      <CosmicCanvas
        scene={scene}
        agentState={agentState}
        className="absolute inset-0 w-full h-full"
      />

      {/* scene selector */}
      <div className="absolute top-3 right-3 sm:top-4 sm:right-5 flex flex-wrap gap-1.5 z-10 max-w-[60vw] justify-end">
        {SCENES.map((s) => (
          <button
            key={s.id}
            onClick={() => setScene(s.id)}
            title={s.label}
            aria-label={s.label}
            aria-pressed={scene === s.id}
            className={cn(
              "w-8 h-8 sm:w-9 sm:h-9 rounded-lg flex items-center justify-center text-sm sm:text-base transition",
              "backdrop-blur-md bg-black/40 border border-white/10 hover:border-cyan-400/50 hover:bg-black/60",
              scene === s.id && "ring-1 ring-cyan-400 shadow-[0_0_18px_-4px_rgba(78,200,255,0.7)]"
            )}
          >
            {s.icon}
          </button>
        ))}
      </div>

      {/* status overlay */}
      <div className="relative z-10 flex flex-col items-center gap-2.5 sm:gap-3 px-4 sm:px-8 text-center max-w-2xl">
        <div
          className={cn(
            "flex items-center gap-2 text-[11px] sm:text-xs font-mono uppercase tracking-widest px-3 py-1 rounded-full backdrop-blur-md border",
            "bg-black/40 border-white/10",
            sInfo.color
          )}
        >
          {sInfo.icon}
          <span>{sInfo.label}</span>
          <span className="opacity-40">·</span>
          <span className="opacity-70">{agentState}</span>
        </div>

        <h1 className="text-xl sm:text-3xl font-bold text-gradient-cosmic text-shimmer">
          FLUX 2.0
        </h1>
        <p className="text-[11px] sm:text-sm text-muted-foreground max-w-md">
          Космический ИИ-ассистент · мост к твоему браузеру и приложениям
        </p>

        {/* status line */}
        <div className="px-3 py-1.5 rounded-lg backdrop-blur-md bg-black/40 border border-white/10 min-h-[32px] flex items-center gap-2 max-w-lg w-full">
          <Sparkles size={12} className="text-cyan-400 shrink-0" />
          <span className="text-[11px] sm:text-sm text-foreground/90 text-left line-clamp-2" aria-live="polite">
            {statusText}
          </span>
        </div>

        {/* mini stats */}
        <div className="flex flex-wrap justify-center gap-1.5 sm:gap-2">
          <StatPill label="Вкладок" value={tabs.length} accent="text-cyan-300" />
          <StatPill label="AI читает" value={watchingTabs} accent="text-teal-300" />
          <StatPill label="Приложений" value={apps.length} accent="text-purple-300" />
          <StatPill label="Запущено" value={runningApps} accent="text-emerald-300" />
        </div>
      </div>
    </div>
  );
}

function StatPill({ label, value, accent }: { label: string; value: number; accent: string }) {
  return (
    <div className="flex flex-col items-center px-2.5 py-1 rounded-lg backdrop-blur-md bg-black/40 border border-white/10 min-w-[64px]">
      <span className={cn("text-base font-bold font-mono", accent)}>{value}</span>
      <span className="text-[9px] uppercase tracking-wider text-muted-foreground">{label}</span>
    </div>
  );
}
