"use client";

import { useFlux } from "./store";
import { Cpu, Globe, AppWindow, Brain, Mic, Volume2, Zap, Wrench, BookOpen, NotebookPen } from "lucide-react";
import { cn } from "@/lib/utils";

export function Footer() {
  const {
    agentState, statusText, cdpOnline, cdpTabs, tabs, apps,
    uiaWindows, games, autospeak, tools, skills, brain,
  } = useFlux();

  const uiaControls = uiaWindows.reduce((s, w) => s + w.controls.length, 0);
  const uiaWatching = uiaWindows.reduce((s, w) => s + w.controls.filter((c) => c.watching).length, 0);
  const memAllowed = games.filter((g) => g.memoryAllowed).length;

  return (
    <footer
      className="shrink-0 border-t border-border bg-card/70 backdrop-blur-md px-3 sm:px-4 py-1.5 flex items-center gap-3 text-[10px] sm:text-[11px] font-mono text-muted-foreground overflow-x-auto flux-scroll"
      role="contentinfo"
    >
      <span className="flex items-center gap-1 shrink-0">
        <span className={cn(
          "w-1.5 h-1.5 rounded-full status-pulse",
          agentState === "idle" && "bg-cyan-400/70",
          agentState === "listen" && "bg-teal-400",
          agentState === "think" && "bg-purple-400",
          agentState === "speak" && "bg-emerald-400",
        )} />
        <span className="uppercase tracking-wider">{agentState}</span>
      </span>

      <span className="opacity-30 shrink-0">·</span>

      <span className="truncate flex-1 min-w-[120px]" title={statusText}>
        {statusText}
      </span>

      <span className="opacity-30 shrink-0 hidden sm:inline">·</span>

      <span className="flex items-center gap-1 shrink-0 hidden sm:flex">
        <Globe size={11} className={cdpOnline ? "text-emerald-400" : "text-red-400"} />
        <span>CDP</span>
        <span className={cdpOnline ? "text-emerald-300" : "text-red-300"}>
          {cdpOnline ? `${cdpTabs}` : "off"}
        </span>
      </span>

      <span className="opacity-30 shrink-0 hidden md:inline">·</span>

      <span className="flex items-center gap-1 shrink-0 hidden md:flex">
        <Globe size={11} className="text-cyan-400" />
        <span>{tabs.length} tabs</span>
      </span>

      <span className="opacity-30 shrink-0 hidden md:inline">·</span>

      <span className="flex items-center gap-1 shrink-0 hidden md:flex">
        <AppWindow size={11} className="text-purple-400" />
        <span>{apps.filter((a) => a.running).length}/{apps.length} app</span>
      </span>

      <span className="opacity-30 shrink-0 hidden lg:inline">·</span>

      <span className="flex items-center gap-1 shrink-0 hidden lg:flex">
        <Cpu size={11} className="text-cyan-400" />
        <span>UIA {uiaWatching}/{uiaControls}</span>
      </span>

      <span className="opacity-30 shrink-0 hidden lg:inline">·</span>

      <span className="flex items-center gap-1 shrink-0 hidden lg:flex">
        <Brain size={11} className={memAllowed > 0 ? "text-emerald-400" : "text-amber-400"} />
        <span>mem {memAllowed}/{games.length}</span>
      </span>

      <span className="opacity-30 shrink-0 hidden xl:inline">·</span>

      <span className="flex items-center gap-1 shrink-0 hidden xl:flex">
        <Wrench size={11} className="text-amber-400" />
        <span>{tools.length} тулзов</span>
      </span>

      <span className="opacity-30 shrink-0 hidden xl:inline">·</span>

      <span className="flex items-center gap-1 shrink-0 hidden xl:flex">
        <BookOpen size={11} className="text-emerald-400" />
        <span>{skills.length} скиллов</span>
      </span>

      <span className="opacity-30 shrink-0 hidden xl:inline">·</span>

      <span className="flex items-center gap-1 shrink-0 hidden xl:flex">
        <NotebookPen size={11} className="text-purple-400" />
        <span>{brain.notes.length + brain.todos.length + brain.facts.length} фактов</span>
      </span>

      <span className="opacity-30 shrink-0">·</span>

      <span className="flex items-center gap-1 shrink-0 hidden xl:flex">
        <Volume2 size={11} className={autospeak ? "text-emerald-400" : "text-muted-foreground/40"} />
        <span>{autospeak ? "озвучка вкл" : "озвучка выкл"}</span>
      </span>

      <span className="opacity-30 shrink-0 hidden xl:inline">·</span>

      <span className="flex items-center gap-1 shrink-0">
        <Zap size={11} className="text-amber-400" />
        <span>357 тулзов</span>
      </span>
    </footer>
  );
}
