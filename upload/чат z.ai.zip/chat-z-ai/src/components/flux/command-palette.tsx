"use client";

import { useEffect, useMemo, useState, useRef } from "react";
import { useFlux, type ViewName, type SceneName } from "./store";
import {
  Home, Globe, AppWindow, Cpu, Brain, MessageSquare, Wrench, BookOpen, NotebookPen,
  Terminal, Plug, Activity, Search, CornerDownLeft, Settings, Sparkles,
} from "lucide-react";
import {
  Dialog, DialogContent, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

interface CommandItem {
  id: string;
  label: string;
  hint: string;
  icon: React.ReactNode;
  group: "views" | "scenes" | "actions";
  action: () => void;
}

const VIEW_COMMANDS: { id: ViewName; label: string; icon: React.ReactNode }[] = [
  { id: "home", label: "Главная (сфера)", icon: <Home size={16} /> },
  { id: "browser", label: "Браузер-мост", icon: <Globe size={16} /> },
  { id: "apps", label: "Приложения-мост", icon: <AppWindow size={16} /> },
  { id: "uia", label: "UIA-мост (окна ОС)", icon: <Cpu size={16} /> },
  { id: "memory", label: "Память игр (офлайн)", icon: <Brain size={16} /> },
  { id: "chat", label: "Чат с FLUX", icon: <MessageSquare size={16} /> },
  { id: "tools", label: "Каталог тулзов (357)", icon: <Wrench size={16} /> },
  { id: "skills", label: "Скиллы (локал + NVIDIA)", icon: <BookOpen size={16} /> },
  { id: "brain", label: "Память/Заметки/TODO", icon: <NotebookPen size={16} /> },
  { id: "playground", label: "Code Playground", icon: <Terminal size={16} /> },
  { id: "connections", label: "Соединения (провайдеры)", icon: <Plug size={16} /> },
  { id: "selftest", label: "Self-Test / Диагностика", icon: <Activity size={16} /> },
];

const SCENE_COMMANDS: { id: SceneName; label: string; icon: string }[] = [
  { id: "uranus", label: "Уран — высший разум", icon: "🪐" },
  { id: "solar", label: "Солнечная система", icon: "☀" },
  { id: "galaxy", label: "Галактика Млечный Путь", icon: "🌀" },
  { id: "space", label: "Космос: туманности + чёрная дыра", icon: "🌌" },
  { id: "aurora", label: "Аврора — полярное сияние", icon: "🌠" },
  { id: "pulsar", label: "Пульсар — нейтронная звезда", icon: "✦" },
  { id: "nebula", label: "Туманность — облако газа", icon: "☁" },
  { id: "blackhole", label: "Чёрная дыра крупным планом", icon: "⚫" },
  { id: "supernova", label: "Сверхновая — взрыв звезды", icon: "💥" },
  { id: "solarflare", label: "Солнечная вспышка — протуберанцы", icon: "🌞" },
  { id: "quasar", label: "Квазар — джеты из чёрной дыры", icon: "🎯" },
  { id: "wormhole", label: "Кротовая нора — туннель света", icon: "🕳" },
  { id: "binarystar", label: "Двойная звезда — аккреционный поток", icon: "💫" },
  { id: "magnetar", label: "Магнетар — магнитное поле + джеты", icon: "🧲" },
  { id: "cosmicweb", label: "Космическая паутина — филаменты", icon: "🕸" },
  { id: "whitedwarf", label: "Белый карлик — кристаллизация", icon: "⚪" },
  { id: "nsmerger", label: "Слияние нейтронных звёзд — килонова", icon: "🌠" },
  { id: "accretiondisk", label: "Аккреционный диск — спиральные волны", icon: "💿" },
  { id: "pwn", label: "Туманность ветра пульсара — синхротрон", icon: "🌟" },
  { id: "tde", label: "Приливное разрушение звезды", icon: "💥" },
  { id: "grb", label: "Гамма-всплеск — релятивистские джеты", icon: "⚡" },
  { id: "magnetosphere", label: "Магнитосфера — поле + солнечный ветер", icon: "🌍" },
  { id: "hotjupiter", label: "Горячий юпитер — испаряющиеся полосы", icon: "🪐" },
  { id: "browndwarf", label: "Коричневый карлик — провалившаяся звезда", icon: "🌑" },
  { id: "protoplanetary", label: "Протопланетный диск — формирующаяся планета", icon: "💿" },
  { id: "hypergiant", label: "Гипергигант — чудовищная звезда", icon: "🌟" },
  { id: "wolfrayet", label: "Wolf-Rayet — звёздный ветер + оболочка", icon: "✦" },
  { id: "ringnebula", label: "Кольцевая туманность — планетарная", icon: "💍" },
  { id: "crabnebula", label: "Туманность Краба — остаток сверхновой", icon: "🦀" },
  { id: "solarouter", label: "Внешняя солнечная система", icon: "🪐" },
  { id: "helix", label: "Туманность Геликс — глаз", icon: "👁" },
  { id: "orion", label: "Туманность Ориона — колыбель звёзд", icon: "⚔" },
  { id: "eagle", label: "Туманность Орёл — столпы творения", icon: "🦅" },
];

export function CommandPalette({ open, onOpenChange, onOpenSettings }: { open: boolean; onOpenChange: (b: boolean) => void; onOpenSettings: () => void }) {
  const { setView, setScene, scene, view, clearChat, setAutospeak, autospeak } = useFlux();
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const commands: CommandItem[] = useMemo(() => {
    const items: CommandItem[] = [];
    // views
    for (const v of VIEW_COMMANDS) {
      items.push({
        id: `view-${v.id}`,
        label: v.label,
        hint: "Перейти",
        icon: v.icon,
        group: "views",
        action: () => { setView(v.id); onOpenChange(false); },
      });
    }
    // scenes
    for (const s of SCENE_COMMANDS) {
      items.push({
        id: `scene-${s.id}`,
        label: s.label,
        hint: "Сцена",
        icon: <span className="text-base">{s.icon}</span>,
        group: "scenes",
        action: () => { setScene(s.id); onOpenChange(false); },
      });
    }
    // actions
    items.push({
      id: "action-settings",
      label: "Открыть настройки",
      hint: "Действие",
      icon: <Settings size={16} />,
      group: "actions",
      action: () => { onOpenSettings(); onOpenChange(false); },
    });
    items.push({
      id: "action-toggle-autospeak",
      label: autospeak ? "Выключить озвучку ответов" : "Включить озвучку ответов",
      hint: "Действие",
      icon: <Sparkles size={16} />,
      group: "actions",
      action: () => { setAutospeak(!autospeak); onOpenChange(false); },
    });
    items.push({
      id: "action-clear-chat",
      label: "Очистить чат",
      hint: "Действие",
      icon: <MessageSquare size={16} />,
      group: "actions",
      action: () => { clearChat(); setView("chat"); onOpenChange(false); },
    });
    items.push({
      id: "action-current-scene",
      label: `Текущая сцена: ${SCENE_COMMANDS.find((s) => s.id === scene)?.label || scene}`,
      hint: "Инфо",
      icon: <Sparkles size={16} />,
      group: "actions",
      action: () => { onOpenChange(false); },
    });
    items.push({
      id: "action-current-view",
      label: `Текущий раздел: ${VIEW_COMMANDS.find((v) => v.id === view)?.label || view}`,
      hint: "Инфо",
      icon: <Sparkles size={16} />,
      group: "actions",
      action: () => { onOpenChange(false); },
    });
    return items;
  }, [setView, setScene, scene, view, autospeak, setAutospeak, clearChat, onOpenChange, onOpenSettings]);

  const filtered = useMemo(() => {
    if (!query.trim()) return commands;
    const q = query.toLowerCase();
    return commands.filter((c) => c.label.toLowerCase().includes(q) || c.hint.toLowerCase().includes(q) || c.group.includes(q));
  }, [commands, query]);

  // focus input when opened + reset state (safe: only runs on `open` transition)
  useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  // reset query + selection when palette closes (avoids stale state on next open)
  useEffect(() => {
    if (!open) {
      const id = setTimeout(() => { setQuery(""); setSelected(0); }, 100);
      return () => clearTimeout(id);
    }
  }, [open]);

  // clamp selection when filtered list shrinks (in-handler, not effect)
  const safeSelected = Math.min(selected, Math.max(0, filtered.length - 1));

  // keyboard navigation
  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelected((s) => Math.min(s + 1, filtered.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelected((s) => Math.max(s - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const item = filtered[safeSelected];
      if (item) item.action();
    } else if (e.key === "Escape") {
      onOpenChange(false);
    }
  };

  // group filtered items
  const groups = useMemo(() => {
    const g: Record<string, CommandItem[]> = { views: [], scenes: [], actions: [] };
    for (const c of filtered) g[c.group].push(c);
    return g;
  }, [filtered]);

  const groupLabels: Record<string, string> = {
    views: "Разделы",
    scenes: "Космические сцены",
    actions: "Действия",
  };

  // flatten for indexing
  const flat = [...groups.views, ...groups.scenes, ...groups.actions];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-xl p-0 gap-0 overflow-hidden top-[15vh] translate-y-0"
        onKeyDown={onKeyDown}
        aria-describedby={undefined}
      >
        <DialogTitle className="sr-only">Командная палитра</DialogTitle>
        <DialogDescription className="sr-only">
          Поиск разделов, космических сцен и действий. Используй стрелки для навигации, Enter для выбора, Escape для закрытия.
        </DialogDescription>
        {/* search input */}
        <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
          <Search size={16} className="text-muted-foreground shrink-0" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Поиск разделов, сцен, действий… (Cmd+K / Ctrl+K)"
            className="flex-1 bg-transparent outline-none text-sm placeholder:text-muted-foreground"
            aria-label="Поиск команд"
          />
          <kbd className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted/60 border border-border text-muted-foreground">ESC</kbd>
        </div>

        {/* results */}
        <div className="max-h-[60vh] overflow-y-auto flux-scroll">
          {flat.length === 0 ? (
            <div className="px-4 py-8 text-center text-xs text-muted-foreground">
              Ничего не найдено по запросу «{query}»
            </div>
          ) : (
            <div className="py-1.5">
              {Object.entries(groups).map(([g, items]) => {
                if (items.length === 0) return null;
                return (
                  <div key={g}>
                    <div className="px-4 pt-2 pb-1 text-[10px] uppercase tracking-wider text-muted-foreground font-mono">
                      {groupLabels[g]}
                    </div>
                    {items.map((item) => {
                      const idx = flat.indexOf(item);
                      const isSel = idx === safeSelected;
                      return (
                        <button
                          key={item.id}
                          onClick={() => item.action()}
                          onMouseEnter={() => setSelected(idx)}
                          className={cn(
                            "w-full px-4 py-2 flex items-center gap-3 text-left transition",
                            isSel ? "bg-cyan-500/15 text-cyan-100" : "hover:bg-accent"
                          )}
                        >
                          <span className={cn("shrink-0", isSel ? "text-cyan-300" : "text-muted-foreground")}>
                            {item.icon}
                          </span>
                          <span className="flex-1 text-xs truncate">{item.label}</span>
                          <span className="text-[10px] text-muted-foreground font-mono shrink-0">{item.hint}</span>
                          {isSel && <CornerDownLeft size={12} className="text-cyan-300 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* footer */}
        <div className="px-4 py-2 border-t border-border bg-muted/30 flex items-center justify-between text-[10px] font-mono text-muted-foreground">
          <span>↑↓ навигация · Enter выбрать · ESC закрыть</span>
          <span>{flat.length} команд</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}
