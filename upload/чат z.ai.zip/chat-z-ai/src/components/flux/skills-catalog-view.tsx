"use client";

import { useEffect, useMemo, useState } from "react";
import { useFlux, type Skill } from "./store";
import { CosmicCanvas } from "./cosmic-canvas";
import {
  BookOpen, Search, Filter, Bot, Sparkles, Star, Pin, PinOff, FileText, Cloud,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { StaggerContainer, StaggerItem } from "./motion";
import { cn } from "@/lib/utils";

const SOURCE_META = {
  local: { label: "Локальный", icon: <FileText size={11} />, accent: "text-emerald-300", bg: "bg-emerald-500/15 border-emerald-500/30" },
  nvidia: { label: "NVIDIA/skills", icon: <Cloud size={11} />, accent: "text-cyan-300", bg: "bg-cyan-500/15 border-cyan-500/30" },
};

export function SkillsCatalogView() {
  const { skills, setSkills, setStatusText, setView } = useFlux();
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [source, setSource] = useState("all");
  const [counts, setCounts] = useState({ local: 0, nvidia: 0, total: 0, catalog_total: 400 });
  const [selected, setSelected] = useState<Skill | null>(null);
  const [autoMatchQuery, setAutoMatchQuery] = useState("");
  const [autoMatchResult, setAutoMatchResult] = useState<Skill[]>([]);

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      try {
        const r = await fetch("/api/skills");
        const d = await r.json();
        if (active && Array.isArray(d.skills)) {
          setSkills(d.skills);
          setCounts(d.counts);
        }
      } catch { /* noop */ }
      finally { if (active) setLoading(false); }
    })();
    return () => { active = false; };
  }, [setSkills]);

  const filtered = useMemo(() => {
    let r = skills;
    if (source !== "all") r = r.filter((s) => s.source === source);
    if (query.trim()) {
      const q = query.toLowerCase();
      r = r.filter(
        (s) => s.name.toLowerCase().includes(q) || s.description.toLowerCase().includes(q) || s.category.toLowerCase().includes(q)
      );
    }
    return [...r].sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned) || a.name.localeCompare(b.name));
  }, [skills, source, query]);

  const autoMatch = async () => {
    if (!autoMatchQuery.trim()) return;
    try {
      const r = await fetch("/api/skills", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "auto_match", query: autoMatchQuery }),
      });
      const d = await r.json();
      if (d.ok && Array.isArray(d.matched)) setAutoMatchResult(d.matched);
    } catch { /* noop */ }
  };

  return (
    <div className="relative flex-1 flex flex-col overflow-hidden">
      <div className="absolute inset-0 opacity-25 pointer-events-none">
        <CosmicCanvas scene="nebula" agentState="idle" className="w-full h-full" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background pointer-events-none" />

      <div className="relative z-10 flex flex-col h-full">
        {/* toolbar */}
        <div className="px-3 sm:px-5 py-3 border-b border-border bg-card/50 backdrop-blur-md flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 mr-2">
            <BookOpen size={18} className="text-emerald-400" />
            <h2 className="font-bold text-base sm:text-lg text-shimmer">Каталог скиллов</h2>
            <Badge variant="outline" className="text-[10px] font-mono">
              {counts.total} / {counts.catalog_total}+
            </Badge>
            <Badge className="text-[10px] font-mono bg-emerald-500/15 text-emerald-300 border-emerald-500/30">
              {counts.local} локал
            </Badge>
            <Badge className="text-[10px] font-mono bg-cyan-500/15 text-cyan-300 border-cyan-500/30">
              {counts.nvidia} NVIDIA
            </Badge>
          </div>
          <div className="flex-1" />
          <div className="relative flex-1 min-w-[160px] max-w-[280px]">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Поиск скиллов…"
              className="h-8 pl-8 text-xs"
              aria-label="Поиск скиллов"
            />
          </div>
          <Select value={source} onValueChange={setSource}>
            <SelectTrigger className="w-[140px] h-8 text-xs" aria-label="Источник">
              <Filter size={12} className="mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all" className="text-xs">Все</SelectItem>
              <SelectItem value="local" className="text-xs">Локальные</SelectItem>
              <SelectItem value="nvidia" className="text-xs">NVIDIA</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* auto-match bar */}
        <div className="px-3 sm:px-5 py-2 border-b border-border/50 bg-card/30 flex flex-wrap items-center gap-2">
          <Sparkles size={13} className="text-cyan-400 shrink-0" />
          <span className="text-[11px] text-muted-foreground shrink-0">Авто-подбор:</span>
          <Input
            value={autoMatchQuery}
            onChange={(e) => setAutoMatchQuery(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") autoMatch(); }}
            placeholder="Напр.: найти титан в subnautica"
            className="h-7 flex-1 min-w-[140px] text-xs"
          />
          <Button size="sm" onClick={autoMatch} className="h-7 text-xs gap-1 bg-cyan-500/20 border border-cyan-400/40 text-cyan-200 hover:bg-cyan-500/30">
            <Bot size={11} />
            Подобрать
          </Button>
          {autoMatchResult.length > 0 && (
            <span className="text-[10px] text-emerald-300 font-mono">
              {autoMatchResult.length} совпадений
            </span>
          )}
        </div>

        {/* auto-match results */}
        {autoMatchResult.length > 0 && (
          <div className="px-3 sm:px-5 py-2 border-b border-border/50 bg-cyan-500/5">
            <div className="text-[10px] uppercase tracking-wider text-cyan-300 mb-1.5">Релевантные скиллы:</div>
            <div className="flex flex-wrap gap-1.5">
              {autoMatchResult.map((s) => {
                const m = SOURCE_META[s.source];
                return (
                  <button
                    key={s.id}
                    onClick={() => setSelected(s)}
                    className={cn("px-2 py-1 rounded-md border text-[10px] flex items-center gap-1 hover:bg-accent", m.bg, m.accent)}
                  >
                    {m.icon}
                    <span className="font-mono">{s.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* skills grid */}
        <ScrollArea className="flex-1">
          <div className="p-3 sm:p-5">
            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="rounded-lg glass-panel p-3 space-y-2">
                    <div className="h-3 w-2/3 rounded shimmer" />
                    <div className="h-2 w-full rounded shimmer" />
                  </div>
                ))}
              </div>
            ) : (
              <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {filtered.map((s) => {
                  const m = SOURCE_META[s.source];
                  return (
                    <StaggerItem key={s.id}>
                    <article
                      className={cn(
                        "game-card-hover card-lift rounded-xl overflow-hidden glass-panel border-gradient-cosmic cursor-pointer",
                        s.pinned && "ring-1 ring-amber-400/40"
                      )}
                      onClick={() => setSelected(s)}
                    >
                      <div className="p-3 space-y-2">
                        <div className="flex items-center gap-2">
                          <span className={cn("shrink-0", m.accent)}>{m.icon}</span>
                          <code className="text-xs font-mono text-foreground/90 truncate flex-1">{s.name}</code>
                          {s.pinned && <Pin size={11} className="text-amber-400 fill-amber-400/40 shrink-0" />}
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Badge variant="outline" className={cn("text-[9px] py-0 px-1.5 font-mono border", m.bg, m.accent)}>
                            {m.label}
                          </Badge>
                          <Badge variant="outline" className="text-[9px] py-0 px-1.5 font-mono">{s.category}</Badge>
                        </div>
                        <p className="text-[11px] text-foreground/75 leading-snug line-clamp-2">{s.description}</p>
                      </div>
                    </article>
                    </StaggerItem>
                  );
                })}
              </StaggerContainer>
            )}
          </div>
        </ScrollArea>

        {/* footer */}
        <div className="px-3 sm:px-5 py-2 border-t border-border bg-card/60 backdrop-blur-md flex flex-wrap items-center gap-2 text-[11px] font-mono text-muted-foreground">
          <span className="flex items-center gap-1">
            <Star size={12} className="text-amber-400" />
            авто-режим: 1-2 скилла впрыскиваются в системный промпт на каждый запрос
          </span>
          <span className="opacity-30">·</span>
          <span>каталог NVIDIA кэшируется на 24 ч, тела качаются по требованию</span>
        </div>
      </div>

      {/* detail modal */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden p-0 gap-0">
          <DialogHeader className="px-5 py-3 border-b border-border">
            <DialogTitle className="text-base flex items-center gap-2">
              {selected && SOURCE_META[selected.source].icon}
              <code className="font-mono text-emerald-300">{selected?.name}</code>
              {selected && (
                <Badge variant="outline" className={cn("text-[9px] font-mono border", SOURCE_META[selected.source].bg, SOURCE_META[selected.source].accent)}>
                  {SOURCE_META[selected.source].label}
                </Badge>
              )}
            </DialogTitle>
            <DialogDescription className="text-xs">{selected?.description}</DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[55vh]">
            <div className="p-5 space-y-3">
              <div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">Тело скилла (SKILL.md)</div>
                <pre className="text-[11px] font-mono text-foreground/85 leading-relaxed bg-muted/40 border border-border/50 rounded-md p-3 whitespace-pre-wrap">
{selected?.body}
                </pre>
              </div>
              <div className="flex items-center justify-between gap-2 pt-2 border-t border-border">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 text-xs gap-1"
                  onClick={async () => {
                    if (!selected) return;
                    try {
                      await fetch("/api/skills", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ action: "toggle_pin", id: selected.id }),
                      });
                    } catch { /* noop */ }
                    setSelected({ ...selected, pinned: !selected.pinned });
                  }}
                >
                  {selected?.pinned ? <PinOff size={12} /> : <Pin size={12} />}
                  {selected?.pinned ? "Открепить" : "Закрепить"}
                </Button>
                <Button
                  size="sm"
                  className="h-8 text-xs gap-1 bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/30"
                  onClick={() => {
                    if (!selected) return;
                    setView("chat");
                    setSelected(null);
                    setStatusText(`📚 скилл ${selected.name} активирован для чата`);
                  }}
                >
                  <Bot size={12} />
                  Использовать в чате
                </Button>
              </div>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
