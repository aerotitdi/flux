"use client";

import { useEffect, useRef, useState } from "react";
import { useFlux, type ChatMessage } from "./store";
import { CosmicCanvas } from "./cosmic-canvas";
import {
  Send, Mic, Brain, Search, Wrench, Bot, Sparkles,
  RefreshCw, ClipboardCopy, Check, Square, ExternalLink, PanelRightOpen, X,
} from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StaggerItem } from "./motion";
import { cn } from "@/lib/utils";

const ZAI_SHARED_URL = "https://chat.z.ai/s/51186326-0b08-4fc5-8dec-43b96132fdfb";

const SAMPLE_PROMPTS = [
  "Какие вкладки открыты в браузере?",
  "Какие игры сейчас играются?",
  "Запусти Steam",
  "Найди ближайший титан в Subnautica",
  "Какие окна открыты в UIA?",
];

export function ChatPanel() {
  const {
    messages, pushMessage, clearChat, autospeak, thinkMode, searchEngine,
    setStatusText, setAgentState, agentState,
    tabs, apps, uiaWindows, games,
    zaiPanelOpen, setZaiPanelOpen,
  } = useFlux();

  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [recording, setRecording] = useState(false);
  const [historyLoaded, setHistoryLoaded] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const savedIdsRef = useRef<Set<string>>(new Set());

  // Load persisted chat history from SQLite on mount
  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const r = await fetch("/api/chat-history");
        const d = await r.json();
        if (active && Array.isArray(d.messages) && d.messages.length > 0) {
          // Only load if store is empty (don't overwrite current session)
          if (useFlux.getState().messages.length === 0) {
            useFlux.setState({ messages: d.messages });
            setStatusText(`Восстановлено ${d.count} сообщений из истории`);
          }
        }
      } catch { /* noop */ }
      finally { if (active) setHistoryLoaded(true); }
    })();
    return () => { active = false; };
  }, [setStatusText]);

  // Save message to SQLite whenever a new message is pushed
  // (only after history is loaded to avoid saving the loaded messages back)
  useEffect(() => {
    if (!historyLoaded || messages.length === 0) return;
    const lastMsg = messages[messages.length - 1];
    // Save only if this message hasn't been saved yet (simple dedup by id)
    if (savedIdsRef.current.has(lastMsg.id)) return;
    savedIdsRef.current.add(lastMsg.id);
    fetch("/api/chat-history", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "save", message: lastMsg }),
    }).catch(() => {});
  }, [messages, historyLoaded]);

  // auto-scroll on new message
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, busy]);

  // patch helper: replace the AI message with the given id
  const patchAi = (id: string, patch: Partial<ChatMessage>) => {
    useFlux.setState((s) => {
      const idx = s.messages.findIndex((m) => m.id === id);
      if (idx < 0) return s;
      const copy = [...s.messages];
      copy[idx] = { ...copy[idx], ...patch };
      return { messages: copy };
    });
  };

  const send = async (textOverride?: string) => {
    const text = (textOverride ?? input).trim();
    if (!text || busy) return;
    setInput("");
    setBusy(true);
    setAgentState("listen");
    setStatusText("Слушаю…");

    pushMessage({
      id: "u" + Date.now(),
      role: "user",
      text,
      ts: Date.now(),
    });

    const aiId = "a" + Date.now();
    pushMessage({
      id: aiId,
      role: "assistant",
      text: "",
      ts: Date.now(),
      toolCalls: [],
    });

    abortRef.current = new AbortController();
    try {
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text,
          thinkMode,
          searchEngine,
          autospeak,
          history: messages.slice(-6),
          context: {
            tabs: tabs.map((t) => ({
              id: t.id, title: t.title, url: t.url, category: t.category,
              aiLink: t.aiLink, aiSummary: t.aiSummary, tags: t.tags, watching: t.watching,
            })),
            apps: apps
              .filter((a) => a.running)
              .map((a) => ({
                id: a.id, name: a.name, category: a.category,
                description: a.description, running: a.running,
                aiLink: a.aiLink, aiSummary: a.aiSummary, watching: a.watching,
              })),
            uia: {
              windows: uiaWindows.length,
              controls: uiaWindows.reduce((s, w) => s + w.controls.length, 0),
              watching: uiaWindows.reduce((s, w) => s + w.controls.filter((c) => c.watching).length, 0),
            },
            games: games
              .filter((g) => g.memoryAllowed && g.offline)
              .map((g) => ({
                id: g.slug, name: g.name, offline: g.offline, memoryAllowed: g.memoryAllowed,
                player: g.player, nearest: g.nearest,
              })),
          },
        }),
        signal: abortRef.current.signal,
      });
      if (!r.body) throw new Error("no body");

      const reader = r.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      const tools: { name: string; ok: boolean; preview: string }[] = [];
      let aiThinkMode: ChatMessage["thinkMode"] = undefined;
      let searchUsed = false;
      let skillName: string | undefined;
      let finalText = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const data = line.slice(6).trim();
          if (data === "[DONE]") continue;
          let ev: { type: string; [k: string]: unknown };
          try {
            ev = JSON.parse(data);
          } catch {
            continue;
          }
          switch (ev.type) {
            case "think":
              aiThinkMode = ev.mode as ChatMessage["thinkMode"];
              setAgentState("think");
              setStatusText(`Думаю… (${aiThinkMode}${ev.search ? " + поиск" : ""})`);
              patchAi(aiId, { thinkMode: aiThinkMode });
              break;
            case "search":
              searchUsed = true;
              setStatusText(`🔍 ${ev.engine} — нашёл ${ev.n}`);
              patchAi(aiId, { searchUsed: true });
              break;
            case "skill":
              skillName = ev.name as string;
              setStatusText(`📚 скилл: ${skillName}`);
              patchAi(aiId, { skillUsed: skillName });
              break;
            case "tool_start":
              setAgentState("think");
              setStatusText(`🔧 ${ev.name}`);
              break;
            case "tool_end":
              tools.push({
                name: ev.name as string,
                ok: !!ev.ok,
                preview: (ev.preview as string) || "",
              });
              patchAi(aiId, { toolCalls: [...tools] });
              setAgentState("speak");
              setStatusText("Говорю…");
              break;
            case "token":
              finalText += ev.text as string;
              patchAi(aiId, { text: finalText });
              break;
            case "done":
              finalText = (ev.text as string) || finalText;
              patchAi(aiId, { text: finalText, searchUsed, skillUsed: skillName, toolCalls: [...tools], thinkMode: aiThinkMode });
              setStatusText(
                `Готово: ${finalText
                  .replace(/\*-|\-\*/g, "")
                  .trim()
                  .slice(0, 60)}…`
              );
              setAgentState("idle");
              break;
            case "error":
              patchAi(aiId, { text: `Ошибка: ${ev.text}` });
              setStatusText(`Ошибка: ${ev.text}`);
              setAgentState("idle");
              break;
          }
        }
      }
    } catch (e: unknown) {
      const err = e as Error;
      if (err.name !== "AbortError") {
        pushMessage({
          id: "a" + Date.now(),
          role: "assistant",
          text: `Ошибка: ${err.message}`,
          ts: Date.now(),
        });
      }
      setStatusText("Готово к новому запросу");
      setAgentState("idle");
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  };

  const toggleMic = () => {
    setRecording((r) => !r);
    setStatusText(recording ? "Микрофон выкл" : "🎤 слушаю…");
    if (!recording) {
      setAgentState("listen");
      setTimeout(() => {
        setRecording(false);
        setAgentState("idle");
        setStatusText("Распознал — нажми Send");
      }, 2200);
    } else {
      setAgentState("idle");
    }
  };

  const stop = () => {
    abortRef.current?.abort();
    setBusy(false);
    setAgentState("idle");
    setStatusText("Остановлено");
  };

  return (
    <div className="relative flex-1 flex flex-col overflow-hidden">
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <CosmicCanvas scene="uranus" agentState={agentState} className="w-full h-full" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background/60 to-background pointer-events-none" />

      <div className="relative z-10 flex flex-col h-full">
        {/* toolbar */}
        <div className="px-3 sm:px-5 py-2.5 border-b border-border bg-card/60 backdrop-blur-md flex items-center gap-2">
          <Bot size={18} className="text-cyan-400" />
          <h2 className="font-bold text-base sm:text-lg text-shimmer">Чат с FLUX</h2>
          <Badge variant="outline" className="text-[10px] font-mono">
            {messages.length} сообщ.
          </Badge>
          {busy && (
            <Badge className="text-[10px] font-mono bg-purple-500/20 text-purple-200 border-purple-400/40">
              <Brain size={9} className="mr-0.5 animate-pulse" />
              {thinkMode}
            </Badge>
          )}
          <div className="flex-1" />
          {/* z.ai shared chat toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setZaiPanelOpen(true)}
            className="h-8 text-xs text-cyan-300 hover:text-cyan-200 hover:bg-cyan-500/10"
            title="Открыть общий чат z.ai"
          >
            <PanelRightOpen size={14} className="mr-1" />
            z.ai чат
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              clearChat();
              savedIdsRef.current.clear();
              fetch("/api/chat-history", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ action: "clear" }),
              }).catch(() => {});
              setStatusText("Чат очищен + история удалена из SQLite");
            }}
            className="h-8 text-xs text-muted-foreground hover:text-foreground"
          >
            <RefreshCw size={12} className="mr-1" />
            Очистить
          </Button>
        </div>

        {/* messages — native scroll */}
        <div
          ref={scrollRef}
          className="flex-1 overflow-y-auto flux-scroll"
          aria-live="polite"
          aria-atomic="false"
        >
          <div className="p-3 sm:p-5 space-y-3 max-w-4xl mx-auto">
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-400/30 via-purple-500/30 to-emerald-400/30 flex items-center justify-center text-3xl mb-4 float-slow">
                  🪐
                </div>
                <h3 className="text-lg font-bold text-gradient-cosmic mb-2">Привет, я FLUX 2.0</h3>
                <p className="text-xs sm:text-sm text-muted-foreground max-w-md mb-5">
                  Спроси про вкладки браузера, запущенные приложения, напиши код или поищи свежее в сети.
                  Я вижу твой Chrome и работаю с ним через CDP-мост.
                </p>
                <div className="flex flex-col gap-1.5 max-w-md w-full">
                  {SAMPLE_PROMPTS.map((p) => (
                    <button
                      key={p}
                      onClick={() => send(p)}
                      className="text-left text-xs sm:text-sm px-3 py-2 rounded-lg border border-border bg-card/50 hover:bg-accent hover:border-cyan-400/40 transition text-foreground/80"
                    >
                      <Sparkles size={11} className="inline mr-1.5 text-cyan-400" />
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((m) => (
              <StaggerItem key={m.id}>
                <MessageRow msg={m} />
              </StaggerItem>
            ))}

            {busy && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground pl-2">
                <div className="flex gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" />
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce"
                    style={{ animationDelay: "150ms" }}
                  />
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce"
                    style={{ animationDelay: "300ms" }}
                  />
                </div>
                <span className="font-mono">{useFlux.getState().statusText}</span>
              </div>
            )}
          </div>
        </div>

        {/* sample prompts strip */}
        {messages.length > 0 && !busy && (
          <div className="px-3 sm:px-5 py-1.5 border-t border-border/50 bg-card/30 flex gap-1.5 overflow-x-auto flux-scroll">
            {SAMPLE_PROMPTS.map((p) => (
              <button
                key={p}
                onClick={() => send(p)}
                className="shrink-0 text-[11px] px-2 py-1 rounded-full border border-border bg-card/60 hover:bg-accent hover:border-cyan-400/40 transition text-foreground/70"
              >
                {p}
              </button>
            ))}
          </div>
        )}

        {/* input footer */}
        <div className="px-3 sm:px-5 py-3 border-t border-border bg-card/80 backdrop-blur-md flex items-end gap-2">
          <button
            onClick={toggleMic}
            className={cn(
              "shrink-0 w-10 h-10 rounded-lg flex items-center justify-center border transition",
              recording
                ? "bg-red-500/30 border-red-400/60 text-red-200 mic-rec"
                : "bg-muted/60 border-border text-muted-foreground hover:bg-accent hover:text-foreground"
            )}
            aria-pressed={recording}
            aria-label="Микрофон (браузерный)"
            title={recording ? "Записываю…" : "Микрофон (браузерный)"}
          >
            <Mic size={16} />
          </button>

          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Сообщение… (Enter — отправить, Shift+Enter — перенос)"
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                if (busy) stop();
                else send();
              }
            }}
            className="flex-1 min-h-[40px] max-h-[160px] resize-none text-sm"
            aria-label="Поле ввода сообщения"
          />

          {busy ? (
            <Button
              size="sm"
              variant="destructive"
              onClick={stop}
              className="h-10 px-4 gap-1.5"
            >
              <Square size={12} className="fill-current" />
              Стоп
            </Button>
          ) : (
            <Button
              size="sm"
              onClick={() => send()}
              disabled={!input.trim()}
              className="h-10 px-4 gap-1.5 bg-gradient-to-r from-cyan-500/80 to-purple-500/80 hover:from-cyan-500 hover:to-purple-500 text-white border-0"
            >
              <Send size={14} />
              Отправить
            </Button>
          )}
        </div>
      </div>

      {/* z.ai shared chat slide-over panel */}
      {zaiPanelOpen && (
        <div className="absolute inset-y-0 right-0 z-30 w-full sm:w-[420px] lg:w-[480px] glass-panel border-l border-cyan-400/30 shadow-2xl flex flex-col">
          <div className="px-3 py-2 border-b border-border bg-card/60 backdrop-blur-md flex items-center gap-2">
            <Sparkles size={14} className="text-cyan-400" />
            <h3 className="font-semibold text-sm flex-1">Общий чат z.ai</h3>
            <a
              href={ZAI_SHARED_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="h-7 w-7 rounded-md flex items-center justify-center text-muted-foreground hover:bg-accent hover:text-foreground"
              title="Открыть в новой вкладке"
            >
              <ExternalLink size={13} />
            </a>
            <button
              onClick={() => setZaiPanelOpen(false)}
              className="h-7 w-7 rounded-md flex items-center justify-center text-muted-foreground hover:bg-accent hover:text-foreground"
              aria-label="Закрыть панель"
            >
              <X size={14} />
            </button>
          </div>
          <div className="flex-1 relative">
            <iframe
              src={ZAI_SHARED_URL}
              title="z.ai общий чат"
              className="absolute inset-0 w-full h-full"
              style={{ border: 0, background: "#0b0d12" }}
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
              loading="lazy"
            />
          </div>
          <div className="px-3 py-1.5 border-t border-border bg-card/60 backdrop-blur-md text-[10px] font-mono text-muted-foreground flex items-center gap-1.5">
            <Sparkles size={10} className="text-cyan-400" />
            <span>Этот чат z.ai — референс. FLUX работает с тем же GLM + 357 тулзов.</span>
          </div>
        </div>
      )}
    </div>
  );
}

function MessageRow({ msg }: { msg: ChatMessage }) {
  const isUser = msg.role === "user";
  const [copied, setCopied] = useState(false);

  const copy = () => {
    navigator.clipboard.writeText(msg.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const rendered = isUser ? (
    <p className="whitespace-pre-wrap break-words text-sm">{msg.text}</p>
  ) : (
    <AssistantContent msg={msg} />
  );

  return (
    <div className={cn("flex flex-col gap-1.5", isUser ? "items-end" : "items-start")}>
      {!isUser && (msg.toolCalls?.length || msg.searchUsed || msg.skillUsed || msg.thinkMode) && (
        <div className="flex flex-wrap gap-1.5 text-[10px]">
          {msg.thinkMode && msg.thinkMode !== "off" && (
            <Chip icon={<Brain size={10} />} text={`think: ${msg.thinkMode}`} variant="think" />
          )}
          {msg.searchUsed && (
            <Chip icon={<Search size={10} />} text="веб-поиск" variant="search" />
          )}
          {msg.skillUsed && (
            <Chip icon={<Sparkles size={10} />} text={`скилл: ${msg.skillUsed}`} variant="skill" />
          )}
 {msg.toolCalls?.map((t, i) => (
            <Chip
              key={i}
              icon={<Wrench size={10} />}
              text={t.name}
              variant={t.ok ? "ok" : "err"}
              title={t.preview}
            />
          ))}
        </div>
      )}

      <div
        className={cn(
          "group relative max-w-[88%] sm:max-w-[80%] rounded-xl px-3.5 py-2.5 chat-bubble-enter",
          isUser
            ? "bg-cyan-500/15 border border-cyan-400/30 text-foreground"
            : "glass-panel text-foreground"
        )}
      >
        {rendered}
        <button
          onClick={copy}
          className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-card border border-border opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-muted-foreground hover:text-foreground"
          aria-label="Копировать текст"
          title="Копировать как есть"
        >
          {copied ? <Check size={11} className="text-emerald-400" /> : <ClipboardCopy size={11} />}
        </button>
      </div>

      <span className="text-[10px] text-muted-foreground font-mono px-1">
        {new Date(msg.ts).toLocaleTimeString("ru-RU", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        })}
      </span>
    </div>
  );
}

function AssistantContent({ msg }: { msg: ChatMessage }) {
  const text = msg.text;
  if (!text) {
    return (
      <span className="inline-flex items-center gap-1.5 text-sm text-muted-foreground">
        <Sparkles size={12} className="animate-pulse text-cyan-400" />
        генерирую ответ…
      </span>
    );
  }

  const parts: { type: "text" | "code"; content: string; lang?: string }[] = [];
  let i = 0;
  while (i < text.length) {
    const start = text.indexOf("```", i);
    if (start < 0) {
      parts.push({ type: "text", content: text.slice(i) });
      break;
    }
    if (start > i) parts.push({ type: "text", content: text.slice(i, start) });
    const end = text.indexOf("```", start + 3);
    if (end < 0) {
      parts.push({ type: "code", content: text.slice(start + 3) });
      break;
    }
    const block = text.slice(start + 3, end);
    const nl = block.indexOf("\n");
    const lang = nl >= 0 ? block.slice(0, nl).trim() : "";
    const code = nl >= 0 ? block.slice(nl + 1) : "";
    parts.push({ type: "code", content: code, lang });
    i = end + 3;
  }

  return (
    <div className="text-sm leading-relaxed space-y-2">
      {parts.map((p, idx) =>
        p.type === "code" ? (
          <CodeBlock key={idx} code={p.content} lang={p.lang || "code"} />
        ) : (
          <VoiceMarkText key={idx} text={p.content} />
        )
      )}
    </div>
  );
}

function VoiceMarkText({ text }: { text: string }) {
  const regex = /\*-([\s\S]*?)-\*/g;
  const out: React.ReactNode[] = [];
  let last = 0;
  let m: RegExpExecArray | null;
  let k = 0;
  while ((m = regex.exec(text)) !== null) {
    if (m.index > last) out.push(<span key={k++}>{text.slice(last, m.index)}</span>);
    out.push(
      <span key={k++} className="voicemark" title="Эта часть озвучивается голосом">
        {m[1]}
      </span>
    );
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push(<span key={k++}>{text.slice(last)}</span>);
  return (
    <p className="whitespace-pre-wrap break-words [&_a]:text-cyan-300 [&_a]:underline">
      {out}
    </p>
  );
}

function CodeBlock({ code, lang }: { code: string; lang: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <div className="rounded-lg overflow-hidden border border-border bg-black/40 my-2">
      <div className="flex items-center justify-between px-2.5 py-1.5 bg-muted/40 border-b border-border">
        <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">
          {lang}
        </span>
        <div className="flex gap-1">
          <button
            onClick={copy}
            className="text-[10px] px-1.5 py-0.5 rounded bg-muted/60 text-muted-foreground hover:bg-accent hover:text-foreground flex items-center gap-1"
          >
            {copied ? <Check size={10} className="text-emerald-400" /> : <ClipboardCopy size={10} />}
            {copied ? "Скопировано" : "Копировать"}
          </button>
          <button
            className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 flex items-center gap-1"
            title="Прогнать через /api/runcode"
          >
            <Sparkles size={10} />
            Запустить
          </button>
        </div>
      </div>
      <pre className="p-2.5 text-[12px] font-mono overflow-x-auto flux-scroll bg-[#0b0d11] text-emerald-100/90">
        <code>{code}</code>
      </pre>
    </div>
  );
}

function Chip({
  icon,
  text,
  variant,
  title,
}: {
  icon: React.ReactNode;
  text: string;
  variant: "ok" | "err" | "think" | "search" | "skill";
  title?: string;
}) {
  const cls = {
    ok: "bg-emerald-500/15 border-emerald-400/40 text-emerald-300",
    err: "bg-red-500/15 border-red-400/40 text-red-300",
    think: "bg-amber-500/15 border-amber-400/40 text-amber-300",
    search: "bg-cyan-500/15 border-cyan-400/40 text-cyan-300",
    skill: "bg-purple-500/15 border-purple-400/40 text-purple-300",
  }[variant];
  return (
    <span
      className={cn("inline-flex items-center gap-1 px-2 py-0.5 rounded-full border font-mono", cls)}
      title={title}
    >
      {icon}
      {text}
    </span>
  );
}
