"use client";

import { useEffect, useMemo, useState } from "react";
import { useFlux, type AppItem } from "./store";
import { CosmicCanvas } from "./cosmic-canvas";
import {
  AppWindow, Play, Square, Pin, PinOff, Search, Filter, RefreshCw,
  Bot, Sparkles, Activity, Zap, Eye, EyeOff, Link2,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { StaggerContainer, StaggerItem } from "./motion";
import { cn } from "@/lib/utils";

const CATS: { id: AppItem["category"] | "all"; label: string; icon: string }[] = [
  { id: "all", label: "Все", icon: "◎" },
  { id: "game", label: "Игры", icon: "🎮" },
  { id: "dev", label: "Разработка", icon: "⚙" },
  { id: "media", label: "Медиа", icon: "🎬" },
  { id: "social", label: "Общение", icon: "💬" },
  { id: "work", label: "Работа", icon: "💼" },
  { id: "system", label: "Система", icon: "🖥" },
  { id: "utility", label: "Утилиты", icon: "🔧" },
];

export function AppsBridgeView() {
  const { apps, setApps, toggleRunning, togglePin, toggleAppWatch, launchApp, setStatusText, setView } = useFlux();
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<AppItem["category"] | "all">("all");

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      try {
        const r = await fetch("/api/apps");
        const d = await r.json();
        if (active && Array.isArray(d.apps)) setApps(d.apps);
      } catch {
        /* noop */
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [setApps]);

  const filtered = useMemo(() => {
    let r = apps;
    if (cat !== "all") r = r.filter((a) => a.category === cat);
    if (query.trim()) {
      const q = query.toLowerCase();
      r = r.filter(
        (a) =>
          a.name.toLowerCase().includes(q) ||
          a.description.toLowerCase().includes(q) ||
          a.category.toLowerCase().includes(q)
      );
    }
    // pinned first, then by launchCount desc
    return [...r].sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return (b.launchCount || 0) - (a.launchCount || 0);
    });
  }, [apps, cat, query]);

  const running = apps.filter((a) => a.running).length;
  const pinned = apps.filter((a) => a.pinned).length;

  const launch = async (id: string) => {
    launchApp(id);
    try {
      await fetch("/api/launch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, action: "launch" }),
      });
    } catch {
      /* noop */
    }
    const a = apps.find((x) => x.id === id);
    if (a) setStatusText(`🔧 app_launch → ${a.name} (PID: ${Math.floor(Math.random() * 9000 + 1000)})`);
  };

  const kill = async (id: string) => {
    toggleRunning(id);
    const a = apps.find((x) => x.id === id);
    if (a) setStatusText(`🔧 os_window_close → ${a.name}`);
    try {
      await fetch("/api/launch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, action: "kill" }),
      });
    } catch {
      /* noop */
    }
  };

  const askAbout = (id: string) => {
    setView("chat");
    const a = apps.find((x) => x.id === id);
    if (a) setStatusText(`ИИ переключился на ${a.name} — задайте вопрос`);
  };

  return (
    <div className="relative flex-1 flex flex-col overflow-hidden">
      <div className="absolute inset-0 opacity-30 pointer-events-none">
        <CosmicCanvas scene="galaxy" agentState="idle" className="w-full h-full" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background pointer-events-none" />

      <div className="relative z-10 flex flex-col h-full">
        {/* toolbar */}
        <div className="px-3 sm:px-5 py-3 border-b border-border bg-card/50 backdrop-blur-md flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 mr-2">
            <AppWindow size={18} className="text-purple-400" />
            <h2 className="font-bold text-base sm:text-lg text-shimmer">Приложения-мост</h2>
            <Badge variant="outline" className="text-[10px] font-mono">{apps.length} приложений</Badge>
            <Badge className="text-[10px] font-mono bg-emerald-500/15 text-emerald-300 border-emerald-500/30">
              <Activity size={9} className="mr-0.5" />
              {running} запущено
            </Badge>
            <Badge className="text-[10px] font-mono bg-amber-500/15 text-amber-300 border-amber-500/30">
              {pinned} закреплено
            </Badge>
          </div>

          <div className="flex-1" />

          <div className="relative flex-1 min-w-[160px] max-w-[280px]">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Поиск приложений…"
              className="h-8 pl-8 text-xs"
              aria-label="Поиск приложений"
            />
          </div>

          <Select value={cat} onValueChange={(v) => setCat(v as AppItem["category"] | "all")}>
            <SelectTrigger className="w-[140px] h-8 text-xs" aria-label="Фильтр категорий">
              <Filter size={12} className="mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CATS.map((c) => (
                <SelectItem key={c.id} value={c.id} className="text-xs">
                  {c.icon} {c.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* category chips */}
        <div className="px-3 sm:px-5 py-2 flex gap-1.5 overflow-x-auto flux-scroll border-b border-border/50 bg-card/30">
          {CATS.map((c) => {
            const count = c.id === "all" ? apps.length : apps.filter((a) => a.category === c.id).length;
            const active = cat === c.id;
            return (
              <button
                key={c.id}
                onClick={() => setCat(c.id)}
                className={cn(
                  "shrink-0 px-2.5 py-1 rounded-full text-[11px] font-mono transition border flex items-center gap-1",
                  active
                    ? "bg-purple-500/20 border-purple-400/50 text-purple-200"
                    : "bg-transparent border-border text-muted-foreground hover:text-foreground hover:bg-accent"
                )}
              >
                <span>{c.icon}</span>
                <span>{c.label}</span>
                <span className="opacity-50">{count}</span>
              </button>
            );
          })}
        </div>

        {/* apps grid */}
        <ScrollArea className="flex-1">
          <div className="p-3 sm:p-5">
            {loading ? (
              <SkeletonGrid />
            ) : filtered.length === 0 ? (
              <EmptyState />
            ) : (
              <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
                {filtered.map((app) => (
                  <StaggerItem key={app.id}>
                  <AppCard
                    app={app}
                    onLaunch={() => launch(app.id)}
                    onKill={() => kill(app.id)}
                    onPin={() => togglePin(app.id)}
                    onWatch={() => {
                      toggleAppWatch(app.id);
                      setStatusText(
                        app.watching
                          ? `Перестал читать ${app.aiLink || app.id}`
                          : `Готово: теперь ИИ читает ${app.aiLink} (${app.name})`
                      );
                    }}
                    onAsk={() => askAbout(app.id)}
                  />
                  </StaggerItem>
                ))}
              </StaggerContainer>
            )}
          </div>
        </ScrollArea>

        {/* footer */}
        <div className="px-3 sm:px-5 py-2 border-t border-border bg-card/60 backdrop-blur-md flex flex-wrap items-center gap-2 text-[11px] font-mono text-muted-foreground">
          <span className="flex items-center gap-1">
            <Zap size={12} className="text-amber-400" />
            agent вызывает <code className="text-amber-300">app_launch</code>
          </span>
          <span className="opacity-30">·</span>
          <span>Каждое приложение = карточка с состоянием и количеством запусков</span>
          <span className="opacity-30">·</span>
          <span>ИИ видит: какие запущены, какие закреплены, сколько раз открывались</span>
        </div>
      </div>
    </div>
  );
}

function AppCard({
  app,
  onLaunch,
  onKill,
  onPin,
  onWatch,
  onAsk,
}: {
  app: AppItem;
  onLaunch: () => void;
  onKill: () => void;
  onPin: () => void;
  onWatch: () => void;
  onAsk: () => void;
}) {
  const cat = CATS.find((c) => c.id === app.category);
  return (
    <article
      className={cn(
        "game-card-hover card-lift relative rounded-xl overflow-hidden glass-panel border-gradient-cosmic",
        app.running && "ring-1 ring-emerald-400/60 glow-green",
        app.pinned && "ring-1 ring-amber-400/40",
        app.watching && "ring-1 ring-teal-400/60"
      )}
    >
      {/* icon banner */}
      <div
        className="relative h-20 sm:h-24 flex items-center justify-center overflow-hidden"
        style={{
          background: `radial-gradient(circle at 50% 50%, ${app.accent}66, transparent 70%), linear-gradient(135deg, #14172a, #0b0d18)`,
        }}
      >
        <div className="text-5xl float-slow drop-shadow-lg" aria-hidden="true">
          {app.icon}
        </div>
        {/* running indicator */}
        {app.running && (
          <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/30 border border-emerald-400/50 text-[10px] text-emerald-100 font-mono backdrop-blur-sm">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping" />
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-400" />
            </span>
            ЗАПУЩЕНО
          </div>
        )}
        {/* AI reading badge */}
        {app.watching && (
          <div className="absolute top-2 left-1/2 -translate-x-1/2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-teal-500/30 border border-teal-400/50 text-[10px] text-teal-100 font-mono backdrop-blur-sm">
            <Eye size={10} />
            ИИ читает
          </div>
        )}
        {/* pin badge */}
        {app.pinned && (
          <div className="absolute top-2 right-2 text-amber-400">
            <Pin size={14} className="fill-amber-400/40" />
          </div>
        )}
        {/* launch count */}
        <div className="absolute bottom-2 right-2 text-[10px] font-mono text-white/60">
          ×{app.launchCount || 0}
        </div>
      </div>

      {/* content */}
      <div className="p-3 flex flex-col gap-2">
        <div className="flex items-start gap-2">
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-semibold leading-tight truncate" title={app.name}>
              {app.name}
            </h3>
            <div className="flex items-center gap-1.5 mt-0.5">
              <Badge variant="outline" className="text-[9px] py-0 px-1.5 font-mono">
                {cat?.icon} {cat?.label}
              </Badge>
            </div>
          </div>
        </div>

        {/* AI-readable link (same pattern as browser tabs) */}
        {app.aiLink && (
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-purple-500/10 border border-purple-400/30">
            <Link2 size={11} className="text-purple-300 shrink-0" />
            <code className="text-[10px] text-purple-200 font-mono truncate flex-1">{app.aiLink}</code>
            <span className="text-[9px] text-purple-300/70 font-mono shrink-0">ссылка</span>
          </div>
        )}

        {/* AI summary */}
        {app.aiSummary && (
          <p className="text-[11px] text-foreground/75 leading-snug line-clamp-2" title={app.aiSummary}>
            <Sparkles size={9} className="inline mr-1 text-purple-400" />
            {app.aiSummary}
          </p>
        )}

        {/* exe path */}
        {app.exe && (
          <div className="px-2 py-1 rounded bg-muted/50 border border-border/50">
            <code className="text-[9px] text-muted-foreground font-mono truncate block" title={app.exe}>
              {app.exe}
            </code>
          </div>
        )}

        {/* actions */}
        <div className="flex items-center gap-1 mt-1 pt-2 border-t border-border/50">
          {app.running ? (
            <button
              onClick={onKill}
              className="flex-1 h-7 rounded-md text-[10px] font-medium bg-red-500/15 text-red-200 border border-red-400/30 hover:bg-red-500/25 flex items-center justify-center gap-1"
            >
              <Square size={12} className="fill-current" />
              Остановить
            </button>
          ) : (
            <button
              onClick={onLaunch}
              className="flex-1 h-7 rounded-md text-[10px] font-medium bg-emerald-500/20 text-emerald-200 border border-emerald-400/40 hover:bg-emerald-500/30 flex items-center justify-center gap-1"
            >
              <Play size={12} className="fill-current" />
              Запустить
            </button>
          )}
          <button
            onClick={onWatch}
            className={cn(
              "h-7 w-7 rounded-md flex items-center justify-center border transition",
              app.watching
                ? "bg-teal-500/20 text-teal-200 border-teal-400/40 hover:bg-teal-500/30"
                : "bg-muted/60 text-muted-foreground border-border hover:bg-accent"
            )}
            title={app.watching ? "Перестать читать" : "Читать для ИИ"}
            aria-pressed={app.watching}
          >
            {app.watching ? <EyeOff size={12} /> : <Eye size={12} />}
          </button>
          <button
            onClick={onAsk}
            className="h-7 px-2 rounded-md text-[10px] font-medium bg-purple-500/15 text-purple-200 border border-purple-400/30 hover:bg-purple-500/25 flex items-center gap-1"
            title="Спросить ИИ об этом приложении"
          >
            <Bot size={12} />
            <span className="hidden sm:inline">Спросить</span>
          </button>
          <button
            onClick={onPin}
            className={cn(
              "h-7 w-7 rounded-md flex items-center justify-center border transition",
              app.pinned
                ? "bg-amber-500/15 text-amber-300 border-amber-400/40 hover:bg-amber-500/25"
                : "bg-muted/60 text-muted-foreground border-border hover:bg-accent"
            )}
            title={app.pinned ? "Открепить" : "Закрепить"}
            aria-pressed={app.pinned}
          >
            {app.pinned ? <PinOff size={12} /> : <Pin size={12} />}
          </button>
        </div>
      </div>
    </article>
  );
}

function SkeletonGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="rounded-xl overflow-hidden glass-panel">
          <div className="h-20 sm:h-24 shimmer" />
          <div className="p-3 space-y-2">
            <div className="h-3 w-2/3 rounded shimmer" />
            <div className="h-2 w-full rounded shimmer" />
          </div>
        </div>
      ))}
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center text-muted-foreground">
      <AppWindow size={48} className="opacity-40 mb-3" />
      <p className="text-sm">Приложений не найдено</p>
      <p className="text-xs mt-1">Попробуйте изменить фильтр или поисковый запрос</p>
    </div>
  );
}
