"use client";

import { useEffect, useState } from "react";
import { useFlux, type GameMemory } from "./store";
import { CosmicCanvas } from "./cosmic-canvas";
import {
  Brain, ShieldCheck, ShieldAlert, ShieldX, Eye, EyeOff, Zap,
  Crosshair, MapPin, Wind, Package, Sparkles, Activity, Lock,
  Unlock, AlertTriangle, Bot, Link2,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

export function GameMemoryView() {
  const { games, setGames, setMemoryAllowed, setStatusText, setView, setAgentState } = useFlux();
  const [loading, setLoading] = useState(true);
  const [confirmGame, setConfirmGame] = useState<GameMemory | null>(null);
  const [confirmChecked, setConfirmChecked] = useState(false);
  const [snapshot, setSnapshot] = useState<GameMemory | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      try {
        const r = await fetch("/api/games");
        const d = await r.json();
        if (active && Array.isArray(d.games)) setGames(d.games);
      } catch { /* noop */ }
      finally { if (active) setLoading(false); }
    })();
    return () => { active = false; };
  }, [setGames]);

  const safeGames = games.filter((g) => g.offline && g.whitelisted);
  const blockedGames = games.filter((g) => !g.offline || !g.whitelisted);
  const allowedCount = games.filter((g) => g.memoryAllowed).length;

  const requestAccess = async (g: GameMemory) => {
    if (g.antiCheat.detected || g.networkActivity || !g.offline || !g.whitelisted) {
      setStatusText(`ОТКАЗ: ${g.name} — онлайн-игра/анти-чит, чтение памяти запрещено`);
      return;
    }
    setConfirmGame(g);
    setConfirmChecked(false);
  };

  const grantAccess = async () => {
    if (!confirmGame || !confirmChecked) return;
    try {
      const r = await fetch("/api/games", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "grant_access", id: confirmGame.id }),
      });
      const d = await r.json();
      if (d.ok) {
        setMemoryAllowed(confirmGame.id, true);
        setStatusText(`Готово: выдан доступ к памяти ${confirmGame.name} (офлайн, проверено)`);
      }
    } catch { /* noop */ }
    setConfirmGame(null);
  };

  const revokeAccess = async (g: GameMemory) => {
    try {
      await fetch("/api/games", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "revoke_access", id: g.id }),
      });
    } catch { /* noop */ }
    setMemoryAllowed(g.id, false);
    setSnapshot(null);
    setStatusText(`Доступ к памяти ${g.name} отозван пользователем`);
  };

  const readMemory = async (g: GameMemory) => {
    setAgentState("think");
    setStatusText(`🔧 game_memory_read → ${g.slug} (PID ${g.processId})`);
    try {
      const r = await fetch("/api/games", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "read_memory", id: g.id }),
      });
      const d = await r.json();
      if (d.ok && d.snapshot) {
        setSnapshot({ ...g, ...d.snapshot });
        setAgentState("speak");
        setStatusText(`Готово: прочёл память ${g.name} — игрок в ${g.biome}, ближайший ${g.nearest?.[0]?.name || "ресурс"} в ${g.nearest?.[0]?.distance || "?"} м`);
      } else {
        setAgentState("idle");
        setStatusText(d.message || "Чтение памяти не удалось");
      }
    } catch (e) {
      setAgentState("idle");
      setStatusText("Ошибка чтения памяти");
    }
  };

  return (
    <div className="relative flex-1 flex flex-col overflow-hidden">
      <div className="absolute inset-0 opacity-25 pointer-events-none">
        <CosmicCanvas scene="space" agentState="idle" className="w-full h-full" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background pointer-events-none" />

      <div className="relative z-10 flex flex-col h-full">
        {/* toolbar */}
        <div className="px-3 sm:px-5 py-3 border-b border-border bg-card/50 backdrop-blur-md flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 mr-2">
            <Brain size={18} className="text-purple-400" />
            <h2 className="font-bold text-base sm:text-lg text-shimmer">Память игр</h2>
            <Badge variant="outline" className="text-[10px] font-mono">{games.length} игр</Badge>
            <Badge className="text-[10px] font-mono bg-emerald-500/15 text-emerald-300 border-emerald-500/30">
              {allowedCount} с доступом
            </Badge>
          </div>
          <div className="flex-1" />
          <Badge className="text-[10px] font-mono bg-amber-500/15 text-amber-300 border-amber-500/30">
            <ShieldCheck size={9} className="mr-0.5" />
            ОФЛАЙН ОДИночные ИГРЫ ТОЛЬКО
          </Badge>
        </div>

        {/* ETHICS WARNING BANNER */}
        <div className="mx-3 sm:mx-5 mt-3 p-3 rounded-lg border border-amber-500/40 bg-amber-500/10 backdrop-blur-md flex items-start gap-3">
          <AlertTriangle size={18} className="text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs sm:text-[13px] leading-snug">
            <p className="font-semibold text-amber-200 mb-0.5">
              Этический режим: только одиночные офлайн-игры
            </p>
            <p className="text-amber-100/80">
              FLUX читает память <b>только</b> игр, которые пользователь явно добавил в whitelist
              и вручную дал доступ. Если у игры есть анти-чит (VAC, EAC, BattlEye, Riot Vanguard)
              или сетевая активность — <b>доступ жёстко блокируется</b>. Использование для
              онлайн-игр = чит и бан. Это сравнимо с Verity (Minecraft single-player map viewer)
              и приемлемо только для одиночных игр.
            </p>
          </div>
        </div>

        <ScrollArea className="flex-1 mt-2">
          <div className="p-3 sm:p-5 space-y-4">
            {/* SAFE GAMES (whitelist + offline) */}
            <section>
              <div className="flex items-center gap-2 mb-2">
                <ShieldCheck size={14} className="text-emerald-400" />
                <h3 className="text-sm font-semibold">Офлайн одиночные игры (whitelist)</h3>
                <span className="text-[10px] font-mono text-muted-foreground">{safeGames.length} игр</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                {safeGames.map((g) => (
                  <GameCard
                    key={g.id}
                    game={g}
                    onRequest={() => requestAccess(g)}
                    onRevoke={() => revokeAccess(g)}
                    onRead={() => readMemory(g)}
                    onAsk={() => {
                      setView("chat");
                      setStatusText(`ИИ видит память ${g.slug} — задайте вопрос про ресурсы`);
                    }}
                    isSnapshot={snapshot?.id === g.id}
                  />
                ))}
                {safeGames.length === 0 && (
                  <div className="text-xs text-muted-foreground py-6 text-center col-span-full">
                    Нет игр в whitelist. Запустите одиночную игру и добавьте её.
                  </div>
                )}
              </div>
            </section>

            {/* BLOCKED GAMES (anti-cheat / online) */}
            <section>
              <div className="flex items-center gap-2 mb-2">
                <ShieldX size={14} className="text-red-400" />
                <h3 className="text-sm font-semibold">Заблокированы (анти-чит / онлайн)</h3>
                <span className="text-[10px] font-mono text-muted-foreground">{blockedGames.length} игр</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {blockedGames.map((g) => (
                  <BlockedGameCard key={g.id} game={g} />
                ))}
                {blockedGames.length === 0 && (
                  <div className="text-xs text-muted-foreground py-6 text-center col-span-full">
                    Нет заблокированных игр.
                  </div>
                )}
              </div>
            </section>

            {/* SNAPSHOT DETAIL (if any) */}
            {snapshot && (
              <section>
                <div className="flex items-center gap-2 mb-2">
                  <Crosshair size={14} className="text-cyan-400" />
                  <h3 className="text-sm font-semibold">Снимок памяти — {snapshot.name}</h3>
                  <Badge className="text-[9px] font-mono bg-cyan-500/15 text-cyan-300 border-cyan-500/30">
                    live ({new Date().toLocaleTimeString("ru-RU")})
                  </Badge>
                </div>
                <SnapshotDetail game={snapshot} />
              </section>
            )}
          </div>
        </ScrollArea>

        {/* footer */}
        <div className="px-3 sm:px-5 py-2 border-t border-border bg-card/60 backdrop-blur-md flex flex-wrap items-center gap-2 text-[11px] font-mono text-muted-foreground">
          <span className="flex items-center gap-1">
            <ShieldAlert size={12} className="text-amber-400" />
            agent вызывает <code className="text-amber-300">game_memory_read</code>
          </span>
          <span className="opacity-30">·</span>
          <span>только после явного разрешения пользователя</span>
          <span className="opacity-30">·</span>
          <span className="flex items-center gap-1">
            <Lock size={12} className="text-red-400" />
            анти-чит = отказ
          </span>
        </div>
      </div>

      {/* CONFIRMATION MODAL */}
      <Dialog open={!!confirmGame} onOpenChange={(o) => !o && setConfirmGame(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <Lock size={16} className="text-amber-400" />
              Подтвердите доступ к памяти
            </DialogTitle>
            <DialogDescription className="text-xs">
              Вы собираетесь дать FLUX доступ к памяти процесса{" "}
              <code className="text-foreground">{confirmGame?.exe}</code> ({confirmGame?.name}).
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3">
            <div className="p-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 space-y-1.5">
              <div className="flex items-center gap-2 text-xs">
                <ShieldCheck size={12} className="text-emerald-400" />
                <span>Игра офлайн (нет сетевой активности)</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <ShieldCheck size={12} className="text-emerald-400" />
                <span>Анти-чит не обнаружен</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <ShieldCheck size={12} className="text-emerald-400" />
                <span>Игра в whitelist одиночных игр</span>
              </div>
            </div>

            <div className="p-3 rounded-lg border border-amber-500/30 bg-amber-500/10">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <Switch checked={confirmChecked} onCheckedChange={setConfirmChecked} />
                <span className="text-xs leading-snug">
                  <b>Я подтверждаю:</b> {confirmGame?.name} — это одиночная офлайн-игра.
                  Использование для <b>онлайн-игр с анти-читом</b> (CS2, Valorant, Fortnite, Dota 2 ranked и т.п.)
                  запрещено и приравнивается к читерству. Я беру на себя ответственность за свой выбор.
                </span>
              </label>
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <Button variant="ghost" size="sm" onClick={() => setConfirmGame(null)} className="h-8 text-xs">
                Отмена
              </Button>
              <Button
                size="sm"
                onClick={grantAccess}
                disabled={!confirmChecked}
                className="h-8 text-xs gap-1.5 bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/30"
              >
                <Unlock size={12} />
                Дать доступ
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function GameCard({
  game,
  onRequest,
  onRevoke,
  onRead,
  onAsk,
  isSnapshot,
}: {
  game: GameMemory;
  onRequest: () => void;
  onRevoke: () => void;
  onRead: () => void;
  onAsk: () => void;
  isSnapshot: boolean;
}) {
  return (
    <article
      className={cn(
        "game-card-hover relative rounded-xl overflow-hidden glass-panel border-gradient-cosmic",
        game.memoryAllowed && "ring-1 ring-emerald-400/60 glow-green",
        isSnapshot && "ring-2 ring-cyan-400/70 glow-teal"
      )}
    >
      <div
        className="relative h-16 sm:h-20 flex items-center justify-between px-4 overflow-hidden"
        style={{
          background: `radial-gradient(circle at 20% 50%, ${game.memoryAllowed ? "rgba(62,207,142,0.25)" : "rgba(120,80,180,0.18)"}, transparent 70%), linear-gradient(135deg, #14172a, #0b0d18)`,
        }}
      >
        <div className="flex items-center gap-2">
          <Brain size={18} className={game.memoryAllowed ? "text-emerald-300" : "text-purple-300"} />
          <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">mem:{game.slug}</span>
        </div>
        {game.memoryAllowed ? (
          <Badge className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border-emerald-500/40">
            <Unlock size={9} className="mr-0.5" /> ДОСТУП
          </Badge>
        ) : (
          <Badge variant="outline" className="text-[10px] font-mono">
            <Lock size={9} className="mr-0.5" /> нет доступа
          </Badge>
        )}
      </div>

      <div className="p-3 space-y-2.5">
        <div>
          <h3 className="text-sm font-semibold leading-tight">{game.name}</h3>
          <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
            {game.running ? (
              <Badge className="text-[9px] py-0 px-1.5 font-mono bg-emerald-500/15 text-emerald-300 border-emerald-500/30">
                <Activity size={9} className="mr-0.5" /> запущена
              </Badge>
            ) : (
              <Badge variant="outline" className="text-[9px] py-0 px-1.5 font-mono">не запущена</Badge>
            )}
            <Badge variant="outline" className="text-[9px] py-0 px-1.5 font-mono">
              {game.offline ? "офлайн" : "онлайн"}
            </Badge>
            {game.processId && (
              <Badge variant="outline" className="text-[9px] py-0 px-1.5 font-mono">PID {game.processId}</Badge>
            )}
          </div>
        </div>

        {/* AI-readable link */}
        <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-purple-500/10 border border-purple-400/30">
          <Link2 size={11} className="text-purple-300 shrink-0" />
          <code className="text-[10px] text-purple-200 font-mono truncate flex-1">mem:{game.slug}</code>
          <span className="text-[9px] text-purple-300/70 font-mono shrink-0">ссылка</span>
        </div>

        {game.exe && (
          <div className="px-2 py-1 rounded bg-muted/50 border border-border/50">
            <code className="text-[9px] text-muted-foreground font-mono truncate block" title={game.exe}>
              {game.exe}
            </code>
          </div>
        )}

        <div className="flex items-center gap-1 pt-1 border-t border-border/50">
          {!game.memoryAllowed ? (
            <Button
              size="sm"
              onClick={onRequest}
              className="flex-1 h-7 text-[10px] gap-1 bg-emerald-500/15 text-emerald-200 border border-emerald-400/30 hover:bg-emerald-500/25"
            >
              <Unlock size={11} /> Дать доступ
            </Button>
          ) : (
            <>
              <Button
                size="sm"
                onClick={onRead}
                disabled={!game.running}
                className="flex-1 h-7 text-[10px] gap-1 bg-cyan-500/15 text-cyan-200 border border-cyan-400/30 hover:bg-cyan-500/25"
              >
                <Eye size={11} /> Прочитать
              </Button>
              <Button
                size="sm"
                onClick={onRevoke}
                className="h-7 px-2 text-[10px] bg-red-500/10 text-red-300 border border-red-500/30 hover:bg-red-500/20"
              >
                <Lock size={11} />
              </Button>
            </>
          )}
          <Button
            size="sm"
            onClick={onAsk}
            disabled={!game.memoryAllowed}
            className="h-7 px-2 text-[10px] bg-purple-500/15 text-purple-200 border border-purple-400/30 hover:bg-purple-500/25"
            title="Спросить ИИ об игре"
          >
            <Bot size={11} />
          </Button>
        </div>
      </div>
    </article>
  );
}

function BlockedGameCard({ game }: { game: GameMemory }) {
  return (
    <article className="relative rounded-xl overflow-hidden border border-red-500/30 bg-red-500/5 opacity-75">
      <div className="p-3 space-y-2">
        <div className="flex items-center gap-2">
          <ShieldX size={14} className="text-red-400 shrink-0" />
          <h3 className="text-sm font-semibold flex-1 truncate">{game.name}</h3>
          <Badge variant="outline" className="text-[9px] font-mono border-red-500/40 text-red-300">
            ЗАБЛОКИРОВАНО
          </Badge>
        </div>
        <div className="space-y-1 text-[11px]">
          {game.antiCheat.detected && (
            <div className="flex items-center gap-1.5 text-red-300">
              <ShieldAlert size={11} />
              <span>Анти-чит: <b>{game.antiCheat.name}</b></span>
            </div>
          )}
          {game.networkActivity && (
            <div className="flex items-center gap-1.5 text-red-300">
              <Activity size={11} />
              <span>Сетевая активность (онлайн)</span>
            </div>
          )}
          {!game.offline && (
            <div className="flex items-center gap-1.5 text-red-300">
              <ShieldX size={11} />
              <span>Игра не в режиме офлайн</span>
            </div>
          )}
        </div>
        <p className="text-[10px] text-muted-foreground leading-snug">
          FLUX никогда не будет читать память этой игры — это приведёт к бану аккаунта.
          Чтение памяти онлайн-игр приравнивается к читерству.
        </p>
      </div>
    </article>
  );
}

function SnapshotDetail({ game }: { game: GameMemory }) {
  return (
    <div className="rounded-xl glass-panel border-gradient-cosmic p-4 space-y-3">
      {/* player + biome */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <div className="p-2 rounded-lg bg-muted/40 border border-border/50">
          <div className="flex items-center gap-1 text-[9px] text-muted-foreground uppercase tracking-wider">
            <MapPin size={10} /> Игрок
          </div>
          <code className="text-[11px] font-mono text-foreground/90">
            {game.player ? `${game.player.x.toFixed(0)}, ${game.player.y.toFixed(0)}, ${game.player.z.toFixed(0)}` : "—"}
          </code>
        </div>
        <div className="p-2 rounded-lg bg-muted/40 border border-border/50">
          <div className="flex items-center gap-1 text-[9px] text-muted-foreground uppercase tracking-wider">
            <MapPin size={10} /> Биом
          </div>
          <code className="text-[11px] font-mono text-foreground/90">{game.biome || "—"}</code>
        </div>
        <div className="p-2 rounded-lg bg-muted/40 border border-border/50">
          <div className="flex items-center gap-1 text-[9px] text-muted-foreground uppercase tracking-wider">
            <Wind size={10} /> Глубина
          </div>
          <code className="text-[11px] font-mono text-foreground/90">
            {game.player ? `${game.player.depth} м` : "—"}
          </code>
        </div>
        <div className="p-2 rounded-lg bg-muted/40 border border-border/50">
          <div className="flex items-center gap-1 text-[9px] text-muted-foreground uppercase tracking-wider">
            <Activity size={10} /> Кислород
          </div>
          <code className="text-[11px] font-mono text-cyan-300">{game.oxygen ?? "—"}/60</code>
        </div>
      </div>

      {/* inventory */}
      {game.inventory && game.inventory.length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">
            <Package size={11} /> Инвентарь
          </div>
          <div className="flex flex-wrap gap-1.5">
            {game.inventory.map((it, i) => (
              <span key={i} className="px-2 py-0.5 rounded-md bg-muted/50 border border-border/50 text-[11px] font-mono">
                {it.item} <span className="text-amber-300">×{it.count}</span>
              </span>
            ))}
          </div>
        </div>
      )}

      {/* nearest resources */}
      {game.nearest && game.nearest.length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">
            <Crosshair size={11} /> Ближайшие ресурсы (live из памяти)
          </div>
          <div className="space-y-1.5">
            {game.nearest.map((n, i) => (
              <div
                key={i}
                className={cn(
                  "flex items-center gap-2 p-2 rounded-md border",
                  i === 0
                    ? "border-teal-400/40 bg-teal-500/10"
                    : "border-border/50 bg-muted/30"
                )}
              >
                <div className={cn(
                  "w-7 h-7 rounded-md flex items-center justify-center text-xs font-bold",
                  i === 0 ? "bg-teal-500/20 text-teal-300" : "bg-muted/60 text-muted-foreground"
                )}>
                  {i + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium truncate">{n.name}</div>
                  <div className="text-[10px] font-mono text-muted-foreground">
                    @{n.coords.x}, {n.coords.y}, {n.coords.z} · глубина {n.depth} м
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-sm font-bold text-cyan-300">{n.distance} м</div>
                  <div className="text-[10px] text-muted-foreground">{n.direction}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="text-[10px] text-muted-foreground/80 font-mono pt-1 border-t border-border/30">
        <Sparkles size={9} className="inline mr-1 text-cyan-400" />
        Этот снимок виден ИИ в чате как <code className="text-purple-300">КОНТЕКСТ ПАМЯТИ ИГРЫ [{game.slug}]</code>.
        Спросите «найди ближайший титан» — ИИ ответит по этим данным.
      </div>
    </div>
  );
}
