"use client";

import { useState } from "react";
import { Home, Globe, AppWindow, MessageSquare, Settings, Volume2, Cpu, Brain, Wrench, BookOpen, NotebookPen, Terminal, Plug, Activity, Command, Menu, X } from "lucide-react";
import { useFlux, type ViewName } from "./store";
import { ThemeSwitcher } from "./theme-switcher";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface NavItem {
  id: ViewName | "palette";
  label: string;
  icon: React.ReactNode;
  badge?: string;
  slot?: "main" | "bottom";
}

const NAV: NavItem[] = [
  { id: "palette", label: "Командная палитра (Cmd+K)", icon: <Command size={20} />, slot: "main" },
  { id: "home", label: "Главная (сфера)", icon: <Home size={20} /> },
  { id: "browser", label: "Браузер-мост", icon: <Globe size={20} />, badge: "tabs" },
  { id: "apps", label: "Приложения-мост", icon: <AppWindow size={20} />, badge: "apps" },
  { id: "uia", label: "UIA-мост (окна ОС)", icon: <Cpu size={20} />, badge: "uia" },
  { id: "memory", label: "Память игр (офлайн)", icon: <Brain size={20} />, badge: "mem" },
  { id: "chat", label: "Чат", icon: <MessageSquare size={20} /> },
  { id: "tools", label: "Каталог тулзов (357)", icon: <Wrench size={20} />, badge: "tools" },
  { id: "skills", label: "Скиллы (локал + NVIDIA)", icon: <BookOpen size={20} />, badge: "skills" },
  { id: "brain", label: "Память/Заметки/TODO", icon: <NotebookPen size={20} />, badge: "brain" },
  { id: "playground", label: "Code Playground", icon: <Terminal size={20} /> },
  { id: "connections", label: "Соединения (провайдеры)", icon: <Plug size={20} /> },
  { id: "selftest", label: "Self-Test / Диагностика", icon: <Activity size={20} /> },
];

export function Sidebar({
  onOpenSettings,
  onOpenPalette,
}: {
  onOpenSettings: () => void;
  onOpenPalette: () => void;
}) {
  const { view, setView, autospeak, setAutospeak } = useFlux();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNav = (id: ViewName) => {
    setView(id);
    setMobileOpen(false);
  };

  return (
    <>
      {/* mobile hamburger toggle — only visible on small screens */}
      <button
        onClick={() => setMobileOpen((o) => !o)}
        className="lg:hidden fixed top-2 left-2 z-50 w-10 h-10 rounded-lg bg-card border border-border flex items-center justify-center text-foreground shadow-lg"
        aria-label={mobileOpen ? "Закрыть меню" : "Открыть меню"}
        aria-expanded={mobileOpen}
      >
        {mobileOpen ? <X size={18} /> : <Menu size={18} />}
      </button>

      {/* mobile overlay — click to close */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
          onClick={() => setMobileOpen(false)}
          aria-hidden="true"
        />
      )}

    <TooltipProvider delayDuration={200}>
      <nav
        className={cn(
          "w-14 sm:w-16 shrink-0 bg-sidebar border-r border-sidebar-border flex flex-col items-center py-3 gap-1.5",
          // mobile: fixed drawer, hidden by default; lg: always visible
          "fixed lg:static top-0 bottom-0 left-0 z-40 transition-transform duration-200",
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
        aria-label="Главная навигация"
      >
        {/* logo */}
        <button
          onClick={onOpenPalette}
          className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400/80 via-purple-500/70 to-emerald-400/60 flex items-center justify-center text-white font-bold text-lg shadow-lg glow-teal mb-2 transition hover:scale-105 hover:shadow-cyan-400/40"
          title="Командная палитра (Cmd+K)"
          aria-label="Командная палитра"
        >
          F
        </button>

        <div className="w-8 h-px bg-sidebar-border mb-1" />

        {NAV.map((item) => {
          const isPalette = item.id === "palette";
          const active = !isPalette && view === item.id;
          const handleClick = () => {
            if (isPalette) {
              onOpenPalette();
            } else {
              handleNav(item.id as ViewName);
            }
          };
          return (
            <Tooltip key={item.id}>
              <TooltipTrigger asChild>
                <button
                  onClick={handleClick}
                  className={cn(
                    "relative w-10 h-10 rounded-xl flex items-center justify-center transition-all",
                    "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                    isPalette && "ring-1 ring-cyan-400/40 text-cyan-300 hover:ring-cyan-400/70",
                    active
                      ? "bg-sidebar-accent text-sidebar-primary shadow-inner ring-1 ring-sidebar-primary/40"
                      : "text-sidebar-foreground/70"
                  )}
                  aria-pressed={active}
                  aria-label={item.label}
                >
                  {item.icon}
                  {active && (
                    <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 rounded-r bg-sidebar-primary" />
                  )}
                </button>
              </TooltipTrigger>
              <TooltipContent side="right" className="text-xs">
                {item.label}
              </TooltipContent>
            </Tooltip>
          );
        })}

        <div className="flex-1" />

        {/* theme switcher */}
        <Tooltip>
          <TooltipTrigger asChild>
            <div>
              <ThemeSwitcher />
            </div>
          </TooltipTrigger>
          <TooltipContent side="right" className="text-xs">
            Сменить тему интерфейса
          </TooltipContent>
        </Tooltip>

        {/* settings */}
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={onOpenSettings}
              className="w-10 h-10 rounded-xl flex items-center justify-center text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition"
              aria-label="Настройки"
            >
              <Settings size={20} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="right" className="text-xs">
            Настройки
          </TooltipContent>
        </Tooltip>

        {/* autospeak */}
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={() => setAutospeak(!autospeak)}
              className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center transition",
                autospeak
                  ? "bg-emerald-500/20 text-emerald-300 glow-green"
                  : "text-sidebar-foreground/40 hover:bg-sidebar-accent"
              )}
              aria-pressed={autospeak}
              aria-label={autospeak ? "Озвучка ответов вкл" : "Озвучка ответов выкл"}
            >
              <Volume2 size={20} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="right" className="text-xs">
            Озвучивать ответы: {autospeak ? "вкл" : "выкл"}
          </TooltipContent>
        </Tooltip>
      </nav>
    </TooltipProvider>
    </>
  );
}
