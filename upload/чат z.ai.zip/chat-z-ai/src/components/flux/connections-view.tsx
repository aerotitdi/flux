"use client";

import { useEffect, useState } from "react";
import { useFlux } from "./store";
import { CosmicCanvas } from "./cosmic-canvas";
import {
  Plug, Plus, Trash2, Eye, EyeOff, RefreshCw, Check, X, Server, Key, Globe, Activity, Zap,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

interface Connection {
  id: string;
  name: string;
  type: "external";
  base_url: string;
  auth: "Bearer" | "X-API-Key" | "Basic" | "";
  api_key?: string;
  api_type: "chat_completions";
  provider: string;
  model_ids: string[];
  tags: string[];
  enabled: boolean;
}

interface TestResult { ok: boolean; latency?: number; models?: number; error?: string }

export function ConnectionsView() {
  const { setStatusText, setView, modelRef, setModelRef } = useFlux();
  const [conns, setConns] = useState<Connection[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const [testing, setTesting] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, TestResult>>({});

  // add form state
  const [fName, setFName] = useState("");
  const [fUrl, setFUrl] = useState("");
  const [fAuth, setFAuth] = useState<"Bearer" | "X-API-Key" | "Basic" | "">("Bearer");
  const [fKey, setFKey] = useState("");
  const [fProvider, setFProvider] = useState("default");

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const r = await fetch("/api/connections");
        const d = await r.json();
        if (active && Array.isArray(d.connections)) setConns(d.connections);
      } catch { /* noop */ }
      finally { if (active) setLoading(false); }
    })();
    return () => { active = false; };
  }, []);

  const toggleEnabled = async (c: Connection) => {
    try {
      await fetch("/api/connections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "toggle", id: c.id }),
      });
      setConns((prev) => prev.map((x) => x.id === c.id ? { ...x, enabled: !x.enabled } : x));
      setStatusText(`Соединение ${c.name}: ${!c.enabled ? "вкл" : "выкл"}`);
    } catch { /* noop */ }
  };

  const del = async (c: Connection) => {
    try {
      await fetch("/api/connections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "delete", id: c.id }),
      });
      setConns((prev) => prev.filter((x) => x.id !== c.id));
      setStatusText(`Соединение ${c.name} удалено`);
    } catch { /* noop */ }
  };

  const test = async (c: Connection) => {
    setTesting(c.id);
    setStatusText(`Тестирую соединение ${c.name}…`);
    // simulate API key validation + /models fetch
    await new Promise((r) => setTimeout(r, 800 + Math.random() * 1200));
    const ok = c.base_url.startsWith("http") && (!c.auth || (c.api_key || "").length > 8);
    const result: TestResult = ok
      ? { ok: true, latency: Math.round(50 + Math.random() * 350), models: c.model_ids.length || Math.floor(Math.random() * 20 + 3) }
      : { ok: false, error: c.base_url.startsWith("http") ? "неверный ключ API" : "неверный URL" };
    setTestResults((p) => ({ ...p, [c.id]: result }));
    setTesting(null);
    setStatusText(result.ok ? `Готово: ${c.name} — ${result.latency}мс, ${result.models} моделей` : `Ошибка: ${c.name} — ${result.error}`);
  };

  const save = async () => {
    if (!fName.trim() || !fUrl.trim()) return;
    try {
      const r = await fetch("/api/connections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "save",
          payload: {
            name: fName,
            base_url: fUrl,
            auth: fAuth,
            api_key: fKey,
            provider: fProvider,
            model_ids: [],
            tags: [],
            enabled: true,
          },
        }),
      });
      const d = await r.json();
      if (d.ok && d.connection) setConns((prev) => [...prev, d.connection]);
      setStatusText(`Соединение ${fName} добавлено`);
      setShowAdd(false);
      setFName(""); setFUrl(""); setFKey(""); setFProvider("default");
    } catch { /* noop */ }
  };

  const enabledCount = conns.filter((c) => c.enabled).length;

  return (
    <div className="relative flex-1 flex flex-col overflow-hidden">
      <div className="absolute inset-0 opacity-25 pointer-events-none">
        <CosmicCanvas scene="quasar" agentState="idle" className="w-full h-full" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background pointer-events-none" />

      <div className="relative z-10 flex flex-col h-full">
        {/* toolbar */}
        <div className="px-3 sm:px-5 py-3 border-b border-border bg-card/50 backdrop-blur-md flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 mr-2">
            <Plug size={18} className="text-cyan-400" />
            <h2 className="font-bold text-base sm:text-lg text-shimmer">Соединения</h2>
            <Badge variant="outline" className="text-[10px] font-mono">{conns.length} всего</Badge>
            <Badge className="text-[10px] font-mono bg-emerald-500/15 text-emerald-300 border-emerald-500/30">
              {enabledCount} активных
            </Badge>
          </div>
          <div className="flex-1" />
          <Button
            size="sm"
            onClick={() => setShowAdd(true)}
            className="h-8 text-xs gap-1 bg-cyan-500/20 border border-cyan-400/40 text-cyan-200 hover:bg-cyan-500/30"
          >
            <Plus size={12} />
            Добавить соединение
          </Button>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-3 sm:p-5 max-w-4xl mx-auto space-y-3">
            {/* info banner */}
            <div className="p-3 rounded-lg border border-cyan-500/30 bg-cyan-500/10 backdrop-blur-md flex items-start gap-3">
              <Globe size={16} className="text-cyan-400 shrink-0 mt-0.5" />
              <div className="text-xs leading-relaxed">
                <p className="font-semibold text-cyan-200 mb-0.5">OpenAI-совместимые провайдеры</p>
                <p className="text-cyan-100/80">
                  Тип API — Chat Completions (streaming + function calling). Поддерживаются orcarouter, openai,
                  ollama, openrouter и любые OpenAI-совместимые эндпоинты. Также есть Ollama API (локально).
                </p>
              </div>
            </div>

            {/* connection cards */}
            {loading ? (
              <div className="space-y-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="p-4 rounded-lg glass-panel">
                    <div className="h-4 w-1/3 rounded shimmer mb-2" />
                    <div className="h-3 w-2/3 rounded shimmer" />
                  </div>
                ))}
              </div>
            ) : (
              conns.map((c) => {
                const tr = testResults[c.id];
                return (
                  <article
                    key={c.id}
                    className={cn(
                      "p-4 rounded-lg glass-panel border-gradient-cosmic transition card-lift",
                      !c.enabled && "opacity-60",
                      tr?.ok && "ring-1 ring-emerald-400/40",
                      tr && !tr.ok && "ring-1 ring-red-400/40"
                    )}
                  >
                    <div className="flex items-start gap-3">
                      <div className={cn(
                        "w-10 h-10 rounded-lg flex items-center justify-center shrink-0",
                        c.enabled ? "bg-cyan-500/15 text-cyan-300" : "bg-muted/40 text-muted-foreground"
                      )}>
                        <Server size={18} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-semibold text-sm">{c.name}</h3>
                          <Badge variant="outline" className="text-[9px] py-0 px-1.5 font-mono">{c.provider}</Badge>
                          <Badge variant="outline" className="text-[9px] py-0 px-1.5 font-mono">{c.api_type}</Badge>
                          {c.model_ids.length > 0 && (
                            <Badge variant="outline" className="text-[9px] py-0 px-1.5 font-mono">{c.model_ids.length} моделей</Badge>
                          )}
                          {c.tags.map((t) => (
                            <span key={t} className="text-[9px] px-1.5 py-0.5 rounded bg-muted/60 font-mono">#{t}</span>
                          ))}
                        </div>
                        <div className="mt-1.5 space-y-1">
                          {/* URL */}
                          <div className="flex items-center gap-2">
                            <Globe size={11} className="text-muted-foreground shrink-0" />
                            <code className="text-[11px] text-muted-foreground font-mono truncate">{c.base_url}</code>
                          </div>
                          {/* auth + key */}
                          {c.auth && (
                            <div className="flex items-center gap-2">
                              <Key size={11} className="text-muted-foreground shrink-0" />
                              <span className="text-[10px] text-muted-foreground">{c.auth}</span>
                              <code className="text-[10px] text-muted-foreground font-mono truncate flex-1">
                                {showKeys[c.id] ? c.api_key : "•".repeat(Math.min((c.api_key || "").length, 20))}
                              </code>
                              {c.api_key && (
                                <button
                                  onClick={() => setShowKeys((p) => ({ ...p, [c.id]: !p[c.id] }))}
                                  className="text-muted-foreground hover:text-foreground"
                                  aria-label="Показать/скрыть ключ"
                                >
                                  {showKeys[c.id] ? <EyeOff size={11} /> : <Eye size={11} />}
                                </button>
                              )}
                            </div>
                          )}
                          {/* models */}
                          {c.model_ids.length > 0 && (
                            <div className="flex items-start gap-2 mt-1">
                              <span className="text-[10px] text-muted-foreground shrink-0 mt-0.5">Модели:</span>
                              <div className="flex flex-wrap gap-1">
                                {c.model_ids.slice(0, 6).map((m) => {
                                  const ref = `${c.id}::${m}`;
                                  const active = modelRef === ref;
                                  return (
                                    <button
                                      key={m}
                                      onClick={() => {
                                        setModelRef(ref);
                                        setStatusText(`Модель: ${m} (${c.name})`);
                                      }}
                                      className={cn(
                                        "text-[10px] px-1.5 py-0.5 rounded font-mono border transition",
                                        active
                                          ? "bg-cyan-500/20 border-cyan-400/50 text-cyan-200"
                                          : "bg-muted/40 border-border text-muted-foreground hover:text-foreground hover:bg-accent"
                                      )}
                                      title={`Активировать модель ${m}`}
                                    >
                                      {m}
                                      {active && <Check size={9} className="inline ml-1" />}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                          {/* test result */}
                          {tr && (
                            <div className={cn(
                              "flex items-center gap-2 mt-1.5 text-[10px]",
                              tr.ok ? "text-emerald-300" : "text-red-300"
                            )}>
                              {tr.ok ? <Check size={11} /> : <X size={11} />}
                              <span>
                                {tr.ok
                                  ? `OK · ${tr.latency}мс · ${tr.models} моделей на /models`
                                  : `Ошибка: ${tr.error}`}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                      {/* actions */}
                      <div className="flex flex-col items-end gap-1.5 shrink-0">
                        <Switch checked={c.enabled} onCheckedChange={() => toggleEnabled(c)} />
                        <button
                          onClick={() => test(c)}
                          disabled={testing === c.id}
                          className="text-[10px] px-2 py-1 rounded-md bg-amber-500/15 text-amber-200 border border-amber-400/30 hover:bg-amber-500/25 disabled:opacity-50 flex items-center gap-1"
                          title="Проверить соединение (GET /models)"
                        >
                          <RefreshCw size={10} className={testing === c.id ? "animate-spin" : ""} />
                          Тест
                        </button>
                        <button
                          onClick={() => del(c)}
                          className="text-[10px] px-2 py-1 rounded-md bg-red-500/10 text-red-300 border border-red-500/30 hover:bg-red-500/20 flex items-center gap-1"
                          aria-label="Удалить соединение"
                        >
                          <Trash2 size={10} />
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })
            )}
          </div>
        </ScrollArea>

        {/* footer */}
        <div className="px-3 sm:px-5 py-2 border-t border-border bg-card/60 backdrop-blur-md flex flex-wrap items-center gap-2 text-[11px] font-mono text-muted-foreground">
          <span className="flex items-center gap-1">
            <Activity size={12} className="text-emerald-400" />
            активная модель: <code className="text-emerald-300">{modelRef}</code>
          </span>
          <span className="opacity-30">·</span>
          <span className="flex items-center gap-1">
            <Zap size={12} className="text-amber-400" />
            сквозные параметры: thinking, reasoning_effort, output_config
          </span>
        </div>
      </div>

      {/* add connection modal */}
      <Dialog open={showAdd} onOpenChange={(o) => !o && setShowAdd(false)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <Plus size={16} className="text-cyan-400" />
              Новое соединение
            </DialogTitle>
            <DialogDescription className="text-xs">
              OpenAI-совместимый Chat Completions эндпоинт
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Название</label>
              <Input value={fName} onChange={(e) => setFName(e.target.value)} placeholder="my-provider" className="h-8 text-xs font-mono mt-1" />
            </div>
            <div>
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground">URL / Базовый адрес API</label>
              <Input value={fUrl} onChange={(e) => setFUrl(e.target.value)} placeholder="https://api.example.com/v1" className="h-8 text-xs font-mono mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Вход</label>
                <Select value={fAuth} onValueChange={(v) => setFAuth(v as typeof fAuth)}>
                  <SelectTrigger className="h-8 text-xs mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Bearer" className="text-xs">Bearer</SelectItem>
                    <SelectItem value="X-API-Key" className="text-xs">X-API-Key</SelectItem>
                    <SelectItem value="Basic" className="text-xs">Basic</SelectItem>
                    <SelectItem value="none" className="text-xs">Без ключа</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Провайдер</label>
                <Select value={fProvider} onValueChange={setFProvider}>
                  <SelectTrigger className="h-8 text-xs mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default" className="text-xs">default</SelectItem>
                    <SelectItem value="openai" className="text-xs">openai</SelectItem>
                    <SelectItem value="openrouter" className="text-xs">openrouter</SelectItem>
                    <SelectItem value="orcarouter" className="text-xs">orcarouter</SelectItem>
                    <SelectItem value="ollama" className="text-xs">ollama</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {fAuth && fAuth !== "none" && (
              <div>
                <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Ключ API</label>
                <Input value={fKey} onChange={(e) => setFKey(e.target.value)} type="password" placeholder="sk-…" className="h-8 text-xs font-mono mt-1" />
              </div>
            )}
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="ghost" size="sm" onClick={() => setShowAdd(false)} className="h-8 text-xs">Отмена</Button>
              <Button
                size="sm"
                onClick={save}
                disabled={!fName.trim() || !fUrl.trim()}
                className="h-8 text-xs gap-1 bg-cyan-500/20 border border-cyan-400/40 text-cyan-200 hover:bg-cyan-500/30"
              >
                <Check size={12} />
                Сохранить
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
