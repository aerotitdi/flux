"use client";

import { useEffect, useState } from "react";
import { Palette, Check } from "lucide-react";
import { useFlux } from "./store";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuLabel, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

const THEMES: { id: FluxTheme; label: string; description: string; swatch: string[] }[] = [
  { id: "cosmic", label: "Космическая (cyan/teal)", description: "По умолчанию — teal-cyan акцент на тёмном фоне", swatch: ["#4f8cff", "#3ecf8e", "#b07cff"] },
  { id: "midnight", label: "Полночная (фиолетовая)", description: "Фиолетовый акцент для глубокого кодинга", swatch: ["#b07cff", "#9c4edd", "#3ecf8e"] },
  { id: "deepspace", label: "Глубокий космос (синяя)", description: "Холодный синий акцент — спокойный и сфокусированный", swatch: ["#5b9eff", "#4a7fd0", "#3ecf8e"] },
  { id: "ember", label: "Тлеющая (оранжевая)", description: "Тёплый оранжевый акцент для энергии", swatch: ["#ff8c30", "#ffd76a", "#ff6b6b"] },
];

type FluxTheme = "cosmic" | "midnight" | "deepspace" | "ember";

function applyThemeClass(theme: FluxTheme) {
  const html = document.documentElement;
  html.classList.remove("theme-cosmic", "theme-midnight", "theme-deepspace", "theme-ember");
  if (theme !== "cosmic") {
    html.classList.add(`theme-${theme}`);
  }
}

export function ThemeSwitcher() {
  const { theme, setTheme } = useFlux();
  const [hoveredTheme, setHoveredTheme] = useState<FluxTheme | null>(null);

  // apply committed theme on mount + whenever theme changes (commit)
  useEffect(() => {
    applyThemeClass(theme);
  }, [theme]);

  const current = THEMES.find((t) => t.id === theme) || THEMES[0];

  const handleHover = (t: FluxTheme | null) => {
    setHoveredTheme(t);
    if (t === null) {
      applyThemeClass(theme);
    } else if (t !== theme) {
      applyThemeClass(t);
    }
  };

  return (
    <DropdownMenu
      onOpenChange={(open) => {
        if (!open) {
          applyThemeClass(theme);
          setHoveredTheme(null);
        }
      }}
    >
      <DropdownMenuTrigger asChild>
        <button
          className="w-10 h-10 rounded-xl flex items-center justify-center text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition"
          aria-label="Сменить тему"
          title={`Тема: ${current.label}`}
        >
          <Palette size={20} />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <DropdownMenuLabel className="text-xs uppercase tracking-wider text-muted-foreground flex items-center justify-between">
          <span>Тема интерфейса</span>
          <span className="text-[9px] normal-case font-mono text-muted-foreground/70">наведи для превью</span>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {THEMES.map((t) => (
          <DropdownMenuItem
            key={t.id}
            onClick={() => setTheme(t.id as FluxTheme)}
            onMouseEnter={() => handleHover(t.id as FluxTheme)}
            onMouseLeave={() => handleHover(null)}
            className={cn(
              "flex items-start gap-3 py-2 cursor-pointer transition-colors",
              theme === t.id && "bg-accent",
              hoveredTheme === t.id && theme !== t.id && "bg-accent/50"
            )}
          >
            <div className="flex gap-0.5 shrink-0 mt-0.5">
              {t.swatch.map((c, i) => (
                <span
                  key={i}
                  className="w-3 h-3 rounded-full border border-white/20"
                  style={{ background: c }}
                />
              ))}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-medium">{t.label}</span>
                {theme === t.id && <Check size={11} className="text-primary" />}
              </div>
              <p className="text-[10px] text-muted-foreground leading-snug mt-0.5">{t.description}</p>
            </div>
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        <div className="px-2 py-1.5 text-[10px] font-mono text-muted-foreground text-center">
          наведи на тему — увидишь превью; клик — зафиксируешь
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
