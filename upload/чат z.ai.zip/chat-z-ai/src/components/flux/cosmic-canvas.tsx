"use client";

import { useEffect, useRef, useState, useCallback } from "react";

export type SceneName = "uranus" | "solar" | "galaxy" | "space" | "aurora" | "pulsar" | "nebula" | "blackhole" | "supernova" | "solarflare" | "quasar" | "wormhole" | "binarystar" | "magnetar" | "cosmicweb" | "whitedwarf" | "nsmerger" | "accretiondisk" | "pwn" | "tde" | "grb" | "magnetosphere" | "hotjupiter" | "browndwarf" | "protoplanetary" | "hypergiant" | "wolfrayet" | "ringnebula" | "crabnebula" | "solarouter" | "helix" | "orion" | "eagle";
export type AgentState = "idle" | "listen" | "think" | "speak";

interface CosmicCanvasProps {
  scene: SceneName;
  agentState: AgentState;
  className?: string;
}

/**
 * Improved cosmic scene canvas. Builds on the original FLUX 2.0 scenes
 * (Uranus / Solar / Galaxy / Space) with:
 *  - higher particle counts
 *  - richer gradients and nebulae
 *  - shooting stars + parallax dust
 *  - reactive aura per agent state (listen=teal, think=purple, speak=green, idle=cyan)
 *  - DPR-aware crispness
 */
export function CosmicCanvas({ scene, agentState, className }: CosmicCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<SceneName>(scene);
  const stateRef = useRef<AgentState>(agentState);
  const [ready, setReady] = useState(false);

  // keep refs synced without restarting RAF
  useEffect(() => {
    sceneRef.current = scene;
  }, [scene]);
  useEffect(() => {
    stateRef.current = agentState;
  }, [agentState]);

  // initialize starfield + galaxy points once
  const dataRef = useRef<{ stars: number[][]; gal: number[] } | null>(null);
  const init = useCallback(() => {
    const stars: number[][] = [];
    for (let i = 0; i < 220; i++) {
      stars.push([Math.random(), Math.random(), Math.random() * 1.6 + 0.3, Math.random() * 6.28]);
    }
    // shooting stars pool
    const shots: number[] = [];
    for (let i = 0; i < 6; i++) shots.push(Math.random() * 1000 + 200);
    // galaxy arms
    const gal: number[] = [];
    for (let i = 0; i < 1100; i++) {
      const arm = i % 4;
      const u = 0.1 + Math.pow(Math.random(), 0.7) * 0.95;
      const a = (arm * Math.PI) / 2 + u * 3.4 + (Math.random() - 0.5) * 0.5 / (0.35 + u);
      gal.push(u, a, Math.random(), Math.random() * 6.28);
    }
    dataRef.current = { stars, gal: shots };
  }, []);

  useEffect(() => {
    init();
    setReady(true);
  }, [init]);

  useEffect(() => {
    if (!ready) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let t = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      if (w && h && canvas.width !== Math.round(w * dpr)) {
        canvas.width = Math.round(w * dpr);
        canvas.height = Math.round(h * dpr);
      }
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const stateCol = (st: AgentState) =>
      st === "listen" ? "53,224,194" : st === "think" ? "176,124,255" : st === "speak" ? "62,207,142" : "120,210,230";

    // shooting stars
    const shots: { x: number; y: number; vx: number; vy: number; life: number; max: number }[] = [];
    const spawnShot = (W: number, H: number) => {
      const startX = Math.random() * W * 0.6;
      const startY = Math.random() * H * 0.4;
      const angle = Math.PI / 5 + Math.random() * 0.3;
      const speed = 6 + Math.random() * 4;
      shots.push({
        x: startX,
        y: startY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 0,
        max: 50 + Math.random() * 30,
      });
    };

    const starsBg = (W: number, H: number, tt: number) => {
      const data = dataRef.current;
      if (!data) return;
      for (const s of data.stars) {
        const al = 0.25 + 0.6 * Math.abs(Math.sin(tt / 50 + s[3]));
        ctx.fillStyle = `rgba(230,240,255,${al})`;
        ctx.fillRect(s[0] * W, s[1] * H, s[2], s[2]);
      }
      // occasional shooting star
      if (Math.random() < 0.005 && shots.length < 3) spawnShot(W, H);
      for (let i = shots.length - 1; i >= 0; i--) {
        const s = shots[i];
        s.x += s.vx;
        s.y += s.vy;
        s.life++;
        const alpha = Math.max(0, 1 - s.life / s.max);
        const grad = ctx.createLinearGradient(s.x - s.vx * 8, s.y - s.vy * 8, s.x, s.y);
        grad.addColorStop(0, "rgba(255,255,255,0)");
        grad.addColorStop(1, `rgba(180,230,255,${alpha})`);
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(s.x - s.vx * 8, s.y - s.vy * 8);
        ctx.lineTo(s.x, s.y);
        ctx.stroke();
        if (s.life > s.max || s.x > W || s.y > H) shots.splice(i, 1);
      }
    };

    /* URANUS — high mind, tilted rings, drifting bands */
    const drawUranus = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.26;
      const pulse = st === "listen" ? 1 + 0.03 * Math.sin(tt / 6) : st === "speak" ? 1 + 0.02 * Math.sin(tt / 3) : 1;
      const Rp = R * pulse, gc = stateCol(st);
      const g = ctx.createRadialGradient(cx, cy, Rp * 0.7, cx, cy, Rp * 2.6);
      g.addColorStop(0, `rgba(${gc},0.32)`);
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
      const tilt = -1.15;
      const ring = (front: boolean) => {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(tilt);
        for (let k = 0; k < 3; k++) {
          const rr = Rp * (1.5 + k * 0.28), ry = rr * 0.3;
          ctx.beginPath();
          ctx.ellipse(0, 0, rr, ry, 0, front ? 0 : Math.PI, front ? Math.PI : Math.PI * 2);
          const shim = st === "think" ? 0.8 + 0.2 * Math.sin(tt / 4 + k) : 1;
          ctx.strokeStyle = `rgba(190,235,245,${(0.36 - k * 0.09) * (front ? 1 : 0.55) * shim})`;
          ctx.lineWidth = k === 0 ? 2.4 : 1.5;
          ctx.stroke();
        }
        ctx.restore();
      };
      const sats: { x: number; y: number; front: boolean }[] = [];
      for (let i = 0; i < 3; i++) {
        const a = tt / 160 + i * 2.1, rr = Rp * (1.5 + (i % 3) * 0.28), ry = rr * 0.3;
        const x0 = Math.cos(a) * rr, y0 = Math.sin(a) * ry;
        sats.push({
          x: cx + x0 * Math.cos(tilt) - y0 * Math.sin(tilt),
          y: cy + x0 * Math.sin(tilt) + y0 * Math.cos(tilt),
          front: Math.sin(a) > 0,
        });
      }
      ring(false);
      for (const s of sats) {
        if (!s.front) {
          ctx.fillStyle = "rgba(200,240,250,0.5)";
          ctx.beginPath();
          ctx.arc(s.x, s.y, 2, 0, 6.283);
          ctx.fill();
        }
      }
      const pg = ctx.createRadialGradient(cx - Rp * 0.45, cy - Rp * 0.4, Rp * 0.15, cx, cy, Rp);
      pg.addColorStop(0, "#eafffb");
      pg.addColorStop(0.35, "#9fe3e0");
      pg.addColorStop(0.75, "#3d9aa0");
      pg.addColorStop(1, "#123c46");
      ctx.beginPath();
      ctx.arc(cx, cy, Rp, 0, 6.283);
      ctx.fillStyle = pg;
      ctx.fill();
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, Rp, 0, 6.283);
      ctx.clip();
      for (let b = 0; b < 6; b++) {
        const y = cy - Rp + (b + 0.5) * (Rp * 2) / 6 + Math.sin(tt / 90 + b * 2) * 2;
        ctx.fillStyle = `rgba(255,255,255,${0.05 + 0.025 * Math.sin(tt / 70 + b)})`;
        ctx.fillRect(cx - Rp, y - Rp * 0.06, Rp * 2, Rp * 0.12);
      }
      const tg = ctx.createRadialGradient(cx - Rp * 0.6, cy - Rp * 0.5, Rp * 0.2, cx, cy, Rp * 1.25);
      tg.addColorStop(0, "rgba(0,0,0,0)");
      tg.addColorStop(0.75, "rgba(0,0,0,0.05)");
      tg.addColorStop(1, "rgba(2,10,18,0.55)");
      ctx.fillStyle = tg;
      ctx.fillRect(cx - Rp, cy - Rp, Rp * 2, Rp * 2);
      ctx.restore();
      for (const s of sats) {
        if (s.front) {
          ctx.fillStyle = "rgba(230,250,255,0.95)";
          ctx.beginPath();
          ctx.arc(s.x, s.y, 2.6, 0, 6.283);
          ctx.fill();
        }
      }
      ring(true);
    };

    /* SOLAR SYSTEM — sun with corona + 8 planets + moon */
    const PLANETS = [
      ["Меркурий", "#c8c8c8", 0.16, 4.15, 2.0],
      ["Венера", "#e8c468", 0.22, 1.62, 3.0],
      ["Земля", "#5aa7ff", 0.29, 1.0, 3.2],
      ["Марс", "#ff7f50", 0.36, 0.53, 2.6],
      ["Юпитер", "#d8a56c", 0.48, 0.084, 6.5],
      ["Сатурн", "#e3cf9e", 0.6, 0.034, 5.5],
      ["Уран", "#9fe3e0", 0.72, 0.012, 4.2],
      ["Нептун", "#6f8cff", 0.84, 0.006, 4.0],
    ] as const;

    const drawSolar = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2, R0 = Math.min(W, H) * 0.46;
      const m = st === "think" ? 5 : st === "listen" ? 2 : st === "speak" ? 3 : 1;
      const pr = R0 * 0.1 * (1 + 0.06 * Math.sin(tt / (st === "speak" ? 4 : 12)));
      const sg = ctx.createRadialGradient(cx, cy, 0, cx, cy, pr * 3.4);
      sg.addColorStop(0, "#fff8e0");
      sg.addColorStop(0.25, "#ffd76a");
      sg.addColorStop(0.55, "rgba(255,150,40,0.35)");
      sg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = sg;
      ctx.beginPath();
      ctx.arc(cx, cy, pr * 3.4, 0, 6.283);
      ctx.fill();
      // corona rays
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(tt / 800);
      for (let i = 0; i < 12; i++) {
        ctx.rotate((Math.PI * 2) / 12);
        const rl = pr * (2.2 + 0.4 * Math.sin(tt / 30 + i));
        const grad = ctx.createLinearGradient(0, 0, rl, 0);
        grad.addColorStop(0, "rgba(255,200,80,0.4)");
        grad.addColorStop(1, "rgba(255,200,80,0)");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.moveTo(0, -pr * 0.1);
        ctx.lineTo(rl, 0);
        ctx.lineTo(0, pr * 0.1);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
      for (const [n, c, f, s, sz] of PLANETS) {
        const rr = R0 * f;
        ctx.beginPath();
        ctx.ellipse(cx, cy, rr, rr * 0.42, 0, 0, 6.283);
        ctx.strokeStyle = "rgba(160,190,230,0.16)";
        ctx.lineWidth = 1;
        ctx.stroke();
        const a = (tt / 400) * s * m + f * 20, x = cx + Math.cos(a) * rr, y = cy + Math.sin(a) * rr * 0.42;
        ctx.beginPath();
        ctx.arc(x, y, sz, 0, 6.283);
        ctx.fillStyle = c;
        ctx.fill();
        if (n === "Сатурн") {
          ctx.beginPath();
          ctx.ellipse(x, y, sz * 2.1, sz * 0.8, -0.4, 0, 6.283);
          ctx.strokeStyle = "rgba(230,210,160,0.8)";
          ctx.lineWidth = 1.2;
          ctx.stroke();
        }
        if (n === "Уран") {
          ctx.beginPath();
          ctx.ellipse(x, y, sz * 1.9, sz * 0.5, 1.2, 0, 6.283);
          ctx.strokeStyle = "rgba(160,230,235,0.7)";
          ctx.lineWidth = 1;
          ctx.stroke();
        }
        if (n === "Земля") {
          const ma = (tt / 60) * m;
          ctx.beginPath();
          ctx.arc(x + Math.cos(ma) * (sz + 4), y + Math.sin(ma) * (sz + 4) * 0.6, 1.2, 0, 6.283);
          ctx.fillStyle = "#dfe6ee";
          ctx.fill();
        }
      }
    };

    /* GALAXY — spiral with bulge, dust lanes, halo, clusters */
    const galData: number[][] = [];
    {
      for (let i = 0; i < 1100; i++) {
        const arm = i % 4;
        const u = 0.1 + Math.pow(Math.random(), 0.7) * 0.95;
        const a = (arm * Math.PI) / 2 + u * 3.4 + (Math.random() - 0.5) * 0.5 / (0.35 + u);
        galData.push([u, a, Math.random(), Math.random() * 6.28]);
      }
    }
    const drawGalaxy = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2, Rm = Math.min(W, H) * 0.46;
      const m = st === "think" ? 3 : 1, tilt = 0.45, squash = 0.55;
      const pulse = st === "listen" ? 1 + 0.08 * Math.sin(tt / 6) : 1;
      const hg = ctx.createRadialGradient(cx, cy, 0, cx, cy, Rm * 1.1);
      hg.addColorStop(0, "rgba(150,120,220,0.12)");
      hg.addColorStop(0.6, "rgba(120,90,200,0.05)");
      hg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.arc(cx, cy, Rm * 1.1, 0, 6.283);
      ctx.fill();
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(tilt);
      const cg = ctx.createRadialGradient(0, 0, 0, 0, 0, Rm * 0.32);
      cg.addColorStop(0, "rgba(255,246,225,0.95)");
      cg.addColorStop(0.35, "rgba(255,214,150,0.45)");
      cg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.ellipse(0, 0, Rm * 0.32 * pulse, Rm * 0.17 * pulse, 0, 0, 6.283);
      ctx.fill();
      ctx.restore();
      for (const [u, a0, w] of galData) {
        const sp = 0.9 / (0.35 + u), a = a0 + (tt / 220) * sp * m, r = u * Rm;
        const x0 = Math.cos(a) * r, y0 = Math.sin(a) * r * squash;
        const x = cx + x0 * Math.cos(tilt) - y0 * Math.sin(tilt);
        const y = cy + x0 * Math.sin(tilt) + y0 * Math.cos(tilt);
        let al = 0.25 + 0.7 * w;
        if (st === "speak") al *= 0.7 + 0.5 * Math.abs(Math.sin(tt / 5 - u * 7));
        if (w < 0.22) {
          const dx = cx + Math.cos(a + 0.1) * r * Math.cos(tilt) - Math.sin(a + 0.1) * r * squash * Math.sin(tilt);
          const dy = cy + Math.cos(a + 0.1) * r * Math.sin(tilt) + Math.sin(a + 0.1) * r * squash * Math.cos(tilt);
          ctx.fillStyle = `rgba(120,80,60,${0.22 + 0.15 * w * 4})`;
          ctx.fillRect(dx, dy, 1.6, 1.6);
          continue;
        }
        const inner = 1 - u;
        ctx.fillStyle = w > 0.86 ? `rgba(190,215,255,${al})` : inner > 0.55 ? `rgba(255,236,205,${al})` : `rgba(205,175,255,${al * 0.9})`;
        const sz = w > 0.93 ? 2.2 : 1.3;
        ctx.fillRect(x, y, sz, sz);
      }
      for (let i = 0; i < 30; i++) {
        const u = 0.25 + ((i * 0.618) % 0.7);
        const a = (i % 4) * (Math.PI / 2) + u * 3.4 + (tt / 220) * (0.9 / (0.35 + u)) * m;
        const r = u * Rm;
        const x0 = Math.cos(a) * r, y0 = Math.sin(a) * r * squash;
        const x = cx + x0 * Math.cos(tilt) - y0 * Math.sin(tilt);
        const y = cy + x0 * Math.sin(tilt) + y0 * Math.cos(tilt);
        ctx.fillStyle = `rgba(220,240,255,${0.5 + 0.4 * Math.sin(tt / 20 + i)})`;
        ctx.fillRect(x - 1, y - 1, 2.4, 2.4);
      }
    };

    /* SPACE — nebulae + mini galaxies + black hole */
    const drawSpace = (W: number, H: number, tt: number, st: AgentState) => {
      const m = st === "think" ? 2.5 : 1;
      const neb = [
        [0.28, 0.32, 0.5, "176,124,255", 0.16],
        [0.74, 0.62, 0.56, "53,180,224", 0.13],
        [0.56, 0.22, 0.36, "255,120,180", 0.1],
        [0.18, 0.78, 0.42, "80,220,190", 0.09],
      ] as const;
      const boost = st === "listen" ? 1.3 : st === "speak" ? 1.15 : 1;
      for (const [fx, fy, fr, col, al] of neb) {
        const x = fx * W + Math.sin(tt / 300 + fx * 9) * W * 0.02;
        const y = fy * H + Math.cos(tt / 260 + fy * 7) * H * 0.02;
        const r = fr * Math.min(W, H);
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, `rgba(${col},${al * boost})`);
        g.addColorStop(0.5, `rgba(${col},${al * 0.4 * boost})`);
        g.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);
      }
      for (let gi = 0; gi < 2; gi++) {
        const gx = (gi ? 0.8 : 0.2) * W, gy = (gi ? 0.26 : 0.76) * H;
        const gr = Math.min(W, H) * (gi ? 0.09 : 0.12);
        const rot = (tt / 400) * (gi ? 1.4 : 1) * m + gi * 2;
        for (let i = 0; i < 240; i++) {
          const u = 0.15 + (i / 240) * 0.9, arm = i % 2;
          const a = arm * Math.PI + u * 4 + rot / (0.5 + u);
          const x = gx + Math.cos(a) * u * gr, y = gy + Math.sin(a) * u * gr * 0.5;
          ctx.fillStyle = `rgba(210,225,255,${0.5 * (1 - u * 0.6)})`;
          ctx.fillRect(x, y, 1.2, 1.2);
        }
        const cgg = ctx.createRadialGradient(gx, gy, 0, gx, gy, gr * 0.35);
        cgg.addColorStop(0, "rgba(255,240,210,0.8)");
        cgg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = cgg;
        ctx.beginPath();
        ctx.arc(gx, gy, gr * 0.35, 0, 6.283);
        ctx.fill();
      }
      // black hole with accretion disk + photon ring + infalling particles
      const bx = 0.52 * W, by = 0.54 * H, br = Math.min(W, H) * 0.085;
      ctx.save();
      ctx.translate(bx, by);
      ctx.rotate(-0.35);
      for (let k = 0; k < 26; k++) {
        const rr = br * (1.5 + k * 0.065);
        const al = 0.4 * (1 - k / 26) * (st === "speak" ? 0.75 + 0.35 * Math.sin(tt / 4 - k * 0.5) : 1);
        ctx.beginPath();
        ctx.ellipse(0, 0, rr, rr * 0.22, 0, 0, Math.PI);
        ctx.strokeStyle = `rgba(255,${175 - k * 3},80,${al})`;
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.beginPath();
        ctx.ellipse(0, 0, rr, rr * 0.22, 0, Math.PI, 2 * Math.PI);
        ctx.strokeStyle = `rgba(255,${150 - k * 3},60,${al * 0.45})`;
        ctx.stroke();
      }
      ctx.restore();
      const ringPulse = st === "listen" ? 1 + 0.05 * Math.sin(tt / 5) : 1;
      const pg = ctx.createRadialGradient(bx, by, br * 0.5, bx, by, br * 1.32 * ringPulse);
      pg.addColorStop(0, "rgba(0,0,0,1)");
      pg.addColorStop(0.72, "rgba(0,0,0,0.92)");
      pg.addColorStop(0.88, "rgba(255,195,125,0.55)");
      pg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.arc(bx, by, br * 1.32 * ringPulse, 0, 6.283);
      ctx.fill();
      ctx.fillStyle = "#000";
      ctx.beginPath();
      ctx.arc(bx, by, br, 0, 6.283);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(bx, by, br * 1.5, br * 1.5, 0, Math.PI * 1.05, Math.PI * 1.95);
      ctx.strokeStyle = "rgba(255,215,155,0.35)";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      for (let i = 0; i < 48; i++) {
        const u = 1.9 - ((tt / 140) * m + i * 0.31) % 1.6;
        if (u < 1.08) continue;
        const a = (tt / 90) * m + i * 0.7;
        const x = bx + Math.cos(a) * u * br * 1.4;
        const y = by + Math.sin(a) * u * br * 0.5;
        ctx.fillStyle = `rgba(255,200,140,${0.7 * ((u - 1) / 0.9)})`;
        ctx.fillRect(x, y, 1.5, 1.5);
      }
    };

    /* AURORA BOREALIS — flowing ribbons of green/teal/violet light */
    const drawAurora = (W: number, H: number, tt: number, st: AgentState) => {
      const m = st === "think" ? 1.5 : st === "listen" ? 1.2 : 1;
      const bands = [
        { col: "120,255,170", y: 0.35, amp: 0.12, freq: 0.018, op: 0.55, w: 60 },
        { col: "80,220,200", y: 0.45, amp: 0.16, freq: 0.022, op: 0.45, w: 70 },
        { col: "160,120,255", y: 0.55, amp: 0.18, freq: 0.026, op: 0.4, w: 80 },
        { col: "100,180,255", y: 0.62, amp: 0.14, freq: 0.02, op: 0.35, w: 50 },
      ];
      // base night gradient
      const g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, "rgba(8,12,24,0)");
      g.addColorStop(0.7, "rgba(6,10,20,0.4)");
      g.addColorStop(1, "rgba(0,2,8,0.7)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
      for (const b of bands) {
        ctx.beginPath();
        ctx.moveTo(0, b.y * H);
        for (let x = 0; x <= W; x += 4) {
          const y =
            b.y * H +
            Math.sin((x * b.freq + tt / 60) * m) * (b.amp * H) +
            Math.sin((x * b.freq * 2.1 + tt / 35) * m) * (b.amp * 0.35 * H);
          ctx.lineTo(x, y);
        }
        for (let x = W; x >= 0; x -= 4) {
          const y =
            b.y * H +
            Math.sin((x * b.freq + tt / 60) * m) * (b.amp * H) +
            Math.sin((x * b.freq * 2.1 + tt / 35) * m) * (b.amp * 0.35 * H);
          ctx.lineTo(x, y + b.w);
        }
        ctx.closePath();
        const grad = ctx.createLinearGradient(0, b.y * H - b.w, 0, b.y * H + b.w);
        grad.addColorStop(0, `rgba(${b.col},0)`);
        grad.addColorStop(0.5, `rgba(${b.col},${b.op * (st === "speak" ? 0.8 + 0.2 * Math.sin(tt / 5) : 1)})`);
        grad.addColorStop(1, `rgba(${b.col},0)`);
        ctx.fillStyle = grad;
        ctx.fill();
      }
      // horizon glow
      const hg = ctx.createRadialGradient(W / 2, H, 0, W / 2, H, W * 0.7);
      hg.addColorStop(0, "rgba(80,140,180,0.18)");
      hg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = hg;
      ctx.fillRect(0, H * 0.4, W, H * 0.6);
    };

    /* PULSAR — fast-rotating neutron star with twin beams */
    const drawPulsar = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.13;
      const m = st === "think" ? 3 : st === "listen" ? 1.8 : st === "speak" ? 2.4 : 1;
      const beamAngle = (tt / 50) * m;
      const gc = stateCol(st);
      // halo
      const g = ctx.createRadialGradient(cx, cy, R, cx, cy, R * 6);
      g.addColorStop(0, `rgba(${gc},0.25)`);
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
      // twin beams (long rotating triangles)
      for (const side of [0, Math.PI]) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(beamAngle + side);
        const beamLen = R * (8 + (st === "speak" ? 1.5 * Math.sin(tt / 4) : 0));
        const grad = ctx.createLinearGradient(0, 0, beamLen, 0);
        grad.addColorStop(0, `rgba(220,240,255,${st === "speak" ? 0.85 : 0.5})`);
        grad.addColorStop(0.3, `rgba(${gc},0.4)`);
        grad.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.moveTo(0, -R * 0.18);
        ctx.lineTo(beamLen, -R * 0.05);
        ctx.lineTo(beamLen, R * 0.05);
        ctx.lineTo(0, R * 0.18);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
      // pulsar core
      const pulse = 1 + 0.06 * Math.sin(tt / 3);
      const pg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * pulse);
      pg.addColorStop(0, "#ffffff");
      pg.addColorStop(0.4, "#cfeaff");
      pg.addColorStop(0.8, "#5aa7ff");
      pg.addColorStop(1, "#0a2a55");
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.arc(cx, cy, R * pulse, 0, 6.283);
      ctx.fill();
      // ring of infalling matter
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(-beamAngle * 0.5);
      for (let i = 0; i < 50; i++) {
        const u = ((tt / 20 + i * 0.2) * m) % 2;
        if (u < 0.3) continue;
        const a = i * 0.13;
        const r = R * (1.4 + u * 0.8);
        const x = Math.cos(a) * r;
        const y = Math.sin(a) * r * 0.4;
        const al = (1 - u / 2) * 0.7;
        ctx.fillStyle = `rgba(200,220,255,${al})`;
        ctx.fillRect(x, y, 1.5, 1.5);
      }
      ctx.restore();
    };

    /* NEBULA CLOUD — colorful gas clouds with star-forming regions */
    const drawNebula = (W: number, H: number, tt: number, st: AgentState) => {
      const m = st === "think" ? 2 : 1;
      const boost = st === "listen" ? 1.25 : st === "speak" ? 1.15 : 1;
      const clouds = [
        { x: 0.32, y: 0.4, r: 0.45, col: "255,100,160", op: 0.35 },
        { x: 0.62, y: 0.55, r: 0.4, col: "120,160,255", op: 0.3 },
        { x: 0.5, y: 0.3, r: 0.5, col: "255,180,120", op: 0.28 },
        { x: 0.75, y: 0.35, r: 0.32, col: "180,120,255", op: 0.32 },
        { x: 0.22, y: 0.65, r: 0.36, col: "120,255,200", op: 0.22 },
      ];
      for (const c of clouds) {
        const x = c.x * W + Math.sin(tt / 400 + c.x * 7) * W * 0.015;
        const y = c.y * H + Math.cos(tt / 350 + c.y * 5) * H * 0.015;
        const r = c.r * Math.min(W, H);
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, `rgba(${c.col},${c.op * boost})`);
        g.addColorStop(0.5, `rgba(${c.col},${c.op * 0.4 * boost})`);
        g.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);
      }
      // dense bright clusters
      for (let i = 0; i < 60; i++) {
        const u = (i / 60) * 2;
        const a = u * 4.3 + tt / 800 * m;
        const r = Math.min(W, H) * (0.05 + ((i * 0.137) % 0.45));
        const cx = W / 2 + Math.cos(a) * r;
        const cy = H / 2 + Math.sin(a) * r;
        const al = 0.6 + 0.4 * Math.sin(tt / 18 + i);
        const sz = 1.5 + (i % 4) * 0.5;
        ctx.fillStyle = `rgba(255,240,220,${al})`;
        ctx.fillRect(cx - sz / 2, cy - sz / 2, sz, sz);
      }
      // hot stars in nebula
      for (let i = 0; i < 18; i++) {
        const x = ((i * 137.5) % W);
        const y = ((i * 73.3) % H);
        const al = 0.5 + 0.5 * Math.sin(tt / 30 + i);
        ctx.fillStyle = `rgba(220,200,255,${al})`;
        ctx.beginPath();
        ctx.arc(x, y, 1.5 + Math.sin(tt / 50 + i) * 0.5, 0, 6.283);
        ctx.fill();
        // diffraction spikes
        ctx.strokeStyle = `rgba(255,255,255,${al * 0.3})`;
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        ctx.moveTo(x - 4, y);
        ctx.lineTo(x + 4, y);
        ctx.moveTo(x, y - 4);
        ctx.lineTo(x, y + 4);
        ctx.stroke();
      }
    };

    /* BLACK HOLE close-up — massive accretion disk + photon ring + lensed starlight */
    const drawBlackHole = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.13;
      const m = st === "think" ? 2.5 : st === "listen" ? 1.5 : st === "speak" ? 2 : 1;
      const tilt = 0.35;
      // background glow
      const bg = ctx.createRadialGradient(cx, cy, R, cx, cy, R * 9);
      bg.addColorStop(0, "rgba(255,140,60,0.18)");
      bg.addColorStop(0.5, "rgba(120,80,200,0.08)");
      bg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);
      // lensed background stars (arc distortion)
      ctx.save();
      ctx.translate(cx, cy);
      for (let i = 0; i < 80; i++) {
        const a = i * 0.21 + tt / 600;
        const baseR = R * (2.5 + ((i * 0.73) % 6));
        // photon ring proximity bends the apparent position
        const bend = 1 + 0.6 / (1 + (baseR / R - 1));
        const r = baseR * bend;
        const x = Math.cos(a) * r;
        const y = Math.sin(a) * r * 0.7;
        const al = 0.4 + 0.6 * Math.abs(Math.sin(tt / 40 + i));
        ctx.fillStyle = `rgba(220,230,255,${al})`;
        ctx.fillRect(x, y, 1.4, 1.4);
      }
      ctx.restore();
      // accretion disk — many thin elliptical rings rotating
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(tilt);
      for (let k = 0; k < 40; k++) {
        const rr = R * (1.4 + k * 0.085);
        const ry = rr * 0.22;
        const phase = (tt / 30) * m + k * 0.4;
        const baseHue = 30 + k * 4; // amber → red
        const al = Math.max(0, 0.55 * (1 - k / 40)) * (st === "speak" ? 0.7 + 0.5 * Math.abs(Math.sin(tt / 4 - k * 0.3)) : 1);
        ctx.beginPath();
        ctx.ellipse(0, 0, rr, ry, 0, 0, 6.283);
        ctx.strokeStyle = `hsla(${baseHue}, 90%, ${60 - k * 0.5}%, ${al})`;
        ctx.lineWidth = 1.6;
        ctx.stroke();
        // bright hotspot on disk
        const hx = Math.cos(phase) * rr;
        const hy = Math.sin(phase) * ry;
        const hg = ctx.createRadialGradient(hx, hy, 0, hx, hy, rr * 0.12);
        hg.addColorStop(0, `hsla(${baseHue + 20}, 100%, 80%, ${al * 1.2})`);
        hg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = hg;
        ctx.beginPath();
        ctx.arc(hx, hy, rr * 0.12, 0, 6.283);
        ctx.fill();
      }
      ctx.restore();
      // photon ring (Einstein ring)
      const ringR = R * 1.05;
      const ringPulse = 1 + 0.02 * Math.sin(tt / 8);
      ctx.beginPath();
      ctx.arc(cx, cy, ringR * ringPulse, 0, 6.283);
      ctx.strokeStyle = `rgba(255,200,120,${0.85 * (st === "listen" ? 1.15 : 1)})`;
      ctx.lineWidth = 2.2;
      ctx.shadowBlur = 18;
      ctx.shadowColor = "rgba(255,180,100,0.8)";
      ctx.stroke();
      ctx.shadowBlur = 0;
      // event horizon (pure black)
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.92, 0, 6.283);
      ctx.fillStyle = "#000";
      ctx.fill();
      // secondary ring (inner photon sphere glow)
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.92, 0, 6.283);
      const hg = ctx.createRadialGradient(cx, cy, R * 0.92, cx, cy, R * 1.1);
      hg.addColorStop(0, "rgba(0,0,0,0)");
      hg.addColorStop(0.5, "rgba(255,180,80,0.5)");
      hg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = hg;
      ctx.fill();
    };

    /* SUPERNOVA — exploding star with shockwave + debris + flash */
    const drawSupernova = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const m = st === "think" ? 1.8 : st === "speak" ? 1.5 : 1;
      // cyclical explosion — every 8 seconds
      const cycle = (tt / 60) % 8;
      const phase = cycle / 8; // 0..1
      const flash = phase < 0.08 ? (0.08 - phase) / 0.08 : 0;
      const shockwaveR = phase * Math.min(W, H) * 0.6;
      // background tint
      const bg = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(W, H) * 0.7);
      bg.addColorStop(0, `rgba(255,${220 - phase * 80},${150 - phase * 100},${0.35 * (1 - phase * 0.5)})`);
      bg.addColorStop(0.5, "rgba(120,60,180,0.1)");
      bg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);
      // starfield shift (parallax outward)
      ctx.save();
      ctx.translate(cx, cy);
      for (let i = 0; i < 60; i++) {
        const a = i * 0.37;
        const r = (i % 12 + 1) * 30 * (1 + phase * 0.4 * m);
        const x = Math.cos(a) * r;
        const y = Math.sin(a) * r;
        const al = 0.3 + 0.7 * Math.abs(Math.sin(tt / 30 + i));
        ctx.fillStyle = `rgba(255,240,200,${al})`;
        ctx.fillRect(x, y, 1.4, 1.4);
      }
      ctx.restore();
      // shockwave ring (expanding)
      if (shockwaveR > 10) {
        ctx.beginPath();
        ctx.arc(cx, cy, shockwaveR, 0, 6.283);
        ctx.strokeStyle = `rgba(255,${180 - phase * 100},${100 - phase * 80},${0.6 * (1 - phase)})`;
        ctx.lineWidth = 3 + 4 * (1 - phase);
        ctx.stroke();
        // secondary shockwave
        ctx.beginPath();
        ctx.arc(cx, cy, shockwaveR * 0.7, 0, 6.283);
        ctx.strokeStyle = `rgba(255,220,160,${0.35 * (1 - phase)})`;
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      // debris particles flying outward
      ctx.save();
      ctx.translate(cx, cy);
      for (let i = 0; i < 120; i++) {
        const a = (i / 120) * 6.283 + i * 0.07;
        const speed = 1 + (i % 5) * 0.5;
        const r = phase * Math.min(W, H) * 0.5 * speed * (0.7 + 0.6 * Math.sin(i));
        const x = Math.cos(a) * r;
        const y = Math.sin(a) * r;
        const al = (1 - phase) * (0.5 + 0.5 * Math.sin(tt / 20 + i));
        const hue = (i % 3 === 0) ? 30 : (i % 3 === 1) ? 0 : 280;
        ctx.fillStyle = `hsla(${hue}, 90%, ${65 - phase * 25}%, ${al})`;
        const sz = 1.5 + (i % 3);
        ctx.fillRect(x, y, sz, sz);
      }
      ctx.restore();
      // core star
      const coreR = Math.min(W, H) * 0.08 * (1 + flash * 2.5);
      const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, coreR * 3);
      cg.addColorStop(0, `rgba(255,255,${230 - phase * 100},${0.95 + flash * 0.5})`);
      cg.addColorStop(0.3, `rgba(255,${180 - phase * 80},100,${0.6 * (1 - phase * 0.5)})`);
      cg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.arc(cx, cy, coreR * 3, 0, 6.283);
      ctx.fill();
      // bright flash
      if (flash > 0) {
        ctx.fillStyle = `rgba(255,255,255,${flash * 0.7})`;
        ctx.fillRect(0, 0, W, H);
      }
    };

    /* SOLAR FLARE — sun with erupting prominences + corona + flare bursts */
    const drawSolarFlare = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.18;
      const m = st === "think" ? 1.6 : st === "speak" ? 1.3 : 1;
      // outer corona
      const cg = ctx.createRadialGradient(cx, cy, R, cx, cy, R * 4.5);
      cg.addColorStop(0, "rgba(255,180,80,0.35)");
      cg.addColorStop(0.4, "rgba(255,120,40,0.18)");
      cg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = cg;
      ctx.fillRect(0, 0, W, H);
      // sun body
      const sg = ctx.createRadialGradient(cx - R * 0.3, cy - R * 0.3, 0, cx, cy, R);
      sg.addColorStop(0, "#fff8e0");
      sg.addColorStop(0.4, "#ffd76a");
      sg.addColorStop(0.8, "#ff8c30");
      sg.addColorStop(1, "#c44010");
      ctx.fillStyle = sg;
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 6.283);
      ctx.fill();
      // surface granulation
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 6.283);
      ctx.clip();
      for (let i = 0; i < 30; i++) {
        const a = i * 0.41 + tt / 200;
        const rr = R * (0.3 + (i % 5) * 0.14);
        const gx = cx + Math.cos(a) * rr;
        const gy = cy + Math.sin(a) * rr;
        const gr = 6 + (i % 4) * 3;
        const gg = ctx.createRadialGradient(gx, gy, 0, gx, gy, gr);
        gg.addColorStop(0, `rgba(255,${180 - (i % 3) * 30},60,0.5)`);
        gg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = gg;
        ctx.beginPath();
        ctx.arc(gx, gy, gr, 0, 6.283);
        ctx.fill();
      }
      ctx.restore();
      // prominences (erupting arcs from surface)
      for (let i = 0; i < 8; i++) {
        const baseA = (i / 8) * 6.283 + tt / 600 * m;
        const phase = (tt / 80 + i * 1.7) % 6.283;
        const peakH = R * (0.25 + 0.35 * Math.abs(Math.sin(phase)));
        const bx = cx + Math.cos(baseA) * R;
        const by = cy + Math.sin(baseA) * R;
        const tx = cx + Math.cos(baseA) * (R + peakH);
        const ty = cy + Math.sin(baseA) * (R + peakH);
        const mx = (bx + tx) / 2 + Math.cos(baseA + Math.PI / 2) * peakH * 0.5;
        const my = (by + ty) / 2 + Math.sin(baseA + Math.PI / 2) * peakH * 0.5;
        ctx.beginPath();
        ctx.moveTo(bx, by);
        ctx.quadraticCurveTo(mx, my, tx, ty);
        ctx.quadraticCurveTo(mx, my, bx, by);
        const al = 0.4 + 0.4 * Math.sin(phase);
        ctx.strokeStyle = `rgba(255,${140 + 40 * Math.sin(phase)},40,${al})`;
        ctx.lineWidth = 3;
        ctx.shadowBlur = 12;
        ctx.shadowColor = "rgba(255,120,40,0.8)";
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
      // flare bursts (occasional bright flashes at edge)
      for (let i = 0; i < 5; i++) {
        const a = i * 1.27 + tt / 90 * m;
        const burstPhase = (tt / 40 + i * 2.3) % 4;
        if (burstPhase > 1) continue;
        const fr = R * (1 + burstPhase * 0.3);
        const fx = cx + Math.cos(a) * fr;
        const fy = cy + Math.sin(a) * fr;
        const fa = (1 - burstPhase) * 0.7;
        const fg = ctx.createRadialGradient(fx, fy, 0, fx, fy, 30);
        fg.addColorStop(0, `rgba(255,255,200,${fa})`);
        fg.addColorStop(1, "rgba(255,180,40,0)");
        ctx.fillStyle = fg;
        ctx.beginPath();
        ctx.arc(fx, fy, 30, 0, 6.283);
        ctx.fill();
      }
    };

    /* QUASAR — supermassive black hole with relativistic jets shooting out */
    const drawQuasar = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.1;
      const m = st === "think" ? 2.2 : st === "speak" ? 1.6 : 1;
      // background glow (reddish accretion)
      const bg = ctx.createRadialGradient(cx, cy, R, cx, cy, Math.max(W, H));
      bg.addColorStop(0, "rgba(255,80,40,0.22)");
      bg.addColorStop(0.4, "rgba(180,40,180,0.1)");
      bg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);
      // relativistic jets (perpendicular to disk)
      const jetLen = Math.min(W, H) * 0.55;
      for (const dir of [-1, 1]) {
        const jg = ctx.createLinearGradient(cx, cy, cx, cy + dir * jetLen);
        jg.addColorStop(0, `rgba(180,220,255,${0.85 * (st === "speak" ? 1.2 : 1)})`);
        jg.addColorStop(0.3, "rgba(120,180,255,0.5)");
        jg.addColorStop(0.7, "rgba(80,140,255,0.25)");
        jg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = jg;
        ctx.beginPath();
        ctx.moveTo(cx - R * 0.3, cy);
        ctx.lineTo(cx + R * 0.3, cy);
        ctx.lineTo(cx + R * 0.15, cy + dir * jetLen);
        ctx.lineTo(cx - R * 0.15, cy + dir * jetLen);
        ctx.closePath();
        ctx.fill();
        // jet particles (turbulent)
        for (let i = 0; i < 40; i++) {
          const u = ((tt / 18 + i * 0.31) * m) % 1;
          if (u < 0.05) continue;
          const px = cx + (Math.sin(u * 8 + i) * R * 0.4);
          const py = cy + dir * u * jetLen;
          const al = (1 - u) * 0.7;
          ctx.fillStyle = `rgba(200,230,255,${al})`;
          ctx.fillRect(px, py, 1.5, 1.5);
        }
      }
      // accretion disk (thin, viewed edge-on but bright)
      ctx.save();
      ctx.translate(cx, cy);
      for (let k = 0; k < 30; k++) {
        const rr = R * (1.3 + k * 0.13);
        const ry = rr * 0.16;
        const phase = (tt / 24) * m + k * 0.3;
        const hue = 15 + k * 3; // red → orange
        const al = Math.max(0, 0.6 * (1 - k / 30));
        ctx.beginPath();
        ctx.ellipse(0, 0, rr, ry, 0, 0, 6.283);
        ctx.strokeStyle = `hsla(${hue}, 95%, ${55 - k * 0.3}%, ${al})`;
        ctx.lineWidth = 1.4;
        ctx.stroke();
        // bright spot on disk
        const hx = Math.cos(phase) * rr;
        const hy = Math.sin(phase) * ry;
        const hg = ctx.createRadialGradient(hx, hy, 0, hx, hy, rr * 0.18);
        hg.addColorStop(0, `hsla(${hue + 15}, 100%, 80%, ${al * 1.3})`);
        hg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = hg;
        ctx.beginPath();
        ctx.arc(hx, hy, rr * 0.18, 0, 6.283);
        ctx.fill();
      }
      ctx.restore();
      // black hole core
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 6.283);
      ctx.fillStyle = "#000";
      ctx.fill();
      // photon ring
      ctx.beginPath();
      ctx.arc(cx, cy, R * 1.04, 0, 6.283);
      ctx.strokeStyle = "rgba(255,180,80,0.8)";
      ctx.lineWidth = 1.8;
      ctx.shadowBlur = 14;
      ctx.shadowColor = "rgba(255,150,60,0.7)";
      ctx.stroke();
      ctx.shadowBlur = 0;
    };

    /* WORMHOLE — tunnel of swirling light rings (Einstein-Rosen bridge) */
    const drawWormhole = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const m = st === "think" ? 2 : st === "speak" ? 1.4 : 1;
      const maxR = Math.max(W, H) * 0.7;
      // background void
      ctx.fillStyle = "rgba(2,4,12,0.4)";
      ctx.fillRect(0, 0, W, H);
      // concentric rings moving toward viewer (depth)
      for (let i = 0; i < 36; i++) {
        const u = ((i / 36) + (tt / 200) * m) % 1; // 0..1 depth
        const r = u * maxR;
        if (r < 4) continue;
        const hue = 200 + u * 80; // blue → purple → magenta
        const al = Math.max(0, 0.6 * (1 - u * 0.7)) * (1 - Math.pow(1 - u, 3) * 0.5);
        const ry = r * 0.95;
        // swirling rotation
        const rot = (tt / 80) * m + u * 4;
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(rot);
        ctx.beginPath();
        ctx.ellipse(0, 0, r, ry, 0, 0, 6.283);
        ctx.strokeStyle = `hsla(${hue}, 90%, ${50 + u * 30}%, ${al})`;
        ctx.lineWidth = 1 + u * 2;
        ctx.stroke();
        // bright arc on one side
        ctx.beginPath();
        ctx.ellipse(0, 0, r, ry, 0, 0, Math.PI * 0.6);
        ctx.strokeStyle = `hsla(${hue + 20}, 100%, 75%, ${al * 1.4})`;
        ctx.lineWidth = 1.5 + u * 1.5;
        ctx.shadowBlur = 8;
        ctx.shadowColor = `hsla(${hue}, 100%, 60%, 0.6)`;
        ctx.stroke();
        ctx.shadowBlur = 0;
        ctx.restore();
      }
      // central bright event horizon (the other side)
      const eg = ctx.createRadialGradient(cx, cy, 0, cx, cy, maxR * 0.15);
      eg.addColorStop(0, `rgba(255,255,255,${0.9 + 0.1 * Math.sin(tt / 6)})`);
      eg.addColorStop(0.4, "rgba(180,220,255,0.6)");
      eg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = eg;
      ctx.beginPath();
      ctx.arc(cx, cy, maxR * 0.15, 0, 6.283);
      ctx.fill();
      // streaking particles through tunnel
      for (let i = 0; i < 80; i++) {
        const u = ((tt / 60 + i * 0.087) * m) % 1;
        const a = i * 0.27 + tt / 600;
        const r = u * maxR * 0.95;
        const x = cx + Math.cos(a) * r;
        const y = cy + Math.sin(a) * r;
        const al = (1 - u) * 0.8;
        const len = 2 + u * 6;
        ctx.strokeStyle = `rgba(220,230,255,${al})`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + Math.cos(a) * len, y + Math.sin(a) * len);
        ctx.stroke();
      }
    };

    /* BINARY STAR — two stars orbiting with shared accretion stream + Lagrange glow */
    const drawBinaryStar = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const m = st === "think" ? 1.8 : st === "speak" ? 1.4 : 1;
      const sep = Math.min(W, H) * 0.18;
      const orbitT = (tt / 180) * m;
      // primary (orange giant) + secondary (blue dwarf)
      const x1 = cx + Math.cos(orbitT) * sep * 0.4;
      const y1 = cy + Math.sin(orbitT) * sep * 0.4;
      const x2 = cx - Math.cos(orbitT) * sep * 0.6;
      const y2 = cy - Math.sin(orbitT) * sep * 0.6;
      const R1 = Math.min(W, H) * 0.075;
      const R2 = Math.min(W, H) * 0.045;
      // background glow
      const bg = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.min(W, H) * 0.6);
      bg.addColorStop(0, "rgba(255,180,80,0.12)");
      bg.addColorStop(0.5, "rgba(80,140,255,0.08)");
      bg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);
      // accretion stream from secondary → primary (curved gas trail)
      const steps = 30;
      ctx.beginPath();
      for (let i = 0; i <= steps; i++) {
        const u = i / steps;
        const sx = x2 + (x1 - x2) * u;
        const sy = y2 + (y1 - y2) * u + Math.sin(u * Math.PI) * 20 * Math.sin(tt / 30);
        if (i === 0) ctx.moveTo(sx, sy);
        else ctx.lineTo(sx, sy);
      }
      ctx.strokeStyle = `rgba(255,200,120,${0.4 + 0.2 * Math.sin(tt / 20)})`;
      ctx.lineWidth = 4;
      ctx.shadowBlur = 10;
      ctx.shadowColor = "rgba(255,180,80,0.6)";
      ctx.stroke();
      ctx.shadowBlur = 0;
      // particles along stream
      for (let i = 0; i < 40; i++) {
        const u = ((tt / 60 + i * 0.025) * m) % 1;
        const sx = x2 + (x1 - x2) * u;
        const sy = y2 + (y1 - y2) * u + Math.sin(u * Math.PI) * 20 * Math.sin(tt / 30);
        const al = Math.sin(u * Math.PI) * 0.8;
        ctx.fillStyle = `rgba(255,220,150,${al})`;
        ctx.fillRect(sx, sy, 1.6, 1.6);
      }
      // primary star (orange giant) with corona
      const p1g = ctx.createRadialGradient(x1, y1, 0, x1, y1, R1 * 2.2);
      p1g.addColorStop(0, "rgba(255,180,80,0.7)");
      p1g.addColorStop(0.5, "rgba(255,120,40,0.25)");
      p1g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = p1g;
      ctx.beginPath();
      ctx.arc(x1, y1, R1 * 2.2, 0, 6.283);
      ctx.fill();
      const s1g = ctx.createRadialGradient(x1 - R1 * 0.3, y1 - R1 * 0.3, 0, x1, y1, R1);
      s1g.addColorStop(0, "#fff5d0");
      s1g.addColorStop(0.5, "#ffb84a");
      s1g.addColorStop(1, "#c45010");
      ctx.fillStyle = s1g;
      ctx.beginPath();
      ctx.arc(x1, y1, R1, 0, 6.283);
      ctx.fill();
      // secondary star (blue dwarf) with corona
      const p2g = ctx.createRadialGradient(x2, y2, 0, x2, y2, R2 * 2.5);
      p2g.addColorStop(0, "rgba(120,180,255,0.7)");
      p2g.addColorStop(0.5, "rgba(80,140,255,0.25)");
      p2g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = p2g;
      ctx.beginPath();
      ctx.arc(x2, y2, R2 * 2.5, 0, 6.283);
      ctx.fill();
      const s2g = ctx.createRadialGradient(x2 - R2 * 0.3, y2 - R2 * 0.3, 0, x2, y2, R2);
      s2g.addColorStop(0, "#e0f0ff");
      s2g.addColorStop(0.5, "#6ab0ff");
      s2g.addColorStop(1, "#1c4fa0");
      ctx.fillStyle = s2g;
      ctx.beginPath();
      ctx.arc(x2, y2, R2, 0, 6.283);
      ctx.fill();
      // orbit trace (faint ellipse)
      ctx.beginPath();
      ctx.ellipse(cx, cy, sep * 0.4, sep * 0.4, 0, 0, 6.283);
      ctx.strokeStyle = "rgba(255,200,120,0.08)";
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.beginPath();
      ctx.ellipse(cx, cy, sep * 0.6, sep * 0.6, 0, 0, 6.283);
      ctx.strokeStyle = "rgba(120,180,255,0.08)";
      ctx.stroke();
    };

    /* MAGNETAR — neutron star with powerful magnetic field loops + polar jets */
    const drawMagnetar = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.09;
      const m = st === "think" ? 2 : st === "speak" ? 1.6 : 1;
      const rot = (tt / 200) * m;
      // pulsing halo (magnetic field disturbance)
      const haloPulse = 1 + 0.08 * Math.sin(tt / 8);
      const hg = ctx.createRadialGradient(cx, cy, R, cx, cy, R * 7 * haloPulse);
      hg.addColorStop(0, `rgba(150,200,255,${0.3 * (st === "speak" ? 1.3 : 1)})`);
      hg.addColorStop(0.5, "rgba(120,100,220,0.1)");
      hg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = hg;
      ctx.fillRect(0, 0, W, H);
      // magnetic field loops (dipole — closed loops from N to S pole)
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(rot);
      for (let k = 1; k <= 5; k++) {
        const ringR = R * (1.5 + k * 0.6);
        ctx.beginPath();
        ctx.ellipse(0, 0, ringR, ringR * 1.6, 0, 0, 6.283);
        ctx.strokeStyle = `rgba(180,220,255,${0.35 - k * 0.05})`;
        ctx.lineWidth = 1.2;
        ctx.shadowBlur = 6;
        ctx.shadowColor = "rgba(150,200,255,0.5)";
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
      ctx.restore();
      // polar jets (along magnetic axis)
      for (const dir of [-1, 1]) {
        const jg = ctx.createLinearGradient(cx, cy, cx, cy + dir * R * 5);
        jg.addColorStop(0, "rgba(180,220,255,0.6)");
        jg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(rot);
        ctx.fillStyle = jg;
        ctx.beginPath();
        ctx.moveTo(-R * 0.2, 0);
        ctx.lineTo(R * 0.2, 0);
        ctx.lineTo(R * 0.08, dir * R * 5);
        ctx.lineTo(-R * 0.08, dir * R * 5);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
      // magnetar core (intense blue-white)
      const pulse = 1 + 0.05 * Math.sin(tt / 4);
      const cg = ctx.createRadialGradient(cx - R * 0.2, cy - R * 0.2, 0, cx, cy, R * pulse);
      cg.addColorStop(0, "#ffffff");
      cg.addColorStop(0.4, "#cfe4ff");
      cg.addColorStop(0.8, "#4a7fd0");
      cg.addColorStop(1, "#0a1c44");
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.arc(cx, cy, R * pulse, 0, 6.283);
      ctx.fill();
      // starquake bursts (occasional ripples)
      const quakePhase = (tt / 80) % 4;
      if (quakePhase < 1.5) {
        const qr = R * (1 + quakePhase * 1.5);
        ctx.beginPath();
        ctx.arc(cx, cy, qr, 0, 6.283);
        ctx.strokeStyle = `rgba(200,230,255,${0.5 * (1 - quakePhase / 1.5)})`;
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    };

    /* COSMIC WEB — large-scale structure: filaments + galaxy clusters + voids */
    const drawCosmicWeb = (W: number, H: number, tt: number, st: AgentState) => {
      const m = st === "think" ? 1.5 : 1;
      const boost = st === "listen" ? 1.2 : st === "speak" ? 1.15 : 1;
      // dark voids background
      ctx.fillStyle = "rgba(4,6,16,0.4)";
      ctx.fillRect(0, 0, W, H);
      // pre-computed node positions (deterministic — uses golden ratio spacing)
      const nodes: { x: number; y: number; mass: number }[] = [];
      for (let i = 0; i < 40; i++) {
        const x = ((i * 137.5) % W);
        const y = ((i * 73.3 + (i % 3) * 200) % H);
        nodes.push({ x, y, mass: 0.5 + (i % 5) * 0.3 });
      }
      // filaments (connect nearby nodes)
      ctx.lineWidth = 1;
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i], b = nodes[j];
          const dx = b.x - a.x, dy = b.y - a.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < Math.min(W, H) * 0.25) {
            const al = (1 - dist / (Math.min(W, H) * 0.25)) * 0.35 * boost;
            ctx.strokeStyle = `rgba(180,160,255,${al})`;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            // slight curve via midpoint offset
            const mx = (a.x + b.x) / 2 + Math.sin(tt / 200 + i + j) * 8;
            const my = (a.y + b.y) / 2 + Math.cos(tt / 220 + i + j) * 8;
            ctx.quadraticCurveTo(mx, my, b.x, b.y);
            ctx.stroke();
          }
        }
      }
      // galaxy clusters (bright nodes with glow)
      for (let i = 0; i < nodes.length; i++) {
        const n = nodes[i];
        const pulse = 1 + 0.3 * Math.sin(tt / 30 + i);
        const sz = n.mass * 3 * pulse * boost;
        // glow
        const gg = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, sz * 6);
        const hue = (i % 3 === 0) ? "255,200,150" : (i % 3 === 1) ? "180,200,255" : "230,180,255";
        gg.addColorStop(0, `rgba(${hue},${0.7 * boost})`);
        gg.addColorStop(0.4, `rgba(${hue},${0.2 * boost})`);
        gg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = gg;
        ctx.beginPath();
        ctx.arc(n.x, n.y, sz * 6, 0, 6.283);
        ctx.fill();
        // core
        ctx.fillStyle = `rgba(255,240,220,${0.9 * boost})`;
        ctx.beginPath();
        ctx.arc(n.x, n.y, sz, 0, 6.283);
        ctx.fill();
        // surrounding stars in cluster
        for (let s = 0; s < 8; s++) {
          const a = s * 0.785 + tt / 800 * m + i;
          const r = sz * (2 + (s % 3));
          ctx.fillStyle = `rgba(220,220,255,${0.4 + 0.4 * Math.sin(tt / 40 + s + i)})`;
          ctx.fillRect(n.x + Math.cos(a) * r, n.y + Math.sin(a) * r, 1.2, 1.2);
        }
      }
    };

    /* WHITE DWARF — dense Earth-sized stellar core with crystallization + faint planetary nebula */
    const drawWhiteDwarf = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.06;
      const m = st === "think" ? 1.5 : st === "speak" ? 1.2 : 1;
      // planetary nebula (faint outer glow — leftover gas)
      const ng = ctx.createRadialGradient(cx, cy, R * 3, cx, cy, R * 18);
      ng.addColorStop(0, "rgba(120,180,255,0.18)");
      ng.addColorStop(0.4, "rgba(150,120,220,0.1)");
      ng.addColorStop(0.8, "rgba(80,100,180,0.05)");
      ng.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = ng;
      ctx.fillRect(0, 0, W, H);
      // nebula filaments (curved wisps)
      for (let i = 0; i < 6; i++) {
        const a0 = i * (Math.PI * 2 / 6) + tt / 1200 * m;
        ctx.beginPath();
        for (let s = 0; s <= 30; s++) {
          const u = s / 30;
          const r = R * (3 + u * 8);
          const wobble = Math.sin(u * 6 + tt / 60 + i) * 0.3;
          const a = a0 + wobble;
          const x = cx + Math.cos(a) * r;
          const y = cy + Math.sin(a) * r * 0.7;
          if (s === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.strokeStyle = `rgba(180,200,255,${0.12 + 0.08 * Math.sin(tt / 40 + i)})`;
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      // intense white core with pulsation
      const pulse = 1 + 0.04 * Math.sin(tt / 5);
      const cg = ctx.createRadialGradient(cx - R * 0.2, cy - R * 0.2, 0, cx, cy, R * pulse * 2);
      cg.addColorStop(0, "#ffffff");
      cg.addColorStop(0.3, "#e8f0ff");
      cg.addColorStop(0.6, "#a0c0ff");
      cg.addColorStop(0.85, "#3a5a8a");
      cg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.arc(cx, cy, R * pulse * 2, 0, 6.283);
      ctx.fill();
      // dense core
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(cx, cy, R * pulse, 0, 6.283);
      ctx.fill();
      // crystallization lattice (faint hexagonal pattern clipped to core)
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R * pulse * 0.95, 0, 6.283);
      ctx.clip();
      ctx.strokeStyle = `rgba(120,180,255,${0.25 + 0.15 * Math.sin(tt / 20)})`;
      ctx.lineWidth = 0.5;
      const hex = R * 0.35;
      for (let row = -3; row <= 3; row++) {
        for (let col = -3; col <= 3; col++) {
          const ox = col * hex * 1.5 + (row % 2 ? hex * 0.75 : 0);
          const oy = row * hex * 1.3;
          ctx.beginPath();
          for (let k = 0; k < 6; k++) {
            const a = k * Math.PI / 3 + tt / 600;
            const x = cx + ox + Math.cos(a) * hex * 0.5;
            const y = cy + oy + Math.sin(a) * hex * 0.5;
            if (k === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
          }
          ctx.closePath();
          ctx.stroke();
        }
      }
      ctx.restore();
      // diffraction spikes
      ctx.strokeStyle = `rgba(255,255,255,${0.5 * (st === "speak" ? 1.3 : 1)})`;
      ctx.lineWidth = 1;
      const spikeLen = R * (6 + (st === "speak" ? 2 * Math.sin(tt / 4) : 0));
      ctx.beginPath();
      ctx.moveTo(cx - spikeLen, cy); ctx.lineTo(cx + spikeLen, cy);
      ctx.moveTo(cx, cy - spikeLen); ctx.lineTo(cx, cy + spikeLen);
      ctx.stroke();
    };

    /* NEUTRON STAR MERGER — two inspiraling NS with kilonova ejecta + GW ripples */
    const drawNsMerger = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const m = st === "think" ? 2 : st === "speak" ? 1.5 : 1;
      // cyclical inspiral + merger every 6 seconds
      const cycle = (tt / 60) % 6;
      const phase = cycle / 6; // 0..1
      const merged = phase > 0.7;
      const R = Math.min(W, H) * 0.04;
      // gravitational wave ripples (concentric expanding circles)
      for (let i = 0; i < 5; i++) {
        const gwU = ((tt / 80 + i * 0.2) * m) % 1;
        if (gwU < 0.05) continue;
        const gwR = gwU * Math.min(W, H) * 0.5;
        ctx.beginPath();
        ctx.arc(cx, cy, gwR, 0, 6.283);
        ctx.strokeStyle = `rgba(180,160,255,${0.3 * (1 - gwU)})`;
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
      // kilonova ejecta (after merger)
      if (merged) {
        const mergerU = (phase - 0.7) / 0.3;
        for (let i = 0; i < 80; i++) {
          const a = (i / 80) * 6.283 + i * 0.13;
          const speed = 0.5 + (i % 5) * 0.3;
          const r = mergerU * Math.min(W, H) * 0.4 * speed;
          const x = cx + Math.cos(a) * r;
          const y = cy + Math.sin(a) * r * 0.6;
          const al = (1 - mergerU) * 0.8;
          const hue = i % 3 === 0 ? 40 : i % 3 === 1 ? 0 : 280; // amber/red/purple
          ctx.fillStyle = `hsla(${hue}, 90%, ${65 - mergerU * 25}%, ${al})`;
          const sz = 2 + (i % 3);
          ctx.fillRect(x, y, sz, sz);
        }
        // kilonova flash
        const flashG = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.min(W, H) * 0.3);
        flashG.addColorStop(0, `rgba(255,255,255,${0.6 * (1 - mergerU)})`);
        flashG.addColorStop(0.5, `rgba(255,180,80,${0.3 * (1 - mergerU)})`);
        flashG.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = flashG;
        ctx.fillRect(0, 0, W, H);
      }
      // two neutron stars inspiraling
      if (!merged) {
        const sep = R * (8 * (1 - phase * 0.85)); // shrinking orbit
        const orbitT = (tt / 10) * m * (1 + phase * 5); // accelerating
        for (const dir of [-1, 1]) {
          const x = cx + Math.cos(orbitT) * sep * dir;
          const y = cy + Math.sin(orbitT) * sep * dir * 0.6;
          // corona
          const cg = ctx.createRadialGradient(x, y, 0, x, y, R * 4);
          cg.addColorStop(0, "rgba(180,220,255,0.6)");
          cg.addColorStop(1, "rgba(0,0,0,0)");
          ctx.fillStyle = cg;
          ctx.beginPath();
          ctx.arc(x, y, R * 4, 0, 6.283);
          ctx.fill();
          // dense core
          ctx.fillStyle = "#cfe4ff";
          ctx.beginPath();
          ctx.arc(x, y, R, 0, 6.283);
          ctx.fill();
          ctx.fillStyle = "#ffffff";
          ctx.beginPath();
          ctx.arc(x - R * 0.3, y - R * 0.3, R * 0.4, 0, 6.283);
          ctx.fill();
        }
        // tidal disruption trail between the two
        const x1 = cx + Math.cos(orbitT) * sep;
        const y1 = cy + Math.sin(orbitT) * sep * 0.6;
        const x2 = cx - Math.cos(orbitT) * sep;
        const y2 = cy - Math.sin(orbitT) * sep * 0.6;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.quadraticCurveTo(cx, cy, x2, y2);
        ctx.strokeStyle = `rgba(180,220,255,${0.3 + 0.4 * phase})`;
        ctx.lineWidth = 1 + phase * 3;
        ctx.stroke();
      } else {
        // post-merger single bright object
        const mergerR = R * (1 + (phase - 0.7) * 3);
        const mg = ctx.createRadialGradient(cx, cy, 0, cx, cy, mergerR * 3);
        mg.addColorStop(0, "#ffffff");
        mg.addColorStop(0.3, "#ffd870");
        mg.addColorStop(0.7, "#ff6020");
        mg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = mg;
        ctx.beginPath();
        ctx.arc(cx, cy, mergerR * 3, 0, 6.283);
        ctx.fill();
      }
    };

    /* ACCRETION DISK — detailed disk around central object with spiral density waves */
    const drawAccretionDisk = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.08;
      const m = st === "think" ? 2 : st === "speak" ? 1.5 : 1;
      const tilt = 0.42; // disk tilt
      // outer halo
      const bg = ctx.createRadialGradient(cx, cy, R, cx, cy, R * 12);
      bg.addColorStop(0, "rgba(255,140,60,0.15)");
      bg.addColorStop(0.5, "rgba(120,80,200,0.08)");
      bg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(tilt);
      // disk rings with spiral density waves
      for (let k = 0; k < 60; k++) {
        const rr = R * (1.3 + k * 0.075);
        const ry = rr * 0.20;
        const phase = (tt / 22) * m * (1 + 0.5 / (1 + k * 0.1));
        const baseHue = 25 + k * 2.5;
        const al = Math.max(0, 0.6 * (1 - k / 60));
        // spiral density modulation
        const armMod = 0.5 + 0.5 * Math.sin(k * 0.3 + phase * 0.5);
        // draw partial arcs to simulate spiral arms
        for (let arc = 0; arc < 4; arc++) {
          const aStart = arc * (Math.PI / 2) + phase;
          const aEnd = aStart + Math.PI / 2 * (0.5 + 0.4 * armMod);
          ctx.beginPath();
          ctx.ellipse(0, 0, rr, ry, 0, aStart, aEnd);
          ctx.strokeStyle = `hsla(${baseHue}, 90%, ${55 - k * 0.4}%, ${al * armMod})`;
          ctx.lineWidth = 1.6;
          ctx.stroke();
        }
        // bright hot spots on inner edge
        if (k < 12) {
          const hphase = (tt / 30) * m + k * 0.5;
          const hx = Math.cos(hphase) * rr;
          const hy = Math.sin(hphase) * ry;
          const hg = ctx.createRadialGradient(hx, hy, 0, hx, hy, rr * 0.15);
          hg.addColorStop(0, `hsla(${baseHue + 25}, 100%, 80%, ${al * 1.3})`);
          hg.addColorStop(1, "rgba(0,0,0,0)");
          ctx.fillStyle = hg;
          ctx.beginPath();
          ctx.arc(hx, hy, rr * 0.15, 0, 6.283);
          ctx.fill();
        }
      }
      ctx.restore();
      // central object — pure black event horizon
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.85, 0, 6.283);
      ctx.fillStyle = "#000";
      ctx.fill();
      // photon ring (thin bright circle at ISCO)
      const ringPulse = 1 + 0.015 * Math.sin(tt / 9);
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.95 * ringPulse, 0, 6.283);
      ctx.strokeStyle = `rgba(255,200,120,${0.9 * (st === "listen" ? 1.15 : 1)})`;
      ctx.lineWidth = 2;
      ctx.shadowBlur = 16;
      ctx.shadowColor = "rgba(255,180,80,0.7)";
      ctx.stroke();
      ctx.shadowBlur = 0;
      // relativistic beaming — brighter top of disk (Doppler boost)
      const beam = ctx.createLinearGradient(0, cy - R * 5, 0, cy + R * 5);
      beam.addColorStop(0, "rgba(255,200,120,0.12)");
      beam.addColorStop(0.5, "rgba(0,0,0,0)");
      beam.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = beam;
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(tilt);
      ctx.fillRect(-R * 8, -R * 5, R * 16, R * 10);
      ctx.restore();
    };

    /* PWN — Pulsar Wind Nebula: pulsar + relativistic wind + synchrotron nebula */
    const drawPWN = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.04;
      const m = st === "think" ? 1.8 : st === "speak" ? 1.4 : 1;
      // outer nebula glow (synchrotron emission)
      const ng = ctx.createRadialGradient(cx, cy, R * 2, cx, cy, R * 16);
      ng.addColorStop(0, "rgba(120,180,255,0.25)");
      ng.addColorStop(0.4, "rgba(180,120,255,0.15)");
      ng.addColorStop(0.7, "rgba(255,120,200,0.08)");
      ng.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = ng;
      ctx.fillRect(0, 0, W, H);
      // wispy filaments of the nebula
      for (let i = 0; i < 18; i++) {
        const a0 = i * 0.41 + tt / 400 * m;
        ctx.beginPath();
        for (let s = 0; s <= 25; s++) {
          const u = s / 25;
          const r = R * (3 + u * 9);
          const wobble = Math.sin(u * 5 + tt / 50 + i * 0.7) * 0.4;
          const a = a0 + wobble;
          const x = cx + Math.cos(a) * r;
          const y = cy + Math.sin(a) * r * 0.7;
          if (s === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        const hue = (i % 3 === 0) ? 200 : (i % 3 === 1) ? 280 : 320;
        const al = 0.18 + 0.1 * Math.sin(tt / 30 + i);
        ctx.strokeStyle = `hsla(${hue}, 80%, 70%, ${al})`;
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }
      // pulsar wind particles (outflowing)
      for (let i = 0; i < 70; i++) {
        const u = ((tt / 40 + i * 0.043) * m) % 1;
        if (u < 0.05) continue;
        const a = i * 0.27 + tt / 300;
        const r = u * R * 12;
        const x = cx + Math.cos(a) * r;
        const y = cy + Math.sin(a) * r * 0.65;
        const al = (1 - u) * 0.7;
        ctx.fillStyle = `rgba(200,220,255,${al})`;
        const sz = 1 + (1 - u) * 1.5;
        ctx.fillRect(x, y, sz, sz);
      }
      // pulsar core (bright) + halo
      const halo = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 5);
      halo.addColorStop(0, "rgba(255,255,255,0.9)");
      halo.addColorStop(0.3, "rgba(180,220,255,0.5)");
      halo.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = halo;
      ctx.beginPath();
      ctx.arc(cx, cy, R * 5, 0, 6.283);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 6.283);
      ctx.fill();
      // pulsar beams (rotating)
      const beamA = (tt / 18) * m;
      for (const off of [0, Math.PI]) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(beamA + off);
        const bg = ctx.createLinearGradient(0, 0, R * 7, 0);
        bg.addColorStop(0, `rgba(220,240,255,${0.7 + 0.2 * Math.sin(tt / 5)})`);
        bg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = bg;
        ctx.beginPath();
        ctx.moveTo(0, -R * 0.15);
        ctx.lineTo(R * 7, -R * 0.04);
        ctx.lineTo(R * 7, R * 0.04);
        ctx.lineTo(0, R * 0.15);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
    };

    /* TDE — Tidal Disruption Event: star torn apart by SMBH with stream */
    const drawTDE = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.07;
      const m = st === "think" ? 1.5 : st === "speak" ? 1.2 : 1;
      // cyclical disruption every 7 seconds
      const cycle = (tt / 60) % 7;
      const phase = cycle / 7;
      // background glow
      const bg = ctx.createRadialGradient(cx, cy, R, cx, cy, R * 10);
      bg.addColorStop(0, "rgba(255,150,80,0.15)");
      bg.addColorStop(0.5, "rgba(255,80,40,0.08)");
      bg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);
      // black hole core
      ctx.fillStyle = "#000";
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.85, 0, 6.283);
      ctx.fill();
      // photon ring
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.95, 0, 6.283);
      ctx.strokeStyle = "rgba(255,200,120,0.8)";
      ctx.lineWidth = 2;
      ctx.shadowBlur = 12;
      ctx.shadowColor = "rgba(255,180,80,0.6)";
      ctx.stroke();
      ctx.shadowBlur = 0;
      // incoming star + tidal stretching
      const starAngle = phase * 6.283 + tt / 600 * m;
      const dist = R * (8 - phase * 6);
      const sx = cx + Math.cos(starAngle) * dist;
      const sy = cy + Math.sin(starAngle) * dist * 0.6;
      const stretchPhase = Math.max(0, phase - 0.3); // stretch starts when close
      const stretch = stretchPhase > 0 ? 1 + stretchPhase * 4 : 1;
      // stretched star (elongated ellipsoid)
      ctx.save();
      ctx.translate(sx, sy);
      ctx.rotate(starAngle + Math.PI / 2);
      const sg = ctx.createRadialGradient(0, 0, 0, 0, 0, R * 0.5 * stretch);
      sg.addColorStop(0, "rgba(255,240,200,0.95)");
      sg.addColorStop(0.5, "rgba(255,180,100,0.6)");
      sg.addColorStop(1, "rgba(255,120,40,0)");
      ctx.fillStyle = sg;
      ctx.beginPath();
      ctx.ellipse(0, 0, R * 0.5, R * 0.5 * stretch, 0, 0, 6.283);
      ctx.fill();
      ctx.restore();
      // debris stream from star → black hole
      ctx.beginPath();
      for (let s = 0; s <= 30; s++) {
        const u = s / 30;
        const ang = starAngle + Math.PI * 0.2 * u;
        const d = dist * (1 - u);
        const x = cx + Math.cos(ang) * d;
        const y = cy + Math.sin(ang) * d * 0.6;
        if (s === 0) ctx.moveTo(sx, sy); else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = `rgba(255,180,100,${0.5 + 0.3 * phase})`;
      ctx.lineWidth = 1.5;
      ctx.stroke();
      // debris particles along stream
      for (let i = 0; i < 40; i++) {
        const u = ((tt / 80 + i * 0.025) * m) % 1;
        const ang = starAngle + Math.PI * 0.2 * u;
        const d = dist * (1 - u);
        const x = cx + Math.cos(ang) * d;
        const y = cy + Math.sin(ang) * d * 0.6;
        const al = (1 - u) * 0.8;
        ctx.fillStyle = `rgba(255,200,120,${al})`;
        ctx.fillRect(x, y, 1.5, 1.5);
      }
      // accretion flare (when star close)
      if (phase > 0.4) {
        const flare = (phase - 0.4) / 0.6;
        const fg = ctx.createRadialGradient(cx, cy, R, cx, cy, R * 4);
        fg.addColorStop(0, `rgba(255,255,200,${flare * 0.6})`);
        fg.addColorStop(0.5, `rgba(255,180,80,${flare * 0.3})`);
        fg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = fg;
        ctx.beginPath();
        ctx.arc(cx, cy, R * 4, 0, 6.283);
        ctx.fill();
      }
    };

    /* GRB — Gamma-Ray Burst: jets from collapsing massive star + afterglow */
    const drawGRB = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const m = st === "think" ? 1.6 : st === "speak" ? 1.3 : 1;
      // cyclical burst every 5 seconds
      const cycle = (tt / 60) % 5;
      const phase = cycle / 5;
      const burst = phase < 0.15 ? (0.15 - phase) / 0.15 : 0;
      // central collapsing star (progenitor)
      const R = Math.min(W, H) * 0.05;
      const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * (2 + burst * 5));
      cg.addColorStop(0, `rgba(255,255,255,${0.9 + burst * 0.5})`);
      cg.addColorStop(0.3, `rgba(255,180,80,${0.5 + burst * 0.4})`);
      cg.addColorStop(0.7, "rgba(180,80,40,0.2)");
      cg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.arc(cx, cy, R * (2 + burst * 5), 0, 6.283);
      ctx.fill();
      // collapsar core
      ctx.fillStyle = burst > 0.5 ? "#000" : "#402010";
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.6, 0, 6.283);
      ctx.fill();
      // relativistic jets (perpendicular — bi-polar)
      const jetAngle = Math.PI / 2 + Math.sin(tt / 600) * 0.1;
      for (const dir of [-1, 1]) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(jetAngle);
        const jetLen = Math.min(W, H) * (0.45 + burst * 0.3);
        // jet core (gamma ray)
        const jg = ctx.createLinearGradient(0, 0, 0, dir * jetLen);
        jg.addColorStop(0, `rgba(255,255,255,${0.9 + burst * 0.5})`);
        jg.addColorStop(0.3, `rgba(180,220,255,${0.6 + burst * 0.3})`);
        jg.addColorStop(0.6, "rgba(120,180,255,0.3)");
        jg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = jg;
        ctx.beginPath();
        ctx.moveTo(-R * 0.25, 0);
        ctx.lineTo(R * 0.25, 0);
        ctx.lineTo(R * 0.08, dir * jetLen);
        ctx.lineTo(-R * 0.08, dir * jetLen);
        ctx.closePath();
        ctx.fill();
        // jet cocoon (afterglow)
        ctx.beginPath();
        ctx.moveTo(-R * 0.5, 0);
        ctx.lineTo(R * 0.5, 0);
        ctx.lineTo(R * 0.18, dir * jetLen * 0.9);
        ctx.lineTo(-R * 0.18, dir * jetLen * 0.9);
        ctx.closePath();
        ctx.fillStyle = `rgba(255,140,80,${0.2 + 0.2 * (1 - phase)})`;
        ctx.fill();
        ctx.restore();
      }
      // shocked particles along jets
      for (let i = 0; i < 80; i++) {
        const u = ((tt / 30 + i * 0.034) * m) % 1;
        if (u < 0.05) continue;
        const sideSign = i % 2 === 0 ? 1 : -1;
        const along = u * Math.min(W, H) * 0.45;
        const perp = Math.sin(u * 8 + i) * R * (0.3 + u * 0.7);
        const x = cx + Math.cos(jetAngle) * sideSign * along + Math.cos(jetAngle + Math.PI / 2) * perp;
        const y = cy + Math.sin(jetAngle) * sideSign * along + Math.sin(jetAngle + Math.PI / 2) * perp;
        const al = (1 - u) * 0.7;
        const hue = u < 0.3 ? 60 : u < 0.6 ? 200 : 280;
        ctx.fillStyle = `hsla(${hue}, 90%, 75%, ${al})`;
        ctx.fillRect(x, y, 1.5, 1.5);
      }
      // bright flash at burst peak
      if (burst > 0.3) {
        ctx.fillStyle = `rgba(255,255,255,${burst * 0.4})`;
        ctx.fillRect(0, 0, W, H);
      }
    };

    /* MAGNETOSPHERE — planet with dipole magnetic field + aurora + solar wind */
    const drawMagnetosphere = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.12;
      const m = st === "think" ? 1.6 : st === "speak" ? 1.3 : 1;
      const tilt = -0.4;
      // magnetopause (bow shock + tail)
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(tilt);
      // bow shock arc (sun-facing side)
      ctx.beginPath();
      ctx.arc(-R * 0.3, 0, R * 2.2, -Math.PI / 2.2, Math.PI / 2.2);
      ctx.strokeStyle = `rgba(120,180,255,${0.3 + 0.1 * Math.sin(tt / 30)})`;
      ctx.lineWidth = 2;
      ctx.shadowBlur = 8;
      ctx.shadowColor = "rgba(120,180,255,0.5)";
      ctx.stroke();
      ctx.shadowBlur = 0;
      // magnetotail (extending right)
      ctx.beginPath();
      ctx.moveTo(R * 1.5, -R * 1.5);
      ctx.quadraticCurveTo(R * 6, -R * 0.5, R * 8, -R * 0.3);
      ctx.lineTo(R * 8, R * 0.3);
      ctx.quadraticCurveTo(R * 6, R * 0.5, R * 1.5, R * 1.5);
      ctx.closePath();
      ctx.fillStyle = `rgba(100,140,220,${0.08 + 0.04 * Math.sin(tt / 50)})`;
      ctx.fill();
      ctx.restore();
      // solar wind particles (incoming from left)
      for (let i = 0; i < 40; i++) {
        const u = ((tt / 40 + i * 0.05) * m) % 1;
        if (u > 0.5) continue; // only show on left side
        const y = ((i * 23.7) % H);
        const x = u * cx * 1.8;
        const deflection = Math.sin(u * Math.PI) * (y > H / 2 ? 8 : -8);
        ctx.fillStyle = `rgba(255,220,150,${0.5 * (1 - u * 2)})`;
        ctx.fillRect(x, y + deflection, 1.2, 1.2);
      }
      // field lines (dipole — closed loops on sun side, open on tail)
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(tilt);
      for (let k = 1; k <= 4; k++) {
        const fr = R * (1.3 + k * 0.4);
        // sun-side closed loop
        ctx.beginPath();
        ctx.ellipse(-R * 0.3, 0, fr, fr * 1.4, 0, Math.PI * 0.55, Math.PI * 1.45);
        ctx.strokeStyle = `rgba(180,200,255,${0.3 - k * 0.05})`;
        ctx.lineWidth = 1;
        ctx.stroke();
        // tail-side open field line
        ctx.beginPath();
        ctx.moveTo(R * 0.5, -fr * 0.7);
        ctx.quadraticCurveTo(R * 4, -fr * 0.4, R * 7, -fr * 0.2);
        ctx.strokeStyle = `rgba(180,200,255,${0.25 - k * 0.04})`;
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(R * 0.5, fr * 0.7);
        ctx.quadraticCurveTo(R * 4, fr * 0.4, R * 7, fr * 0.2);
        ctx.stroke();
      }
      ctx.restore();
      // aurora at poles
      for (const pole of [-1, 1]) {
        const ax = cx + Math.sin(tilt) * R * 0.6 * pole;
        const ay = cy + Math.cos(tilt) * R * 0.6 * pole;
        const ag = ctx.createRadialGradient(ax, ay, 0, ax, ay, R * 0.6);
        ag.addColorStop(0, `rgba(120,255,180,${0.5 + 0.3 * Math.sin(tt / 8 + pole)})`);
        ag.addColorStop(0.5, "rgba(120,200,255,0.2)");
        ag.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = ag;
        ctx.beginPath();
        ctx.arc(ax, ay, R * 0.6, 0, 6.283);
        ctx.fill();
      }
      // planet body
      const pg = ctx.createRadialGradient(cx - R * 0.4, cy - R * 0.4, 0, cx, cy, R);
      pg.addColorStop(0, "#9fe3e0");
      pg.addColorStop(0.4, "#3d9aa0");
      pg.addColorStop(1, "#123c46");
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 6.283);
      ctx.fill();
      // terminator shadow
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 6.283);
      ctx.clip();
      const tg = ctx.createLinearGradient(cx - R, 0, cx + R, 0);
      tg.addColorStop(0, "rgba(0,0,0,0)");
      tg.addColorStop(0.5, "rgba(0,0,0,0)");
      tg.addColorStop(1, "rgba(0,0,0,0.5)");
      ctx.fillStyle = tg;
      ctx.fillRect(cx - R, cy - R, R * 2, R * 2);
      ctx.restore();
    };

    /* HOT JUPITER — gas giant with banded atmosphere + glowing hot side */
    const drawHotJupiter = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.22;
      const m = st === "think" ? 1.4 : st === "speak" ? 1.2 : 1;
      // corona glow (hot atmosphere evaporating)
      const cg = ctx.createRadialGradient(cx, cy, R, cx, cy, R * 1.8);
      cg.addColorStop(0, "rgba(255,140,80,0.25)");
      cg.addColorStop(0.5, "rgba(255,80,40,0.1)");
      cg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = cg;
      ctx.fillRect(0, 0, W, H);
      // planet body with hot-side / cold-side gradient
      const pg = ctx.createRadialGradient(cx - R * 0.5, cy - R * 0.3, 0, cx, cy, R * 1.2);
      pg.addColorStop(0, "#ffe0a0");
      pg.addColorStop(0.3, "#ffa050");
      pg.addColorStop(0.6, "#c44020");
      pg.addColorStop(1, "#2a0a08");
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 6.283);
      ctx.fill();
      // banded atmosphere (clipped to disk)
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 6.283);
      ctx.clip();
      const bands = 9;
      for (let b = 0; b < bands; b++) {
        const y = cy - R + (b + 0.5) * (R * 2 / bands) + Math.sin(tt / 80 + b * 2) * 3 * m;
        const hue = 20 + (b % 3) * 8;
        const sat = 80 + (b % 2) * 10;
        const light = 35 + (b % 4) * 8;
        ctx.fillStyle = `hsla(${hue}, ${sat}%, ${light}%, ${0.5 + 0.15 * Math.sin(tt / 60 + b)})`;
        ctx.fillRect(cx - R, y - R * 0.06, R * 2, R * 0.12);
      }
      // great red spot analog (storm)
      const stormX = cx + Math.cos(tt / 200 * m) * R * 0.3;
      const stormY = cy + R * 0.15;
      const sg = ctx.createRadialGradient(stormX, stormY, 0, stormX, stormY, R * 0.18);
      sg.addColorStop(0, "rgba(180,40,20,0.8)");
      sg.addColorStop(0.6, "rgba(120,30,15,0.4)");
      sg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = sg;
      ctx.beginPath();
      ctx.ellipse(stormX, stormY, R * 0.18, R * 0.1, 0, 0, 6.283);
      ctx.fill();
      ctx.restore();
      // limb darkening
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 6.283);
      ctx.clip();
      const lg = ctx.createRadialGradient(cx, cy, R * 0.7, cx, cy, R);
      lg.addColorStop(0, "rgba(0,0,0,0)");
      lg.addColorStop(1, "rgba(0,0,0,0.4)");
      ctx.fillStyle = lg;
      ctx.fillRect(cx - R, cy - R, R * 2, R * 2);
      ctx.restore();
      // trailing evaporating gas (from hot side)
      for (let i = 0; i < 30; i++) {
        const u = ((tt / 60 + i * 0.033) * m) % 1;
        if (u < 0.1) continue;
        const a = (i * 0.41) % (Math.PI / 1.5) - Math.PI / 3;
        const r = R * (1 + u * 4);
        const x = cx + R * 0.6 + Math.cos(a) * r * 0.3 + u * R * 3;
        const y = cy + Math.sin(a) * r * 0.4;
        const al = (1 - u) * 0.5;
        ctx.fillStyle = `rgba(255,180,100,${al})`;
        ctx.fillRect(x, y, 1.5, 1.5);
      }
    };

    /* BROWN DWARF — small failed star with banded clouds + faint glow */
    const drawBrownDwarf = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.16;
      const m = st === "think" ? 1.4 : 1;
      // faint corona
      const cg = ctx.createRadialGradient(cx, cy, R, cx, cy, R * 2.2);
      cg.addColorStop(0, "rgba(180,100,50,0.2)");
      cg.addColorStop(0.5, "rgba(120,60,30,0.08)");
      cg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = cg;
      ctx.fillRect(0, 0, W, H);
      // body — reddish-brown
      const pg = ctx.createRadialGradient(cx - R * 0.3, cy - R * 0.3, 0, cx, cy, R);
      pg.addColorStop(0, "#c08060");
      pg.addColorStop(0.4, "#804020");
      pg.addColorStop(0.8, "#3a1808");
      pg.addColorStop(1, "#1a0804");
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 6.283);
      ctx.fill();
      // banded turbulent clouds
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 6.283);
      ctx.clip();
      for (let b = 0; b < 11; b++) {
        const y = cy - R + (b + 0.5) * (R * 2 / 11) + Math.sin(tt / 90 + b * 1.5) * 4 * m;
        const hue = 15 + (b % 4) * 5;
        const light = 20 + (b % 5) * 6;
        ctx.fillStyle = `hsla(${hue}, 60%, ${light}%, ${0.45 + 0.15 * Math.sin(tt / 50 + b)})`;
        ctx.fillRect(cx - R, y - R * 0.055, R * 2, R * 0.11);
      }
      // cloud swirls (turbulent eddies)
      for (let i = 0; i < 6; i++) {
        const a = i * 1.05 + tt / 200 * m;
        const sx = cx + Math.cos(a) * R * 0.5;
        const sy = cy + Math.sin(a) * R * 0.4;
        const sg = ctx.createRadialGradient(sx, sy, 0, sx, sy, R * 0.15);
        sg.addColorStop(0, "rgba(220,160,100,0.3)");
        sg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = sg;
        ctx.beginPath();
        ctx.arc(sx, sy, R * 0.15, 0, 6.283);
        ctx.fill();
      }
      ctx.restore();
      // limb darkening
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 6.283);
      ctx.clip();
      const lg = ctx.createRadialGradient(cx, cy, R * 0.6, cx, cy, R);
      lg.addColorStop(0, "rgba(0,0,0,0)");
      lg.addColorStop(1, "rgba(0,0,0,0.55)");
      ctx.fillStyle = lg;
      ctx.fillRect(cx - R, cy - R, R * 2, R * 2);
      ctx.restore();
      // faint methane-band glow (faint cool glow)
      const fg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.1);
      fg.addColorStop(0, "rgba(0,0,0,0)");
      fg.addColorStop(0.95, "rgba(180,100,50,0)");
      fg.addColorStop(1, "rgba(255,150,80,0.15)");
      ctx.fillStyle = fg;
      ctx.beginPath();
      ctx.arc(cx, cy, R * 1.1, 0, 6.283);
      ctx.fill();
    };

    /* PROTO-PLANETARY DISK — young star with dust rings + forming planets */
    const drawProtoplanetary = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.08;
      const m = st === "think" ? 1.5 : st === "speak" ? 1.2 : 1;
      const tilt = 0.38;
      // outer dust glow
      const bg = ctx.createRadialGradient(cx, cy, R, cx, cy, R * 10);
      bg.addColorStop(0, "rgba(255,180,100,0.15)");
      bg.addColorStop(0.5, "rgba(180,120,60,0.06)");
      bg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);
      // dust disk — many faint rings
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(tilt);
      for (let k = 0; k < 50; k++) {
        const rr = R * (1.5 + k * 0.12);
        const ry = rr * 0.18;
        const al = Math.max(0, 0.18 * (1 - k / 50));
        const hue = 30 + k * 1.5;
        ctx.beginPath();
        ctx.ellipse(0, 0, rr, ry, 0, 0, 6.283);
        ctx.strokeStyle = `hsla(${hue}, 70%, ${40 + k * 0.5}%, ${al})`;
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }
      // gap in disk (where planet is forming)
      const gapR = R * 4.2;
      ctx.beginPath();
      ctx.ellipse(0, 0, gapR, gapR * 0.18, 0, 0, 6.283);
      ctx.strokeStyle = "rgba(0,0,0,0.4)";
      ctx.lineWidth = 8;
      ctx.stroke();
      ctx.restore();
      // forming planet (bright dot in the gap)
      const planetA = (tt / 200) * m;
      const px = cx + Math.cos(planetA) * gapR * Math.cos(tilt) - gapR * 0.18 * Math.sin(planetA) * Math.sin(tilt);
      const py = cy + Math.cos(planetA) * gapR * Math.sin(tilt) + gapR * 0.18 * Math.sin(planetA) * Math.cos(tilt);
      const pglow = ctx.createRadialGradient(px, py, 0, px, py, 12);
      pglow.addColorStop(0, "rgba(255,240,200,0.9)");
      pglow.addColorStop(0.5, "rgba(255,180,100,0.4)");
      pglow.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = pglow;
      ctx.beginPath();
      ctx.arc(px, py, 12, 0, 6.283);
      ctx.fill();
      ctx.fillStyle = "#ffe0a0";
      ctx.beginPath();
      ctx.arc(px, py, 4, 0, 6.283);
      ctx.fill();
      // central protostar
      const starPulse = 1 + 0.05 * Math.sin(tt / 5);
      const sg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 3 * starPulse);
      sg.addColorStop(0, "rgba(255,240,200,0.9)");
      sg.addColorStop(0.3, "rgba(255,180,80,0.5)");
      sg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = sg;
      ctx.beginPath();
      ctx.arc(cx, cy, R * 3 * starPulse, 0, 6.283);
      ctx.fill();
      ctx.fillStyle = "#fff5d0";
      ctx.beginPath();
      ctx.arc(cx, cy, R * starPulse, 0, 6.283);
      ctx.fill();
      // dust particles swirling
      for (let i = 0; i < 60; i++) {
        const u = (i % 12) / 12;
        const a = i * 0.37 + tt / 150 * m * (1.5 - u);
        const rr = R * (2 + u * 5);
        const x = cx + Math.cos(a) * rr * Math.cos(tilt) - rr * 0.18 * Math.sin(a) * Math.sin(tilt);
        const y = cy + Math.cos(a) * rr * Math.sin(tilt) + rr * 0.18 * Math.sin(a) * Math.cos(tilt);
        const al = 0.3 + 0.3 * Math.sin(tt / 20 + i);
        ctx.fillStyle = `rgba(255,200,120,${al})`;
        ctx.fillRect(x, y, 1.2, 1.2);
      }
    };

    /* HYPERGIANT — extremely massive star with violent surface + strong wind */
    const drawHypergiant = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.22;
      const m = st === "think" ? 1.6 : st === "speak" ? 1.3 : 1;
      // huge corona
      const cg = ctx.createRadialGradient(cx, cy, R, cx, cy, R * 3.5);
      cg.addColorStop(0, "rgba(255,200,100,0.3)");
      cg.addColorStop(0.3, "rgba(255,120,40,0.15)");
      cg.addColorStop(0.7, "rgba(200,60,20,0.06)");
      cg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = cg;
      ctx.fillRect(0, 0, W, H);
      // stellar wind particles (outflowing in all directions)
      for (let i = 0; i < 80; i++) {
        const u = ((tt / 50 + i * 0.038) * m) % 1;
        if (u < 0.08) continue;
        const a = i * 0.27 + tt / 800;
        const r = R * (1 + u * 2.5);
        const x = cx + Math.cos(a) * r;
        const y = cy + Math.sin(a) * r;
        const al = (1 - u) * 0.6;
        const hue = u < 0.3 ? 30 : u < 0.6 ? 15 : 0;
        ctx.fillStyle = `hsla(${hue}, 90%, 65%, ${al})`;
        ctx.fillRect(x, y, 1.5 + (1 - u), 1.5 + (1 - u));
      }
      // star body — yellow hypergiant
      const pulse = 1 + 0.04 * Math.sin(tt / 4);
      const sg = ctx.createRadialGradient(cx - R * 0.3, cy - R * 0.3, 0, cx, cy, R * pulse);
      sg.addColorStop(0, "#fffce0");
      sg.addColorStop(0.3, "#ffe070");
      sg.addColorStop(0.6, "#ffa030");
      sg.addColorStop(0.85, "#e04010");
      sg.addColorStop(1, "#5a1004");
      ctx.fillStyle = sg;
      ctx.beginPath();
      ctx.arc(cx, cy, R * pulse, 0, 6.283);
      ctx.fill();
      // violent surface granulation (large convection cells)
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R * pulse, 0, 6.283);
      ctx.clip();
      for (let i = 0; i < 25; i++) {
        const a = i * 0.51 + tt / 150 * m;
        const rr = R * (0.2 + (i % 5) * 0.16);
        const gx = cx + Math.cos(a) * rr;
        const gy = cy + Math.sin(a) * rr;
        const gr = 15 + (i % 4) * 8;
        const gg = ctx.createRadialGradient(gx, gy, 0, gx, gy, gr);
        const cellHue = i % 3 === 0 ? 25 : i % 3 === 1 ? 10 : 35;
        gg.addColorStop(0, `hsla(${cellHue}, 90%, 60%, 0.5)`);
        gg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = gg;
        ctx.beginPath();
        ctx.arc(gx, gy, gr, 0, 6.283);
        ctx.fill();
      }
      ctx.restore();
      // limb darkening
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R * pulse, 0, 6.283);
      ctx.clip();
      const lg = ctx.createRadialGradient(cx, cy, R * 0.6, cx, cy, R * pulse);
      lg.addColorStop(0, "rgba(0,0,0,0)");
      lg.addColorStop(1, "rgba(60,10,0,0.5)");
      ctx.fillStyle = lg;
      ctx.fillRect(cx - R, cy - R, R * 2, R * 2);
      ctx.restore();
      // occasional mass ejection plumes
      for (let i = 0; i < 4; i++) {
        const a = i * (Math.PI / 2) + tt / 300 * m;
        const phase = (tt / 100 + i * 1.5) % 4;
        if (phase > 2) continue;
        const plumeR = R * (1 + phase * 0.4);
        const px = cx + Math.cos(a) * plumeR;
        const py = cy + Math.sin(a) * plumeR;
        const pg = ctx.createRadialGradient(px, py, 0, px, py, R * 0.3);
        pg.addColorStop(0, `rgba(255,200,80,${0.5 * (1 - phase / 2)})`);
        pg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = pg;
        ctx.beginPath();
        ctx.arc(px, py, R * 0.3, 0, 6.283);
        ctx.fill();
      }
    };

    /* WOLF-RAYET — hot luminous star with strong stellar wind + nebular shell */
    const drawWolfRayet = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.1;
      const m = st === "think" ? 1.5 : 1;
      // outer nebular shell (ejected wind)
      const ng = ctx.createRadialGradient(cx, cy, R * 2, cx, cy, R * 12);
      ng.addColorStop(0, "rgba(100,180,255,0.2)");
      ng.addColorStop(0.4, "rgba(80,140,220,0.12)");
      ng.addColorStop(0.7, "rgba(60,100,180,0.05)");
      ng.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = ng;
      ctx.fillRect(0, 0, W, H);
      // shell filaments (expanding bubble structure)
      for (let i = 0; i < 12; i++) {
        const a0 = i * 0.524 + tt / 500 * m;
        ctx.beginPath();
        for (let s = 0; s <= 20; s++) {
          const u = s / 20;
          const r = R * (2 + u * 7);
          const wobble = Math.sin(u * 4 + tt / 40 + i) * 0.25;
          const a = a0 + wobble;
          const x = cx + Math.cos(a) * r;
          const y = cy + Math.sin(a) * r * 0.85;
          if (s === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.strokeStyle = `rgba(150,200,255,${0.12 + 0.06 * Math.sin(tt / 30 + i)})`;
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
      // strong stellar wind (radial outflow)
      for (let i = 0; i < 100; i++) {
        const u = ((tt / 35 + i * 0.027) * m) % 1;
        if (u < 0.05) continue;
        const a = i * 0.189 + tt / 900;
        const r = u * R * 9;
        const x = cx + Math.cos(a) * r;
        const y = cy + Math.sin(a) * r * 0.85;
        const al = (1 - u) * 0.6;
        const hue = u < 0.3 ? 200 : u < 0.6 ? 220 : 250;
        ctx.fillStyle = `hsla(${hue}, 80%, 70%, ${al})`;
        const sz = 1 + (1 - u) * 1.2;
        ctx.fillRect(x, y, sz, sz);
      }
      // hot blue star core
      const pulse = 1 + 0.06 * Math.sin(tt / 3);
      const sg = ctx.createRadialGradient(cx - R * 0.2, cy - R * 0.2, 0, cx, cy, R * pulse * 2);
      sg.addColorStop(0, "#ffffff");
      sg.addColorStop(0.3, "#cfe4ff");
      sg.addColorStop(0.6, "#6090e0");
      sg.addColorStop(0.85, "#2040a0");
      sg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = sg;
      ctx.beginPath();
      ctx.arc(cx, cy, R * pulse * 2, 0, 6.283);
      ctx.fill();
      ctx.fillStyle = "#e8f0ff";
      ctx.beginPath();
      ctx.arc(cx, cy, R * pulse, 0, 6.283);
      ctx.fill();
      // emission lines (bright spikes — characteristic WR spectrum)
      ctx.strokeStyle = `rgba(180,220,255,${0.5 + 0.3 * Math.sin(tt / 6)})`;
      ctx.lineWidth = 1;
      const spike = R * (4 + (st === "speak" ? 2 * Math.sin(tt / 5) : 0));
      ctx.beginPath();
      ctx.moveTo(cx - spike, cy); ctx.lineTo(cx + spike, cy);
      ctx.moveTo(cx, cy - spike); ctx.lineTo(cx, cy + spike);
      ctx.moveTo(cx - spike * 0.7, cy - spike * 0.7);
      ctx.lineTo(cx + spike * 0.7, cy + spike * 0.7);
      ctx.moveTo(cx - spike * 0.7, cy + spike * 0.7);
      ctx.lineTo(cx + spike * 0.7, cy - spike * 0.7);
      ctx.stroke();
    };

    /* RING NEBULA — planetary nebula with expanding ring + central white dwarf */
    const drawRingNebula = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.16;
      const m = st === "think" ? 1.3 : 1;
      const pulse = st === "listen" ? 1 + 0.03 * Math.sin(tt / 6) : 1;
      // outer glow halo
      const hg = ctx.createRadialGradient(cx, cy, R * 0.5, cx, cy, R * 2.5);
      hg.addColorStop(0, "rgba(100,200,180,0.15)");
      hg.addColorStop(0.5, "rgba(80,120,220,0.08)");
      hg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = hg;
      ctx.fillRect(0, 0, W, H);
      // main ring (torus cross-section — 3 layered ellipses)
      for (let layer = 0; layer < 3; layer++) {
        const rr = R * (0.85 + layer * 0.15) * pulse;
        const ry = rr * 0.7;
        const hue = layer === 0 ? 170 : layer === 1 ? 220 : 280;
        const al = (0.5 - layer * 0.12) * (st === "speak" ? 0.8 + 0.2 * Math.sin(tt / 5) : 1);
        ctx.beginPath();
        ctx.ellipse(cx, cy, rr, ry, 0, 0, 6.283);
        ctx.strokeStyle = `hsla(${hue}, 80%, 60%, ${al})`;
        ctx.lineWidth = 8 + layer * 4;
        ctx.shadowBlur = 20;
        ctx.shadowColor = `hsla(${hue}, 80%, 50%, 0.4)`;
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
      // ring filaments (radial striations)
      for (let i = 0; i < 30; i++) {
        const a = i * 0.21 + tt / 500 * m;
        const r1 = R * 0.75 * pulse;
        const r2 = R * 1.15 * pulse;
        const ry1 = r1 * 0.7, ry2 = r2 * 0.7;
        const x1 = cx + Math.cos(a) * r1, y1 = cy + Math.sin(a) * ry1;
        const x2 = cx + Math.cos(a) * r2, y2 = cy + Math.sin(a) * ry2;
        const al = 0.2 + 0.2 * Math.sin(tt / 30 + i);
        ctx.strokeStyle = `rgba(180,220,255,${al})`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x1, y1); ctx.lineTo(x2, y2);
        ctx.stroke();
      }
      // central white dwarf (hot remnant)
      const dwPulse = 1 + 0.04 * Math.sin(tt / 4);
      const dg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 0.2 * dwPulse);
      dg.addColorStop(0, "#ffffff");
      dg.addColorStop(0.5, "#cfe4ff");
      dg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = dg;
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.2 * dwPulse, 0, 6.283);
      ctx.fill();
    };

    /* CRAB NEBULA — supernova remnant with tangled filaments + pulsar */
    const drawCrabNebula = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.22;
      const m = st === "think" ? 1.4 : 1;
      const boost = st === "listen" ? 1.2 : 1;
      // diffuse glow
      const bg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.5);
      bg.addColorStop(0, `rgba(255,120,60,${0.2 * boost})`);
      bg.addColorStop(0.4, `rgba(180,80,40,${0.12 * boost})`);
      bg.addColorStop(0.7, `rgba(100,60,180,${0.08 * boost})`);
      bg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);
      // tangled filaments (random-walk webs)
      for (let i = 0; i < 8; i++) {
        ctx.beginPath();
        let fx = cx + (Math.sin(tt / 200 + i * 1.3) * R * 0.3);
        let fy = cy + (Math.cos(tt / 180 + i * 1.1) * R * 0.2);
        ctx.moveTo(fx, fy);
        for (let s = 0; s < 25; s++) {
          const a = s * 0.41 + i * 0.8 + tt / 300 * m;
          const r = R * (0.3 + (s % 5) * 0.15);
          fx += Math.cos(a) * 8;
          fy += Math.sin(a) * 6;
          ctx.lineTo(fx, fy);
        }
        const hue = i % 3 === 0 ? 20 : i % 3 === 1 ? 200 : 280;
        const al = (0.3 + 0.15 * Math.sin(tt / 25 + i)) * boost;
        ctx.strokeStyle = `hsla(${hue}, 85%, 60%, ${al})`;
        ctx.lineWidth = 1.5;
        ctx.shadowBlur = 6;
        ctx.shadowColor = `hsla(${hue}, 80%, 50%, 0.3)`;
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
      // scattered glowing knots
      for (let i = 0; i < 50; i++) {
        const a = i * 0.37 + tt / 400 * m;
        const r = R * (0.2 + ((i * 0.137) % 0.9));
        const x = cx + Math.cos(a) * r;
        const y = cy + Math.sin(a) * r * 0.7;
        const al = 0.3 + 0.4 * Math.sin(tt / 20 + i);
        const hue = i % 4 === 0 ? 30 : i % 4 === 1 ? 15 : i % 4 === 2 ? 220 : 280;
        ctx.fillStyle = `hsla(${hue}, 90%, 65%, ${al * boost})`;
        const sz = 1.5 + (i % 3) * 0.5;
        ctx.fillRect(x, y, sz, sz);
      }
      // central pulsar (neutron star remnant)
      const pPulse = 1 + 0.06 * Math.sin(tt / 3);
      const pg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 0.08 * pPulse * 3);
      pg.addColorStop(0, "#ffffff");
      pg.addColorStop(0.5, "rgba(200,230,255,0.4)");
      pg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.08 * pPulse * 3, 0, 6.283);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.04 * pPulse, 0, 6.283);
      ctx.fill();
    };

    /* SOLAR OUTER — outer solar system: Jupiter, Saturn, Uranus, Neptune on wide orbits */
    const drawSolarOuter = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R0 = Math.min(W, H) * 0.42;
      const m = st === "think" ? 4 : st === "listen" ? 2 : 1;
      // sun (small, center)
      const sunR = Math.min(W, H) * 0.04;
      const sg = ctx.createRadialGradient(cx, cy, 0, cx, cy, sunR * 2.5);
      sg.addColorStop(0, "#fff8e0");
      sg.addColorStop(0.4, "#ffd76a");
      sg.addColorStop(1, "rgba(255,150,40,0)");
      ctx.fillStyle = sg;
      ctx.beginPath();
      ctx.arc(cx, cy, sunR * 2.5, 0, 6.283);
      ctx.fill();
      ctx.fillStyle = "#fff8e0";
      ctx.beginPath();
      ctx.arc(cx, cy, sunR, 0, 6.283);
      ctx.fill();
      // outer planets
      const planets = [
        { name: "J", color: "#d8a56c", f: 0.30, s: 0.084, sz: 5.5 },
        { name: "S", color: "#e3cf9e", f: 0.45, s: 0.034, sz: 5.0 },
        { name: "U", color: "#9fe3e0", f: 0.65, s: 0.012, sz: 3.5 },
        { name: "N", color: "#6f8cff", f: 0.85, s: 0.006, sz: 3.5 },
      ];
      for (const p of planets) {
        const rr = R0 * p.f;
        // orbit
        ctx.beginPath();
        ctx.ellipse(cx, cy, rr, rr * 0.35, 0, 0, 6.283);
        ctx.strokeStyle = "rgba(160,190,230,0.12)";
        ctx.lineWidth = 1;
        ctx.stroke();
        // planet
        const a = (tt / 400) * p.s * m + p.f * 20;
        const x = cx + Math.cos(a) * rr;
        const y = cy + Math.sin(a) * rr * 0.35;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(x, y, p.sz, 0, 6.283);
        ctx.fill();
        // Saturn ring
        if (p.name === "S") {
          ctx.beginPath();
          ctx.ellipse(x, y, p.sz * 2.2, p.sz * 0.7, -0.4, 0, 6.283);
          ctx.strokeStyle = "rgba(230,210,160,0.6)";
          ctx.lineWidth = 1.2;
          ctx.stroke();
        }
        if (p.name === "U") {
          ctx.beginPath();
          ctx.ellipse(x, y, p.sz * 2, p.sz * 0.5, 1.2, 0, 6.283);
          ctx.strokeStyle = "rgba(160,230,235,0.5)";
          ctx.lineWidth = 1;
          ctx.stroke();
        }
        // Jupiter moons
        if (p.name === "J") {
          for (let mn = 0; mn < 3; mn++) {
            const ma = a * 4 + mn * 2.1;
            const mr = p.sz + 3 + mn * 2;
            const mx = x + Math.cos(ma) * mr;
            const my = y + Math.sin(ma) * mr * 0.5;
            ctx.fillStyle = "rgba(200,200,200,0.5)";
            ctx.fillRect(mx, my, 1, 1);
          }
        }
      }
    };

    /* HELIX NEBULA — eye-shaped planetary nebula with radial spokes */
    const drawHelix = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.18;
      const m = st === "think" ? 1.3 : 1;
      const boost = st === "listen" ? 1.2 : 1;
      // outer halo
      const hg = ctx.createRadialGradient(cx, cy, R * 0.3, cx, cy, R * 2);
      hg.addColorStop(0, `rgba(100,200,255,${0.2 * boost})`);
      hg.addColorStop(0.5, `rgba(180,100,200,${0.1 * boost})`);
      hg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = hg;
      ctx.fillRect(0, 0, W, H);
      // eye-shaped outer ring (flattened ellipse)
      for (let layer = 0; layer < 4; layer++) {
        const rr = R * (0.7 + layer * 0.15);
        const ry = rr * 0.55;
        const hue = layer === 0 ? 190 : layer === 1 ? 220 : layer === 2 ? 280 : 320;
        const al = (0.4 - layer * 0.08) * boost;
        ctx.beginPath();
        ctx.ellipse(cx, cy, rr, ry, 0, 0, 6.283);
        ctx.strokeStyle = `hsla(${hue}, 75%, 55%, ${al})`;
        ctx.lineWidth = 6 + layer * 3;
        ctx.shadowBlur = 15;
        ctx.shadowColor = `hsla(${hue}, 70%, 50%, 0.3)`;
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
      // radial spokes (characteristic helix structure)
      for (let i = 0; i < 24; i++) {
        const a = i * 0.262 + tt / 400 * m;
        const r1 = R * 0.3;
        const r2 = R * 1.0;
        const ry1 = r1 * 0.55, ry2 = r2 * 0.55;
        const x1 = cx + Math.cos(a) * r1, y1 = cy + Math.sin(a) * ry1;
        const x2 = cx + Math.cos(a) * r2, y2 = cy + Math.sin(a) * ry2;
        const al = (0.2 + 0.15 * Math.sin(tt / 25 + i)) * boost;
        ctx.strokeStyle = `rgba(150,200,255,${al})`;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(x1, y1); ctx.lineTo(x2, y2);
        ctx.stroke();
      }
      // central white dwarf
      const dwP = 1 + 0.05 * Math.sin(tt / 4);
      const dg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 0.15 * dwP);
      dg.addColorStop(0, "#ffffff");
      dg.addColorStop(0.5, "rgba(200,230,255,0.5)");
      dg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = dg;
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.15 * dwP, 0, 6.283);
      ctx.fill();
    };

    /* ORION NEBULA — star-forming region with bright Trapezium cluster */
    const drawOrion = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.2;
      const m = st === "think" ? 1.4 : 1;
      const boost = st === "listen" ? 1.2 : 1;
      // greenish diffuse glow (characteristic Orion color)
      const bg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.5);
      bg.addColorStop(0, `rgba(100,200,120,${0.25 * boost})`);
      bg.addColorStop(0.3, `rgba(80,160,200,${0.15 * boost})`);
      bg.addColorStop(0.6, `rgba(180,80,140,${0.1 * boost})`);
      bg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);
      // dust clouds (irregular blobs)
      const clouds = [
        { x: 0.35, y: 0.4, r: 0.35, col: "80,180,100", op: 0.3 },
        { x: 0.6, y: 0.5, r: 0.4, col: "100,140,200", op: 0.25 },
        { x: 0.5, y: 0.3, r: 0.3, col: "200,100,140", op: 0.2 },
        { x: 0.45, y: 0.6, r: 0.25, col: "150,200,80", op: 0.22 },
      ];
      for (const c of clouds) {
        const x = c.x * W + Math.sin(tt / 300 + c.x * 7) * W * 0.01;
        const y = c.y * H + Math.cos(tt / 280 + c.y * 5) * H * 0.01;
        const r = c.r * R;
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, `rgba(${c.col},${c.op * boost})`);
        g.addColorStop(0.5, `rgba(${c.col},${c.op * 0.3 * boost})`);
        g.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);
      }
      // Trapezium cluster (4 bright young stars)
      const trap = [
        { x: -0.03, y: -0.02, s: 3 },
        { x: 0.02, y: -0.03, s: 2.5 },
        { x: 0.01, y: 0.03, s: 2 },
        { x: -0.02, y: 0.02, s: 1.8 },
      ];
      for (const t of trap) {
        const x = cx + t.x * R * 5;
        const y = cy + t.y * R * 5;
        const pulse = 1 + 0.15 * Math.sin(tt / 8 + t.x * 10);
        const g = ctx.createRadialGradient(x, y, 0, x, y, t.s * 4 * pulse);
        g.addColorStop(0, `rgba(255,255,240,${0.9 * boost})`);
        g.addColorStop(0.3, `rgba(200,230,255,${0.4 * boost})`);
        g.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, y, t.s * 4 * pulse, 0, 6.283);
        ctx.fill();
        ctx.fillStyle = "#fffce0";
        ctx.beginPath();
        ctx.arc(x, y, t.s * pulse, 0, 6.283);
        ctx.fill();
      }
      // scattered newborn stars
      for (let i = 0; i < 40; i++) {
        const a = i * 0.31 + tt / 600 * m;
        const r = R * (0.2 + ((i * 0.137) % 0.8));
        const x = cx + Math.cos(a) * r;
        const y = cy + Math.sin(a) * r * 0.7;
        const al = 0.3 + 0.4 * Math.sin(tt / 15 + i);
        ctx.fillStyle = `rgba(255,240,200,${al * boost})`;
        ctx.fillRect(x, y, 1.2, 1.2);
      }
    };

    /* EAGLE NEBULA — pillars of creation + bright stellar nursery */
    const drawEagle = (W: number, H: number, tt: number, st: AgentState) => {
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.22;
      const m = st === "think" ? 1.3 : 1;
      const boost = st === "listen" ? 1.15 : 1;
      // warm diffuse background
      const bg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.5);
      bg.addColorStop(0, `rgba(200,140,80,${0.2 * boost})`);
      bg.addColorStop(0.4, `rgba(120,80,180,${0.1 * boost})`);
      bg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);
      // pillars of creation (3 vertical dust columns)
      const pillars = [
        { x: 0.35, w: 0.06, h: 0.45 },
        { x: 0.5, w: 0.08, h: 0.55 },
        { x: 0.65, w: 0.05, h: 0.4 },
      ];
      for (const p of pillars) {
        const px = p.x * W;
        const pw = p.w * W;
        const ph = p.h * H;
        const py = cy - ph * 0.3;
        // pillar body (dark dust)
        const pg = ctx.createLinearGradient(px - pw, 0, px + pw, 0);
        pg.addColorStop(0, `rgba(60,30,20,${0.6 * boost})`);
        pg.addColorStop(0.5, `rgba(30,15,10,${0.8 * boost})`);
        pg.addColorStop(1, `rgba(60,30,20,${0.6 * boost})`);
        ctx.fillStyle = pg;
        // irregular pillar shape
        ctx.beginPath();
        ctx.moveTo(px - pw, py + ph);
        ctx.quadraticCurveTo(px - pw * 1.3, cy, px - pw * 0.5, py);
        ctx.quadraticCurveTo(px, py - ph * 0.1 + Math.sin(tt / 80) * 5, px + pw * 0.5, py);
        ctx.quadraticCurveTo(px + pw * 1.3, cy, px + pw, py + ph);
        ctx.closePath();
        ctx.fill();
        // glowing tips (star formation at pillar tops)
        for (let g = 0; g < 4; g++) {
          const gx = px + (Math.sin(tt / 60 + g + p.x * 10) * pw * 0.5);
          const gy = py + Math.cos(tt / 50 + g) * ph * 0.15;
          const gr = 4 + g * 2;
          const gg = ctx.createRadialGradient(gx, gy, 0, gx, gy, gr * 2);
          gg.addColorStop(0, `rgba(255,220,150,${0.8 * boost})`);
          gg.addColorStop(0.5, `rgba(255,150,80,${0.3 * boost})`);
          gg.addColorStop(1, "rgba(0,0,0,0)");
          ctx.fillStyle = gg;
          ctx.beginPath();
          ctx.arc(gx, gy, gr * 2, 0, 6.283);
          ctx.fill();
        }
      }
      // background stars
      for (let i = 0; i < 60; i++) {
        const x = ((i * 137.5) % W);
        const y = ((i * 73.3) % H);
        const al = 0.3 + 0.5 * Math.sin(tt / 20 + i);
        ctx.fillStyle = `rgba(220,200,255,${al * boost})`;
        ctx.fillRect(x, y, 1.2, 1.2);
      }
      // bright cluster stars (upper area)
      for (let i = 0; i < 12; i++) {
        const x = cx + Math.cos(i * 0.52 + tt / 500 * m) * R * 0.7;
        const y = cy - R * 0.5 + Math.sin(i * 0.7) * R * 0.2;
        const al = 0.5 + 0.4 * Math.sin(tt / 10 + i);
        const g = ctx.createRadialGradient(x, y, 0, x, y, 6);
        g.addColorStop(0, `rgba(255,250,220,${al * boost})`);
        g.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, y, 6, 0, 6.283);
        ctx.fill();
      }
    };

    const loop = () => {
      t++;
      const W = canvas.clientWidth, H = canvas.clientHeight;
      if (W && H) {
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, W, H);
        const st = stateRef.current;
        const sc = sceneRef.current;
        starsBg(W, H, t);
        if (sc === "solar") drawSolar(W, H, t, st);
        else if (sc === "galaxy") drawGalaxy(W, H, t, st);
        else if (sc === "uranus") drawUranus(W, H, t, st);
        else if (sc === "aurora") drawAurora(W, H, t, st);
        else if (sc === "pulsar") drawPulsar(W, H, t, st);
        else if (sc === "nebula") drawNebula(W, H, t, st);
        else if (sc === "blackhole") drawBlackHole(W, H, t, st);
        else if (sc === "supernova") drawSupernova(W, H, t, st);
        else if (sc === "solarflare") drawSolarFlare(W, H, t, st);
        else if (sc === "quasar") drawQuasar(W, H, t, st);
        else if (sc === "wormhole") drawWormhole(W, H, t, st);
        else if (sc === "binarystar") drawBinaryStar(W, H, t, st);
        else if (sc === "magnetar") drawMagnetar(W, H, t, st);
        else if (sc === "cosmicweb") drawCosmicWeb(W, H, t, st);
        else if (sc === "whitedwarf") drawWhiteDwarf(W, H, t, st);
        else if (sc === "nsmerger") drawNsMerger(W, H, t, st);
        else if (sc === "accretiondisk") drawAccretionDisk(W, H, t, st);
        else if (sc === "pwn") drawPWN(W, H, t, st);
        else if (sc === "tde") drawTDE(W, H, t, st);
        else if (sc === "grb") drawGRB(W, H, t, st);
        else if (sc === "magnetosphere") drawMagnetosphere(W, H, t, st);
        else if (sc === "hotjupiter") drawHotJupiter(W, H, t, st);
        else if (sc === "browndwarf") drawBrownDwarf(W, H, t, st);
        else if (sc === "protoplanetary") drawProtoplanetary(W, H, t, st);
        else if (sc === "hypergiant") drawHypergiant(W, H, t, st);
        else if (sc === "wolfrayet") drawWolfRayet(W, H, t, st);
        else if (sc === "ringnebula") drawRingNebula(W, H, t, st);
        else if (sc === "crabnebula") drawCrabNebula(W, H, t, st);
        else if (sc === "solarouter") drawSolarOuter(W, H, t, st);
        else if (sc === "helix") drawHelix(W, H, t, st);
        else if (sc === "orion") drawOrion(W, H, t, st);
        else if (sc === "eagle") drawEagle(W, H, t, st);
        else drawSpace(W, H, t, st);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [ready]);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      style={{ width: "100%", height: "100%", display: "block" }}
      aria-hidden="true"
    />
  );
}
