"use client";

import { create } from "zustand";
import type { SceneName, AgentState } from "./cosmic-canvas";

export type ViewName = "home" | "browser" | "apps" | "uia" | "memory" | "chat" | "tools" | "skills" | "brain" | "playground" | "connections" | "selftest";

export interface BrowserTab {
  id: string;
  windowId: number;
  title: string;
  url: string;
  favIconUrl?: string;
  active?: boolean;
  audible?: boolean;
  category: "game" | "work" | "social" | "media" | "dev" | "shop" | "other";
  aiLink: string;
  aiSummary: string;
  tags: string[];
  accent: string;
  watching?: boolean;
}

export interface AppItem {
  id: string;
  name: string;
  category: "game" | "work" | "media" | "dev" | "social" | "system" | "utility";
  exe?: string;
  icon: string;
  accent: string;
  description: string;
  running?: boolean;
  pinned?: boolean;
  launchCount?: number;
  // AI-readable extensions (so apps read like browser tabs):
  aiLink?: string;
  aiSummary?: string;
  aiTags?: string[];
  watching?: boolean;
}

export interface UiaControl {
  id: string;
  type: "button" | "text" | "edit" | "list" | "menu" | "tab" | "image" | "checkbox" | "slider" | "tree";
  name: string;
  value?: string;
  rect: { x: number; y: number; w: number; h: number };
  enabled: boolean;
  visible: boolean;
  aiLink: string;
  aiSummary: string;
  watching?: boolean;
}

export interface UiaWindow {
  windowId: number;
  title: string;
  process: string;
  focused: boolean;
  bounds: { x: number; y: number; w: number; h: number };
  controls: UiaControl[];
}

export interface GameNearest {
  name: string;
  distance: number;
  direction: string;
  depth: number;
  coords: { x: number; y: number; z: number };
}

export interface GameMemory {
  id: string;
  name: string;
  slug: string;
  exe: string;
  offline: boolean;
  whitelisted: boolean;
  running: boolean;
  memoryAllowed: boolean;
  antiCheat: { detected: boolean; name?: string; processes: string[] };
  networkActivity: boolean;
  processId?: number;
  player?: { x: number; y: number; z: number; depth: number };
  biome?: string;
  oxygen?: number;
  inventory?: { item: string; count: number }[];
  nearest?: GameNearest[];
  warningLevel: "safe" | "blocked" | "unknown";
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system" | "tool";
  text: string;
  ts: number;
  toolCalls?: { name: string; ok: boolean; preview: string }[];
  thinkMode?: "off" | "brief" | "medium" | "deep";
  searchUsed?: boolean;
  skillUsed?: string;
  images?: string[];
}

export interface Tool {
  id: string;
  name: string;
  category: string;
  description: string;
  core?: boolean;
  args?: { name: string; desc: string; required?: boolean }[];
}

export interface Skill {
  id: string;
  name: string;
  source: "local" | "nvidia";
  category: string;
  description: string;
  body: string;
  matched?: boolean;
  pinned?: boolean;
}

export interface Note { id: string; text: string; ts: number; tags?: string[] }
export interface Todo { id: string; text: string; done: boolean; ts: number; priority: "low" | "medium" | "high" }
export interface Fact { key: string; value: string; ts: number }
export interface KV { key: string; value: string; ts: number }
export interface Timer { id: string; label: string; fireAt: number; fired: boolean }

interface FluxState {
  view: ViewName;
  setView: (v: ViewName) => void;

  scene: SceneName;
  setScene: (s: SceneName) => void;
  agentState: AgentState;
  setAgentState: (s: AgentState) => void;
  statusText: string;
  setStatusText: (s: string) => void;

  tabs: BrowserTab[];
  setTabs: (t: BrowserTab[]) => void;
  toggleWatch: (id: string) => void;
  closeTab: (id: string) => void;
  openTab: (url: string, title: string) => void;

  apps: AppItem[];
  setApps: (a: AppItem[]) => void;
  toggleAppWatch: (id: string) => void;
  toggleRunning: (id: string) => void;
  togglePin: (id: string) => void;
  launchApp: (id: string) => void;

  uiaWindows: UiaWindow[];
  setUiaWindows: (w: UiaWindow[]) => void;
  toggleUiaControlWatch: (id: string) => void;

  games: GameMemory[];
  setGames: (g: GameMemory[]) => void;
  setMemoryAllowed: (id: string, allowed: boolean) => void;

  // z.ai shared chat panel
  zaiPanelOpen: boolean;
  setZaiPanelOpen: (b: boolean) => void;

  // tools catalog (357 total in original FLUX)
  tools: Tool[];
  setTools: (t: Tool[]) => void;

  // skills catalog (local + NVIDIA)
  skills: Skill[];
  setSkills: (s: Skill[]) => void;

  // brain (memory/notes/todos/kv/timers)
  brain: {
    notes: Note[];
    todos: Todo[];
    facts: Fact[];
    kvs: KV[];
    timers: Timer[];
  };
  setBrain: (b: FluxState["brain"]) => void;
  toggleTodo: (id: string) => void;

  messages: ChatMessage[];
  pushMessage: (m: ChatMessage) => void;
  clearChat: () => void;

  autospeak: boolean;
  setAutospeak: (b: boolean) => void;
  theme: "cosmic" | "midnight" | "deepspace" | "ember";
  setTheme: (t: FluxState["theme"]) => void;
  searchEngine: string;
  setSearchEngine: (s: string) => void;
  modelRef: string;
  setModelRef: (s: string) => void;
  thinkMode: "off" | "brief" | "medium" | "deep";
  setThinkMode: (m: "off" | "brief" | "medium" | "deep") => void;

  cdpOnline: boolean;
  cdpBrowser: string;
  cdpTabs: number;
  setCdp: (online: boolean, browser: string, tabs: number) => void;
}

function slugifyApp(id: string, name: string): string {
  return "app:" + (name.toLowerCase().replace(/[^a-z0-9а-я]+/gi, "-").replace(/^-+|-+$/g, "") || id);
}

function summarizeApp(name: string, category: string, description: string): string {
  return `${name} (${category}). ${description}`;
}

// localStorage helpers for client-side persistence
function loadLS<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : fallback;
  } catch { return fallback; }
}
function saveLS<T>(key: string, value: T): void {
  if (typeof window === "undefined") return;
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* noop */ }
}

export const useFlux = create<FluxState>((set) => ({
  view: "home",
  setView: (v) => set({ view: v }),

  scene: loadLS<SceneName>("flux_scene", "uranus"),
  setScene: (s) => { saveLS("flux_scene", s); set({ scene: s }); },
  agentState: "idle",
  setAgentState: (s) => set({ agentState: s }),
  statusText: "Ожидание…",
  setStatusText: (s) => set({ statusText: s }),

  tabs: [],
  setTabs: (t) => set({ tabs: t }),
  toggleWatch: (id) =>
    set((st) => ({
      tabs: st.tabs.map((t) => (t.id === id ? { ...t, watching: !t.watching } : t)),
    })),
  closeTab: (id) => set((st) => ({ tabs: st.tabs.filter((t) => t.id !== id) })),
  openTab: (url, title) =>
    set((st) => ({
      tabs: [
        ...st.tabs,
        {
          id: "tab-" + Date.now().toString(36),
          windowId: 1,
          title,
          url,
          category: "other" as const,
          aiLink: "tab" + (st.tabs.length + 1),
          aiSummary: "Новая вкладка, открытая из интерфейса FLUX.",
          tags: [],
          accent: "#4f8cff",
        },
      ],
    })),

  apps: [],
  setApps: (a) =>
    set({
      apps: a.map((app) => ({
        ...app,
        aiLink: app.aiLink || slugifyApp(app.id, app.name),
        aiSummary: app.aiSummary || summarizeApp(app.name, app.category, app.description),
        aiTags: app.aiTags || [app.category, app.running ? "running" : "stopped"],
        watching: app.watching ?? false,
      })),
    }),
  toggleAppWatch: (id) =>
    set((st) => ({
      apps: st.apps.map((a) => (a.id === id ? { ...a, watching: !a.watching } : a)),
    })),
  toggleRunning: (id) =>
    set((st) => ({
      apps: st.apps.map((a) =>
        a.id === id ? { ...a, running: !a.running, launchCount: (a.launchCount || 0) + (a.running ? 0 : 1) } : a
      ),
    })),
  togglePin: (id) =>
    set((st) => ({ apps: st.apps.map((a) => (a.id === id ? { ...a, pinned: !a.pinned } : a)) })),
  launchApp: (id) =>
    set((st) => ({
      apps: st.apps.map((a) =>
        a.id === id ? { ...a, running: true, launchCount: (a.launchCount || 0) + 1 } : a
      ),
    })),

  uiaWindows: [],
  setUiaWindows: (w) => set({ uiaWindows: w }),
  toggleUiaControlWatch: (id) =>
    set((st) => ({
      uiaWindows: st.uiaWindows.map((w) => ({
        ...w,
        controls: w.controls.map((c) => (c.id === id ? { ...c, watching: !c.watching } : c)),
      })),
    })),

  games: [],
  setGames: (g) => set({ games: g }),
  setMemoryAllowed: (id, allowed) =>
    set((st) => ({
      games: st.games.map((g) => (g.id === id ? { ...g, memoryAllowed: allowed } : g)),
    })),

  zaiPanelOpen: false,
  setZaiPanelOpen: (b) => set({ zaiPanelOpen: b }),

  tools: [],
  setTools: (t) => set({ tools: t }),

  skills: [],
  setSkills: (s) => set({ skills: s }),

  brain: { notes: [], todos: [], facts: [], kvs: [], timers: [] },
  setBrain: (b) => set({ brain: b }),
  toggleTodo: (id) =>
    set((st) => ({
      brain: {
        ...st.brain,
        todos: st.brain.todos.map((t) => (t.id === id ? { ...t, done: !t.done } : t)),
      },
    })),

  messages: [],
  pushMessage: (m) => set((st) => ({ messages: [...st.messages, m] })),
  clearChat: () => set({ messages: [] }),

  autospeak: loadLS<boolean>("flux_autospeak", true),
  setAutospeak: (b) => { saveLS("flux_autospeak", b); set({ autospeak: b }); },
  theme: loadLS<FluxState["theme"]>("flux_theme", "cosmic"),
  setTheme: (t) => { saveLS("flux_theme", t); set({ theme: t }); },
  searchEngine: loadLS<string>("flux_searchEngine", "duckduckgo"),
  setSearchEngine: (s) => { saveLS("flux_searchEngine", s); set({ searchEngine: s }); },
  modelRef: loadLS<string>("flux_modelRef", "demo::flux-pro"),
  setModelRef: (s) => { saveLS("flux_modelRef", s); set({ modelRef: s }); },
  thinkMode: loadLS<"off" | "brief" | "medium" | "deep">("flux_thinkMode", "medium"),
  setThinkMode: (m) => { saveLS("flux_thinkMode", m); set({ thinkMode: m }); },

  cdpOnline: false,
  cdpBrowser: "—",
  cdpTabs: 0,
  setCdp: (online, browser, tabs) =>
    set({ cdpOnline: online, cdpBrowser: browser, cdpTabs: tabs }),
}));
