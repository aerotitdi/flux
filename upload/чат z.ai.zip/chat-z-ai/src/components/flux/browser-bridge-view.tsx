"use client";

import { useEffect, useMemo, useState } from "react";
import { useFlux, type BrowserTab } from "./store";
import { CosmicCanvas } from "./cosmic-canvas";
import {
  Globe, Eye, EyeOff, X, Volume2, VolumeX, ExternalLink, RefreshCw,
  Search, Filter, Sparkles, Bot, Link2, Tags, Brain, Radio,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { StaggerContainer, StaggerItem } from "./motion";
import { cn } from "@/lib/utils";

const CATEGORIES: { id: BrowserTab["category"] | "all"; label: string; icon: string; accent: string }[] = [
  { id: "all", label: "Все", icon: "◎", accent: "text-cyan-300" },
  { id: "game", label: "Игры", icon: "🎮", accent: "text-amber-300" },
  { id: "work", label: "Работа", icon: "💼", accent: "text-emerald-300" },
  { id: "social", label: "Общение", icon: "💬", accent: "text-indigo-300" },
  { id: "media", label: "Медиа", icon: "🎬", accent: "text-rose-300" },
  { id: "dev", label: "Разработка", icon: "⚙", accent: "text-slate-300" },
  { id: "shop", label: "Покупки", icon: "🛒", accent: "text-blue-300" },
  { id: "other", label: "Прочее", icon: "📄", accent: "text-zinc-300" },
];

export function BrowserBridgeView() {
  const { tabs, setTabs, toggleWatch, closeTab, setStatusText, setView, setAgentState } = useFlux();
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<BrowserTab["category"] | "all">("all");
  const [sortBy, setSortBy] = useState<"default" | "watched" | "title">("default");

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      try {
        const r = await fetch("/api/browser/tabs");
        const d = await r.json();
        if (active && Array.isArray(d.tabs)) setTabs(d.tabs);
      } catch {
        /* noop */
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [setTabs]);

  const filtered = useMemo(() => {
    let r = tabs;
    if (cat !== "all") r = r.filter((t) => t.category === cat);
    if (query.trim()) {
      const q = query.toLowerCase();
      r = r.filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          t.url.toLowerCase().includes(q) ||
          t.aiLink.toLowerCase().includes(q) ||
          t.tags.some((tag) => tag.toLowerCase().includes(q))
      );
    }
    if (sortBy === "watched") r = [...r].sort((a, b) => Number(!!b.watching) - Number(!!a.watching));
    if (sortBy === "title") r = [...r].sort((a, b) => a.title.localeCompare(b.title));
    return r;
  }, [tabs, cat, query, sortBy]);

  const watching = tabs.filter((t) => t.watching).length;
  const gamesCount = tabs.filter((t) => t.category === "game").length;

  // AI scan simulation
  const scanAll = () => {
    setAgentState("think");
    setStatusText("🔧 browser_tabs_list — сканирую все вкладки как ссылки…");
    setTimeout(() => {
      setAgentState("listen");
      setStatusText(`Готово: вижу ${tabs.length} вкладок, ${gamesCount} из них — игры. Каждая как ссылка-карточка для ИИ.`);
    }, 1400);
  };

  return (
    <div className="relative flex-1 flex flex-col overflow-hidden">
      {/* cosmic bg dimmer */}
      <div className="absolute inset-0 opacity-30 pointer-events-none">
        <CosmicCanvas scene="space" agentState="idle" className="w-full h-full" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background pointer-events-none" />

      <div className="relative z-10 flex flex-col h-full">
        {/* toolbar */}
        <div className="px-3 sm:px-5 py-3 border-b border-border bg-card/50 backdrop-blur-md flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 mr-2">
            <Globe size={18} className="text-cyan-400" />
            <h2 className="font-bold text-base sm:text-lg text-shimmer">Браузер-мост</h2>
            <Badge variant="outline" className="text-[10px] font-mono">
              {tabs.length} вкладок
            </Badge>
            <Badge className="text-[10px] font-mono bg-amber-500/15 text-amber-300 border-amber-500/30">
              {gamesCount} игр
            </Badge>
          </div>

          <div className="flex-1" />

          <div className="relative flex-1 min-w-[160px] max-w-[280px]">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Поиск по вкладкам…"
              className="h-8 pl-8 text-xs"
              aria-label="Поиск по вкладкам"
            />
          </div>

          <Select value={cat} onValueChange={(v) => setCat(v as BrowserTab["category"] | "all")}>
            <SelectTrigger className="w-[130px] h-8 text-xs" aria-label="Фильтр категорий">
              <Filter size={12} className="mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CATEGORIES.map((c) => (
                <SelectItem key={c.id} value={c.id} className="text-xs">
                  {c.icon} {c.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
            <SelectTrigger className="w-[140px] h-8 text-xs" aria-label="Сортировка">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="default" className="text-xs">По умолчанию</SelectItem>
              <SelectItem value="watched" className="text-xs">Сначала читаемые</SelectItem>
              <SelectItem value="title" className="text-xs">По названию</SelectItem>
            </SelectContent>
          </Select>

          <Button
            size="sm"
            variant="default"
            onClick={scanAll}
            className="h-8 gap-1.5 bg-cyan-500/20 border border-cyan-400/40 text-cyan-200 hover:bg-cyan-500/30"
          >
            <Bot size={14} />
            <span className="text-xs">ИИ читает все</span>
          </Button>
        </div>

        {/* category chips */}
        <div className="px-3 sm:px-5 py-2 flex gap-1.5 overflow-x-auto flux-scroll border-b border-border/50 bg-card/30">
          {CATEGORIES.map((c) => {
            const count = c.id === "all" ? tabs.length : tabs.filter((t) => t.category === c.id).length;
            const active = cat === c.id;
            return (
              <button
                key={c.id}
                onClick={() => setCat(c.id)}
                className={cn(
                  "shrink-0 px-2.5 py-1 rounded-full text-[11px] font-mono transition border flex items-center gap-1",
                  active
                    ? "bg-cyan-500/20 border-cyan-400/50 text-cyan-200"
                    : "bg-transparent border-border text-muted-foreground hover:text-foreground hover:bg-accent"
                )}
              >
                <span>{c.icon}</span>
                <span>{c.label}</span>
                <span className="opacity-50">{count}</span>
              </button>
            );
          })}
        </div>

        {/* tabs grid as game-like link cards */}
        <ScrollArea className="flex-1">
          <div className="p-3 sm:p-5">
            {loading ? (
              <SkeletonGrid />
            ) : filtered.length === 0 ? (
              <EmptyState />
            ) : (
              <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
                {filtered.map((tab) => (
                  <StaggerItem key={tab.id}>
                  <TabCard
                    tab={tab}
                    onToggleWatch={() => {
                      toggleWatch(tab.id);
                      setStatusText(
                        tab.watching
                          ? `Перестал читать ${tab.aiLink}`
                          : `Готово: теперь ИИ читает ${tab.aiLink} (${tab.title.slice(0, 40)})`
                      );
                    }}
                    onClose={() => {
                      closeTab(tab.id);
                      setStatusText(`Вкладка ${tab.aiLink} закрыта`);
                    }}
                    onAsk={() => {
                      setView("chat");
                      setStatusText(`ИИ переключился на ${tab.aiLink} — задайте вопрос`);
                    }}
                  />
                  </StaggerItem>
                ))}
              </StaggerContainer>
            )}
          </div>
        </ScrollArea>

        {/* footer summary */}
        <div className="px-3 sm:px-5 py-2 border-t border-border bg-card/60 backdrop-blur-md flex flex-wrap items-center gap-2 text-[11px] font-mono text-muted-foreground">
          <span className="flex items-center gap-1">
            <Eye size={12} className="text-teal-400" />
            ИИ читает: <span className="text-teal-300">{watching}</span> из {tabs.length}
          </span>
          <span className="opacity-30">·</span>
          <span className="flex items-center gap-1">
            <Link2 size={12} className="text-purple-400" />
            Каждая вкладка = ссылка <code className="text-purple-300">{`{category}:{slug}`}</code>
          </span>
          <span className="opacity-30">·</span>
          <span className="flex items-center gap-1">
            <Brain size={12} className="text-cyan-400" />
            agent вызывает <code className="text-cyan-300">browser_tabs_list</code>
          </span>
        </div>
      </div>
    </div>
  );
}

function TabCard({
  tab,
  onToggleWatch,
  onClose,
  onAsk,
}: {
  tab: BrowserTab;
  onToggleWatch: () => void;
  onClose: () => void;
  onAsk: () => void;
}) {
  const cat = CATEGORIES.find((c) => c.id === tab.category);
  return (
    <article
      className={cn(
        "game-card-hover card-lift relative rounded-xl overflow-hidden glass-panel border-gradient-cosmic group",
        tab.watching && "ring-1 ring-teal-400/60 glow-teal"
      )}
    >
      {/* screenshot-like header with accent */}
      <div
        className="relative h-28 sm:h-32 overflow-hidden"
        style={{
          background: `radial-gradient(circle at 30% 30%, ${tab.accent}cc, transparent 65%), radial-gradient(circle at 70% 80%, ${tab.accent}55, transparent 60%), linear-gradient(135deg, #14172a, #0b0d18)`,
        }}
      >
        {/* mock UI elements suggesting a screenshot */}
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-2 left-2 w-16 h-2 bg-white/40 rounded" />
          <div className="absolute top-5 left-2 w-24 h-1.5 bg-white/25 rounded" />
          <div className="absolute bottom-3 right-3 w-10 h-10 rounded-full border border-white/30 flex items-center justify-center text-base">
            {tab.favIconUrl || cat?.icon}
          </div>
          <div className="absolute bottom-2 left-2 flex gap-1">
            {tab.tags.slice(0, 3).map((tag) => (
              <span key={tag} className="text-[9px] px-1.5 py-0.5 bg-black/40 rounded text-white/70 font-mono">
                #{tag}
              </span>
            ))}
          </div>
        </div>
        {/* browser chrome dots */}
        <div className="absolute top-2 right-2 flex gap-1 z-10">
          <span className="w-2 h-2 rounded-full bg-red-400/80" />
          <span className="w-2 h-2 rounded-full bg-amber-400/80" />
          <span className="w-2 h-2 rounded-full bg-emerald-400/80" />
        </div>
        {/* "AI reading" badge */}
        {tab.watching && (
          <div className="absolute top-2 left-2 z-10 flex items-center gap-1 px-2 py-0.5 rounded-full bg-teal-500/30 border border-teal-400/50 text-[10px] text-teal-100 font-mono backdrop-blur-sm">
            <Eye size={10} />
            ИИ читает
          </div>
        )}
        {tab.audible && (
          <div className="absolute bottom-2 right-2 z-10">
            <Volume2 size={14} className="text-rose-300/80" />
          </div>
        )}
        {tab.active && (
          <div className="absolute top-2 left-1/2 -translate-x-1/2 z-10 px-1.5 py-0.5 rounded-full bg-cyan-500/40 border border-cyan-300/50 text-[9px] text-cyan-100 font-mono">
            АКТИВНА
          </div>
        )}
      </div>

      {/* content */}
      <div className="p-3 flex flex-col gap-2">
        <div className="flex items-start gap-2">
          <span className="text-lg leading-none mt-0.5">{tab.favIconUrl || cat?.icon}</span>
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-semibold leading-tight truncate" title={tab.title}>
              {tab.title}
            </h3>
            <p className="text-[10px] text-muted-foreground truncate font-mono">{tab.url}</p>
          </div>
        </div>

        {/* AI-readable link */}
        <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-purple-500/10 border border-purple-400/30">
          <Link2 size={11} className="text-purple-300 shrink-0" />
          <code className="text-[10px] text-purple-200 font-mono truncate flex-1">{tab.aiLink}</code>
          <span className="text-[9px] text-purple-300/70 font-mono shrink-0">ссылка</span>
        </div>

        {/* AI summary */}
        <p className="text-[11px] text-foreground/80 leading-snug line-clamp-3" title={tab.aiSummary}>
          <Sparkles size={9} className="inline mr-1 text-cyan-400" />
          {tab.aiSummary}
        </p>

        {/* tags */}
        <div className="flex flex-wrap gap-1">
          {tab.tags.slice(0, 4).map((tag) => (
            <span
              key={tag}
              className="text-[9px] px-1.5 py-0.5 rounded bg-muted/60 text-muted-foreground font-mono"
            >
              #{tag}
            </span>
          ))}
        </div>

        {/* actions */}
        <div className="flex items-center gap-1 mt-1 pt-2 border-t border-border/50">
          <button
            onClick={onToggleWatch}
            className={cn(
              "flex-1 h-7 rounded-md text-[10px] font-medium flex items-center justify-center gap-1 transition",
              tab.watching
                ? "bg-teal-500/20 text-teal-200 border border-teal-400/40 hover:bg-teal-500/30"
                : "bg-muted/60 text-muted-foreground border border-border hover:bg-accent"
            )}
            aria-pressed={tab.watching}
            title={tab.watching ? "Перестать читать" : "Читать для ИИ"}
          >
            {tab.watching ? <EyeOff size={12} /> : <Eye size={12} />}
            {tab.watching ? "Не читать" : "Читать ИИ"}
          </button>
          <button
            onClick={onAsk}
            className="h-7 px-2 rounded-md text-[10px] font-medium bg-cyan-500/15 text-cyan-200 border border-cyan-400/30 hover:bg-cyan-500/25 flex items-center gap-1"
            title="Спросить ИИ об этой вкладке"
          >
            <Bot size={12} />
            <span className="hidden sm:inline">Спросить</span>
          </button>
          <a
            href={tab.url}
            target="_blank"
            rel="noopener noreferrer"
            className="h-7 w-7 rounded-md flex items-center justify-center bg-muted/60 text-muted-foreground border border-border hover:bg-accent hover:text-foreground"
            title="Открыть в новой вкладке"
          >
            <ExternalLink size={12} />
          </a>
          <button
            onClick={onClose}
            className="h-7 w-7 rounded-md flex items-center justify-center bg-red-500/10 text-red-300 border border-red-500/30 hover:bg-red-500/20"
            title="Закрыть вкладку"
            aria-label="Закрыть вкладку"
          >
            <X size={12} />
          </button>
        </div>
      </div>
    </article>
  );
}

function SkeletonGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="rounded-xl overflow-hidden glass-panel">
          <div className="h-28 sm:h-32 shimmer" />
          <div className="p-3 space-y-2">
            <div className="h-3 w-3/4 rounded shimmer" />
            <div className="h-2 w-full rounded shimmer" />
            <div className="h-2 w-2/3 rounded shimmer" />
          </div>
        </div>
      ))}
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center text-muted-foreground">
      <Globe size={48} className="opacity-40 mb-3" />
      <p className="text-sm">Вкладок не найдено</p>
      <p className="text-xs mt-1">Попробуй изменить фильтр или поисковый запрос</p>
    </div>
  );
}
