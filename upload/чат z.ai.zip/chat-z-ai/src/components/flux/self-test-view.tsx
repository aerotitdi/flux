"use client";

import { useEffect, useState } from "react";
import { useFlux } from "./store";
import { CosmicCanvas } from "./cosmic-canvas";
import {
  Activity, CheckCircle2, AlertCircle, XCircle, RefreshCw, Server, Globe, Wrench,
  BookOpen, Brain, Volume2, Terminal, Zap, Clock,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface Check {
  id: string;
  name: string;
  status: "ok" | "warn" | "fail" | "skip";
  detail: string;
  latency?: number;
  category: "system" | "browser" | "tools" | "skills" | "memory" | "voice" | "code";
}

interface Summary { total: number; ok: number; warn: number; fail: number; skip: number }

const CAT_META: Record<Check["category"], { label: string; icon: React.ReactNode; accent: string }> = {
  system: { label: "Система", icon: <Server size={14} />, accent: "text-cyan-300" },
  browser: { label: "Браузер", icon: <Globe size={14} />, accent: "text-blue-300" },
  tools: { label: "Инструменты", icon: <Wrench size={14} />, accent: "text-amber-300" },
  skills: { label: "Скиллы", icon: <BookOpen size={14} />, accent: "text-emerald-300" },
  memory: { label: "Память", icon: <Brain size={14} />, accent: "text-purple-300" },
  voice: { label: "Голос", icon: <Volume2 size={14} />, accent: "text-teal-300" },
  code: { label: "Код", icon: <Terminal size={14} />, accent: "text-orange-300" },
};

const STATUS_META = {
  ok: { label: "OK", icon: <CheckCircle2 size={14} />, color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/30" },
  warn: { label: "WARN", icon: <AlertCircle size={14} />, color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/30" },
  fail: { label: "FAIL", icon: <XCircle size={14} />, color: "text-red-400", bg: "bg-red-500/10 border-red-500/30" },
  skip: { label: "SKIP", icon: <Activity size={14} />, color: "text-zinc-400", bg: "bg-muted/20 border-border" },
};

export function SelfTestView() {
  const { setStatusText } = useFlux();
  const [checks, setChecks] = useState<Check[]>([]);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [byCat, setByCat] = useState<Record<string, Record<string, number>>>({});
  const [loading, setLoading] = useState(true);
  const [ranAt, setRanAt] = useState<string>("");
  const [filter, setFilter] = useState<Check["category"] | "all">("all");

  const run = async () => {
    setLoading(true);
    setStatusText("🔧 --selftest → прогоны проверок…");
    try {
      const r = await fetch("/api/selftest");
      const d = await r.json();
      setChecks(d.checks || []);
      setSummary(d.summary || null);
      setByCat(d.byCat || {});
      setRanAt(d.ranAt || new Date().toISOString());
      setStatusText(`Готово: ${d.summary?.ok}/${d.summary?.total} OK, ${d.summary?.warn} warn, ${d.summary?.fail} fail`);
    } catch { /* noop */ }
    finally { setLoading(false); }
  };

  useEffect(() => {
    run();
  }, []); // run only on mount

  const filtered = filter === "all" ? checks : checks.filter((c) => c.category === filter);

  return (
    <div className="relative flex-1 flex flex-col overflow-hidden">
      <div className="absolute inset-0 opacity-25 pointer-events-none">
        <CosmicCanvas scene="magnetar" agentState="idle" className="w-full h-full" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background pointer-events-none" />

      <div className="relative z-10 flex flex-col h-full">
        {/* toolbar */}
        <div className="px-3 sm:px-5 py-3 border-b border-border bg-card/50 backdrop-blur-md flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 mr-2">
            <Activity size={18} className="text-emerald-400" />
            <h2 className="font-bold text-base sm:text-lg text-shimmer">Self-Test / Диагностика</h2>
            {summary && (
              <Badge variant="outline" className="text-[10px] font-mono">
                {summary.ok}/{summary.total} OK
              </Badge>
            )}
          </div>
          <div className="flex-1" />
          {ranAt && (
            <span className="text-[10px] font-mono text-muted-foreground hidden sm:inline">
              запущено: {new Date(ranAt).toLocaleTimeString("ru-RU")}
            </span>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={run}
            disabled={loading}
            className="h-8 text-xs gap-1 text-muted-foreground hover:text-foreground"
          >
            <RefreshCw size={12} className={loading ? "animate-spin" : ""} />
            Перепроверить
          </Button>
        </div>

        {/* summary cards */}
        {summary && (
          <div className="px-3 sm:px-5 py-3 grid grid-cols-2 sm:grid-cols-4 gap-2 border-b border-border/50 bg-card/30">
            <SummaryCard label="OK" value={summary.ok} total={summary.total} color="emerald" icon={<CheckCircle2 size={16} />} />
            <SummaryCard label="WARN" value={summary.warn} total={summary.total} color="amber" icon={<AlertCircle size={16} />} />
            <SummaryCard label="FAIL" value={summary.fail} total={summary.total} color="red" icon={<XCircle size={16} />} />
            <SummaryCard label="SKIP" value={summary.skip} total={summary.total} color="zinc" icon={<Activity size={16} />} />
          </div>
        )}

        {/* category chips */}
        <div className="px-3 sm:px-5 py-2 flex gap-1.5 overflow-x-auto flux-scroll border-b border-border/50 bg-card/30">
          <button
            onClick={() => setFilter("all")}
            className={cn(
              "shrink-0 px-2.5 py-1 rounded-full text-[11px] font-mono transition border",
              filter === "all"
                ? "bg-cyan-500/20 border-cyan-400/50 text-cyan-200"
                : "bg-transparent border-border text-muted-foreground hover:text-foreground hover:bg-accent"
            )}
          >
            Все ({checks.length})
          </button>
          {Object.entries(CAT_META).map(([k, v]) => {
            const c = byCat[k] || {};
            const total = (c.ok || 0) + (c.warn || 0) + (c.fail || 0) + (c.skip || 0);
            if (total === 0) return null;
            const active = filter === k;
            return (
              <button
                key={k}
                onClick={() => setFilter(k as Check["category"])}
                className={cn(
                  "shrink-0 px-2.5 py-1 rounded-full text-[11px] font-mono transition border flex items-center gap-1.5",
                  active
                    ? "bg-cyan-500/20 border-cyan-400/50 text-cyan-200"
                    : "bg-transparent border-border text-muted-foreground hover:text-foreground hover:bg-accent"
                )}
              >
                {v.icon}
                {v.label}
                <span className="opacity-50">{total}</span>
                {c.fail ? <span className="text-red-300">·{c.fail}✗</span> : null}
                {c.warn ? <span className="text-amber-300">·{c.warn}!</span> : null}
              </button>
            );
          })}
        </div>

        {/* checks list */}
        <ScrollArea className="flex-1">
          <div className="p-3 sm:p-5 max-w-4xl mx-auto">
            {loading && checks.length === 0 ? (
              <div className="space-y-2">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="p-3 rounded-lg glass-panel">
                    <div className="h-3 w-1/3 rounded shimmer mb-2" />
                    <div className="h-2 w-2/3 rounded shimmer" />
                  </div>
                ))}
              </div>
            ) : (
              <motion.div
                initial="hidden"
                animate="visible"
                variants={{ hidden: { opacity: 0 }, visible: { opacity: 1, transition: { staggerChildren: 0.03 } } }}
                className="space-y-1.5"
              >
                {filtered.map((c) => {
                  const sm = STATUS_META[c.status];
                  const cm = CAT_META[c.category];
                  return (
                    <motion.div
                      key={c.id}
                      variants={{ hidden: { opacity: 0, y: 6 }, visible: { opacity: 1, y: 0 } }}
                      className={cn("p-2.5 rounded-lg border flex items-center gap-3 card-lift", sm.bg)}
                    >
                      <span className={cn("shrink-0", sm.color)}>{sm.icon}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <code className="text-[11px] font-mono text-foreground/90">{c.id}</code>
                          <span className="text-[10px] text-muted-foreground truncate">{c.name}</span>
                        </div>
                        <p className="text-[10px] text-muted-foreground/80 mt-0.5 truncate">{c.detail}</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className={cn("text-[9px] flex items-center gap-0.5", cm.accent)}>
                          {cm.icon}
                          {cm.label}
                        </span>
                        {c.latency !== undefined && (
                          <Badge variant="outline" className="text-[9px] py-0 px-1.5 font-mono">
                            <Clock size={9} className="mr-0.5" />
                            {c.latency}мс
                          </Badge>
                        )}
                        <span className={cn("text-[10px] font-mono font-bold", sm.color)}>{sm.label}</span>
                      </div>
                    </motion.div>
                  );
                })}
              </motion.div>
            )}
          </div>
        </ScrollArea>

        {/* footer */}
        <div className="px-3 sm:px-5 py-2 border-t border-border bg-card/60 backdrop-blur-md flex flex-wrap items-center gap-2 text-[11px] font-mono text-muted-foreground">
          <span className="flex items-center gap-1">
            <Zap size={12} className="text-emerald-400" />
            эквивалент <code className="text-emerald-300">python main.py --selftest</code>
          </span>
          <span className="opacity-30">·</span>
          <span>{checks.length} проверок в {Object.keys(byCat).length} категориях</span>
        </div>
      </div>
    </div>
  );
}

function SummaryCard({ label, value, total, color, icon }: { label: string; value: number; total: number; color: string; icon: React.ReactNode }) {
  const colorMap: Record<string, string> = {
    emerald: "text-emerald-300 border-emerald-500/30 bg-emerald-500/10",
    amber: "text-amber-300 border-amber-500/30 bg-amber-500/10",
    red: "text-red-300 border-red-500/30 bg-red-500/10",
    zinc: "text-zinc-300 border-zinc-500/30 bg-zinc-500/10",
  };
  const pct = total > 0 ? Math.round((value / total) * 100) : 0;
  return (
    <div className={cn("p-3 rounded-lg border flex items-center gap-3", colorMap[color])}>
      <span className="shrink-0">{icon}</span>
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline gap-1.5">
          <span className="text-xl font-bold font-mono">{value}</span>
          <span className="text-[10px] uppercase tracking-wider opacity-70">{label}</span>
        </div>
        <div className="text-[9px] font-mono opacity-60">{pct}% от {total}</div>
      </div>
    </div>
  );
}
