"use client";

import { useEffect, useState } from "react";
import {
  X, Plus, Trash2, Eye, EyeOff, RefreshCw, Plug, Volume2, Code2,
  Info, Cpu, Mic, Save, Check, ExternalLink,
} from "lucide-react";
import { useFlux } from "./store";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

interface Connection {
  id: string;
  name: string;
  type: "external";
  base_url: string;
  auth: "Bearer" | "X-API-Key" | "Basic" | "";
  api_key?: string;
  api_type: "chat_completions";
  provider: string;
  model_ids: string[];
  tags: string[];
  enabled: boolean;
}

const TABS = [
  { id: "conns", label: "Подключения", icon: <Plug size={14} /> },
  { id: "voice", label: "Голос и микрофон", icon: <Volume2 size={14} /> },
  { id: "code", label: "Код", icon: <Code2 size={14} /> },
  { id: "about", label: "О системе", icon: <Info size={14} /> },
];

const ENGINES = ["python", "node", "java", "c", "cpp", "go", "rust", "ruby", "php", "bash", "powershell", "sql", "lua", "perl", "kotlin", "ts"];

export function SettingsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { autospeak, setAutospeak, searchEngine, setSearchEngine, thinkMode, setThinkMode } = useFlux();
  const [tab, setTab] = useState("conns");
  const [conns, setConns] = useState<Connection[]>([]);
  const [showKey, setShowKey] = useState(false);
  const [status, setStatus] = useState<{ about: Record<string, unknown> | null; tools: number }>({ about: null, tools: 0 });

  useEffect(() => {
    if (!open) return;
    (async () => {
      try {
        const r = await fetch("/api/connections");
        const d = await r.json();
        if (Array.isArray(d.connections)) setConns(d.connections);
      } catch { /* noop */ }
      try {
        const r = await fetch("/api/status");
        const d = await r.json();
        setStatus({ about: d, tools: d.tools || 0 });
      } catch { /* noop */ }
    })();
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl max-h-[88vh] overflow-hidden p-0 gap-0">
        <DialogHeader className="px-5 py-3 border-b border-border flex-row items-center justify-between">
          <DialogTitle className="text-base flex items-center gap-2">
            <Plug size={16} className="text-cyan-400" />
            Настройки
          </DialogTitle>
        </DialogHeader>

        <Tabs value={tab} onValueChange={setTab} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="px-3 pt-3 bg-transparent justify-start gap-1 border-b border-border rounded-none">
            {TABS.map((t) => (
              <TabsTrigger key={t.id} value={t.id} className="text-xs gap-1.5 data-[state=active]:bg-accent">
                {t.icon}
                {t.label}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="conns" className="flex-1 overflow-y-auto flux-scroll p-5 m-0 data-[state=inactive]:hidden">
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-3 p-3 rounded-lg border border-border bg-card/60">
                <div className="flex-1 min-w-0">
                  <Label className="text-xs font-mono mb-1 block">Ollama API</Label>
                  <Input
                    defaultValue="http://127.0.0.1:11434"
                    className="h-8 text-xs font-mono"
                    placeholder="http://127.0.0.1:11434"
                  />
                </div>
                <Switch defaultChecked />
                <Button size="sm" className="h-8 text-xs gap-1">
                  <Plus size={12} />
                  Подключить
                </Button>
              </div>
              <p className="text-[11px] text-muted-foreground -mt-1">
                Прямые подключения к Ollama (как в Open WebUI): модели тянутся через <code>/v1/models</code>.
              </p>

              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Внешние соединения</h3>
                <Button size="sm" className="h-8 text-xs gap-1 bg-cyan-500/20 border border-cyan-400/40 text-cyan-200 hover:bg-cyan-500/30">
                  <Plus size={12} />
                  Добавить соединение
                </Button>
              </div>

              <div className="space-y-2">
                {conns.map((c) => (
                  <div key={c.id} className="p-3 rounded-lg border border-border bg-card/60 flex items-center gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-sm">{c.name}</span>
                        <Badge variant="outline" className="text-[9px] font-mono">{c.provider}</Badge>
                        <Badge variant="outline" className="text-[9px] font-mono">{c.model_ids.length} моделей</Badge>
                        {c.tags.map((t) => (
                          <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-muted/60 font-mono">#{t}</span>
                        ))}
                      </div>
                      <div className="text-[10px] text-muted-foreground font-mono truncate mt-1">
                        {c.base_url}
                      </div>
                    </div>
                    <Switch
                      checked={c.enabled}
                      onCheckedChange={async () => {
                        try {
                          await fetch("/api/connections", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ action: "toggle", id: c.id }),
                          });
                          setConns((prev) => prev.map((x) => x.id === c.id ? { ...x, enabled: !x.enabled } : x));
                        } catch { /* noop */ }
                      }}
                    />
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-red-300 hover:bg-red-500/10">
                      <Trash2 size={12} />
                    </Button>
                  </div>
                ))}
              </div>

              {/* add connection form */}
              <div className="p-4 rounded-lg border border-dashed border-border bg-card/30 space-y-3">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Новое соединение
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-[10px] font-mono mb-1 block">URL</Label>
                    <Input placeholder="https://api.example.com/v1" className="h-8 text-xs font-mono" />
                  </div>
                  <div>
                    <Label className="text-[10px] font-mono mb-1 block">Название</Label>
                    <Input placeholder="my-provider" className="h-8 text-xs font-mono" />
                  </div>
                </div>
                <div className="grid grid-cols-[120px_1fr_auto] gap-2 items-end">
                  <div>
                    <Label className="text-[10px] font-mono mb-1 block">Вход</Label>
                    <Select defaultValue="Bearer">
                      <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Bearer">Bearer</SelectItem>
                        <SelectItem value="X-API-Key">X-API-Key</SelectItem>
                        <SelectItem value="Basic">Basic</SelectItem>
                        <SelectItem value="none">Без ключа</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-[10px] font-mono mb-1 block">Ключ API</Label>
                    <div className="relative">
                      <Input type={showKey ? "text" : "password"} placeholder="sk-…" className="h-8 text-xs font-mono pr-8" />
                      <button
                        onClick={() => setShowKey(!showKey)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showKey ? <EyeOff size={12} /> : <Eye size={12} />}
                      </button>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="h-8 w-8" title="Тянуть модели с /models">
                    <RefreshCw size={14} />
                  </Button>
                </div>
                <div className="flex justify-end gap-2 pt-1">
                  <Button variant="ghost" size="sm" className="h-8 text-xs">Проверить</Button>
                  <Button size="sm" className="h-8 text-xs gap-1">
                    <Save size={12} />
                    Сохранить
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="voice" className="flex-1 overflow-y-auto flux-scroll p-5 m-0 space-y-3 data-[state=inactive]:hidden">
            <Row label="Микрофон (браузерный)">
              <Select defaultValue="default">
                <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Устройство" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="default">Системное по умолчанию</SelectItem>
                  <SelectItem value="headset">Bluetooth-гарнитура</SelectItem>
                  <SelectItem value="usb">USB-микрофон</SelectItem>
                </SelectContent>
              </Select>
            </Row>
            <Row label="Распознавание">
              <Select defaultValue="auto">
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">auto (браузерное Google/WebSpeech, иначе бэкенд)</SelectItem>
                  <SelectItem value="browser">только браузер (WebSpeech)</SelectItem>
                  <SelectItem value="provider">/audio/transcriptions провайдера</SelectItem>
                  <SelectItem value="whisper">локальный whisper</SelectItem>
                </SelectContent>
              </Select>
            </Row>
            <Row label="Движок озвучки">
              <Select defaultValue="winget">
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="winget">wingetgui.com — 400+ голосов, mp3</SelectItem>
                  <SelectItem value="edge">Edge TTS (локально)</SelectItem>
                  <SelectItem value="browser">браузерный speechSynthesis</SelectItem>
                  <SelectItem value="off">выкл</SelectItem>
                </SelectContent>
              </Select>
            </Row>
            <Row label="Голос Flux">
              <Select defaultValue="amelie">
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="amelie">Amélie (FR)</SelectItem>
                  <SelectItem value="jenny">Jenny (EN)</SelectItem>
                  <SelectItem value="dmitry">Dmitry (RU)</SelectItem>
                  <SelectItem value="yuri">Yuri (RU, deep)</SelectItem>
                </SelectContent>
              </Select>
            </Row>
            <div className="flex items-center justify-between p-3 rounded-lg border border-border bg-card/60">
              <div>
                <Label className="text-xs">Авто-озвучка ответов</Label>
                <p className="text-[10px] text-muted-foreground mt-0.5">Голосом помечается суть в 1-2 фразы внутри маркера <code>*-…-*</code></p>
              </div>
              <Switch checked={autospeak} onCheckedChange={setAutospeak} />
            </div>
            <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5">
              <Mic size={12} />
              Проверить голос
            </Button>
          </TabsContent>

          <TabsContent value="code" className="flex-1 overflow-y-auto flux-scroll p-5 m-0 space-y-3 data-[state=inactive]:hidden">
            <Row label="Движок по умолчанию">
              <Select defaultValue="python">
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ENGINES.map((e) => (
                    <SelectItem key={e} value={e} className="text-xs font-mono">{e}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Row>
            <p className="text-[11px] text-muted-foreground">
              Доступные движки: <span className="font-mono">{ENGINES.join(", ")}</span>.
              Каждый код-блок в ответе ИИ имеет кнопку «Запустить», которая шлёт код на <code>/api/runcode</code>.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {ENGINES.slice(0, 8).map((e) => (
                <div key={e} className="p-2 rounded border border-border bg-card/60 flex items-center gap-1.5">
                  <Check size={12} className="text-emerald-400" />
                  <code className="text-[11px]">{e}</code>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="about" className="flex-1 overflow-y-auto flux-scroll p-5 m-0 space-y-3 data-[state=inactive]:hidden">
            <div className="p-4 rounded-lg border border-border bg-card/60 space-y-2">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <Cpu size={14} className="text-cyan-400" />
                FLUX 2.0 — о системе
              </h3>
              <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-[11px] font-mono">
                <span className="text-muted-foreground">Версия:</span>
                <span>{String(status.about?.version ?? "—")}</span>
                <span className="text-muted-foreground">Инструментов:</span>
                <span>{String(status.about?.tools ?? "—")}</span>
                <span className="text-muted-foreground">Скиллы локальные:</span>
                <span>{String(status.about?.skills_local ?? "—")}</span>
                <span className="text-muted-foreground">Каталог NVIDIA:</span>
                <span>{String(status.about?.skills_remote_catalog ?? "—")}+</span>
                <span className="text-muted-foreground">OS:</span>
                <span>{String(status.about?.os ?? "—")}</span>
                <span className="text-muted-foreground">Python:</span>
                <span>{String(status.about?.python ?? "—")}</span>
                <span className="text-muted-foreground">CDP-порт:</span>
                <span>{String(status.about?.cdp_port ?? "9222")}</span>
              </div>
            </div>

            <Row label="Авто-подбор скиллов">
              <Switch defaultChecked />
            </Row>
            <p className="text-[11px] text-muted-foreground -mt-2">
              Скиллы: локальные (<code>*.md</code>) + каталог NVIDIA <code>build.nvidia.com/skills</code> (400+).
            </p>

            <Row label="Отправка по кодовому слову">
              <Select defaultValue="start">
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="off">режим 1: не важно (отвечает всегда)</SelectItem>
                  <SelectItem value="start">режим 2: только если НАЧАЛ с «флюкс/люкс/flux»</SelectItem>
                  <SelectItem value="any">режим 3: слово где угодно в фразе</SelectItem>
                </SelectContent>
              </Select>
            </Row>
            <p className="text-[11px] text-muted-foreground -mt-2">
              «флюкс как дела» → режим 2 и 3 отвечают; «как дела» → только режим 1.
            </p>

            <Row label="Окно чата (движок)">
              <Select defaultValue="auto">
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">auto (дефолтный → Chrome → Edge → WebView2)</SelectItem>
                  <SelectItem value="default">мой браузер по умолчанию</SelectItem>
                  <SelectItem value="chrome">Google Chrome (app-режим)</SelectItem>
                  <SelectItem value="edge">Microsoft Edge (app-режим)</SelectItem>
                  <SelectItem value="webview">WebView2 (pywebview)</SelectItem>
                  <SelectItem value="web">обычная вкладка</SelectItem>
                </SelectContent>
              </Select>
            </Row>

            <div className="flex items-center justify-between p-3 rounded-lg border border-border bg-card/60">
              <div>
                <Label className="text-xs">Режим раздумий</Label>
                <p className="text-[10px] text-muted-foreground mt-0.5">think-auto решает сам, но можно зафиксировать</p>
              </div>
              <Select value={thinkMode} onValueChange={(v) => setThinkMode(v as typeof thinkMode)}>
                <SelectTrigger className="w-[130px] h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="off">off</SelectItem>
                  <SelectItem value="brief">brief</SelectItem>
                  <SelectItem value="medium">medium</SelectItem>
                  <SelectItem value="deep">deep</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border border-border bg-card/60">
              <div>
                <Label className="text-xs">Поисковый движок</Label>
                <p className="text-[10px] text-muted-foreground mt-0.5">Используется для авто-поиска свежих данных</p>
              </div>
              <Select value={searchEngine} onValueChange={setSearchEngine}>
                <SelectTrigger className="w-[140px] h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="duckduckgo">DuckDuckGo</SelectItem>
                  <SelectItem value="searxng">SearXNG</SelectItem>
                  <SelectItem value="bing">Bing</SelectItem>
                  <SelectItem value="google">Google</SelectItem>
                  <SelectItem value="wikipedia">Wikipedia</SelectItem>
                  <SelectItem value="brave">Brave</SelectItem>
                  <SelectItem value="off">Без поиска</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <a
              href="https://github.com/flux/flux-ai-main"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-xs text-cyan-300 hover:underline"
            >
              <ExternalLink size={12} />
              Полная документация на GitHub
            </a>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3">
      <Label className="text-xs text-muted-foreground w-[160px] shrink-0">{label}</Label>
      <div className="flex-1 min-w-0">{children}</div>
    </div>
  );
}
