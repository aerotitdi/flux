"use client";

import { useEffect, useState } from "react";
import { useFlux, type Note, type Todo, type Fact, type KV, type Timer } from "./store";
import { CosmicCanvas } from "./cosmic-canvas";
import {
  NotebookPen, Search, Plus, Trash2, Check, X, Brain, Clock, Lightbulb, Key, StickyNote,
  ListTodo, Tag, Calendar, Zap, Activity,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { StaggerContainer, StaggerItem } from "./motion";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

interface Stats {
  notes: number;
  todos_open: number;
  todos_done: number;
  facts: number;
  kvs: number;
  timers_active: number;
}

export function BrainView() {
  const { brain, setBrain, toggleTodo, setStatusText } = useFlux();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<Stats>({ notes: 0, todos_open: 0, todos_done: 0, facts: 0, kvs: 0, timers_active: 0 });
  const [tab, setTab] = useState("notes");

  // new item inputs
  const [newNote, setNewNote] = useState("");
  const [newNoteTags, setNewNoteTags] = useState("");
  const [newTodo, setNewTodo] = useState("");
  const [newTodoPriority, setNewTodoPriority] = useState<"low" | "medium" | "high">("medium");
  const [newFactKey, setNewFactKey] = useState("");
  const [newFactValue, setNewFactValue] = useState("");
  const [newKvKey, setNewKvKey] = useState("");
  const [newKvValue, setNewKvValue] = useState("");
  const [newTimerLabel, setNewTimerLabel] = useState("");
  const [newTimerSec, setNewTimerSec] = useState("300");

  const reload = async () => {
    try {
      const r = await fetch("/api/memory");
      const d = await r.json();
      if (d.notes && d.todos && d.facts && d.kvs && d.timers) {
        setBrain({ notes: d.notes, todos: d.todos, facts: d.facts, kvs: d.kvs, timers: d.timers });
        setStats(d.stats);
      }
    } catch { /* noop */ }
    finally { setLoading(false); }
  };

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      try {
        const r = await fetch("/api/memory");
        const d = await r.json();
        if (active && d.notes) {
          setBrain({ notes: d.notes, todos: d.todos, facts: d.facts, kvs: d.kvs, timers: d.timers });
          setStats(d.stats);
        }
      } catch { /* noop */ }
      finally { if (active) setLoading(false); }
    })();
    return () => { active = false; };
  }, [setBrain]);

  const add = async (collection: string, payload: Record<string, unknown>) => {
    try {
      await fetch("/api/memory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "add", collection, payload }),
      });
    } catch { /* noop */ }
    setStatusText(`mem_${collection}_add → сохранено`);
    await reload();
  };

  const del = async (collection: string, id: string) => {
    try {
      await fetch("/api/memory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "delete", collection, id }),
      });
    } catch { /* noop */ }
    setStatusText(`mem_${collection} → удалено`);
    await reload();
  };

  const completeTodo = async (id: string) => {
    toggleTodo(id);
    try {
      await fetch("/api/memory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "complete_todo", id }),
      });
    } catch { /* noop */ }
  };

  const fmtTime = (ts: number) => new Date(ts).toLocaleString("ru-RU", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
  const fmtCountdown = (fireAt: number) => {
    const ms = fireAt - Date.now();
    if (ms <= 0) return "сработал";
    const m = Math.floor(ms / 60000);
    const s = Math.floor((ms % 60000) / 1000);
    return `${m}м ${s}с`;
  };

  return (
    <div className="relative flex-1 flex flex-col overflow-hidden">
      <div className="absolute inset-0 opacity-25 pointer-events-none">
        <CosmicCanvas scene="galaxy" agentState="idle" className="w-full h-full" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background pointer-events-none" />

      <div className="relative z-10 flex flex-col h-full">
        {/* toolbar */}
        <div className="px-3 sm:px-5 py-3 border-b border-border bg-card/50 backdrop-blur-md flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 mr-2">
            <NotebookPen size={18} className="text-emerald-400" />
            <h2 className="font-bold text-base sm:text-lg text-shimmer">Память / Заметки / TODO</h2>
          </div>
          <Badge variant="outline" className="text-[10px] font-mono">{stats.notes} заметок</Badge>
          <Badge variant="outline" className="text-[10px] font-mono">{stats.todos_open}/{stats.todos_open + stats.todos_done} TODO</Badge>
          <Badge variant="outline" className="text-[10px] font-mono">{stats.facts} фактов</Badge>
          <Badge variant="outline" className="text-[10px] font-mono">{stats.kvs} KV</Badge>
          <Badge variant="outline" className="text-[10px] font-mono">{stats.timers_active} таймеров</Badge>
          <div className="flex-1" />
          <Button variant="ghost" size="sm" onClick={reload} className="h-8 text-xs text-muted-foreground hover:text-foreground">
            <Activity size={12} className="mr-1" />
            Обновить
          </Button>
        </div>

        <Tabs value={tab} onValueChange={setTab} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="px-3 pt-2 bg-transparent justify-start gap-1 border-b border-border rounded-none">
            <TabsTrigger value="notes" className="text-xs gap-1.5 data-[state=active]:bg-accent">
              <StickyNote size={12} /> Заметки
            </TabsTrigger>
            <TabsTrigger value="todos" className="text-xs gap-1.5 data-[state=active]:bg-accent">
              <ListTodo size={12} /> TODO
            </TabsTrigger>
            <TabsTrigger value="facts" className="text-xs gap-1.5 data-[state=active]:bg-accent">
              <Lightbulb size={12} /> Факты
            </TabsTrigger>
            <TabsTrigger value="kvs" className="text-xs gap-1.5 data-[state=active]:bg-accent">
              <Key size={12} /> KV
            </TabsTrigger>
            <TabsTrigger value="timers" className="text-xs gap-1.5 data-[state=active]:bg-accent">
              <Clock size={12} /> Таймеры
            </TabsTrigger>
          </TabsList>

          <TabsContent value="notes" className="flex-1 overflow-hidden m-0 data-[state=inactive]:hidden">
            <ScrollArea className="h-full">
              <div className="p-3 sm:p-5 max-w-4xl mx-auto space-y-3">
                {/* add form */}
                <div className="p-3 rounded-lg glass-panel border-gradient-cosmic flex flex-wrap gap-2 items-end">
                  <div className="flex-1 min-w-[180px]">
                    <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Новая заметка</label>
                    <Input
                      value={newNote}
                      onChange={(e) => setNewNote(e.target.value)}
                      placeholder="Текст заметки…"
                      className="h-8 text-xs mt-1"
                    />
                  </div>
                  <div className="w-[160px]">
                    <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Теги (через запятую)</label>
                    <Input
                      value={newNoteTags}
                      onChange={(e) => setNewNoteTags(e.target.value)}
                      placeholder="game, flux"
                      className="h-8 text-xs mt-1 font-mono"
                    />
                  </div>
                  <Button
                    size="sm"
                    className="h-8 text-xs gap-1 bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/30"
                    disabled={!newNote.trim()}
                    onClick={() => {
                      add("notes", { text: newNote, tags: newNoteTags.split(",").map((s) => s.trim()).filter(Boolean) });
                      setNewNote("");
                      setNewNoteTags("");
                    }}
                  >
                    <Plus size={12} /> Добавить
                  </Button>
                </div>
                {/* notes list */}
                <StaggerContainer className="space-y-2">
                  {brain.notes.map((n: Note) => (
                    <StaggerItem key={n.id}>
                    <div className="group p-3 rounded-lg glass-panel flex items-start gap-3">
                      <StickyNote size={14} className="text-amber-400 mt-0.5 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm">{n.text}</p>
                        <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                          <span className="text-[10px] text-muted-foreground font-mono">{fmtTime(n.ts)}</span>
                          {n.tags?.map((t) => (
                            <span key={t} className="text-[9px] px-1.5 py-0.5 rounded bg-muted/60 font-mono">#{t}</span>
                          ))}
                        </div>
                      </div>
                      <button
                        onClick={() => del("notes", n.id)}
                        className="opacity-0 group-hover:opacity-100 transition text-red-300 hover:text-red-200"
                        aria-label="Удалить"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                    </StaggerItem>
                  ))}
                  {brain.notes.length === 0 && !loading && (
                    <p className="text-xs text-muted-foreground text-center py-8">Нет заметок</p>
                  )}
                </StaggerContainer>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="todos" className="flex-1 overflow-hidden m-0 data-[state=inactive]:hidden">
            <ScrollArea className="h-full">
              <div className="p-3 sm:p-5 max-w-4xl mx-auto space-y-3">
                <div className="p-3 rounded-lg glass-panel border-gradient-cosmic flex flex-wrap gap-2 items-end">
                  <div className="flex-1 min-w-[180px]">
                    <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Новая задача</label>
                    <Input
                      value={newTodo}
                      onChange={(e) => setNewTodo(e.target.value)}
                      placeholder="Что нужно сделать…"
                      className="h-8 text-xs mt-1"
                    />
                  </div>
                  <div className="w-[140px]">
                    <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Приоритет</label>
                    <Select value={newTodoPriority} onValueChange={(v) => setNewTodoPriority(v as "low" | "medium" | "high")}>
                      <SelectTrigger className="h-8 text-xs mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low" className="text-xs">low</SelectItem>
                        <SelectItem value="medium" className="text-xs">medium</SelectItem>
                        <SelectItem value="high" className="text-xs">high</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button
                    size="sm"
                    className="h-8 text-xs gap-1 bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/30"
                    disabled={!newTodo.trim()}
                    onClick={() => { add("todos", { text: newTodo, priority: newTodoPriority }); setNewTodo(""); }}
                  >
                    <Plus size={12} /> Добавить
                  </Button>
                </div>
                <StaggerContainer className="space-y-2">
                  {brain.todos.map((t: Todo) => (
                    <StaggerItem key={t.id}>
                    <div
                      className={cn(
                        "group p-3 rounded-lg glass-panel flex items-start gap-3",
                        t.done && "opacity-50"
                      )}
                    >
                      <button
                        onClick={() => completeTodo(t.id)}
                        className={cn(
                          "w-5 h-5 rounded-md border flex items-center justify-center shrink-0 mt-0.5 transition",
                          t.done ? "bg-emerald-500/30 border-emerald-400/60" : "border-border hover:border-emerald-400/60"
                        )}
                        aria-label={t.done ? "Снять отметку" : "Отметить выполненным"}
                      >
                        {t.done && <Check size={12} className="text-emerald-300" />}
                      </button>
                      <div className="flex-1 min-w-0">
                        <p className={cn("text-sm", t.done && "line-through")}>{t.text}</p>
                        <div className="flex items-center gap-2 mt-1.5">
                          <span className="text-[10px] text-muted-foreground font-mono">{fmtTime(t.ts)}</span>
                          <Badge
                            variant="outline"
                            className={cn(
                              "text-[9px] py-0 px-1.5 font-mono",
                              t.priority === "high" && "border-red-500/40 text-red-300",
                              t.priority === "medium" && "border-amber-500/40 text-amber-300",
                              t.priority === "low" && "border-zinc-500/40 text-zinc-300"
                            )}
                          >
                            {t.priority}
                          </Badge>
                        </div>
                      </div>
                      <button
                        onClick={() => del("todos", t.id)}
                        className="opacity-0 group-hover:opacity-100 transition text-red-300 hover:text-red-200"
                        aria-label="Удалить"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                    </StaggerItem>
                  ))}
                  {brain.todos.length === 0 && !loading && (
                    <p className="text-xs text-muted-foreground text-center py-8">Нет задач</p>
                  )}
                </StaggerContainer>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="facts" className="flex-1 overflow-hidden m-0 data-[state=inactive]:hidden">
            <ScrollArea className="h-full">
              <div className="p-3 sm:p-5 max-w-4xl mx-auto space-y-3">
                <div className="p-3 rounded-lg glass-panel border-gradient-cosmic flex flex-wrap gap-2 items-end">
                  <div className="flex-1 min-w-[120px]">
                    <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Ключ</label>
                    <Input value={newFactKey} onChange={(e) => setNewFactKey(e.target.value)} placeholder="user_name" className="h-8 text-xs mt-1 font-mono" />
                  </div>
                  <div className="flex-1 min-w-[120px]">
                    <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Значение</label>
                    <Input value={newFactValue} onChange={(e) => setNewFactValue(e.target.value)} placeholder="Алексей" className="h-8 text-xs mt-1" />
                  </div>
                  <Button
                    size="sm"
                    className="h-8 text-xs gap-1 bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/30"
                    disabled={!newFactKey.trim() || !newFactValue.trim()}
                    onClick={() => { add("facts", { key: newFactKey, value: newFactValue }); setNewFactKey(""); setNewFactValue(""); }}
                  >
                    <Plus size={12} /> Запомнить
                  </Button>
                </div>
                <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {brain.facts.map((f: Fact) => (
                    <StaggerItem key={f.key}>
                    <div className="group p-3 rounded-lg glass-panel flex items-start gap-3">
                      <Lightbulb size={14} className="text-amber-400 mt-0.5 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <code className="text-[11px] font-mono text-cyan-300">{f.key}</code>
                        <p className="text-sm mt-0.5 truncate">{f.value}</p>
                        <span className="text-[10px] text-muted-foreground font-mono">{fmtTime(f.ts)}</span>
                      </div>
                      <button onClick={() => del("facts", f.key)} className="opacity-0 group-hover:opacity-100 transition text-red-300 hover:text-red-200">
                        <Trash2 size={13} />
                      </button>
                    </div>
                    </StaggerItem>
                  ))}
                </StaggerContainer>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="kvs" className="flex-1 overflow-hidden m-0 data-[state=inactive]:hidden">
            <ScrollArea className="h-full">
              <div className="p-3 sm:p-5 max-w-4xl mx-auto space-y-3">
                <div className="p-3 rounded-lg glass-panel border-gradient-cosmic flex flex-wrap gap-2 items-end">
                  <div className="flex-1 min-w-[120px]">
                    <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Key</label>
                    <Input value={newKvKey} onChange={(e) => setNewKvKey(e.target.value)} placeholder="cdp_port" className="h-8 text-xs mt-1 font-mono" />
                  </div>
                  <div className="flex-1 min-w-[120px]">
                    <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Value</label>
                    <Input value={newKvValue} onChange={(e) => setNewKvValue(e.target.value)} placeholder="9222" className="h-8 text-xs mt-1 font-mono" />
                  </div>
                  <Button
                    size="sm"
                    className="h-8 text-xs gap-1 bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/30"
                    disabled={!newKvKey.trim() || !newKvValue.trim()}
                    onClick={() => { add("kvs", { key: newKvKey, value: newKvValue }); setNewKvKey(""); setNewKvValue(""); }}
                  >
                    <Plus size={12} /> Записать
                  </Button>
                </div>
                <StaggerContainer className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {brain.kvs.map((kv: KV) => (
                    <StaggerItem key={kv.key}>
                    <div className="group p-3 rounded-lg glass-panel flex items-start gap-3">
                      <Key size={14} className="text-purple-400 mt-0.5 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <code className="text-[11px] font-mono text-purple-300">{kv.key}</code>
                        <p className="text-sm mt-0.5 font-mono truncate">{kv.value}</p>
                        <span className="text-[10px] text-muted-foreground font-mono">{fmtTime(kv.ts)}</span>
                      </div>
                      <button onClick={() => del("kvs", kv.key)} className="opacity-0 group-hover:opacity-100 transition text-red-300 hover:text-red-200">
                        <Trash2 size={13} />
                      </button>
                    </div>
                    </StaggerItem>
                  ))}
                </StaggerContainer>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="timers" className="flex-1 overflow-hidden m-0 data-[state=inactive]:hidden">
            <ScrollArea className="h-full">
              <div className="p-3 sm:p-5 max-w-4xl mx-auto space-y-3">
                <div className="p-3 rounded-lg glass-panel border-gradient-cosmic flex flex-wrap gap-2 items-end">
                  <div className="flex-1 min-w-[160px]">
                    <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Название таймера</label>
                    <Input value={newTimerLabel} onChange={(e) => setNewTimerLabel(e.target.value)} placeholder="Через 10 мин проверить" className="h-8 text-xs mt-1" />
                  </div>
                  <div className="w-[120px]">
                    <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Секунд</label>
                    <Input value={newTimerSec} onChange={(e) => setNewTimerSec(e.target.value)} type="number" className="h-8 text-xs mt-1 font-mono" />
                  </div>
                  <Button
                    size="sm"
                    className="h-8 text-xs gap-1 bg-amber-500/20 border border-amber-400/40 text-amber-200 hover:bg-amber-500/30"
                    disabled={!newTimerLabel.trim()}
                    onClick={() => { add("timers", { label: newTimerLabel, seconds: parseInt(newTimerSec) || 60 }); setNewTimerLabel(""); setNewTimerSec("300"); }}
                  >
                    <Plus size={12} /> Поставить
                  </Button>
                </div>
                <StaggerContainer className="space-y-2">
                  {brain.timers.map((tm: Timer) => {
                    const ms = tm.fireAt - Date.now();
                    const fired = ms <= 0;
                    return (
                      <StaggerItem key={tm.id}>
                      <div className={cn("group p-3 rounded-lg glass-panel flex items-start gap-3", fired && "opacity-50")}>
                        <Clock size={14} className={cn("mt-0.5 shrink-0", fired ? "text-red-400" : "text-amber-400")} />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm">{tm.label}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-[10px] text-muted-foreground font-mono">
                              {fired ? "сработал" : `через ${fmtCountdown(tm.fireAt)}`}
                            </span>
                            <span className="text-[10px] text-muted-foreground font-mono">→ {fmtTime(tm.fireAt)}</span>
                          </div>
                        </div>
                        <button onClick={() => del("timers", tm.id)} className="opacity-0 group-hover:opacity-100 transition text-red-300 hover:text-red-200">
                          <Trash2 size={13} />
                        </button>
                      </div>
                      </StaggerItem>
                    );
                  })}
                  {brain.timers.length === 0 && !loading && (
                    <p className="text-xs text-muted-foreground text-center py-8">Нет активных таймеров</p>
                  )}
                </StaggerContainer>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>

        {/* footer */}
        <div className="px-3 sm:px-5 py-2 border-t border-border bg-card/60 backdrop-blur-md flex flex-wrap items-center gap-2 text-[11px] font-mono text-muted-foreground">
          <span className="flex items-center gap-1">
            <Brain size={12} className="text-emerald-400" />
            mem_remember / mem_recall / mem_todo_add / mem_kv_set / mem_timer_set
          </span>
          <span className="opacity-30">·</span>
          <span>agent может сохранять и вспоминать факты о пользователе</span>
        </div>
      </div>
    </div>
  );
}
