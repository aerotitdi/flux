# Windows Automation — управление приложениями Windows из FLUX 2.0

Новая возможность FLUX: агент управляет не только вкладками Chrome, но и **оконными
приложениями Windows 10/11** — открывает программы, кликает по кнопкам и меню, вводит
текст, читает содержимое элементов, делает скриншоты окон. Всё через **UI Automation**
(pywinauto, backend `uia`) — без координат мыши, без pyautogui, без прав администратора.

```
Браузерный мост (был):   FLUX → WebSocket 8642 → extension (chrome.debugger) → вкладки Chrome
Windows-мост (новый):    FLUX → WebSocket 8643 → windows_bridge/win_bridge.py → pywinauto/UIA → приложения
```

Протокол идентичен браузерному мосту:

```jsonc
// FLUX -> win_bridge.py
{ "type": "req", "id": 1, "cmd": "click", "app": "Блокнот",
  "control": { "title": "Сохранить", "control_type": "Button" } }

// win_bridge.py -> FLUX
{ "type": "resp", "id": 1, "result": { "ok": true, "clicked": {...} }, "error": null }
```

Keepalive — ping/pong каждые 20 с; при падении сервера FLUX переподключается сам каждые 3 с.

---

## 1. Установка

Требуется Python 3.10+ (тот же, в котором работает FLUX, или любой другой — мост автономен).

```bat
cd windows_bridge
pip install websockets pywinauto mss pillow
```

или разом:

```bat
pip install -r windows_bridge\requirements.txt
```

> `psutil` (необязательно) — точнее определяет имена процессов в команде `apps`.

## 2. Запуск

```bat
python windows_bridge\win_bridge.py
```

или двойной клик по `windows_bridge\start_win_bridge.bat` (сам поставит зависимости и запустит).

Успешный старт:

```
[win_bridge] ws://127.0.0.1:8643/win-bridge  (Ctrl+C — стоп)
```

Лог пишется в `windows_bridge\win_bridge.log` (ротация 1 МБ × 3).

Параметры: `--host` (по умолчанию 127.0.0.1 — **только локально**, не выставляйте в сеть),
`--port` (8643), `--verbose`, `--mock` (симуляция окон для тестов протокола на любой ОС,
включая Linux/macOS — pywinauto не нужен).

Дальше просто запустите FLUX как обычно (`python main.py`). Клиент моста поднимется сам;
зелёная точка `●` в шапке UI (рядом с точкой CDP) и вкладка **⚙ → Windows Automation**
покажут статус, список приложений и лог последних команд.

### Автозапуск (по желанию)

```bat
schtasks /create /tn "FLUX WinBridge" /tr "python C:\путь\к\flux\windows_bridge\win_bridge.py" /sc onlogon
```

или ярлык `start_win_bridge.bat` в `shell:startup`.

## 3. Где видеть Windows Automation (меню UI — эталон, не меняется)

UI FLUX (`ui/index.html`) принят из файла пользователя без правок, поэтому вкладок в
настройках нет — вся функциональность живёт там, где её не нужно рисовать:

- **агент**: тулзы `windows_status/apps/list/children/activate/launch/close/click/type/
  send_keys/read/wait/screenshot/eval` — скажи «покажи запущенные приложения» или
  «открой блокнот и напечатай привет»;
- **API**: `GET /api/win/status` (точка жизни моста), `GET /api/win/apps`,
  `GET /api/win/log` (журнал команд), `POST /api/win/reconnect`, `POST /api/win/cmd`
  (безопасный поднабор);
- **индикатор**: сервер сам держит соединение и переподключается каждые 3 с; статус
  виден в `windows_status` и `/api/win/status`.

## 4. Команды моста (WebSocket-протокол)

| cmd | Параметры | Что делает |
|---|---|---|
| `status` | — | состояние сервера: backend, версии pywinauto/Python/ОС |
| `apps` | — | окна верхнего уровня: `title`, `process`, `pid`, `hwnd` |
| `windows` | — | то же + `rect {left,top,width,height}`, `visible`, `enabled` |
| `activate` | `app` | вывести окно на передний план (разворачивает, если свёрнуто) |
| `launch` | `path` | запустить приложение (`notepad.exe`, путь, команда) → `pid`, `title` |
| `close` | `app` | закрыть окно (WM_CLOSE) |
| `children` | `app`, `control?`, `limit?` | дочерние UI-элементы: `title`, `control_type`, `auto_id`, `class_name`, `rect` |
| `click` | `app`, `control`, `button?`, `double?`, `method?`, `timeout?`(мс) | клик через UIA; `method`: `input` (реальная мышь) / `invoke` (UIA-паттерн, без курсора) |
| `type` | `app`, `control?`, `text`, `replace?`, `timeout?` | ввод текста (unicode); `replace=true` — через ValuePattern.SetValue |
| `send_keys` | `app`, `keys`, `control?` | клавиши в синтаксисе pywinauto: `^s`, `{ENTER}`, `%{F4}` |
| `screenshot` | `app?`, `control?`, `monitor?` | снимок окна/элемента/монитора → `{ok, dataBase64, width, height}` (PNG) |
| `wait` | `app`, `control?`, `timeout`(мс, ≤120000) | ждать появления элемента → `{ok, waited_ms, control}` |
| `read` | `app`, `control?`, `timeout?` | текст/значение элемента (`text`, `value`, `texts`) |
| `eval` | `app?`, `code`, `timeout?` | Python-код в контексте окна (см. ниже) |

`app` — часть заголовка окна («Блокнот»), имя процесса («notepad») или `hwnd` (число).
`control` — критерии поиска UIA-элемента: `title` (подстрока), `title_re`, `auto_id`,
`control_type`, `class_name`, `found_index`, `depth`.

Каждый поиск элемента ограничен таймаутом (`timeout`, по умолчанию 10 с) — pywinauto
никогда не висит вечно. Ошибки возвращаются в поле `error` (формат браузерного моста).

### Примеры JSON-команд

```jsonc
{ "type":"req", "id":"1", "cmd":"apps" }
// → { "type":"resp", "id":"1", "result": { "ok":true, "count":3,
//     "apps":[{"title":"Безымянный — Блокнот","process":"notepad.exe","pid":4242,"hwnd":657548}] }, "error":null }

{ "type":"req", "id":"2", "cmd":"click", "app":"Блокнот",
  "control": { "title":"Сохранить", "control_type":"Button" } }

{ "type":"req", "id":"3", "cmd":"type", "app":"Блокнот",
  "control": { "auto_id":"15" }, "text":"привет" }

{ "type":"req", "id":"4", "cmd":"screenshot", "app":"Блокнот" }
// → { "type":"resp", "id":"4", "result": { "ok":true, "dataBase64":"iVBORw0...", "width":900, "height":640 }, "error":null }

{ "type":"req", "id":"5", "cmd":"eval", "app":"Блокнот",
  "code":"win.child_window(title='Файл', control_type='MenuItem').click_input()" }

{ "type":"req", "id":"6", "cmd":"wait", "app":"Chrome",
  "control": { "title":"Сохранить" }, "timeout":10000 }
```

### eval для Windows

Аналог `browser_tab_eval` (JS в странице): Python-код выполняется в процессе моста,
в контексте найденного окна. В namespace доступны:

```python
win        # pywinauto-обёртка окна (app) или None, если app не задан
Desktop    # pywinauto.Desktop(backend="uia")
pywinauto  # модуль
keyboard   # pywinauto.keyboard
```

Сервер разбирает код через `ast`: значение **последнего выражения** возвращается в
`result`, вывод `print` — в `stdout`. Примеры:

```jsonc
{ "cmd":"eval", "app":"Блокнот", "code":"win.window_text()" }
{ "cmd":"eval", "app":"Блокнот",
  "code":"[ (c.element_info.control_type, c.window_text()) for c in win.descendants()[:40] ]" }
{ "cmd":"eval",
  "code":"Desktop(backend='uia').windows()" }
```

## 5. MCP-инструменты FLUX (категория `windows`)

Зарегистрированы в `app/tools/winapps.py` через общий реестр FLUX
(`app/tools/registry.py`, JSON-Schema параметров в стиле OpenAI tools — так же, как
браузерные `browser_*`). Агент видит их автоматически (top-k retrieval) + системный
промпт и скилл `skills_bundled/windows-automation.md` объясняют порядок работы.

| Инструмент | Команда моста | Назначение |
|---|---|---|
| `windows_status` | `status` | жив ли мост, backend/версия |
| `windows_apps` | `apps` | список приложений |
| `windows_list` | `windows` | окна с координатами/размерами |
| `windows_children` | `children` | элементы окна (разведка перед кликом) |
| `windows_activate` | `activate` | окно на передний план |
| `windows_launch` | `launch` | запуск приложения |
| `windows_close` | `close` | закрыть окно |
| `windows_click` | `click` | клик по элементу (title/auto_id/control_type) |
| `windows_type` | `type` | ввод текста в поле |
| `windows_send_keys` | `send_keys` | клавиши/хоткеи (`^s`, `{ENTER}`) |
| `windows_read` | `read` | текст/значение элемента |
| `windows_wait` | `wait` | ожидание элемента/диалога |
| `windows_screenshot` | `screenshot` | снимок окна → PNG в `data/shots`, картинкой в чат |
| `windows_eval` | `eval` | Python-код в контексте окна |

Скриншоты сохраняются в `~/.flux2/data/shots/win_*.png` и приходят в чат картинкой —
агент «видит» результат своих действий.

## 6. Проверка на блокноте (чек-лист готовности)

1. Запусти мост: `python windows_bridge\win_bridge.py` → точка `●` в шапке FLUX позеленела.
2. Скажи агенту: **«открой блокнот»** → `windows_launch(path='notepad.exe')`.
3. **«напечатай в блокноте „привет от FLUX"»** → `windows_type(app='Блокнот', auto_id='15', text=...)`.
4. **«покажи скриншот блокнота»** → `windows_screenshot(app='Блокнот')`, картинка в чате.
5. **«нажми Ctrl+S и сохрани как test.txt»** → `windows_send_keys(keys='^s')` →
   `windows_wait(title='Сохранить как')` → `windows_type(title='Имя файла:', text='test.txt')` →
   `windows_send_keys(keys='{ENTER}')`.
6. **«закрой блокнот»** → `windows_close(app='Блокнот')`.

Тот же сценарий вручную, одним скриптом (проверяет протокол без агента):

```bat
python tests\win_bridge_e2e.py
```

На машине без Windows тест прогоняет мост в режиме `--mock` (симуляция окон).

## 7. Решение проблем

| Симптом | Причина / лечение |
|---|---|
| Точка серая, «мост не подключён» | `win_bridge.py` не запущен → запусти; FLUX сам переподключится за ≤3 с |
| `pywinauto не установлен` | `pip install pywinauto` в то окружение, откуда запущен мост |
| Элемент не найден | Смотри реальные title/auto_id через `windows_children` (Win11-блокнот: поле = `auto_id '15'`); у некоторых приложений UIA-имена локализованы |
| Приложение с правами админа не управляется | UIA без elevation не видит elevated-окна — запусти мост «от администратора» только для такого случая |
| Скриншот «окно свёрнуто» | Сначала `windows_activate`; мост сам разворачивает окно при клике/снимке |
| Координаты rect «съехали» на HiDPI | Мост сам включает DPI-awareness; не запускай его из сессии с другим масштабом |
| Порт 8643 занят | `python win_bridge.py --port 8650` + в настройках FLUX `win_bridge_url` (config.json → settings) или env `FLUX_WIN_BRIDGE_URL` |

## 8. Безопасность

- Мост слушает **только 127.0.0.1** — снаружи сети команды недоступны.
- `eval` выполняет произвольный Python — это осознанная возможность агента (как
  `browser_tab_eval` для JS); не запускай мост на чужих машинах и не открывай порт наружу.
- Из UI-вкладки разрешён только безопасный поднабор команд (`activate`, `children`,
  `read`, `wait`, `apps`, `windows`, `status`); клики/ввод/eval — только через агента.
- Права администратора по умолчанию НЕ нужны (UIA работает для обычных приложений).

## 9. Файлы интеграции

```
windows_bridge/win_bridge.py        — WS-сервер 8643 (pywinauto UIA + mss), режимы real/mock
windows_bridge/requirements.txt     — зависимости моста
windows_bridge/start_win_bridge.bat — запуск в один клик
app/winbridge.py                    — клиент моста в FLUX (реконнект 3с, keepalive 20с, лог команд)
app/tools/winapps.py                — 14 тулзов windows_* (категория «windows»)
app/server.py                       — /api/win/status|reconnect|apps|log|cmd
ui/index.html                       — вкладка «Windows Automation» + точка ● в шапке
skills_bundled/windows-automation.md — скилл агента (порядок работы с окнами)
tests/win_bridge_e2e.py             — e2e-тест: mock-мост ↔ клиент ↔ тулзы ↔ API ↔ UI
```
