#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""FLUX Windows Bridge — WebSocket-сервер управления Windows-приложениями.

v1.3.0 — собственный музыкальный плеер (отдельный профиль Edge/Chrome
         в режиме --app), не трогает браузер пользователя.
         Глобальные медиа-клавиши, детект плееров, OCR, координатный ввод.

Протокол (как у браузерного моста):
  клиент -> {"type":"req", "id":1, "cmd":"targets"}
  сервер -> {"type":"resp", "id":1, "result":{...}, "error":null}
  сервер -> {"type":"ping"} каждые 20с, клиент отвечает {"type":"pong"}
  сервер -> {"type":"welcome", ...} сразу при подключении

Команды (кратко):
  status / targets / apps / windows
  activate / close / launch
  children / find / read / wait
  click / click_xy / move / drag / scroll
  type / send_keys / key
  screenshot / ocr
  eval

  МУЗЫКА (собственный плеер моста, не браузер пользователя):
  music_play   {query} | {url}   — включить трек (автоплей, свой профиль)
  music_pause  {}                — пауза/продолжить (глобальная медиа-клавиша)
  music_stop   {}                — ПОЛНОСТЬЮ остановить и убить наш плеер
  music_status {}                — что играет
  media        {key}             — play_pause/next/prev/stop/mute/vol_up/vol_down
  players      {}                — какие плееры установлены/запущены
  open_url     {url}             — открыть схему (spotify:, mailto:) в системе

Запуск:   python win_bridge.py
          python win_bridge.py --mock
Лог:      win_bridge.log рядом со скриптом.
"""
from __future__ import annotations

import argparse
import asyncio
import atexit
import base64
import ctypes
import glob
import io
import json
import logging
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.parse
from ctypes import wintypes
from logging.handlers import RotatingFileHandler

VERSION = "1.3.0"
HOST_DEFAULT = "127.0.0.1"
PORT_DEFAULT = 8643
PATH_DEFAULT = "/win-bridge"
PING_INTERVAL = 20
DEFAULT_TIMEOUT_S = 10.0
MAX_TIMEOUT_S = 120.0

log = logging.getLogger("win_bridge")


class WinError(Exception):
    """Ошибка команды — уходит клиенту в поле error ответа."""


# --------------------------------------------------------------------------- #
#  websockets-совместимость                                                    #
# --------------------------------------------------------------------------- #
try:
    from websockets.asyncio.server import serve          # websockets >= 13
except ImportError:                                       # pragma: no cover
    from websockets.server import serve                   # websockets 12 legacy
from websockets.exceptions import ConnectionClosed       # noqa: E402


def _ws_path(ws) -> str:
    req = getattr(ws, "request", None)
    p = getattr(req, "path", None) if req is not None else None
    return p or getattr(ws, "path", "/") or "/"


# --------------------------------------------------------------------------- #
#  Win32-хелперы                                                               #
# --------------------------------------------------------------------------- #
def _enum_top_windows_win32() -> list:
    if sys.platform != "win32":
        return []
    user32 = ctypes.windll.user32
    dwmapi = ctypes.windll.dwmapi
    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    GWL_STYLE = -16
    GWL_EXSTYLE = -20
    WS_CHILD = 0x40000000
    WS_EX_TOOLWINDOW = 0x00000080
    WS_EX_APPWINDOW = 0x00040000
    DWMWA_CLOAKED = 14

    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.IsWindowVisible.restype = wintypes.BOOL
    user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.GetWindowLongW.restype = wintypes.LONG
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextLengthW.restype = ctypes.c_int
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowTextW.restype = ctypes.c_int
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    user32.GetWindowRect.restype = wintypes.BOOL

    out: list = []

    def cb(hwnd, _):
        try:
            if not user32.IsWindowVisible(hwnd):
                return True
            style = user32.GetWindowLongW(hwnd, GWL_STYLE)
            if style & WS_CHILD:
                return True
            ex = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            if (ex & WS_EX_TOOLWINDOW) and not (ex & WS_EX_APPWINDOW):
                return True
            n = user32.GetWindowTextLengthW(hwnd)
            if n <= 0:
                return True
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            title = buf.value
            if not title.strip():
                return True
            try:
                cloaked = wintypes.DWORD(0)
                dwmapi.DwmGetWindowAttribute(
                    wintypes.HWND(hwnd), DWMWA_CLOAKED,
                    ctypes.byref(cloaked), ctypes.sizeof(cloaked))
                if cloaked.value:
                    return True
            except Exception:
                pass
            pid = wintypes.DWORD(0)
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            r = wintypes.RECT()
            user32.GetWindowRect(hwnd, ctypes.byref(r))
            out.append({
                "hwnd": int(hwnd),
                "title": title,
                "pid": pid.value,
                "rect": {"left": r.left, "top": r.top,
                         "width": r.right - r.left, "height": r.bottom - r.top},
            })
        except Exception:
            pass
        return True

    user32.EnumWindows(WNDENUMPROC(cb), 0)
    return out


def _force_foreground(hwnd: int) -> bool:
    if sys.platform != "win32":
        return False
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.SetForegroundWindow.restype = wintypes.BOOL
    user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.ShowWindow.restype = wintypes.BOOL
    user32.IsIconic.argtypes = [wintypes.HWND]
    user32.IsIconic.restype = wintypes.BOOL
    user32.BringWindowToTop.argtypes = [wintypes.HWND]
    user32.BringWindowToTop.restype = wintypes.BOOL
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
    user32.AttachThreadInput.restype = wintypes.BOOL

    h = wintypes.HWND(hwnd)
    fg = user32.GetForegroundWindow()
    if fg == h:
        return True
    cur_tid = int(kernel32.GetCurrentThreadId())
    fg_tid = int(user32.GetWindowThreadProcessId(fg, None)) if fg else 0
    attached = False
    try:
        if fg_tid and fg_tid != cur_tid:
            attached = bool(user32.AttachThreadInput(cur_tid, fg_tid, True))
        if user32.IsIconic(h):
            user32.ShowWindow(h, 9)
            time.sleep(0.05)
        user32.SetForegroundWindow(h)
        user32.BringWindowToTop(h)
    finally:
        if attached:
            user32.AttachThreadInput(cur_tid, fg_tid, False)
    return int(user32.GetForegroundWindow() or 0) == int(hwnd)


def _psapi_proc_name(pid: int) -> str:
    if pid <= 0:
        return ""
    try:
        import psutil
        return psutil.Process(pid).name()
    except Exception:
        pass
    try:
        k32 = ctypes.windll.kernel32
        k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k32.OpenProcess.restype = wintypes.HANDLE
        k32.CloseHandle.argtypes = [wintypes.HANDLE]
        k32.CloseHandle.restype = wintypes.BOOL
        psapi = ctypes.windll.psapi
        psapi.GetModuleBaseNameW.argtypes = [wintypes.HANDLE, wintypes.HMODULE,
                                             wintypes.LPWSTR, wintypes.DWORD]
        psapi.GetModuleBaseNameW.restype = wintypes.DWORD
        h = k32.OpenProcess(0x0410, False, pid)
        if not h:
            h = k32.OpenProcess(0x1000, False, pid)
        if not h:
            return ""
        try:
            buf = ctypes.create_unicode_buffer(512)
            n = psapi.GetModuleBaseNameW(h, None, buf, 512)
            return buf.value if n else ""
        finally:
            k32.CloseHandle(h)
    except Exception:
        return ""


def _virtual_screen() -> dict:
    if sys.platform != "win32":
        return {"left": 0, "top": 0, "width": 0, "height": 0}
    u = ctypes.windll.user32
    return {
        "left": int(u.GetSystemMetrics(76)),
        "top": int(u.GetSystemMetrics(77)),
        "width": int(u.GetSystemMetrics(78)),
        "height": int(u.GetSystemMetrics(79)),
    }


def _run_eval(code: str, ns: dict):
    import ast
    out = io.StringIO()
    old = sys.stdout
    result = None
    try:
        sys.stdout = out
        tree = ast.parse(code)
        if tree.body and isinstance(tree.body[-1], ast.Expr):
            last = ast.Expression(tree.body.pop().value)
            ast.fix_missing_locations(last)
            exec(compile(tree, "<flux-win-eval>", "exec"), ns)
            result = eval(compile(last, "<flux-win-eval>", "eval"), ns)
        else:
            exec(compile(tree, "<flux-win-eval>", "exec"), ns)
    finally:
        sys.stdout = old
    return result, out.getvalue()


# --------------------------------------------------------------------------- #
#  Медиа: глобальные мультимедийные клавиши + детект плееров                   #
# --------------------------------------------------------------------------- #
_MEDIA_KEYS = {
    "play_pause": 0xB3, "playpause": 0xB3, "play": 0xB3, "pause": 0xB3, "toggle": 0xB3,
    "next": 0xB0, "next_track": 0xB0,
    "prev": 0xB1, "prev_track": 0xB1, "previous": 0xB1,
    "stop": 0xB2,
    "mute": 0xAD,
    "vol_up": 0xAF, "volume_up": 0xAF,
    "vol_down": 0xAE, "volume_down": 0xAE,
}
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002

_KNOWN_PLAYERS = {
    "spotify.exe":      {"name": "Spotify",             "scheme": "spotify:",     "web": "https://open.spotify.com"},
    "music.ui.exe":     {"name": "Медиаплеер Windows",  "scheme": None,           "web": None},
    "wmplayer.exe":     {"name": "Windows Media Player", "scheme": None,          "web": None},
    "vlc.exe":          {"name": "VLC",                 "scheme": None,           "web": None},
    "aimp.exe":         {"name": "AIMP",                "scheme": None,           "web": None},
    "foobar2000.exe":   {"name": "foobar2000",          "scheme": None,           "web": None},
    "musicbee.exe":     {"name": "MusicBee",            "scheme": None,           "web": None},
    "yandexmusic.exe":  {"name": "Яндекс.Музыка",       "scheme": "yandexmusic:", "web": "https://music.yandex.ru"},
    "yandex_music.exe": {"name": "Яндекс.Музыка",       "scheme": "yandexmusic:", "web": "https://music.yandex.ru"},
    "itunes.exe":       {"name": "iTunes",              "scheme": "itmss:",       "web": None},
    "applemusic.exe":   {"name": "Apple Music",         "scheme": "music:",       "web": None},
    "deezer.exe":       {"name": "Deezer",              "scheme": None,           "web": "https://www.deezer.com"},
    "tidal.exe":        {"name": "TIDAL",               "scheme": None,           "web": "https://tidal.com"},
    "zunemusic.exe":    {"name": "Groove Music",        "scheme": None,           "web": None},
    "groove.exe":       {"name": "Groove Music",        "scheme": None,           "web": None},
}


def _send_media_key(vk: int) -> bool:
    if sys.platform != "win32":
        return False
    u = ctypes.windll.user32
    u.keybd_event.argtypes = [wintypes.BYTE, wintypes.BYTE, wintypes.DWORD, ctypes.c_void_p]
    u.keybd_event.restype = None
    u.keybd_event(vk, 0, KEYEVENTF_EXTENDEDKEY, 0)
    u.keybd_event(vk, 0, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0)
    return True


def _scan_installed_players() -> list:
    if sys.platform != "win32":
        return []
    found = {}
    try:
        import winreg
        roots = [
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
            (winreg.HKEY_CURRENT_USER,  r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        ]
        for hive, path in roots:
            try:
                with winreg.OpenKey(hive, path) as k:
                    i = 0
                    while True:
                        try:
                            sub = winreg.EnumKey(k, i); i += 1
                        except OSError:
                            break
                        try:
                            with winreg.OpenKey(k, sub) as sk:
                                try:
                                    dn, _ = winreg.QueryValueEx(sk, "DisplayName")
                                except OSError:
                                    continue
                                dnl = dn.lower()
                                for key, meta in _KNOWN_PLAYERS.items():
                                    stem = key.rsplit(".", 1)[0].lower()
                                    if meta["name"].lower() in dnl or stem in dnl:
                                        try:
                                            loc, _ = winreg.QueryValueEx(sk, "InstallLocation")
                                        except OSError:
                                            loc = ""
                                        found[meta["name"]] = {
                                            "name": meta["name"], "where": "registry",
                                            "location": loc,
                                            "scheme": meta.get("scheme"),
                                            "web": meta.get("web"),
                                        }
                        except OSError:
                            continue
            except OSError:
                continue
    except Exception:
        pass
    for root in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                 os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                 os.environ.get("LOCALAPPDATA", "")):
        if not root or not os.path.isdir(root):
            continue
        for key, meta in _KNOWN_PLAYERS.items():
            stem = key.rsplit(".", 1)[0]
            for pat in (os.path.join(root, stem),
                        os.path.join(root, meta["name"]),
                        os.path.join(root, "*", stem)):
                for hit in glob.glob(pat)[:1]:
                    if meta["name"] not in found:
                        found[meta["name"]] = {
                            "name": meta["name"], "where": "filesystem",
                            "location": hit,
                            "scheme": meta.get("scheme"),
                            "web": meta.get("web"),
                        }
    return list(found.values())


# --------------------------------------------------------------------------- #
#  Собственный музыкальный плеер: изолированный Edge/Chrome в режиме --app      #
# --------------------------------------------------------------------------- #
_BROWSER_CANDIDATES = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expanduser(r"~\AppData\Local\Google\Chrome\Application\chrome.exe"),
    os.path.expanduser(r"~\AppData\Local\Microsoft\Edge\Application\msedge.exe"),
]


def _find_browser_exe():
    for p in _BROWSER_CANDIDATES:
        if os.path.isfile(p):
            return p
    for name in ("msedge.exe", "chrome.exe"):
        hit = shutil.which(name)
        if hit:
            return hit
    return None


def _is_media_url(url: str) -> bool:
    u = (url or "").lower()
    return ("youtube.com" in u or "youtu.be" in u or "music.yandex" in u
            or "soundcloud.com" in u or "vimeo.com" in u or "spotify.com" in u)


def _build_autoplay_url(url: str) -> str:
    if not url:
        return url
    if "youtube.com" in url or "youtu.be" in url:
        if "autoplay=" not in url:
            return url + ("&" if "?" in url else "?") + "autoplay=1"
    return url


def _ytdlp_first_id(query: str) -> str:
    """Первый videoID по запросу через yt-dlp (или '' если yt-dlp нет)."""
    q = query.strip()
    if not q:
        return ""
    cmd = None
    exe = shutil.which("yt-dlp") or shutil.which("yt-dlp.exe")
    if exe:
        cmd = [exe]
    else:
        # попробовать как python-модуль (pip install yt-dlp)
        try:
            import yt_dlp  # noqa: F401
            cmd = [sys.executable, "-m", "yt_dlp"]
        except ImportError:
            cmd = None
    if not cmd:
        return ""
    try:
        r = subprocess.run(
            cmd + [f"ytsearch1:{q}", "--print", "id",
                   "--no-warnings", "--quiet", "--skip-download"],
            capture_output=True, text=True, timeout=15,
        )
        out = (r.stdout or "").strip().splitlines()
        vid = out[-1].strip() if out else ""
        return vid if len(vid) >= 6 else ""
    except Exception as e:
        log.debug("yt-dlp resolve failed: %s", e)
        return ""


def _resolve_query_to_url(query: str) -> str:
    q = (query or "").strip()
    if not q:
        return ""
    if q.startswith(("http://", "https://", "spotify:", "yandexmusic:", "music:")):
        return _build_autoplay_url(q)
    vid = _ytdlp_first_id(q)
    if vid:
        return f"https://www.youtube.com/watch?v={vid}&autoplay=1"
    # fallback: поиск на YouTube Music (пользователь сам нажмёт play — но в СВОЁМ окне моста)
    return "https://music.youtube.com/search?q=" + urllib.parse.quote(q)


# --------------------------------------------------------------------------- #
#  OCR                                                                         #
# --------------------------------------------------------------------------- #
def _ocr_try_winocr(png_bytes: bytes, lang: str):
    try:
        import winocr
    except ImportError:
        return None
    try:
        from PIL import Image
    except ImportError:
        return None
    img = Image.open(io.BytesIO(png_bytes))
    try:
        res = asyncio.run(winocr.recognize_pil(img, lang))
    except Exception as e:
        log.warning("winocr.recognize_pil упал: %s", e)
        return None
    words = []
    for line in (res.get("lines") or []):
        ltext = line.get("text", "")
        for w in (line.get("words") or []):
            r = w.get("bounding_rect") or {}
            words.append({
                "text": w.get("text", ""),
                "x": int(r.get("x", r.get("left", 0))),
                "y": int(r.get("y", r.get("top", 0))),
                "w": int(r.get("width", 0)),
                "h": int(r.get("height", 0)),
                "line": ltext,
            })
    return {"engine": "winocr", "words": words}


def _ocr_try_pytesseract(png_bytes: bytes, lang: str):
    try:
        import pytesseract
        from PIL import Image
    except ImportError:
        return None
    try:
        img = Image.open(io.BytesIO(png_bytes))
        data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT, lang=lang)
    except Exception as e:
        log.warning("pytesseract упал: %s", e)
        return None
    words = []
    for i in range(len(data.get("text", []))):
        t = (data["text"][i] or "").strip()
        if not t:
            continue
        words.append({
            "text": t,
            "x": int(data["left"][i]),
            "y": int(data["top"][i]),
            "w": int(data["width"][i]),
            "h": int(data["height"][i]),
            "line": "",
        })
    return {"engine": "pytesseract", "words": words}


# --------------------------------------------------------------------------- #
#  Реальный бэкенд                                                             #
# --------------------------------------------------------------------------- #
class RealBackend:
    name = "uia"
    _WIN_LIST_TTL = 1.5
    _PROC_TTL = 5.0
    _WRAP_TTL = 5.0

    def __init__(self):
        self._pw = None
        self._pw_version = "?"
        self._win_cache = {"t": 0.0, "wins": None}
        self._proc_cache = {"t": 0.0, "map": {}}
        self._wrap_cache: dict = {}
        self._mouse = None
        self._keyboard = None
        # --- музыка ---
        self._music_proc: subprocess.Popen | None = None
        self._music_url: str | None = None
        self._music_profile: str | None = None
        atexit.register(self._music_kill_locked)

    # --- инициализация --------------------------------------------------------
    def _init(self):
        if self._pw is not None:
            return
        if sys.platform != "win32":
            raise WinError("реальный режим только для Windows; для тестов запусти с --mock")
        try:
            import pywinauto
            from pywinauto import Desktop, keyboard, mouse
            from pywinauto.timings import Timings
        except ImportError as e:
            raise WinError(f"pywinauto не установлен: pip install pywinauto ({e})")
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass
        for name, value in (
            ("window_find_timeout", DEFAULT_TIMEOUT_S),
            ("after_click_wait_timeout", 0.3),
            ("after_click_wait", 0.3),
            ("exists_timeout", DEFAULT_TIMEOUT_S),
            ("exists_retry", 0.3),
            ("after_sendkeys_key_wait", 0.05),
            ("after_type_keys_wait", 0.05),
        ):
            try:
                setattr(Timings, name, value)
            except AttributeError:
                log.debug("Timings.%s отсутствует в этой версии pywinauto — пропуск", name)
        self._pw = pywinauto
        self._pw.Desktop = Desktop
        self._pw.keyboard = keyboard
        self._mouse = mouse
        self._keyboard = keyboard
        self._pw_version = getattr(pywinauto, "__version__", "?")

    # --- список окон ----------------------------------------------------------
    def _proc_name(self, pid: int) -> str:
        now = time.time()
        c = self._proc_cache
        if now - c["t"] > self._PROC_TTL:
            c["map"] = {}
            c["t"] = now
        if pid in c["map"]:
            return c["map"][pid]
        name = _psapi_proc_name(pid)
        c["map"][pid] = name
        return name

    def _top_windows(self) -> list:
        self._init()
        now = time.time()
        c = self._win_cache
        if c["wins"] is not None and now - c["t"] < self._WIN_LIST_TTL:
            return c["wins"]
        raw = _enum_top_windows_win32()
        for w in raw:
            w["process"] = self._proc_name(w["pid"])
        c["wins"] = raw
        c["t"] = now
        return raw

    def _invalidate(self):
        self._win_cache["wins"] = None

    # --- pywinauto-обёртка ----------------------------------------------------
    def _wrap_window(self, hwnd: int):
        now = time.time()
        cached = self._wrap_cache.get(hwnd)
        if cached and now - cached[0] < self._WRAP_TTL:
            return cached[1]
        self._init()
        try:
            from pywinauto.uia_element_info import UIAElementInfo
            from pywinauto.controls.uiawrapper import UIAWrapper
            w = UIAWrapper(UIAElementInfo(hwnd))
        except Exception as e:
            raise WinError(f"не удалось обернуть окно hwnd={hwnd}: {e}")
        self._wrap_cache[hwnd] = (now, w)
        return w

    # --- резолвер окна --------------------------------------------------------
    @staticmethod
    def _resolve_target(d: dict):
        """'id' в протоколе — request id, а НЕ окно.
        Берём его как окно только если он похож на hwnd (число >65535 или str 6+ цифр).
        """
        for key in ("hwnd", "tabId", "target", "windowId", "wid", "window", "app"):
            v = d.get(key)
            if v not in (None, ""):
                return v
        v = d.get("id")
        if v in (None, ""):
            return None
        try:
            n = int(v)
            if n > 65535:
                return v
        except (ValueError, TypeError):
            s = str(v)
            if s.isdigit() and len(s) >= 6:
                return v
        return None

    def _find_app(self, app) -> dict:
        if app is None or app == "":
            raise WinError("не указано окно: используй id (hwnd) из cmd=targets/apps "
                           "или app (заголовок/процесс)")
        wins = self._top_windows()
        if not wins:
            raise WinError("видимых окон верхнего уровня не найдено")
        try:
            h = int(app)
            for w in wins:
                if w["hwnd"] == h:
                    return w
        except (ValueError, TypeError):
            pass
        s = str(app).strip()
        low = s.lower()
        for w in wins:
            if w["title"].lower() == low:
                return w
        cands = [w for w in wins if low in w["title"].lower()]
        if cands:
            cands.sort(key=lambda w: (len(w["title"]), w["pid"]))
            return cands[0]
        pname = low if low.endswith(".exe") else low + ".exe"
        for w in wins:
            if (w["process"] or "").lower() == pname:
                return w
        cands = [w for w in wins if low in (w["process"] or "").lower()]
        if cands:
            return cands[0]
        hint = "; ".join(f"id={w['hwnd']} «{w['title'][:30]}»" for w in wins[:10])
        raise WinError(f"окно «{s}» не найдено. Видимые (id=hwnd): {hint}")

    def _resolve(self, d: dict):
        info = self._find_app(self._resolve_target(d))
        return info, self._wrap_window(info["hwnd"])

    # --- UIA-элемент ----------------------------------------------------------
    @staticmethod
    def _ctl_query(control: dict) -> dict:
        q = {}
        if not control:
            return q
        for src, dst in (("title", "title"), ("title_re", "title_re"), ("auto_id", "auto_id"),
                         ("automation_id", "auto_id"), ("control_type", "control_type"),
                         ("class_name", "class_name"), ("class_name_re", "class_name_re"),
                         ("best_match", "best_match")):
            if control.get(src):
                q[dst] = control[src]
        if control.get("found_index"):
            q["found_index"] = int(control["found_index"])
        if control.get("depth"):
            q["depth"] = int(control["depth"])
        return q

    def _find_ctl(self, win, control: dict, timeout_s: float):
        q = self._ctl_query(control)
        if not q:
            return win
        spec = win.child_window(**q)
        try:
            return spec.wait("exists visible enabled", timeout=min(timeout_s, MAX_TIMEOUT_S))
        except Exception:
            try:
                return spec.wait("exists", timeout=1)
            except Exception:
                raise WinError(f"элемент не найден за {timeout_s:.0f}с: {q} "
                               f"(cmd=children покажет доступные элементы окна)")

    @staticmethod
    def _ctl_info(el) -> dict:
        try:
            r = el.rectangle()
            rect = {"left": int(r.left), "top": int(r.top),
                    "width": int(r.width()), "height": int(r.height())}
        except Exception:
            rect = None
        ei = getattr(el, "element_info", None)
        return {
            "title": (el.window_text() or "")[:120] if hasattr(el, "window_text") else "",
            "control_type": str(getattr(ei, "control_type", "") or ""),
            "auto_id": str(getattr(ei, "automation_id", "") or ""),
            "class_name": str(getattr(ei, "class_name", "") or ""),
            "rect": rect,
        }

    @staticmethod
    def _esc_keys(text: str) -> str:
        special = set("^%+~{}()[]")
        return "".join("{" + ch + "}" if ch in special else ch for ch in text)

    # --- инфо -----------------------------------------------------------------
    def status(self, d: dict) -> dict:
        self._init()
        import platform
        return {"ok": True, "backend": self.name, "version": VERSION,
                "pywinauto": self._pw_version,
                "python": platform.python_version(), "os": platform.platform(),
                "mock": False, "screen": _virtual_screen()}

    def targets(self, d: dict) -> dict:
        wins = self._top_windows()
        fg = 0
        try:
            fg = int(ctypes.windll.user32.GetForegroundWindow() or 0)
        except Exception:
            pass
        out = [{
            "id": str(w["hwnd"]), "tabId": str(w["hwnd"]), "hwnd": w["hwnd"],
            "title": w["title"], "process": w["process"], "pid": w["pid"],
            "active": w["hwnd"] == fg, "rect": w["rect"], "url": None,
        } for w in wins]
        return {"ok": True, "count": len(out), "targets": out,
                "screen": _virtual_screen()}

    def apps(self, d: dict) -> dict:
        wins = self._top_windows()
        fg = 0
        try:
            fg = int(ctypes.windll.user32.GetForegroundWindow() or 0)
        except Exception:
            pass
        return {"ok": True, "count": len(wins),
                "apps": [{"id": str(w["hwnd"]), "title": w["title"],
                          "process": w["process"], "pid": w["pid"],
                          "hwnd": w["hwnd"], "active": w["hwnd"] == fg,
                          "rect": w["rect"]} for w in wins]}

    def windows(self, d: dict) -> dict:
        wins = self._top_windows()
        fg = 0
        try:
            fg = int(ctypes.windll.user32.GetForegroundWindow() or 0)
        except Exception:
            pass
        out = [{"id": str(w["hwnd"]), "title": w["title"],
                "process": w["process"], "pid": w["pid"], "hwnd": w["hwnd"],
                "rect": w["rect"], "visible": True, "enabled": True,
                "active": w["hwnd"] == fg} for w in wins]
        return {"ok": True, "count": len(out), "windows": out}

    # --- окна -----------------------------------------------------------------
    def activate(self, d: dict) -> dict:
        info = self._find_app(self._resolve_target(d))
        hwnd = info["hwnd"]
        ok = _force_foreground(hwnd)
        if not ok:
            try:
                self._wrap_window(hwnd).set_focus()
            except Exception as e:
                raise WinError(f"не удалось активировать окно: {e}")
        return {"ok": True, "hwnd": hwnd, "id": str(hwnd), "title": info["title"]}

    def close(self, d: dict) -> dict:
        info = self._find_app(self._resolve_target(d))
        hwnd, title = info["hwnd"], info["title"]
        try:
            self._wrap_window(hwnd).close()
        except Exception:
            try:
                ctypes.windll.user32.PostMessageW(wintypes.HWND(hwnd), 0x0010, 0, 0)
            except Exception as e:
                raise WinError(f"не удалось закрыть окно: {e}")
        self._invalidate()
        return {"ok": True, "hwnd": hwnd, "id": str(hwnd), "title": title}

    def launch(self, d: dict) -> dict:
        path = (d.get("path") or "").strip()
        if not path:
            raise WinError("не указан path")
        self._init()
        app = None
        try:
            from pywinauto import Application
            app = Application(backend="uia").start(path)
            pid = app.process
        except Exception:
            try:
                args = shlex.split(path, posix=False)
            except ValueError:
                args = [path]
            proc = subprocess.Popen(args, shell=(len(args) == 1 and not os.path.exists(path)))
            pid = proc.pid
        out = {"ok": True, "pid": pid, "path": path}
        if app is not None:
            try:
                w = app.top_window()
                w.wait("exists", timeout=15)
                out["title"] = w.window_text()
            except Exception:
                pass
        self._invalidate()
        return out

    # --- UIA ------------------------------------------------------------------
    def children(self, d: dict) -> dict:
        info, win = self._resolve(d)
        timeout_s = self._timeout(d)
        root = self._find_ctl(win, d.get("control") or {}, timeout_s)
        limit = min(int(d.get("limit") or 150), 500)
        try:
            els = root.children()
        except Exception as e:
            raise WinError(f"не удалось прочитать дерево элементов: {e}")
        out = [self._ctl_info(el) for el in els[:limit]]
        return {"ok": True, "count": len(out), "total": len(els), "children": out}

    def find(self, d: dict) -> dict:
        info, win = self._resolve(d)
        q = self._ctl_query(d.get("control") or {})
        if not q:
            raise WinError("нужен control с критериями (title/title_re/control_type/auto_id)")
        limit = min(int(d.get("limit") or 50), 500)
        try:
            els = win.descendants(**q)
        except TypeError:
            els = [e for e in win.descendants() if self._matches(e, q)]
        except Exception as e:
            raise WinError(f"descendants не сработал: {e}")
        out = [self._ctl_info(el) for el in els[:limit]]
        return {"ok": True, "count": len(out), "total": len(els), "elements": out}

    @staticmethod
    def _matches(el, q: dict) -> bool:
        try:
            ei = el.element_info
            if q.get("title") and q["title"].lower() not in (el.window_text() or "").lower():
                return False
            if q.get("control_type") and str(getattr(ei, "control_type", "")) != q["control_type"]:
                return False
            if q.get("auto_id") and str(getattr(ei, "automation_id", "")) != q["auto_id"]:
                return False
            return True
        except Exception:
            return False

    def click(self, d: dict) -> dict:
        if not (d.get("control") or {}) and d.get("x") is not None and d.get("y") is not None:
            return self.click_xy(d)
        info, win = self._resolve(d)
        timeout_s = self._timeout(d)
        el = self._find_ctl(win, d.get("control") or {}, timeout_s)
        cinfo = self._ctl_info(el)
        if not (d.get("control") or {}):
            raise WinError("не указан control (title/auto_id/control_type) или x/y")
        method = (d.get("method") or "input").lower()
        button = (d.get("button") or "left").lower()
        double = bool(d.get("double"))
        try:
            if method == "invoke":
                el.invoke()
            else:
                try:
                    if win.is_minimized():
                        _force_foreground(info["hwnd"])
                except Exception:
                    pass
                el.click_input(button=button, double=double)
        except Exception as e:
            try:
                el.invoke()
            except Exception:
                raise WinError(
                    f"клик не удался ({cinfo.get('control_type')} «{cinfo.get('title')}»): {e}")
        return {"ok": True, "clicked": cinfo, "method": method}

    def wait(self, d: dict) -> dict:
        info, win = self._resolve(d)
        timeout_s = self._timeout(d)
        q = self._ctl_query(d.get("control") or {})
        t0 = time.time()
        if not q:
            el = win
        else:
            try:
                el = win.child_window(**q).wait("exists visible",
                                                timeout=min(timeout_s, MAX_TIMEOUT_S))
            except Exception:
                raise WinError(f"таймаут ожидания ({timeout_s:.0f}с): {q}")
        return {"ok": True, "found": True, "waited_ms": int((time.time() - t0) * 1000),
                "control": self._ctl_info(el)}

    def read(self, d: dict) -> dict:
        info, win = self._resolve(d)
        timeout_s = self._timeout(d)
        el = self._find_ctl(win, d.get("control") or {}, timeout_s)
        cinfo = self._ctl_info(el)
        value = None
        try:
            value = el.iface_value.CurrentValue
        except Exception:
            try:
                value = el.get_value()
            except Exception:
                value = None
        if not cinfo["title"] and isinstance(value, str):
            cinfo["title"] = value[:120]
        texts = []
        try:
            texts = [str(t)[:200] for t in (el.texts() or [])][:10]
        except Exception:
            pass
        return {"ok": True, "text": cinfo["title"],
                "value": value if isinstance(value, (str, int, float, bool)) else str(value),
                "texts": texts,
                **{k: cinfo[k] for k in ("control_type", "auto_id", "class_name", "rect")}}

    # --- координатный ввод ----------------------------------------------------
    def click_xy(self, d: dict) -> dict:
        x, y = d.get("x"), d.get("y")
        if x is None or y is None:
            raise WinError("нужны x и y (абсолютные экранные координаты)")
        x, y = int(x), int(y)
        button = (d.get("button") or "left").lower()
        double = bool(d.get("double"))
        self._init()
        try:
            if double:
                self._mouse.double_click(button=button, coords=(x, y))
            else:
                self._mouse.click(button=button, coords=(x, y))
        except Exception as e:
            raise WinError(f"клик по координатам ({x},{y}) не удался: {e}")
        return {"ok": True, "x": x, "y": y, "button": button, "double": double}

    def move(self, d: dict) -> dict:
        x, y = d.get("x"), d.get("y")
        if x is None or y is None:
            raise WinError("нужны x и y")
        x, y = int(x), int(y)
        self._init()
        try:
            self._mouse.move(coords=(x, y))
        except Exception as e:
            raise WinError(f"move ({x},{y}) не удался: {e}")
        return {"ok": True, "x": x, "y": y}

    def drag(self, d: dict) -> dict:
        for k in ("x1", "y1", "x2", "y2"):
            if d.get(k) is None:
                raise WinError(f"нужен {k}")
        x1, y1 = int(d["x1"]), int(d["y1"])
        x2, y2 = int(d["x2"]), int(d["y2"])
        duration = float(d.get("duration") or 0.4)
        button = (d.get("button") or "left").lower()
        self._init()
        steps = max(5, int(duration * 40))
        try:
            self._mouse.move(coords=(x1, y1))
            time.sleep(0.05)
            self._mouse.press(button=button, coords=(x1, y1))
            for i in range(1, steps + 1):
                t = i / steps
                self._mouse.move(coords=(int(x1 + (x2 - x1) * t), int(y1 + (y2 - y1) * t)))
                time.sleep(duration / steps)
            self._mouse.release(button=button, coords=(x2, y2))
        except Exception as e:
            try:
                self._mouse.release(button=button, coords=(x2, y2))
            except Exception:
                pass
            raise WinError(f"drag не удался: {e}")
        return {"ok": True, "from": [x1, y1], "to": [x2, y2],
                "duration": duration, "button": button}

    def scroll(self, d: dict) -> dict:
        delta = int(d.get("delta") or 0)
        if delta == 0:
            raise WinError("нужен delta (целое, >0 — вверх, <0 — вниз)")
        x, y = d.get("x"), d.get("y")
        self._init()
        try:
            if x is not None and y is not None:
                self._mouse.scroll(coords=(int(x), int(y)), wheel_dist=delta)
            else:
                self._mouse.scroll(wheel_dist=delta)
        except Exception as e:
            raise WinError(f"scroll не удался: {e}")
        return {"ok": True, "delta": delta, "x": x, "y": y}

    def key(self, d: dict) -> dict:
        keys = d.get("keys")
        if not keys:
            raise WinError("не указан keys (синтаксис pywinauto: '^s', '{ENTER}', '%{F4}')")
        self._init()
        try:
            self._keyboard.send_keys(str(keys), pause=0.03)
        except Exception as e:
            raise WinError(f"key не удался: {e}")
        return {"ok": True, "keys": str(keys)}

    # --- МУЗЫКА: собственный изолированный плеер ------------------------------
    def _music_kill_locked(self):
        """Внутренний (без блокировки): убить процесс плеера и сбросить состояние."""
        proc = self._music_proc
        self._music_proc = None
        self._music_url = None
        if proc and proc.poll() is None:
            pid = proc.pid
            try:
                if sys.platform == "win32":
                    subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                                   capture_output=True, timeout=5)
                else:
                    proc.terminate()
            except Exception as e:
                log.warning("не убить плеер PID %s: %s", pid, e)
            return pid
        return None

    def music_play(self, d: dict) -> dict:
        """Включить музыку в СВОЁМ окне (отдельный профиль Edge/Chrome, режим --app).
        НЕ открывает вкладки в браузере пользователя.
        """
        url_in = (d.get("url") or "").strip()
        query = (d.get("query") or d.get("q") or d.get("text") or "").strip()

        # «играй/включи» без уточнений и что-то уже играет → тумблер play/pause
        if not url_in and not query:
            if self._music_proc and self._music_proc.poll() is None:
                _send_media_key(_MEDIA_KEYS["play_pause"])
                return {"ok": True, "action": "toggle_playpause",
                        "url": self._music_url}
            raise WinError("нужен query (название трека) или url")

        target = _build_autoplay_url(url_in) if url_in else _resolve_query_to_url(query)
        if not target:
            raise WinError("не удалось определить URL для воспроизведения")

        # Убить прошлый плеер (не трогаем ничего чужого)
        self._music_kill_locked()

        exe = _find_browser_exe()
        if not exe:
            raise WinError("не найден Edge/Chrome для собственного плеера моста")

        profile = os.path.join(tempfile.gettempdir(), "flux_music_profile")
        os.makedirs(profile, exist_ok=True)

        args = [
            exe,
            f"--app={target}",
            f"--user-data-dir={profile}",
            "--autoplay-policy=no-user-gesture-required",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-sync",
            "--disable-features=Translate,AutofillServerCommunication",
            "--window-size=1100,720",
        ]
        try:
            proc = subprocess.Popen(args, close_fds=True,
                                    creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        except Exception as e:
            raise WinError(f"не удалось запустить плеер: {e}")

        self._music_proc = proc
        self._music_url = target
        self._music_profile = profile
        log.info("музыка: запущен собственный плеер PID=%s url=%s", proc.pid, target)
        return {"ok": True, "pid": proc.pid, "url": target,
                "query": query or None, "profile": profile}

    def music_pause(self, d: dict) -> dict:
        if not _send_media_key(_MEDIA_KEYS["play_pause"]):
            raise WinError("медиа-клавиши только на Windows")
        return {"ok": True, "action": "play_pause", "playing": bool(
            self._music_proc and self._music_proc.poll() is None)}

    def music_stop(self, d: dict) -> dict:
        """Полностью остановить: убить наш плеер-процесс.
        Ничего чужого (пользовательский браузер, Spotify пользователя) не трогаем.
        """
        killed = self._music_kill_locked()
        log.info("музыка: остановлено, убит PID=%s", killed)
        return {"ok": True, "killed_pid": killed, "action": "stop"}

    def music_status(self, d: dict) -> dict:
        alive = bool(self._music_proc and self._music_proc.poll() is None)
        return {"ok": True, "playing": alive,
                "pid": (self._music_proc.pid if self._music_proc else None),
                "url": self._music_url,
                "profile": self._music_profile}

    def media(self, d: dict) -> dict:
        key = str(d.get("key") or d.get("keys") or d.get("action") or "").lower().strip()
        if not key:
            raise WinError(f"нужен key: один из {sorted(set(_MEDIA_KEYS))}")
        vk = _MEDIA_KEYS.get(key)
        if vk is None:
            raise WinError(f"неизвестная медиа-клавиша «{key}»; "
                           f"доступны: {sorted(set(_MEDIA_KEYS))}")
        if not _send_media_key(vk):
            raise WinError("медиа-клавиши работают только на Windows")
        return {"ok": True, "key": key, "vk": hex(vk)}

    def players(self, d: dict) -> dict:
        running = []
        for w in self._top_windows():
            p = (w["process"] or "").lower()
            if p in _KNOWN_PLAYERS:
                meta = _KNOWN_PLAYERS[p]
                running.append({"name": meta["name"], "process": p,
                                "hwnd": w["hwnd"], "id": str(w["hwnd"]),
                                "title": w["title"], "pid": w["pid"],
                                "scheme": meta.get("scheme"), "web": meta.get("web")})
        installed = _scan_installed_players()
        return {"ok": True, "running": running, "installed": installed,
                "count_running": len(running), "count_installed": len(installed)}

    def open_url(self, d: dict) -> dict:
        url = (d.get("url") or d.get("path") or "").strip()
        if not url:
            raise WinError("нужен url (например 'spotify:search:Queen' или 'https://...')")
        try:
            if sys.platform == "win32":
                os.startfile(url)       # noqa: S606
            else:
                subprocess.Popen(["xdg-open", url])
        except Exception as e:
            raise WinError(f"не удалось открыть «{url}»: {e}")
        return {"ok": True, "url": url}

    # --- ввод текста ----------------------------------------------------------
    def type_text(self, d: dict) -> dict:
        text = d.get("text")
        if text is None:
            raise WinError("не указан text")
        text = str(text)
        target = self._resolve_target(d)
        if target is None and not d.get("control"):
            self._init()
            try:
                self._keyboard.send_keys(self._esc_keys(text), with_spaces=True,
                                         with_tabs=True, with_newlines=True, pause=0.02)
            except Exception as e:
                raise WinError(f"глобальный ввод не удался: {e}")
            return {"ok": True, "typed": len(text), "mode": "global_type_keys"}
        info, win = self._resolve(d)
        timeout_s = self._timeout(d)
        el = self._find_ctl(win, d.get("control") or {}, timeout_s)
        replace = bool(d.get("replace"))
        try:
            el.set_focus()
        except Exception:
            pass
        if replace:
            try:
                el.iface_value.SetValue(text)
                return {"ok": True, "typed": len(text), "mode": "set_value",
                        "control": self._ctl_info(el)}
            except Exception:
                pass
            try:
                el.type_keys("^a{DELETE}", pause=0.01)
            except Exception:
                pass
        try:
            el.type_keys(self._esc_keys(text), with_spaces=True, with_tabs=True,
                         with_newlines=True, pause=0.02)
        except Exception as e:
            raise WinError(f"ввод текста не удался: {e}")
        return {"ok": True, "typed": len(text), "mode": "type_keys",
                "control": self._ctl_info(el)}

    def send_keys(self, d: dict) -> dict:
        keys = d.get("keys")
        if not keys:
            raise WinError("не указан keys (синтаксис pywinauto: '^s', '{ENTER}', '%{F4}')")
        keys = str(keys)
        target = self._resolve_target(d)
        if target is None and not d.get("control"):
            self._init()
            try:
                self._keyboard.send_keys(keys, pause=0.03)
            except Exception as e:
                raise WinError(f"глобальный send_keys не удался: {e}")
            return {"ok": True, "keys": keys, "mode": "global"}
        info, win = self._resolve(d)
        timeout_s = self._timeout(d)
        el = self._find_ctl(win, d.get("control") or {}, timeout_s) if d.get("control") else win
        try:
            try:
                win.set_focus()
            except Exception:
                _force_foreground(info["hwnd"])
            el.type_keys(keys, pause=0.03)
        except Exception as e:
            try:
                self._keyboard.send_keys(keys, pause=0.03)
            except Exception:
                raise WinError(f"send_keys не удался: {e}")
        return {"ok": True, "keys": keys}

    # --- скриншот / OCR -------------------------------------------------------
    def _grab_png(self, d: dict):
        try:
            import mss
            from PIL import Image
        except ImportError as e:
            raise WinError(f"нужны mss и pillow: pip install mss pillow ({e})")
        MSS = getattr(mss, "MSS", None) or getattr(mss, "mss")
        timeout_s = self._timeout(d)
        source, region = "screen", None
        if d.get("region"):
            r = d["region"]
            region = {"left": int(r.get("left", 0)), "top": int(r.get("top", 0)),
                      "width": int(r.get("width", 0)), "height": int(r.get("height", 0))}
            source = "region"
        else:
            target = self._resolve_target(d)
            if target is not None:
                info = self._find_app(target)
                win = self._wrap_window(info["hwnd"])
                el = self._find_ctl(win, d.get("control") or {}, timeout_s) \
                    if d.get("control") else win
                try:
                    if hasattr(el, "is_minimized") and el.is_minimized():
                        _force_foreground(info["hwnd"])
                        time.sleep(0.2)
                        win = self._wrap_window(info["hwnd"])
                        el = self._find_ctl(win, d.get("control") or {}, timeout_s) \
                            if d.get("control") else win
                    r = el.rectangle()
                    if int(r.width()) <= 0 or int(r.height()) <= 0:
                        raise WinError("окно свёрнуто или нулевого размера — сначала cmd=activate")
                    region = {"left": int(r.left), "top": int(r.top),
                              "width": int(r.width()), "height": int(r.height())}
                    source = "control" if d.get("control") else "window"
                except WinError:
                    raise
                except Exception as e:
                    raise WinError(f"не удалось получить границы окна: {e}")
        with MSS() as sct:
            if region is None:
                mon = int(d.get("monitor") or 0)
                mons = sct.monitors
                if mon < 0 or mon >= len(mons):
                    mon = 0
                region = mons[mon]
                source = f"monitor[{mon}]"
            shot = sct.grab(region)
            img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
        return img, {k: int(v) for k, v in region.items()}, source

    def screenshot(self, d: dict) -> dict:
        try:
            from PIL import Image  # noqa: F401
        except ImportError as e:
            raise WinError(f"нужна pillow: pip install pillow ({e})")
        fmt = (d.get("format") or "png").lower()
        if fmt == "jpg":
            fmt = "jpeg"
        if fmt not in ("png", "jpeg"):
            fmt = "png"
        quality = int(d.get("quality") or 85)
        scale = float(d.get("scale") or 1.0)

        img, region, source = self._grab_png(d)
        if scale != 1.0 and scale > 0:
            img = img.resize((max(1, int(img.width * scale)),
                              max(1, int(img.height * scale))), Image.LANCZOS)

        buf = io.BytesIO()
        if fmt == "jpeg":
            img.save(buf, format="JPEG", quality=quality, optimize=True)
        else:
            img.save(buf, format="PNG", optimize=True)
        return {"ok": True, "dataBase64": base64.b64encode(buf.getvalue()).decode("ascii"),
                "format": fmt, "width": img.width, "height": img.height,
                "source": source, "region": region, "screen": _virtual_screen()}

    def ocr(self, d: dict) -> dict:
        shot = self.screenshot({**d, "format": "png", "scale": 1.0})
        png_bytes = base64.b64decode(shot["dataBase64"])
        lang = str(d.get("lang") or "ru")
        res = _ocr_try_winocr(png_bytes, lang)
        if res is None:
            res = _ocr_try_pytesseract(png_bytes, lang)
        if res is None:
            raise WinError(
                "OCR недоступен. Установи один из: "
                "`pip install winocr` (рекомендуется, Windows.Media.Ocr) "
                "или `pip install pytesseract` + tesseract.exe"
            )
        reg = shot.get("region") or {"left": 0, "top": 0}
        dx, dy = int(reg.get("left", 0)), int(reg.get("top", 0))
        for w in res["words"]:
            w["abs_x"] = w["x"] + dx
            w["abs_y"] = w["y"] + dy
        return {"ok": True, "engine": res["engine"], "lang": lang,
                "count": len(res["words"]), "words": res["words"],
                "region": shot.get("region"), "screen": shot.get("screen")}

    # --- eval -----------------------------------------------------------------
    def eval_code(self, d: dict) -> dict:
        self._init()
        code = d.get("code")
        if not code or not str(code).strip():
            raise WinError("не указан code")
        code = str(code)
        win = None
        target = self._resolve_target(d)
        if target is not None:
            info = self._find_app(target)
            win = self._wrap_window(info["hwnd"])
        import pywinauto as _pyw
        from pywinauto import Desktop, keyboard, mouse
        ns = {"win": win, "Desktop": Desktop, "pywinauto": _pyw,
              "keyboard": keyboard, "mouse": mouse, "backend": self,
              "__name__": "flux_eval"}
        try:
            result, stdout = _run_eval(code, ns)
        except WinError:
            raise
        except Exception as e:
            raise WinError(f"{type(e).__name__}: {e}")
        try:
            json.dumps(result)
            res_repr = result
        except Exception:
            res_repr = repr(result)[:4000]
        return {"ok": True, "result": res_repr, "stdout": stdout[:4000]}

    @staticmethod
    def _timeout(d: dict) -> float:
        t = d.get("timeout")
        if t is None:
            t = (d.get("timeout_s") or DEFAULT_TIMEOUT_S) * 1000 if d.get("timeout_s") \
                else DEFAULT_TIMEOUT_S * 1000
        try:
            t = float(t) / 1000.0
        except Exception:
            t = DEFAULT_TIMEOUT_S
        return max(0.5, min(t, MAX_TIMEOUT_S))


# --------------------------------------------------------------------------- #
#  Mock-бэкенд                                                                 #
# --------------------------------------------------------------------------- #
class MockRect:
    def __init__(self, l, t, r, b):
        self.left, self.top, self.right, self.bottom = l, t, r, b

    def width(self):
        return self.right - self.left

    def height(self):
        return self.bottom - self.top


class MockCtl:
    def __init__(self, title, control_type, auto_id, rect, state):
        self._title, self._ct, self._aid, self._rect = title, control_type, auto_id, rect
        self._state = state

    def window_text(self):
        return self._title

    def rectangle(self):
        return self._rect

    def is_visible(self):
        return True

    def is_enabled(self):
        return True

    def set_focus(self):
        self._state["focused"] = self

    def click_input(self, button="left", double=False):
        self._state["events"].append({"action": "click", "control": self._title,
                                      "type": self._ct, "button": button, "double": double})

    def invoke(self):
        self.click_input()

    def type_keys(self, keys, **kw):
        if self._ct in ("Edit", "Document"):
            self._state.setdefault("texts", {})[self._aid or self._title] = \
                self._state.get("texts", {}).get(self._aid or self._title, "") + keys
        self._state["events"].append({"action": "type", "control": self._title, "keys": keys})

    def texts(self):
        v = self._state.get("texts", {}).get(self._aid or self._title, "")
        return [v] if v else []

    def children(self):
        return []

    @property
    def element_info(self):
        outer = self

        class EI:
            control_type = outer._ct
            automation_id = outer._aid
            class_name = "Mock" + outer._ct
        return EI()


class MockSpec:
    def __init__(self, ctl):
        self._ctl = ctl

    def wait(self, state="exists", timeout=10):
        if self._ctl is None:
            raise WinError(f"таймаут ожидания ({timeout}с): элемент не найден (mock)")
        return self._ctl

    def wrapper_object(self):
        return self._ctl


class MockWin:
    def __init__(self, title, process, pid, hwnd, rect, controls, state):
        self._title, self._process, self._pid, self._hwnd = title, process, pid, hwnd
        self._rect, self._controls, self._state = rect, controls, state

    def window_text(self):
        return self._title

    def process_id(self):
        return self._pid

    @property
    def handle(self):
        return self._hwnd

    def rectangle(self):
        return self._rect

    def is_visible(self):
        return True

    def is_minimized(self):
        return False

    def is_enabled(self):
        return True

    def set_focus(self):
        self._state["active"] = self._hwnd

    def close(self):
        self._state["closed"].append(self._hwnd)

    def click_input(self, **kw):
        self._state["events"].append({"action": "click_window", "title": self._title})

    def type_keys(self, keys, **kw):
        self._state["events"].append({"action": "type_window", "title": self._title, "keys": keys})

    def texts(self):
        return [self._title]

    def children(self):
        return list(self._controls)

    def descendants(self, **q):
        hits = []
        stack = list(self._controls)
        while stack:
            c = stack.pop(0)
            if (not q.get("title") or q["title"].lower() in c._title.lower()) and \
               (not q.get("control_type") or c._ct == q["control_type"]) and \
               (not q.get("auto_id") or c._aid == q["auto_id"]):
                hits.append(c)
            stack.extend(c.children())
        return hits

    def child_window(self, **q):
        def match(c):
            if q.get("title") and q["title"].lower() not in c._title.lower():
                return False
            if q.get("control_type") and c._ct != q["control_type"]:
                return False
            if q.get("auto_id") and c._aid != q["auto_id"]:
                return False
            return True
        for c in self._controls:
            if match(c):
                return MockSpec(c)
        return MockSpec(None)

    @property
    def element_info(self):
        class EI:
            control_type = "Window"
            automation_id = ""
            class_name = "MockWindow"
        return EI()


class MockBackend:
    name = "mock"

    def __init__(self):
        self._state = {"events": [], "texts": {}, "closed": [], "active": None, "focused": None}
        self._next_pid = 5000
        self._wins = {}
        self._music_proc = None
        self._music_url = None
        self._add("Безымянный — Блокнот", "notepad.exe", 0x000A0B0C,
                  (100, 100, 900, 640),
                  [("Файл", "MenuItem", "MenuBar.File"), ("Правка", "MenuItem", "MenuBar.Edit"),
                   ("Сохранить", "Button", "SaveButton"), ("Текстовый редактор", "Edit", "15")])
        self._add("Новая вкладка — Google Chrome", "chrome.exe", 0x000C0FFEE,
                  (0, 0, 1920, 1080), [("Адресная строка", "Edit", "address")])
        self._add("Steam", "steam.exe", 0x000E0001,
                  (200, 150, 1200, 800), [("Библиотека", "Button", "LibraryTab")])

    def _add(self, title, process, hwnd, rect, controls):
        self._next_pid += 1
        ctrls = [MockCtl(t, ct, aid, MockRect(*rect), self._state) for t, ct, aid in controls]
        w = MockWin(title, process, self._next_pid, hwnd, MockRect(*rect), ctrls, self._state)
        self._wins[hwnd] = w
        return w

    def status(self, d):
        return {"ok": True, "backend": "mock", "version": VERSION, "pywinauto": "mock",
                "python": sys.version.split()[0], "os": sys.platform, "mock": True,
                "screen": {"left": 0, "top": 0, "width": 1920, "height": 1080}}

    def targets(self, d):
        alive = self._alive()
        return {"ok": True, "count": len(alive),
                "targets": [{"id": str(w._hwnd), "tabId": str(w._hwnd), "hwnd": w._hwnd,
                             "title": w._title, "process": w._process, "pid": w._pid,
                             "active": self._state["active"] == w._hwnd, "url": None,
                             "rect": {"left": w._rect.left, "top": w._rect.top,
                                      "width": int(w._rect.width()),
                                      "height": int(w._rect.height())}}
                            for w in alive],
                "screen": {"left": 0, "top": 0, "width": 1920, "height": 1080}}

    def apps(self, d):
        alive = self._alive()
        return {"ok": True, "count": len(alive),
                "apps": [{"id": str(w._hwnd), "title": w._title, "process": w._process,
                          "pid": w._pid, "hwnd": w._hwnd,
                          "active": self._state["active"] == w._hwnd,
                          "rect": {"left": w._rect.left, "top": w._rect.top,
                                   "width": int(w._rect.width()),
                                   "height": int(w._rect.height())}}
                         for w in alive]}

    def windows(self, d):
        alive = self._alive()
        return {"ok": True, "count": len(alive),
                "windows": [{"id": str(w._hwnd), "title": w._title, "process": w._process,
                             "pid": w._pid, "hwnd": w._hwnd,
                             "rect": {"left": w._rect.left, "top": w._rect.top,
                                      "width": int(w._rect.width()),
                                      "height": int(w._rect.height())},
                             "visible": True, "enabled": True,
                             "active": self._state["active"] == w._hwnd}
                            for w in alive]}

    def activate(self, d):
        w = self._find(RealBackend._resolve_target(d))
        w.set_focus()
        return {"ok": True, "title": w._title, "hwnd": w._hwnd, "id": str(w._hwnd)}

    def close(self, d):
        w = self._find(RealBackend._resolve_target(d))
        w.close()
        return {"ok": True, "title": w._title, "hwnd": w._hwnd, "id": str(w._hwnd)}

    def launch(self, d):
        path = (d.get("path") or "").strip()
        if not path:
            raise WinError("не указан path")
        base = os.path.basename(path.replace("\\", "/")) or "app"
        w = self._add(f"{base} — mock", base, 0x00F00000 + self._next_pid,
                      (50, 50, 850, 650), [("ОК", "Button", "ok")])
        return {"ok": True, "pid": w._pid, "path": path, "title": w._title}

    def children(self, d):
        w = self._find(RealBackend._resolve_target(d))
        els = w.children()
        limit = min(int(d.get("limit") or 150), 500)
        return {"ok": True, "count": len(els[:limit]), "total": len(els),
                "children": [RealBackend._ctl_info(c) for c in els[:limit]]}

    def find(self, d):
        w = self._find(RealBackend._resolve_target(d))
        q = RealBackend._ctl_query(d.get("control") or {})
        if not q:
            raise WinError("нужен control с критериями")
        els = w.descendants(**q)
        limit = min(int(d.get("limit") or 50), 500)
        return {"ok": True, "count": len(els[:limit]), "total": len(els),
                "elements": [RealBackend._ctl_info(c) for c in els[:limit]]}

    def click(self, d):
        if not (d.get("control") or {}) and d.get("x") is not None and d.get("y") is not None:
            return self.click_xy(d)
        if not (d.get("control") or {}):
            raise WinError("не указан control или x/y")
        w = self._find(RealBackend._resolve_target(d))
        ctl = w.child_window(**RealBackend._ctl_query(d["control"])).wait(timeout=1)
        ctl.click_input(button=d.get("button") or "left", double=bool(d.get("double")))
        return {"ok": True, "clicked": RealBackend._ctl_info(ctl),
                "method": d.get("method") or "input"}

    def click_xy(self, d):
        x, y = d.get("x"), d.get("y")
        if x is None or y is None:
            raise WinError("нужны x, y")
        x, y = int(x), int(y)
        self._state["events"].append({"action": "click_xy", "x": x, "y": y,
                                      "button": d.get("button") or "left",
                                      "double": bool(d.get("double"))})
        return {"ok": True, "x": x, "y": y}

    def move(self, d):
        x, y = d.get("x"), d.get("y")
        if x is None or y is None:
            raise WinError("нужны x, y")
        self._state["events"].append({"action": "move", "x": int(x), "y": int(y)})
        return {"ok": True, "x": int(x), "y": int(y)}

    def drag(self, d):
        for k in ("x1", "y1", "x2", "y2"):
            if d.get(k) is None:
                raise WinError(f"нужен {k}")
        self._state["events"].append({"action": "drag",
                                      "from": (int(d["x1"]), int(d["y1"])),
                                      "to": (int(d["x2"]), int(d["y2"]))})
        return {"ok": True, "from": [int(d["x1"]), int(d["y1"])],
                "to": [int(d["x2"]), int(d["y2"])]}

    def scroll(self, d):
        delta = int(d.get("delta") or 0)
        if delta == 0:
            raise WinError("нужен delta")
        self._state["events"].append({"action": "scroll", "x": d.get("x"), "y": d.get("y"),
                                      "delta": delta})
        return {"ok": True, "delta": delta, "x": d.get("x"), "y": d.get("y")}

    def key(self, d):
        if not d.get("keys"):
            raise WinError("не указан keys")
        self._state["events"].append({"action": "key", "keys": str(d["keys"])})
        return {"ok": True, "keys": str(d["keys"])}

    # --- музыка (mock) --------------------------------------------------------
    def music_play(self, d):
        url_in = (d.get("url") or "").strip()
        query = (d.get("query") or d.get("q") or d.get("text") or "").strip()
        if not url_in and not query:
            if self._music_proc is not None:
                self._state["events"].append({"action": "media", "key": "play_pause"})
                return {"ok": True, "action": "toggle_playpause", "url": self._music_url}
            raise WinError("нужен query или url")
        target = url_in or f"https://www.youtube.com/results?search_query={urllib.parse.quote(query)}"
        self._music_proc = {"pid": 999_999}
        self._music_url = target
        self._state["events"].append({"action": "music_play", "url": target, "query": query or None})
        return {"ok": True, "pid": 999_999, "url": target, "query": query or None,
                "profile": os.path.join(tempfile.gettempdir(), "flux_music_profile")}

    def music_pause(self, d):
        self._state["events"].append({"action": "media", "key": "play_pause"})
        return {"ok": True, "action": "play_pause", "playing": self._music_proc is not None}

    def music_stop(self, d):
        killed = 999_999 if self._music_proc else None
        self._music_proc = None
        self._music_url = None
        self._state["events"].append({"action": "music_stop"})
        return {"ok": True, "killed_pid": killed, "action": "stop"}

    def music_status(self, d):
        return {"ok": True, "playing": self._music_proc is not None,
                "pid": (self._music_proc or {}).get("pid"),
                "url": self._music_url, "profile": None}

    def media(self, d):
        key = str(d.get("key") or d.get("keys") or d.get("action") or "").lower().strip()
        if key not in set(_MEDIA_KEYS):
            raise WinError(f"неизвестная медиа-клавиша «{key}»; "
                           f"доступны: {sorted(set(_MEDIA_KEYS))}")
        self._state["events"].append({"action": "media", "key": key})
        return {"ok": True, "key": key}

    def players(self, d):
        return {"ok": True, "running": [], "installed": [
            {"name": "Spotify", "where": "mock", "location": "C:\\mock\\Spotify.exe",
             "scheme": "spotify:", "web": "https://open.spotify.com"},
            {"name": "VLC", "where": "mock", "location": "C:\\mock\\vlc.exe",
             "scheme": None, "web": None},
        ], "count_running": 0, "count_installed": 2}

    def open_url(self, d):
        url = (d.get("url") or d.get("path") or "").strip()
        if not url:
            raise WinError("нужен url")
        self._state["events"].append({"action": "open_url", "url": url})
        return {"ok": True, "url": url}

    def type_text(self, d):
        if d.get("text") is None:
            raise WinError("не указан text")
        text = str(d["text"])
        target = RealBackend._resolve_target(d)
        if target is None and not d.get("control"):
            self._state["events"].append({"action": "global_type", "keys": text})
            return {"ok": True, "typed": len(text), "mode": "global_type_keys"}
        w = self._find(target)
        ctl = w
        if d.get("control"):
            ctl = w.child_window(**RealBackend._ctl_query(d["control"])).wait(timeout=1)
        if d.get("replace") and hasattr(ctl, "_state"):
            ctl._state.get("texts", {})[ctl._aid or ctl._title] = ""
        ctl.type_keys(text)
        return {"ok": True, "typed": len(text), "mode": "mock",
                "control": RealBackend._ctl_info(ctl)}

    def send_keys(self, d):
        if not d.get("keys"):
            raise WinError("не указан keys")
        keys = str(d["keys"])
        target = RealBackend._resolve_target(d)
        if target is None and not d.get("control"):
            self._state["events"].append({"action": "global_keys", "keys": keys})
            return {"ok": True, "keys": keys, "mode": "global"}
        w = self._find(target)
        w.type_keys(keys)
        return {"ok": True, "keys": keys}

    def screenshot(self, d):
        try:
            from PIL import Image, ImageDraw
            img = Image.new("RGB", (640, 400), (18, 22, 30))
            dr = ImageDraw.Draw(img)
            title = "mock desktop"
            target = RealBackend._resolve_target(d)
            if target is not None:
                w = self._find(target)
                title = w._title
            dr.rectangle([8, 8, 631, 391], outline=(90, 130, 200), width=2)
            dr.rectangle([8, 8, 631, 40], fill=(40, 60, 110))
            dr.text((16, 16), title[:60], fill=(235, 240, 250))
            dr.text((16, 60), "MOCK SCREENSHOT (win_bridge --mock)", fill=(150, 160, 180))
            for i, ev in enumerate(self._state["events"][-6:]):
                dr.text((16, 90 + i * 18), str(ev)[:80], fill=(120, 200, 160))
            wpx, hpx = img.width, img.height
        except ImportError:
            png1x1 = base64.b64decode(
                "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
            return {"ok": True, "dataBase64": base64.b64encode(png1x1).decode(),
                    "width": 1, "height": 1, "source": "mock", "region": {}, "format": "png"}
        fmt = (d.get("format") or "png").lower()
        if fmt == "jpg":
            fmt = "jpeg"
        if fmt not in ("png", "jpeg"):
            fmt = "png"
        quality = int(d.get("quality") or 85)
        scale = float(d.get("scale") or 1.0)
        if scale != 1.0 and scale > 0:
            img = img.resize((max(1, int(img.width * scale)),
                              max(1, int(img.height * scale))), Image.LANCZOS)
            wpx, hpx = img.width, img.height
        buf = io.BytesIO()
        if fmt == "jpeg":
            img.save(buf, format="JPEG", quality=quality, optimize=True)
        else:
            img.save(buf, format="PNG", optimize=True)
        return {"ok": True, "dataBase64": base64.b64encode(buf.getvalue()).decode("ascii"),
                "width": wpx, "height": hpx, "source": "mock", "format": fmt,
                "region": {"left": 0, "top": 0, "width": wpx, "height": hpx},
                "screen": {"left": 0, "top": 0, "width": 1920, "height": 1080}}

    def ocr(self, d):
        raise WinError("OCR недоступен в mock-режиме (запусти без --mock на Windows)")

    def wait(self, d):
        w = self._find(RealBackend._resolve_target(d))
        t0 = time.time()
        if d.get("control"):
            ctl = w.child_window(**RealBackend._ctl_query(d["control"])).wait(
                timeout=RealBackend._timeout(d))
            info = RealBackend._ctl_info(ctl)
        else:
            ctl, info = w, RealBackend._ctl_info(w)
        return {"ok": True, "found": True, "waited_ms": int((time.time() - t0) * 1000),
                "control": info}

    def read(self, d):
        w = self._find(RealBackend._resolve_target(d))
        el = w
        if d.get("control"):
            el = w.child_window(**RealBackend._ctl_query(d["control"])).wait(timeout=1)
        info = RealBackend._ctl_info(el)
        value = "".join(el.texts()) if el.texts() else None
        return {"ok": True, "text": info["title"], "value": value,
                "texts": el.texts(),
                **{k: info[k] for k in ("control_type", "auto_id", "class_name", "rect")}}

    def eval_code(self, d):
        code = (d.get("code") or "").strip()
        if not code:
            raise WinError("не указан code")
        target = RealBackend._resolve_target(d)
        win = self._find(target) if target is not None else None
        ns = {"win": win, "Desktop": None, "pywinauto": None, "mock": True}
        try:
            result, stdout = _run_eval(code, ns)
        except WinError:
            raise
        except Exception as e:
            raise WinError(f"{type(e).__name__}: {e}")
        if not isinstance(result, (str, int, float, bool, type(None))):
            result = repr(result)[:4000]
        return {"ok": True, "result": result, "stdout": stdout[:4000]}

    def _alive(self):
        return [w for h, w in self._wins.items() if h not in self._state["closed"]]

    def _find(self, app):
        if not app:
            raise WinError("не указано окно (id или app)")
        alive = self._alive()
        try:
            h = int(app)
            for w in alive:
                if w._hwnd == h:
                    return w
        except (ValueError, TypeError):
            pass
        s = str(app).lower()
        for w in alive:
            if w._title.lower() == s:
                return w
        for w in alive:
            if s in w._title.lower() or s in w._process.lower() or \
               s in w._process.lower().replace(".exe", ""):
                return w
        raise WinError(f"окно «{app}» не найдено (mock). Окна: " +
                       "; ".join(f"id={w._hwnd} «{w._title}»" for w in alive))


# --------------------------------------------------------------------------- #
#  Диспетчер и WebSocket-сервер                                                #
# --------------------------------------------------------------------------- #
HANDLERS = {
    "status": "status",
    "targets": "targets",
    "apps": "apps",
    "windows": "windows",
    "activate": "activate",
    "close": "close",
    "launch": "launch",
    "children": "children",
    "find": "find",
    "click": "click",
    "click_xy": "click_xy",
    "move": "move",
    "drag": "drag",
    "scroll": "scroll",
    "key": "key",
    "type": "type_text",
    "send_keys": "send_keys",
    "screenshot": "screenshot",
    "ocr": "ocr",
    "wait": "wait",
    "read": "read",
    "eval": "eval_code",
    # --- музыка ---
    "music_play": "music_play",
    "music_pause": "music_pause",
    "music_stop": "music_stop",
    "music_off": "music_stop",       # алиас — на случай «флюкс выключи»
    "stop_music": "music_stop",      # алиас
    "music_status": "music_status",
    "media": "media",
    "players": "players",
    "open_url": "open_url",
}

FAST_CMDS = {"status", "targets", "apps", "windows",
             "music_pause", "music_stop", "music_off", "stop_music",
             "music_status", "media", "players", "open_url"}
SLOW_CMDS = {"wait", "eval", "click", "read", "children", "find", "type",
             "send_keys", "screenshot", "ocr", "drag", "music_play"}

BACKEND: object = None


def dispatch_sync(d: dict):
    cmd = str(d.get("cmd") or "")
    method = HANDLERS.get(cmd)
    if not method:
        raise WinError(f"неизвестная команда: {cmd or '(пусто)'}; "
                       f"доступны: {', '.join(sorted(HANDLERS))}")
    return getattr(BACKEND, method)(d)


_CLIENTS: set = set()
_CMD_LOCK = asyncio.Lock()


async def ws_handler(ws, *args):
    path = _ws_path(ws)
    peer = getattr(ws, "remote_address", None)
    _CLIENTS.add(ws)
    log.info("клиент подключён: %s (path=%s) [всего клиентов: %d]",
             peer, path, len(_CLIENTS))
    try:
        await ws.send(json.dumps({
            "type": "welcome",
            "server": "win_bridge",
            "version": VERSION,
            "backend": BACKEND.name if BACKEND else "?",
        }))
    except Exception:
        pass

    async def keepalive():
        try:
            while True:
                await asyncio.sleep(PING_INTERVAL)
                await ws.send(json.dumps({"type": "ping"}))
        except Exception:
            pass

    ping_task = asyncio.create_task(keepalive())
    frame_no = 0
    try:
        async for raw in ws:
            frame_no += 1
            try:
                preview = raw if isinstance(raw, str) else raw.decode("utf-8", "replace")
            except Exception:
                preview = str(raw)
            if frame_no <= 5:
                log.info("<<< %s кадр#%d: %.300s", peer, frame_no, preview)
            else:
                log.debug("<<< %s: %.300s", peer, preview)
            try:
                d = json.loads(preview)
            except Exception:
                log.warning("не-JSON сообщение: %.120s", preview)
                continue
            t = d.get("type")
            if t == "ping":
                await ws.send(json.dumps({"type": "pong"}))
            elif t == "pong":
                log.debug("pong от клиента")
            elif t == "hello":
                log.info("hello от %s", d.get("name") or "клиента")
                await ws.send(json.dumps({
                    "type": "hello_ok",
                    "server": "win_bridge",
                    "version": VERSION,
                    "backend": BACKEND.name if BACKEND else "?",
                    "result": {
                        "ok": True,
                        "server": "win_bridge",
                        "version": VERSION,
                        "backend": BACKEND.name if BACKEND else "?",
                    },
                }))
            elif t == "req":
                asyncio.create_task(handle_req(ws, d))
            else:
                log.warning("неизвестный тип сообщения: %r (полный кадр: %.300s)", t, preview)
    except ConnectionClosed:
        pass
    except Exception as e:
        log.exception("ошибка соединения: %s", e)
    finally:
        ping_task.cancel()
        _CLIENTS.discard(ws)
        try:
            await ws.close()
        except Exception:
            pass
        log.info("клиент отключён: %s [осталось: %d]", peer, len(_CLIENTS))


async def handle_req(ws, d: dict):
    mid = d.get("id")
    cmd = d.get("cmd")
    t0 = time.time()
    error = None
    result = None
    try:
        if cmd in FAST_CMDS:
            result = await asyncio.wait_for(
                asyncio.to_thread(dispatch_sync, d), timeout=10)
        else:
            timeout_s = (RealBackend._timeout(d) + 15) if cmd in SLOW_CMDS else 60
            async with _CMD_LOCK:
                result = await asyncio.wait_for(
                    asyncio.to_thread(dispatch_sync, d), timeout=timeout_s)
    except asyncio.TimeoutError:
        error = f"таймаут команды {cmd} ({time.time() - t0:.0f}с)"
    except WinError as e:
        error = str(e)
    except Exception as e:
        error = f"{type(e).__name__}: {e}"
        log.exception("команда %s упала", cmd)
    ms = int((time.time() - t0) * 1000)
    log.info("req id=%s cmd=%s -> %s (%d мс)",
             mid, cmd, "OK" if error is None else f"ERR: {error[:160]}", ms)
    try:
        await ws.send(json.dumps({"type": "resp", "id": mid,
                                  "result": result, "error": error},
                                 ensure_ascii=False, default=str))
    except Exception as e:
        log.warning("не отправить resp id=%s: %s", mid, e)


def setup_logging(verbose: bool):
    here = os.path.dirname(os.path.abspath(__file__))
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
    log.setLevel(logging.DEBUG if verbose else logging.INFO)
    fh = RotatingFileHandler(os.path.join(here, "win_bridge.log"),
                             maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    sh.setLevel(logging.DEBUG if verbose else logging.INFO)
    log.addHandler(fh)
    log.addHandler(sh)


async def amain(args):
    global BACKEND
    if args.mock:
        BACKEND = MockBackend()
        log.info("MOCK-режим: симуляция окон Windows")
    else:
        BACKEND = RealBackend()
        if sys.platform != "win32":
            log.error("реальный режим только на Windows (pywinauto/UIA). "
                      "Для тестов: python win_bridge.py --mock")
            sys.exit(2)
        BACKEND._init()
        log.info("backend: pywinauto UIA + Win32 EnumWindows, DPI-awareness включён")

    async def _serve():
        async with serve(ws_handler, args.host, args.port,
                         ping_interval=PING_INTERVAL, ping_timeout=PING_INTERVAL * 3,
                         max_size=64 * 1024 * 1024):
            log.info("win_bridge %s слушает ws://%s:%d%s (команды: %s)",
                     VERSION, args.host, args.port, PATH_DEFAULT,
                     ", ".join(sorted(HANDLERS)))
            print(f"[win_bridge] ws://{args.host}:{args.port}{PATH_DEFAULT}  (Ctrl+C — стоп)")
            await asyncio.Future()

    try:
        await _serve()
    except asyncio.CancelledError:
        pass
    finally:
        # Чистим наш плеер при остановке моста
        if hasattr(BACKEND, "_music_kill_locked"):
            try:
                BACKEND._music_kill_locked()
            except Exception:
                pass


def main():
    ap = argparse.ArgumentParser(
        description="FLUX Windows Bridge (ws://127.0.0.1:8643/win-bridge)")
    ap.add_argument("--host", default=HOST_DEFAULT)
    ap.add_argument("--port", type=int, default=PORT_DEFAULT)
    ap.add_argument("--mock", action="store_true",
                    help="симуляция окон (тесты без Windows/pywinauto)")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()
    setup_logging(args.verbose)
    try:
        asyncio.run(amain(args))
    except KeyboardInterrupt:
        log.info("остановлено пользователем (Ctrl+C)")


if __name__ == "__main__":
    main()