@echo off
rem FLUX Windows Bridge: запуск win_bridge.py (ws://127.0.0.1:8643/win-bridge)
rem Двойной клик = старт моста; окно консоли показывает лог (он же в win_bridge.log).
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo [win_bridge] Python не найден в PATH. Установи Python 3.10+ и повтори.
  pause
  exit /b 1
)
python -m pip install -q -r requirements.txt
python win_bridge.py %*
pause
