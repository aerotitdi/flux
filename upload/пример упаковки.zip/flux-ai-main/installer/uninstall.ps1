﻿# FLUX 2.0 - uninstaller (Windows)
param([string]$InstallDir = "")
$ErrorActionPreference = "Stop"
if (-not $InstallDir) { $InstallDir = Join-Path $env:LOCALAPPDATA "Flux2" }
$desk = [Environment]::GetFolderPath("Desktop")
$startup = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup"
foreach ($p in @("$desk\FLUX 2.0.lnk", "$desk\FLUX 2.0 Console.lnk", "$startup\FLUX 2.0.lnk")) {
  if (Test-Path $p) { Remove-Item $p -Force; Write-Host "[FLUX2] удалён ярлык: $p" }
}
if (Test-Path $InstallDir) {
  Remove-Item $InstallDir -Recurse -Force
  Write-Host "[FLUX2] удалён каталог: $InstallDir"
}
Write-Host "[FLUX2] деинсталляция завершена."
