﻿# FLUX 2.0 Desktop - инсталлер (Windows).
# Ставит приложение в каталог, создаёт venv, зависимости, собирает .exe,
# вешает ярлыки на рабочий стол, опционально - автозапуск.
param(
  [string]$InstallDir = "",
  [switch]$SkipExe,      # не собирать .exe (быстрая установка: ярлыки на pythonw)
  [switch]$Autostart,    # ярлык в автозапуск
  [string]$Python = ""   # путь к python.exe, если не находится сам
)
$ErrorActionPreference = "Stop"
function Log($m) { Write-Host "[FLUX2] $m" -ForegroundColor Cyan }

# --- 1. Python ---------------------------------------------------------------
$pyCode = "import sys; print(sys.version_info.major*100+sys.version_info.minor)"
if ($Python) {
  $pyExe0 = $Python; $pyRest = @()
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
  $pyExe0 = "py"; $pyRest = @("-3")
} else {
  $pyExe0 = "python"; $pyRest = @()
}
$ver = (& $pyExe0 @pyRest -c $pyCode) | Select-Object -First 1
$verN = [int]"$ver".Trim()
if ($verN -lt 310) { throw "Нужен Python 3.10+ (найдено: $verN). Поставь с python.org и повторить." }
Log "Python OK ($verN)"

# --- 2. Каталог установки -----------------------------------------------------
if (-not $InstallDir) { $InstallDir = Join-Path $env:LOCALAPPDATA "Flux2" }
$src = Split-Path -Parent $PSScriptRoot   # корень flux2 (родитель installer/)
Log "Каталог установки: $InstallDir"
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Log "Копирую файлы приложения..."
$null = robocopy $src $InstallDir /E /XD .venv __pycache__ dist build .git tests /NFL /NDL /NJH
if ($LASTEXITCODE -gt 7) { throw "robocopy failed ($LASTEXITCODE)" }

# --- 3. venv + зависимости -----------------------------------------------------
$venvPy = Join-Path $InstallDir ".venv\Scripts\python.exe"
if (-not (Test-Path $venvPy)) {
  Log "Создаю изолированный venv..."
  & $pyExe0 @pyRest -m venv "$InstallDir\.venv"
}
Log "Ставлю зависимости (aiohttp, websockets, pywebview, edge-tts, pyinstaller)..."
& $venvPy -m pip install --upgrade pip | Out-Null
& $venvPy -m pip install -r "$InstallDir\requirements.txt" pyinstaller
if ($LASTEXITCODE -ne 0) { throw "pip install failed" }

# --- 4. Сборка .exe -------------------------------------------------------------
$exeChat = Join-Path $InstallDir "dist\FluxChat\FluxChat.exe"
$exeCon  = Join-Path $InstallDir "dist\FluxConsole\FluxConsole.exe"
if (-not $SkipExe) {
  Log "Собираю FluxChat.exe и FluxConsole.exe (пара минут)..."
  Push-Location $InstallDir
  & .venv\Scripts\pyinstaller.exe --noconfirm --clean --name FluxChat --windowed `
    --icon "ui\flux.ico" `
    --add-data "ui;ui" --add-data "skills_bundled;skills_bundled" `
    --hidden-import webview --hidden-import edge_tts --hidden-import websockets main.py | Out-Null
  & .venv\Scripts\pyinstaller.exe --noconfirm --clean --name FluxConsole --console `
    --icon "ui\flux.ico" `
    --add-data "ui;ui" --add-data "skills_bundled;skills_bundled" `
    --hidden-import websockets --hidden-import edge_tts main.py | Out-Null
  Pop-Location
  if (-not (Test-Path $exeChat)) { Log "ВНИМАНИЕ: exe не собрался - ярлыки укажут на pythonw (режим без сборки)." }
} else {
  Log "Пропускаю сборку exe (-SkipExe)"
}

# --- 5. Ярлыки -------------------------------------------------------------------
function New-Shortcut($path, $target, $args, $workdir, $desc) {
  $ws = New-Object -ComObject WScript.Shell
  $lnk = $ws.CreateShortcut($path)
  $lnk.TargetPath = $target
  if ($args) { $lnk.Arguments = $args }
  if ($workdir) { $lnk.WorkingDirectory = $workdir }
  $lnk.Description = $desc
  $ico = Join-Path $InstallDir "ui\flux.ico"
  if (Test-Path $ico) { $lnk.IconLocation = "$ico, 0" }
  $lnk.Save()
}
$desk = [Environment]::GetFolderPath("Desktop")
if (Test-Path $exeChat) {
  New-Shortcut "$desk\FLUX 2.0.lnk" $exeChat "" "" "FLUX 2.0 Desktop - чат-окно"
  New-Shortcut "$desk\FLUX 2.0 Console.lnk" $exeCon "" "" "FLUX 2.0 - терминальный чат"
} else {
  New-Shortcut "$desk\FLUX 2.0.lnk" "$InstallDir\.venv\Scripts\pythonw.exe" "main.py" $InstallDir "FLUX 2.0 Desktop - чат-окно"
  New-Shortcut "$desk\FLUX 2.0 Console.lnk" "$venvPy" "main.py --console" $InstallDir "FLUX 2.0 - терминальный чат"
}
if ($Autostart) {
  $startup = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup"
  Copy-Item "$desk\FLUX 2.0.lnk" $startup -Force
  Log "Автозапуск включён"
}

# --- 6. Самотест -------------------------------------------------------------------
Log "Самотест..."
Push-Location $InstallDir
& $venvPy main.py --selftest
Pop-Location

Log "Установка завершена: $InstallDir"
Log "Первый запуск: ярлык 'FLUX 2.0' -> шестерёнка -> Подключения -> добавить провайдер (API-ключ)."
exit 0
