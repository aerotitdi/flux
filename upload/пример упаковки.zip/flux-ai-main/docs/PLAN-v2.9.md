# FLUX 2.0 — итерация v2.9: чтение страницы, медиа везде, страж ПК

Дата: 2026-10-12 · База: v2.8 (`81fcb47`) · Коммит v2.9 · Инструментов: 411 → **442**

---

## 1. Что просили и что сделано

| Запрос | Статус | Как |
|---|---|---|
| «читал всё что на экране» | ✅ | `app/vision.py` + правка `agent.py`: снимки реально уходят модели |
| «открывает канал и не больше» | ✅ | `browser_page_snapshot` + `browser_act(index=N)` — нумерованная карта страницы |
| «поставь музыку на паузу» (YouTube и любое приложение) | ✅ | GSMTCS + медиа-клавиши + `browser_media_control` |
| «открой канал MrMarmok и последнее видео» | ✅ | цепочка snapshot → act → проверка медиа; закреплено скиллом |
| «включи музыку у себя, не в браузере, зациклить» | ✅ | собственный плеер FLUX (`<audio>` в окне, SSE-команды) |
| «использовать уже скачанные расширения» | ⚠️ частично | инвентаризация + запуск страниц расширения + горячие клавиши. Вызвать API чужого аддона извне нельзя — см. §4 |
| «права как у simple unlocker, страж ПК» | ✅ с шлюзом | инвентаризация автозапуска, снятие блокировок, карантин, блокировка запуска — через политику и подтверждение (§5) |
| «видел автозапуск в винлогоне» | ✅ | Run/RunOnce, Startup, планировщик, службы, WMI-подписки, IFEO, Winlogon, AppInit_DLLs, LSA, BHO |
| «управлять браузером даже с F12» | 🔜 | см. §6 — есть объективное ограничение Chrome |
| «открой Discord и напиши в канал» | 🔜 | см. §7 — делается, но не через токен |

---

## 2. Корень проблемы «открывает и не больше»

Две независимые причины, обе устранены.

### 2.1 Модель физически не видела картинки (дефект D7 из аудита v2.8)

В `agent.py` результат тулза с картинками превращался в строку:

```python
content += "\n[изображения: " + ", ".join(res.images) + "]"
```

То есть модель получала **путь к файлу**, а не изображение. Никакой «читает всё что на экране»
в таких условиях невозможен в принципе.

Теперь (`app/vision.py`):
- картинка перекодируется в JPEG и уменьшается до `vision_max_px` (1568) — скриншот 1080p
  в PNG это 1–3 МБ, в JPEG после ресайза 150–400 КБ, то есть в разы меньше токенов;
- отдаётся сообщением `role=user` **сразу после всех tool-сообщений хода** — так требует
  OpenAI-формат: роль `tool` не принимает `image_url`, а пару `assistant.tool_calls` / `tool`
  нельзя разрывать;
- если провайдер отвергает мультимодальность (`ProviderError` с признаками image/400),
  агент выбрасывает картинки из истории и повторяет ход текстом, сообщив об этом в UI;
- `vision_mode = auto|on|off`, `vision_max_images`, `vision_max_px` в настройках;
  в `auto` слепые модели (whisper/tts/embedding/rerank) определяются по имени.

### 2.2 Модель не знала, на что нажимать

`browser_tab_click(selector=...)` требовал CSS-селектор. Угадать его невозможно: на YouTube
кнопка паузы — это `ytd-player` → shadow root → `button[aria-label="Пауза"]`, и
`document.querySelector` туда не заходит.

Решение — `browser_page_snapshot` возвращает нумерованную карту:

```
СТРАНИЦА: MrMarmok - YouTube
URL: https://www.youtube.com/@MrMarmok/videos
прокрутка: 0/2400 (вверху) | вьюпорт 1280x720 | элементов 187 (обозрено 2411)
ЗАГОЛОВКИ: h1: MrMarmok · h2: Видео
МЕДИА НА СТРАНИЦЕ: video ПАУЗА 42/620с громк.80% 1280x720
ЭЛЕМЕНТЫ (жми browser_act(index=N)):
  [1] link "Видео канала" -> /@MrMarmok/videos y=88
  [14] button "Пауза" y=412
  [15] link "Охота на Разумных Животных" -> /watch?v=AAA y=520
  [23] input type=search "Поиск · Введите запрос" y=12
```

Дальше `browser_act(index=15)` — и видео открыто. Модель видит перечень кнопок вместо задачи
«придумай селектор».

**Ключевые технические решения:**

- элементы хранятся как прямые ссылки в `window.__fluxEls[idx]` → работает внутри shadow DOM,
  не нужно генерировать селекторы;
- обход рекурсивный по shadow roots (глубина ≤ 6, лимит 12000 узлов, флаг `truncated`);
- отбрасываются `display:none` / `visibility:hidden` / `opacity:0` / нулевого размера;
- подпись собирается из `aria-label` → `title` → `alt` → `placeholder` → `name` → `value`
  → `textContent`, у полей ввода `aria-label` и `placeholder` склеиваются;
- перед действием проверяется `el.isConnected` — если SPA перерисовала DOM, тулз говорит
  «элемент исчез, сделай снимок заново» вместо клика в пустоту;
- индексы живут до навигации. Это правильно: после перехода страница другая;
- синтетический `dispatchEvent('click')` многие плееры игнорируют, поэтому `browser_act`
  добивает реальным вводом через CDP `Input.dispatchMouseEvent` по координатам элемента.

**Найденный по пути баг:** скан медиа шёл через `document.querySelectorAll('video,audio')`,
который не проникает в shadow root. Плеер YouTube лежит внутри `ytd-player`, поэтому
`browser_media_control` отвечал «на странице нет media-элемента» именно там, где нужнее всего.
Исправлено во всех трёх местах (снапшот, управление, диагностика) — найден тестом на jsdom.

---

## 3. Медиа: три уровня

| Уровень | Механизм | Покрытие |
|---|---|---|
| **системный** | GSMTCS (`GlobalSystemMediaTransportControlsSessionManager`) через WinRT в скрытом PowerShell; фолбэк — медиа-клавиши `SendInput` | всё, что зарегистрировано в ОС: Chrome, Edge, Spotify, Яндекс Музыка (десктоп), VK Музыка, плеер Windows |
| **страница** | `browser_media_control` (обход shadow DOM) | конкретная вкладка: play / pause / toggle / next / prev / mute / unmute / vol50 / seek±N / rateX |
| **свой плеер** | `<audio>` внутри окна FLUX, команды по SSE | «включи музыку у себя»: плейлист, повтор трека, перемешивание, громкость, ничего внешнего не запускается |

GSMTCS даёт и метаданные: трек, исполнитель, альбом, позиция, длительность, какое приложение
играет и какие команды оно поддерживает. `media_status` дополнительно опрашивает вкладки
музыкальных сервисов и показывает оба источника.

Громкость: точно — через `pycaw` (если установлен), иначе шагами медиа-клавишами
(честно сообщается в ответе).

`media_open_service(service, query)` открывает YouTube Music / Яндекс Музыку / VK Музыку /
Spotify / YouTube и ищет трек. **Потоки из этих сервисов не извлекаются** — они защищены,
и это нарушение их условий использования. Управление плеером работает штатно, этого достаточно.

Настройка `music_source = ask` — если пользователь не уточнил, где включить музыку, агент
спрашивает и предлагает свой плеер (как и просили).

---

## 4. Расширения браузера: что можно и чего нельзя

Сделано:
- `ext_list` — инвентаризация профилей Chrome, Edge, Brave, Vivaldi, Opera, Яндекс Браузера:
  `manifest.json` (MV2 и MV3), разрешение `__MSG_*__` через `_locales/<default_locale>/messages.json`,
  версии, разрешения, хосты, `content_scripts`, popup, options;
- `ext_risk_report` — ранжирование разрешений: `debugger`, `<all_urls>`, `webRequestBlocking`,
  `cookies`, `history`, `nativeMessaging`, `management`, `proxy`, `tabCapture`, `desktopCapture`,
  `declarativeNetRequest` и т.д. Набор `<all_urls>` + `cookies` + `history` + `webRequest` —
  типичный профиль шпионского аддона, помечается красным;
- `ext_open(id)` — открывает `chrome-extension://<id>/<popup|options>` как обычную вкладку,
  дальше её ведут `browser_page_snapshot` / `browser_act`;
- `ext_shortcuts` — читает назначенные команды из `Preferences` профиля; нажать комбинацию
  от имени ОС можно `keyboard_hotkey`;
- `ext_find(query)` — подбирает аддон под задачу.

**Честное ограничение.** Вызвать API чужого расширения из внешнего процесса нельзя — Chrome
такого не предоставляет. Реально доступны три пути: страницы расширения (popup/options),
его горячие клавиши и наше собственное расширение `extension/` (FLUX Bridge), которое как раз
и даёт привилегированный доступ к живому Chrome через `chrome.debugger`. Поэтому
«использовать уже скачанные расширения» = управлять их UI и дёргать их команды, а не
подключаться к их внутренностям.

---

## 5. Страж ПК и почему привилегии за шлюзом

Агент, который сам решает завершить процесс или удалить значение реестра, сломает систему на
первой галлюцинации модели. Поэтому между моделью и ОС стоит `app/guard_policy.py`.

### Три уровня

| Уровень | Действия | Поведение |
|---|---|---|
| **DENY** | см. список ниже | не выполняется никогда, ни в каком режиме, ни по какому токену |
| **CONFIRM** | `process_kill`, `quarantine`, `block_launch`, `policy_restore`, `autostart_remove`, `service_disable`, `file_restore` | запрос в окно FLUX → «Разрешить / Запретить» → одноразовый токен |
| **READ** | вся инвентаризация | свободно |

### Запрещено всегда

- антивирусы и защитные подсистемы: MsMpEng, WinDefend, Sense, SecurityHealthService, wscsvc,
  mpssvc, а также Kaspersky, ESET, Malwarebytes, CrowdStrike, SentinelOne, Carbon Black,
  Sophos, McAfee, Avast/AVG, Bitdefender, Dr.Web, 360, QQ — их нельзя ни завершать,
  ни останавливать, ни блокировать;
- отключение UAC (`EnableLUA=0`), SmartScreen, брандмауэра;
- изменение `Winlogon\Shell`, `Userinit`, `Notify` — ломает вход в систему;
- удаление и карантин чего-либо в `C:\Windows`, `System32`, `SysWOW64`, `WindowsApps`,
  `ProgramData\Microsoft\Windows Defender`;
- необратимые команды: `format`, `diskpart`, `vssadmin delete shadows`,
  `wmic shadowcopy delete`, `bcdedit`, `cipher /w`, `shutdown /s|/r /t 0`, `reg unload/save`;
- **установка** ограничений (`DisableTaskMgr` и т.п.). Снимать — можно, ставить — нельзя.
  Асимметрия намеренная: модуль пригоден для лечения машины и непригоден для её блокировки;
- безвозвратное удаление файлов вообще — только карантин с sha256 и журналом, откуда
  `guard_file_restore` возвращает обратно.

### Подтверждение

```
модель: guard_process_kill(target="suspect.exe")
  -> ToolResult(ok=False, "ЖДЁТ ПОДТВЕРЖДЕНИЯ…", data={need_confirm:"a1b2c3d4e5"})
  -> SSE guard_confirm -> модалка в окне FLUX «🛡 FLUX просит разрешение»
пользователь: «Разрешить»  -> POST /api/guard/confirm -> токен a1b2c3d4e5
модель: guard_process_kill(target="suspect.exe", confirm_token="a1b2c3d4e5")  -> выполнено
```

Токен одноразовый, TTL 120 с, привязан к паре (действие, цель): чужим действием или другой
целью его не использовать. Все решения (включая `DENY` и `REJECTED`) пишутся в
`data/guard_audit.jsonl` и видны через `guard_audit_log`.

`guard_mode`: `confirm` (по умолчанию) · `auto` (без запросов — запретный список действует
всё равно) · `off` (только чтение).

### Что ищет инвентаризация

Run / RunOnce (HKCU, HKLM, Wow6432Node) · `Environment` · `BootExecute` · папки Startup
(пользователь и все) · планировщик задач (`schtasks /query /v`, CSV) · службы с автозапуском
(CIM) · **WMI-подписки** (`__EventFilter`, `CommandLineEventConsumer`, `ActiveScriptEventConsumer`
в `root\subscription`) · IFEO-перехваты (`Debugger` у чужого образа) · Winlogon ·
AppInit_DLLs · LSA Security Packages · SafeBoot · Active Setup · UrlSearchHooks ·
ShellServiceObjectDelayLoad · BHO · расширения браузеров.

Эвристики подозрительности: исполняемый файл в `temp` / `appdata` / `public` / `perflogs` /
`inetcache`; `powershell -enc` / `-w hidden` / `-nop` / `-noni`; `mshta`, `rundll32 javascript`,
`certutil -urlcache`, `bitsadmin /transfer`, `regsvr32 /i:http`, `wscript`/`cscript`,
`IEX(`/`Invoke-Expression`/`DownloadString`/`FromBase64String`; имя файла из 16+ случайных
символов; отсутствие версионной информации у PE.

`guard_policy_status` находит то, чем малварь мешает лечиться: `DisableTaskMgr`,
`DisableRegistryTools`, `DisableCMD`, `DisablePowerShell`, `NoRun`, `NoFolderOptions`,
`NoControlPanel`, `NoDrives`, `DisableLockWorkstation`, а также `DisableAntiSpyware` /
`DisableRealtimeMonitoring` у Defender и `EnableLUA=0`. `guard_policy_restore(only=...)`
снимает их группами (`taskmgr`, `registry`, `cmd`, `run`, `folders`, `defender`, `uac`, `all`),
сохраняя прежние значения в `data/guard_policy_backup.json`. Для ветки HKLM нужны права
администратора — при отказе тулз так и скажет.

---

## 6. F12 / DevTools — объективное ограничение

Когда к вкладке уже подключён DevTools, Chrome отдаёт
`Another debugger is already attached to the browser`, и **никакой** второй отладчик не
подключится — ни CDP, ни `chrome.debugger` из расширения. Это не баг FLUX, а защита Chrome
от двух конкурирующих отладчиков.

Что делаем:
1. детектируем ошибку и возвращаем модели внятную инструкцию вместо стека (уже есть
   `FRIENDLY_HINT`, дополним отдельным случаем про DevTools);
2. предлагаем три рабочих обхода: закрыть DevTools · включить `chrome://inspect` →
   «Allow remote debugging for this browser instance» · использовать FLUX Bridge;
3. для страниц с открытым DevTools остаётся ОС-уровень: `screen_capture_browser_tab`
   не сработает, но `screen_capture_window` (PrintWindow по HWND) и `os_*`/`mouse_*`/
   `keyboard_*` — работают всегда, потому что не зависят от CDP.

Полноценное решение — тулз `browser_devtools_state`, который сообщает, подключён ли отладчик,
и автоматически переключает стратегию на оконный захват + ввод через ОС.

---

## 7. Discord и другие десктоп-приложения

«Открой Discord и напиши в канал „всем спокойной ночи“» делается через **UI-автоматизацию
десктопного приложения** (UIAutomation / `pywinauto` на Windows, AppleScript на macOS):
найти окно → дерево элементов → список серверов/каналов → поле ввода → текст → Enter.
Это тот же принцип, что у AutoHotkey: действия выполняются от имени пользователя в его окне.

Чего делать **не будем**: логиниться пользовательским токеном в Discord API (self-botting).
Это прямое нарушение их ToS и заканчивается баном аккаунта — не та цена за удобство.
Для серверов, где ты админ, есть официальный Bot API с вебхуками — вот он легален, и под
него можно сделать отдельный тулз, если нужно.

План: `app/tools/desktop.py` — `desktop_app_open`, `desktop_ui_tree`, `desktop_find_element`,
`desktop_type_text`, `desktop_click`, `desktop_send_message(app, chat, text)` с готовыми
профилями для Discord и Telegram Desktop, обязательным предпросмотром текста и подтверждением
перед отправкой (сообщение уходит живым людям — случайно отправить черновик дороже,
 чем лишний клик).

---

## 8. Попутно исправлено

| Что | Было | Стало |
|---|---|---|
| `Registry.dispatch` | синхронный тулз выполнялся в event loop: `shell_run` с таймаутом 30 с, PowerShell, чтение большого файла **останавливали весь сервер** — SSE-чат, `/api/events` и срабатывание таймеров замирали | синхронные тулзы уходят в `asyncio.to_thread`; loop продолжает тикать (проверяется тестом) |
| подбор скиллов | читал только первые **400 знаков** тела: инструкция «поставь музыку на паузу» лежала в конце файла, и скилл никогда не подбирался | тело читается целиком (до 6000 знаков), имя `x3` и описание `x2` весят больше, двойной счёт токенов убран |
| `guard_process_list` | падал, если в системе нет `ps` | фолбэк на прямое чтение `/proc` |
| `guardian.py` | **не был импортирован `re`** — `_suspicion()` и `_exe_from_cmd()` упали бы при первом же вызове на Windows | добавлен; покрыто тестами |
| `_norm()` в политике | приводил `/` → `\` для **всей** строки, из-за чего `shutdown /s /t 0` и `cipher /w:c:` не совпадали с запретным списком | отдельный `_norm_cmd()` к прямым слэшам |
| `guard_mode=off` | глушил и чтение (`autostart_list` не начинается с `list`) | явное множество `READ_ACTIONS` + `is_read_action()` |
| скан медиа | `querySelectorAll('video,audio')` не проникал в shadow root → «нет media-элемента» на YouTube | обход shadow roots во всех трёх местах |
| поиск кнопок next/prev | то же | глубокий обход |

---

## 9. Тесты

| Файл | Проверок | Что покрывает |
|---|---|---|
| `tests/test_guardian_browser.py` | **213** | запретный список (Defender/АВ/UAC/Winlogon/системные каталоги/необратимые команды/асимметрия «снять можно — поставить нельзя»), работа в режимах `confirm`/`auto`/`off`, одноразовость и привязка токенов, TTL, аудит-лог, эвристики подозрительности (7 «плохих» и 3 «хороших» командных строки), инвентаризация расширений на синтетическом профиле Chrome (MV2/MV3, `__MSG_*__`, ранжирование риска), зрение (ресайз, JPEG, лимиты, auto/on/off), карта страницы (формат вывода, состояние плеера, limit), медиа (фонотека, сервисы, диагностика), карантин с возвратом файла, неблокирующий dispatch, целостность реестра и retrieval |
| `tests/jsdom/page_snapshot.test.cjs` | **64** | встроенный JS на **настоящем DOM**: страница-макет YouTube с двумя shadow roots; обход теневых корней, подписи через aria-label/placeholder, пропуск `display:none`, последовательная нумерация, `window.__fluxEls`, `data-flux-id`, состояние плеера; `browser_act` click/type/clear/select/press (включая «вариант не найден → список опций»), несуществующий индекс, исчезнувший элемент; `browser_act_text` с регистром и несколькими кандидатами; `browser_media_control` pause/play/toggle/vol/mute/seek±/rate/stop/next-in-shadow-root/неизвестная команда; отключение обхода shadow DOM; лимит элементов и флаг обрезки |
| `tests/check_js.py` | — | все встроенные JS-блоки через `node --check` + проверка, что не осталось плейсхолдеров `__X__` |
| `tests/test_timers_screen.py` | 146 | v2.8: таймеры, PNG-кодер, скриншоты |
| `tests/test_events_sse.py` | 22 | v2.8: сквозной SSE |
| `tests/smoke_ui.py` | 24 | сервер + UI + retrieval |
| `tests/e2e_mock.py` | — | провайдер → агент → тулзы → SSE, регрессий нет |

Итого **445 автоматических проверок**, все зелёные.

Запуск jsdom-теста:
```bash
cd tests/jsdom && npm install jsdom && cd ../..
node tests/jsdom/page_snapshot.test.cjs
```

---

## 10. Дальше

| Итерация | Содержание |
|---|---|
| **v2.10** | `desktop.py`: Discord/Telegram Desktop через UIAutomation, предпросмотр и подтверждение перед отправкой; `browser_devtools_state` и автопереключение на оконный захват при занятом DevTools |
| **v2.11** | пункт 2 ТЗ: загрузка изображений/файлов/каталогов в чат, рекурсивный обход и анализ |
| **v2.12** | пункт 4 ТЗ: статический анализ скачанного (PE, энтропия, обфускация, сигнатуры) **без запуска**; автопроверка загрузок |
| **v2.13** | пункт 5 ТЗ: SearXNG-ридер и кроулер ссылок |
| **v2.14** | пункт 6 ТЗ: лицензии, HWID, keygen, админ-панель, отзыв |
| **v2.15** | пункт 6/7 ТЗ: Nuitka-сборка, VERSIONINFO, пайплайн подписи, инсталлеры, архив |
