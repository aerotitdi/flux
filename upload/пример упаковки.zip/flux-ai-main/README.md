# FLUX 2.0 Desktop

Десктопный ИИ-ассистент: чат в **нативном окне (.exe)** или в **консоли**, микрофон — **браузерный**
(консоль Flux для микрофона больше не открывается), провайдеры по **API-ключу** (OpenAI-совместимые:
orcarouter, openrouter, openai, ollama…), **think-auto** (сам решает, думать ли и гуглить ли),
**357 инструментов**, прогон кода на выбираемом движке, управление браузером **по окнам и вкладкам**,
авто-работа со **скиллами** (локальные + каталог NVIDIA build.nvidia.com/skills).

## Соответствие ТЗ (10 пунктов)

| # | Требование | Где реализовано |
|---|---|---|
| 1 | Минимум настроек: выбор поиска и ИИ для чата | верхняя панель: два селекта; остальное спрятано в ⚙ |
| 2 | Только браузерный микрофон, без консоли Flux | `ui/index.html` (getUserMedia/MediaRecorder/WebSpeech), `app/voicelab.py` |
| 3 | think-auto: сам думает, сколько и гуглит ли | `app/think.py` + авто-поиск в `app/agent.py` |
| 4 | 300+ не повторяющихся тулзов | `app/tools/*` — **357 шт**, retrieval top-k (`app/tools/registry.py`) |
| 5 | Тест кода с выбором движка | `app/tools/codrun.py`: python, node, java, c, cpp, go, rust, ruby, php, bash, powershell, sql, lua, perl, kotlin, ts |
| 6 | Видит каждое окно и каждую вкладку отдельно | `app/browser_cdp.py` (CDP): `browser_windows_list`, `browser_tabs_list` |
| 7 | Переключает/работает с вкладками раздельно | `browser_tab_switch/navigate/click/type/eval/screenshot/...` (по targetId) |
| 8 | Чат в консоли, лучше — в .exe | `python main.py --console`; `.exe` = `packaging/build_exe.bat` → FluxChat.exe |
| 9 | Выбор микро/голоса Flux + API-key провайдеры + скиллы | ⚙ → «Голос и микрофон», модалка «Добавить соединение» (как Open WebUI), `app/skills.py` |
| 10 | Чат как .exe для рынка | PyInstaller-сборка: окно WebView2 + консольный exe |

## Быстрый старт

```bash
pip install -r requirements.txt
python main.py            # чат в нативном окне (Windows: WebView2; иначе откроется браузер)
python main.py --web      # чат в браузере (микрофон браузера)
python main.py --console  # терминальный чат: /model /search /think /tools /reset /exit
python main.py --selftest # отчёт: 357 тулзов, категории, подключение, CDP
```

## Сборка .exe (Windows)

```bat
packaging\build_exe.bat
```
Получится `dist\FluxChat\FluxChat.exe` (окно чата, без консоли) и
`dist\FluxConsole\FluxConsole.exe` (терминальный чат). Конфиг и данные лежат рядом с exe.

## Инсталлер (Windows)

```bat
installer\Flux2-Installer.bat                                :: по умолчанию в %LOCALAPPDATA%\Flux2
installer\Flux2-Installer.bat -InstallDir D:\flux2 -Autostart :: свой каталог + автозапуск
installer\Flux2-Installer.bat -SkipExe                       :: быстро: без сборки pyinstaller
```
Инсталлер: проверяет Python 3.10+, копирует приложение, создаёт изолированный `.venv`,
ставит зависимости, собирает `FluxChat.exe` + `FluxConsole.exe`, вешает ярлыки
«FLUX 2.0» (окно) и «FLUX 2.0 Console» (терминал) на рабочий стол, прогоняет `--selftest`.
Удаление: `installer\uninstall.ps1` (ярлыки, автозапуск, каталог).

## Подключение провайдера (как на скрине Open WebUI)

⚙ → **Подключения** → **+ Добавить соединение**:
- **URL / Базовый адрес API**: например `https://api.orcarouter.ai/v1`
- **Вход**: `Bearer` + **Ключ API** (глазик показывает/скрывает)
- **⟳** — тянет список моделей с конечной точки `/models`
- **› Раскрытые**: передача cookie, заголовки JSON, **сквозные параметры** (`thinking, output_config`),
  ID-префикс, провайдер, IDs моделей (пусто = все из `/models`), теги
- **Сохранить** → модель появляется в селекте на верхней панели.

Тип API — Chat Completions (OpenAI-совместимый, streaming + function calling).

## Голос

- **Микрофон**: браузерный (в окне .exe и в браузере). Выбор устройства — ⚙ → «Голос и микрофон»
  (список подтягивается из браузера через `enumerateDevices`, после разрешения микрофона появляются имена).
- **Распознавание**: `auto` = браузерное Google/WebSpeech первым, при ошибке `network` — запись и
  распознавание на бэкенде (`/audio/transcriptions` провайдера или локальный whisper);
  также режимы `browser`, `provider`, `whisper`.
- **Голос Flux (озвучка)**: движок по умолчанию — **text-to-speech.wingetgui.com**
  (`POST /api/synthesize` → mp3, 322+ голоса, скорость/тон те же): файл сохраняется в `data/audio`,
  кнопка 🔊 у ответа озвучивает, кнопка ⬇ — скачивает mp3. Альтернативы в ⚙ → «Голос»:
  `edge` (локальный edge-tts), `browser` (speechSynthesis), `off`.
  Сервис троттлит частые запросы — в клиенте ретраи с бэкоффом 2 с.

## Интерфейс (меню как на референсе)

Слева вертикальный сайдбар: 🏠 **главная** — космическая сцена + строка статуса
(«Слушаю…», «Думаю… (brief + поиск)», «🔧 browser_tabs_list», «Готово: …», «Говорю…»);
💬 **чат** — лента сообщений с тулз-чипами и скриншотами; ⚙ **настройки**; ☀/ **тема**;
 (внизу) — авто-озвучка ответов. Внизу всегда панель ввода: 🎤 микрофон + поле + «Отправить».

### UI = эталон пользователя (НЕ МЕНЯТЬ)

`ui/index.html` принят из файла пользователя **байт-в-байт без правок** (меню, вкладки
⚙ → Подключения/Голос/Код/О системе, сайдбар, сцены-канвас 🌌  ☀ , гейт кодового
слова «флюкс»). Любые новые возможности добавляются ТОЛЬКО сервером и тулзами, не разметкой:
Windows Automation, таймеры и скриншоты доступны агенту (тулзы `windows_*`, `timer_*`,
`screen_*`) и через API (`/api/win/*`, `/api/timers`, `/api/events`), меню не трогается.
Стражи неизменности: `tests/check_js.py` (синтаксис скриптов, id-ссылки) и
`tests/jsdom/ui_click.test.cjs` (39 кликов по меню: вкладки, сцены, модалки, гейт
кодового слова, отправка в /api/chat) — оба прогоняются на каждом коммите UI.

## v2.7: подключение к ЖИВОМУ Chrome без закрытий

FLUX больше НИКОГДА не закрывает твой Chrome по своей инициативе. Подключение к живому
браузеру без рестарта: в Chrome открой `chrome://inspect/#remote-debugging` и поставь галку
**'Allow remote debugging for this browser instance'** (один раз) — Chrome сам откроет
debug-эндпоинт, а FLUX найдёт её через файл `DevToolsActivePort` в профиле и подключится
мгновенно, со всеми твоими вкладками. Альтернатива один раз: тулз
`browser_enable_debug_shortcut` (прописывает `--remote-debugging-port=9222` в ярлыки Chrome;
порт появится со следующим обычным запуском). `browser_restart_user` — только если ТЫ попросил.
Индикатор в шапке: 🟢 = живой CDP (показывает браузер и число вкладок), 🔴 = кликни и следуй подсказке.

## v2.6: доступ к твоему Chrome изначально + think-medium + без крашей

- **Доступ к ТВОЕМУ Chrome с момента старта FLUX**: фоновый boot-поток при запуске сам
  подключается/поднимает/перезапускает твой Chrome с портом 9222 и реставрацией вкладок.
- **Рестарт больше не крашит FLUX**: убиваются только процессы браузера пользователя;
  окно самого FLUX (app-mode chrome с профилем chrome-app-profile) исключается по cmdline-маркеру.
- **think по умолчанию = medium (средне-тяжёлый), всегда**: план из 3-5 шагов с проверкой
  ключевых (reasoning_effort=medium, budget 6144); deep/brief/auto переключаются как раньше
  (`/think`, `agent_set_think`).
- Никакой about:blank при запуске Chrome (см. v2.5).

## Как проверить порт 9222 (CDP)

- **В FLUX**: точка в шапке окна — 🟢 зелёная = CDP жив (в тултипе браузер и число вкладок),
  🔴 красная = не подключён; **клик по точке** = подключиться/переподключиться.
  Эндпоинт для проверки: `GET /api/cdp` → `{ok, browser, tabs}`.
- **В браузере**: `http://127.0.0.1:9222/json/version` (JSON с версией Chrome) и
  `http://127.0.0.1:9222/json/list` (список вкладок).
- **В консоли Windows**: `netstat -ano | findstr :9222` (LISTENING = жив) или
  PowerShell `Test-NetConnection 127.0.0.1 -Port 9222` → `TcpTestSucceeded : True`.
- **Тулзом**: спроси у агента `browser_status`.

## Настоящий браузер пользователя (v2.5)

CDP не умеет подключаться к УЖЕ запущенному Chrome без флага --remote-debugging-port
(подтверждено доками Chrome DevTools MCP / browserless). Поэтому FLUX делает сам:
1) порт 9222 жив - подключается; 2) Chrome закрыт - поднимает его с дефолтным профилем и портом;
3) Chrome запущен без порта - **аккуратно перезапускает ЕГО ЖЕ** (graceful taskkill) с
--remote-debugging-port и --restore-last-session: все вкладки и окна восстанавливаются,
а агент видит их через browser_tabs_list без гадания по заголовкам окон.
Изолированный профиль больше НЕ поднимается по умолчанию (cdp_mode=user; можно isolated в конфиге).
Новый тулз browser_restart_user - форс-рестарт твоего Chrome с вкладами.
Модель больше не просит «закрой браузер» и не объясняет внутренние механизмы (правило в промпте).

**Кнопки копирования**: у каждого сообщения (твоего и ответа) кнопка ⧉ копирует текст
РОВНО как есть - со всеми скрытыми знаками, включая разметку *-...-* (как копирование кода).

## Управление компьютером (JARVIS, v2.4)

Семейство `computer` (30 тулзов) закрывает список «тулы.txt»: окна ОС (список / фокус / свернуть /
развернуть / восстановить / закрыть / переместить / свернуть всё), мышь (click / double / move /
drag / scroll / position), клавиатура (type / press / hotkey / key_down_up), экран (screenshot /
size / pixel), OCR (Windows.Media.Ocr через PowerShell WinRT или tesseract), ui_tree
(UIAutomation, нужен pywinauto), процессы (list / kill / start), shell_run, app_launch, clipboard.
Бэкенды: Windows — ctypes user32 + SendInput + PowerShell (работает БЕЗ доп. зависимостей),
Linux — xdotool/wmctrl, macOS — osascript; если установлен **pyautogui** — используется он.
«Сверни браузер» теперь = `os_window_minimize`, а не отказ модели.

## Кодовое слово и лимиты (v2.2)

- **Отправка по кодовому слову** (⚙ → О системе → «Отправка по кодовому слову»):
  `off` — отвечает всегда; `start` (по умолчанию) — только если фраза НАЧИНАЕТСЯ с
  «флюкс / люкс / flux» (регистр и пунктуация не важны); `any` — слово где угодно в фразе.
  Без срабатывания запрос модели не уходит: чип «🚫 кодовое слово не услышано» и статус-подсказка,
  текст остаётся в поле. Работает и для текста, и для голосового ввода.
- **Лимит итераций инструментов снят** (max_tool_rounds = 999).
- **Браузер**: тулзы сами поднимают CDP при первом обращении (без простыни ошибок);
  `browser_launch(profile=user)` поднимает ТВОЙ настоящий Chrome с твоими вкладками
  (если Chrome закрыт; иначе подскажет закрыть и повторить); `flux` — изолированное окно;
  Chrome ищется раньше Edge во всех расположениях.

## Дополнения v2.1

- **Авто-подбор пути API**: если `/chat/completions` отдаёт 404 или HTML веб-интерфейса
  (OrcaRouter и т.п.), клиент сам пробует `/v1/chat/completions` и наоборот; удачный путь
  запоминается в соединении (`api_path`), ошибка объясняется по-человечески.
- **Ollama как в Open WebUI**: в ⚙ → «Подключения» блок «Ollama API» (тумблер + адрес
  `http://127.0.0.1:11434` + «Подключить») — создаёт соединение Ollama (`/v1/models`),
  тянет модели и сразу ставит первую активной.
- **Интерпретатор кода прямо в чате**: у каждого код-блока ответа — панелька с языком,
  «▶ запустить» и «⧉». Кнопка шлёт код на бэкенд (`/api/runcode`) и выполняет на движке
  (python, java, c, cpp, go, rust, js, ts, ruby, php, bash, powershell, sql, lua, perl, kotlin),
  вывод (rc/STDOUT/STDERR) появляется под блоком.
- **Голосовая разметка `*-...-*`** (как в FLUX 1.5): озвучивается ТОЛЬКО текст внутри маркера;
  в чате он подсвечен зелёным, сами символы `*-*` скрыты; статус на домике показывает
  озвученную часть зелёным. Модель помечает суть в 1-2 фразы (правило в системном промпте).
- **Голосовой ввод отправляет сразу**: финальная фраза распознавания не ложится в поле, а улетает в чат.
- **Домик не перекидывает в чат**: ответ живёт в статусе и сцене, полная лента — по 💬.
- **Сцена «Космос» по умолчанию** (🌌): туманности, две мини-галактики, чёрная дыра с
  аккреционным диском, фотонным кольцом и падающими частицами; 🌀 — улучшенная галактика
  (балдж, пылевые полосы, скопления, гало); 🪐 Уран и ☀ система остались.
- **Скругления уменьшены** (6-9px вместо 10-16).

## Окно чата: движок (Chrome / Edge / WebView2)

По умолчанию `auto`: FLUX **находит Google Chrome** и открывает окно в app-режиме
(`chrome --app=http://127.0.0.1:8642` + отдельный профиль) — окно без вкладок и панелей,
микрофон и распознавание Google работают как в обычном Chrome. Закрыл окно — FLUX завершился.
Если Chrome нет: Edge app-mode → WebView2 (pywebview) → обычная вкладка.
Переключение: ⚙ → «О системе» → «Окно чата (движок)»: `auto|chrome|edge|webview|web`
(применяется при следующем запуске). Флаги запуска: `--web` (вкладка), `--console` (терминал).

## think-auto и авто-гуглинг

`app/think.py` по запросу решает: `off | brief | deep` + нужен ли веб-поиск до ответа.
Маркеры: «сегодня/новости/курс/погода/актуально» → авто-поиск; «докажи/спроектируй/оптимизируй/сложные
вопросы» → deep; «быстро/кратко» → off. Сквозные параметры соединения (`thinking`, `reasoning_effort`,
`output_config`) передают бюджет раздумий провайдеру. Переключение: ⚙ или `/think`, тулз `agent_set_think`.

## Браузер (окна + вкладки)

Запусти браузер с отладкой (или попроси агента вызвать `browser_launch`):
```bash
chrome --remote-debugging-port=9222 --user-data-dir=~/.flux2/cdp-profile
```
Агент видит список окон и вкладок (`browser_windows_list`, `browser_tabs_list`), переключает
(`browser_tab_switch`), скриншотит (`browser_tab_screenshot` — картинка приходит в чат), читает текст,
кликает, вводит, скроллит, ждёт селекторы, читает cookie, печатает PDF — всё по targetId конкретной вкладки.

## Скиллы

- Локальные: `skills_bundled/*.md` (web-research, code-run-verify, browser-tabs-work, voice-reply-style,
  fact-check, data-analysis, windows-automation).
- Удалённые: каталог **NVIDIA/skills** (build.nvidia.com/skills, 400+), индекс кэшируется на 24 ч,
  тела скиллов качаются по требованию.
- Авто-режим (вкл по умолчанию): на каждый запрос подбирается 1–2 релевантных скилла, их инструкции
  впрыскиваются в системный промпт; в чате появляется чип «📚 скилл».

## Инструменты (425)

Категории: text 50, encode 39, math 33, browser 33, agent 29, formats 28, computer 26,
search 24, files 22, memory 18, convert 18, datetime 18, code 18, net 17, **screen 15**,
**windows 14**, **timers 13**, voice 10.
В запрос модели уходит не весь каталог, а retrieval top-14 релевантных + ядро (`web_search`, `code_test`,
`browser_tabs_list`, `browser_tab_text/screenshot/switch`, `voice_speak`, `mem_remember/recall`,
`wiki_summary`, `weather_now`, `translate_text`, `agent_tools_search`, `skills_list`).
Посмотреть: `/tools <запрос>` в консоли, `GET /api/tools?q=...`, тулзы `agent_tools_search`,
`agent_tools_categories`.

## Тесты

```bash
python main.py --selftest
python tests/e2e_mock.py        # mock-провайдер OpenAI-формата -> агент -> тулзы -> SSE
python tests/win_bridge_e2e.py  # Windows-мост: протокол, 14 команд, реконнект, тулзы, API, UI
python tests/test_timers_screen.py  # 112 проверок: таймеры, PNG-кодер, WAV, контракты screen
python tests/test_events_sse.py     # 21: SSE-события таймеров без хода чата
python tests/check_js.py            # страж UI: node --check скриптов, id-ссылки, сцены/вкладки
node tests/jsdom/ui_click.test.cjs  # 54 клика по меню: вкладки, сцены, тосты (npm i jsdom в tests/jsdom)
```

## Структура

```
flux2/
├─ main.py               # вход: окно(.exe) / --web / --console / --selftest
├─ requirements.txt
├─ packaging/build_exe.bat   # сборка FluxChat.exe + FluxConsole.exe
├─ ui/index.html         # SPA: чат, модалки (подключения как в Open WebUI, голос, код)
├─ skills_bundled/       # локальные SKILL.md
├─ windows_bridge/       # WS-сервер 8643: pywinauto UIA + mss (win_bridge.py, README_windows.md)
├─ tests/e2e_mock.py
├─ tests/win_bridge_e2e.py
└─ app/
   ├─ server.py          # aiohttp: SSE-чат, /api/stt, /api/tts, CRUD подключений
   ├─ agent.py           # цикл: think-auto -> авто-поиск -> скиллы -> тулзы -> ответ
   ├─ think.py           # роутер раздумий
   ├─ providers.py       # OpenAI-совместимый клиент (stream, tools, passthrough)
   ├─ skills.py          # bundled + NVIDIA/skills, авто-подбор
   ├─ browser_cdp.py     # CDP: окна/вкладки/скриншоты/ввод
   ├─ bridge.py          # WS-мост расширения FLUX Bridge (8642)
   ├─ winbridge.py       # клиент Windows-моста (8643): реконнект 3с, keepalive 20с, лог команд
   ├─ voicelab.py        # микрофоны, Edge TTS (голос Flux), STT-маршрутизация
   ├─ memory.py          # память/заметки/todo/kv/таймеры
   └─ tools/             # 404 инструмента по семействам (browser, computer, windows, ...)
```
