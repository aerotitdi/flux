---
name: data-analysis
description: Анализ данных: код-движок python, статистика, таблицы, диаграммы ASCII
---
# Data Analysis
1. Данные приводи к табличному виду (csv/json) инструментами formats_*.
2. Считай статистику кодом: code_test с engine=python (pandas может не быть — используй statistics/csv).
3. Результат покажи таблицей (fmt_table_markdown) и/или misc_ascii_chart.
4. Выводи топ-N выводов, а не сырой дамп.
