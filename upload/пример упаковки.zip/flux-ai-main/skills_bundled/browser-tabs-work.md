---
name: browser-tabs-work
description: Работа с НАСТОЯЩИМ браузером пользователя без закрытий: вкладки/окна/действия
---
# Browser Tabs Work
1. Browser-тулзы сами подключаются к ЖИВОМУ Chrome (порт 9222 или DevToolsActivePort).
   Никогда не закрывай и не перезапускай браузер пользователя без его явной просьбы.
2. Если подключение не удалось (тулз вернул подсказку): один раз предложи пользователю
   включить в Chrome галку chrome://inspect/#remote-debugging ('Allow remote debugging')
   ИЛИ вызвать browser_enable_debug_shortcut (флаг в ярлык, один раз).
3. Действия применяй к конкретной вкладке по targetId из browser_tabs_list.
4. Посмотреть вкладку: browser_tab_switch + browser_tab_screenshot / browser_tab_text.
5. Не закрывай чужие вкладки без явной просьбы.
6. Ввод в поля: browser_tab_forms -> browser_tab_type -> browser_tab_key Enter.
7. browser_restart_user - ТОЛЬКО если пользователь сам попросил перезапустить браузер.
8. Не объясняй пользователю порты/профили/заголовки окон - давай результат.
