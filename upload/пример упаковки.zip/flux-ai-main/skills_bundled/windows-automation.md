---
name: windows-automation
description: Управление Windows-приложениями через UIA-мост (windows_*): запуск, клики, ввод текста, скриншоты окон, чтение элементов
---
# Windows Automation (мост 8643, pywinauto UIA)
1. Проверь мост: windows_status. OFF — один раз предложи пользователю
   `python windows_bridge/win_bridge.py` (README_windows.md) и не подменяй windows_* координатными mouse_*.
2. Найди цель: windows_apps (title/process/hwnd). Нет нужного — windows_launch(path='notepad.exe').
3. Разведка элементов: windows_children(app='Блокнот') → title / control_type / auto_id.
   Кликай и вводи ТОЛЬКО по этим критериям (UIA), никогда «на глаз» по координатам.
4. Действия: windows_click(app, title='Сохранить', control_type='Button');
   windows_type(app, auto_id='15', text='привет', replace=true);
   windows_send_keys(app, keys='^s') — горячие клавиши (pywinauto-синтаксис).
5. Диалоги появляются не мгновенно: windows_wait(app, title='Сохранить как', timeout_s=10),
   затем windows_children уже у диалога.
6. Контроль результата: windows_screenshot(app) (картинка придёт в чат) или windows_read(app, control).
7. Нестандартные сценарии: windows_eval(app, code="win.child_window(title='Файл', control_type='MenuItem').click_input()")
   или code="[ (c.element_info.control_type, c.window_text()) for c in win.descendants()[:50] ]".
8. Типовой сценарий «печать в блокнот + сохранение»:
   windows_launch(path='notepad.exe') → windows_wait(app='Блокнот') →
   windows_type(app='Блокнот', auto_id='15', text='...') → windows_send_keys(app='Блокнот', keys='^s') →
   windows_wait(app='Блокнот', title='Сохранить как') → windows_type(title='Имя файла:', text='otchet.txt') →
   windows_send_keys(keys='{ENTER}') → windows_screenshot(app='Блокнот').
9. Вкладки Chrome — это browser_* (мост 8642), окна приложений ОС — windows_* (мост 8643). Не путай.
