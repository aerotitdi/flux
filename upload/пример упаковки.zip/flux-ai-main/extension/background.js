// FLUX Bridge: мост chrome.debugger <-> WebSocket FLUX (ws://127.0.0.1:8642/bridge)
// Работает в ЖИВОМ Chrome: без --remote-debugging-port, без рестартов.
// Умеет: управление вкладками/окнами + eval в контексте страницы + wait + screenshot.

let ws = null;
const WS_URL = 'ws://127.0.0.1:8642/bridge';

function log(...a) { console.log('[flux-bridge]', ...a); }

// keepalive: MV3 усыпляет service worker через ~30с простоя - будим себя alarms.
// Минимум periodInMinutes в Chrome — 0.5. Меньше — ошибка.
chrome.alarms.create('flux-keepalive', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === 'flux-keepalive' && (!ws || ws.readyState !== 1)) {
    log('alarm: reconnect');
    connect();
  }
});
chrome.runtime.onStartup.addListener(() => connect());
chrome.runtime.onInstalled.addListener(() => connect());

function connect() {
  if (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)) return;

  let sock;
  try { sock = new WebSocket(WS_URL); }
  catch (e) {
    log('ws ctor failed:', e && e.message);
    setTimeout(connect, 3000);
    return;
  }

  ws = sock;

  sock.onopen = () => {
    if (ws !== sock || sock.readyState !== WebSocket.OPEN) return;
    log('connected to FLUX');
    sock.send(JSON.stringify({ type: 'hello', name: 'flux-bridge' }));
  };

  sock.onmessage = (ev) => {
    if (ws !== sock) return;
    let d;
    try { d = JSON.parse(ev.data); } catch (e) { return; }
    if (d.type === 'ping') {
      if (sock.readyState === WebSocket.OPEN) sock.send(JSON.stringify({ type: 'pong' }));
      return;
    }
    if (d.type === 'req') handle(d);
  };

  sock.onclose = () => {
    if (ws === sock) { ws = null; setTimeout(connect, 3000); }
  };
  sock.onerror = () => { try { sock.close(); } catch (e) {} };
}

connect();

chrome.debugger.onEvent.addListener((src, method, params) => {
  if (ws && ws.readyState === 1) {
    ws.send(JSON.stringify({ type: 'event', tabId: src.tabId, method, params }));
  }
});
chrome.debugger.onDetach.addListener((src, reason) => {
  if (ws && ws.readyState === 1) {
    ws.send(JSON.stringify({ type: 'detach', tabId: src.tabId, reason }));
  }
});

function reply(d, result, error) {
  if (ws && ws.readyState === 1) {
    ws.send(JSON.stringify({ type: 'resp', id: d.id, result: result || null, error: error || null }));
  }
}

async function ensureAttach(tabId) {
  try { await chrome.debugger.attach({ tabId }, '1.3'); }
  catch (e) { if (!/already attached/i.test(String(e && e.message))) throw e; }
}

async function cdpCmd(tabId, method, params) {
  await ensureAttach(tabId);
  return await chrome.debugger.sendCommand({ tabId }, method, params || {});
}

// ===== eval в контексте страницы (аналог консоли F12) =====
async function evalInPage(tabId, code, opts) {
  opts = opts || {};
  try { await cdpCmd(tabId, 'Runtime.enable', {}); } catch (e) {}

  const res = await cdpCmd(tabId, 'Runtime.evaluate', {
    expression: String(code),
    returnByValue: opts.returnByValue !== false,
    awaitPromise: opts.awaitPromise !== false,
    includeCommandLineAPI: opts.includeCommandLineAPI !== false,
    userGesture: opts.userGesture !== false,
    allowUnsafeEvalBlockedByCSP: true,
    generatePreview: false,
    timeout: typeof opts.timeout === 'number' ? opts.timeout : undefined
  });

  if (res && res.exceptionDetails) {
    const ed = res.exceptionDetails;
    const msg = (ed.exception && (ed.exception.description || ed.exception.value))
      || ed.text || 'Page eval error';
    const err = new Error('Page eval error: ' + msg);
    err.pageException = ed;
    throw err;
  }

  return (res && res.result) || { type: 'undefined' };
}

// ===== wait: ждём селектор =====
async function waitInPage(tabId, opts) {
  const sel = opts.selector;
  const timeout = typeof opts.timeout === 'number' ? opts.timeout : 15000;
  const interval = typeof opts.interval === 'number' ? opts.interval : 250;
  if (!sel) throw new Error('wait: selector required');

  const code = `(async () => {
    const t0 = Date.now();
    const sel = ${JSON.stringify(sel)};
    while (Date.now() - t0 < ${timeout}) {
      const el = document.querySelector(sel);
      if (el) return { ok: true, waitedMs: Date.now() - t0 };
      await new Promise(r => setTimeout(r, ${interval}));
    }
    return { ok: false, waitedMs: Date.now() - t0 };
  })()`;

  const r = await evalInPage(tabId, code, { awaitPromise: true });
  return r && r.value;
}

async function handle(d) {
  try {
    const c = d.cmd;
    let r;

    if (c === 'targets') {
      const ts = await chrome.tabs.query({});
      r = ts.filter(t => t.url && !/^chrome(-extension)?:/.test(t.url))
        .map(t => ({
          id: String(t.id), windowId: t.windowId,
          title: t.title || '', url: t.url || '', active: !!t.active
        }));
    } else if (c === 'windows') {
      const wins = await chrome.windows.getAll({ populate: true });
      r = wins.map(w => ({
        windowId: w.id, focused: !!w.focused,
        bounds: { left: w.left, top: w.top, width: w.width, height: w.height },
        tabs: (w.tabs || []).filter(t => t.url && !/^chrome(-extension)?:/.test(t.url))
          .map(t => ({ id: String(t.id), title: t.title || '', url: t.url || '', active: !!t.active }))
      }));
    } else if (c === 'activate') {
      const t = await chrome.tabs.get(d.tabId);
      await chrome.tabs.update(d.tabId, { active: true });
      await chrome.windows.update(t.windowId, { focused: true });
      r = { ok: true };
    } else if (c === 'close') { await chrome.tabs.remove(d.tabId); r = { ok: true }; }
    else if (c === 'new') { const t = await chrome.tabs.create({ url: d.url || 'about:blank' }); r = { id: String(t.id) }; }
    else if (c === 'navigate') { await chrome.tabs.update(d.tabId, { url: d.url }); r = { ok: true }; }
    else if (c === 'reload') { await chrome.tabs.reload(d.tabId); r = { ok: true }; }
    else if (c === 'back') { await chrome.tabs.goBack(d.tabId); r = { ok: true }; }
    else if (c === 'forward') { await chrome.tabs.goForward(d.tabId); r = { ok: true }; }
    else if (c === 'cdp') { r = await cdpCmd(d.tabId, d.method, d.params); }
    else if (c === 'winset') { await chrome.windows.update(d.windowId, d.bounds || {}); r = { ok: true }; }
    else if (c === 'eval' || c === 'evalAsync') {
      if (!d.tabId) throw new Error('eval: tabId required');
      if (typeof d.code !== 'string') throw new Error('eval: code (string) required');
      const result = await evalInPage(d.tabId, d.code, d.opts || {});
      r = { ok: true, result };
    }
    else if (c === 'wait') {
      if (!d.tabId) throw new Error('wait: tabId required');
      if (!d.selector) throw new Error('wait: selector required');
      r = await waitInPage(d.tabId, { selector: d.selector, timeout: d.timeout, interval: d.interval });
    }
    else if (c === 'screenshot') {
      if (!d.tabId) throw new Error('screenshot: tabId required');
      const shot = await cdpCmd(d.tabId, 'Page.captureScreenshot', {
        format: d.format || 'png',
        captureBeyondViewport: !!d.fullPage
      });
      r = { ok: true, dataBase64: shot && shot.data, format: d.format || 'png' };
    }
    else throw new Error('unknown cmd: ' + c);

    reply(d, r, null);
  } catch (e) {
    reply(d, null, String((e && e.message) || e));
  }
}