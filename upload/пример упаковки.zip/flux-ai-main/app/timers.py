"""Таймеры FLUX v2.8: планировщик живёт ВНЕ хода чата (пункт 3 ТЗ).

Раньше дедлайны проверялись только в agent.run_turn(): «напомни через 10 минут»
при молчании пользователя не срабатывало НИКОГДА. Теперь:
  TimerStore — data/timers.json, RLock, атомарная запись (лечит гонку D6);
  Scheduler  — daemon-поток, тик 100 мс через Event.wait() (в простое CPU не грузит);
  parse_when — человекочитаемое время: «300», «5 минут», «1ч30м», «1h30m», «14:30»,
               «завтра 9:00», «в пятницу 18:00», «в 9 вечера», «каждые 10 минут 3 раза»;
  повторы    — без дрейфа (due += interval, а не now + interval);
  рестарт    — просроченные < 1 ч срабатывают сразу с флагом restored,
               более старые помечаются missed (тихо) — сирена не орёт среди ночи.
Срабатывание расходится по трём каналам: notify (звук ОС), events (SSE в UI),
agent.unacked (модель обязана сообщить на следующем ходе).
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from datetime import datetime, timedelta
from typing import Callable, Optional

from .config import app_dir

ON_FIRE: list[Callable[[dict], None]] = []     # хуки срабатывания (server навешивает)
RESTORE_WINDOW_S = 3600                        # просрочка < 1ч = «сработать сразу»

RU_UNITS = {"сек": 1, "секунд": 1, "секунды": 1, "секунду": 1, "секунда": 1,
            "seconds": 1, "s": 1,
            "мин": 60, "минут": 60, "минуты": 60, "минуту": 60, "минута": 60,
            "minutes": 60, "m": 60,
            "ч": 3600, "час": 3600, "часа": 3600, "часов": 3600, "часу": 3600,
            "hours": 3600, "h": 3600,
            "д": 86400, "дн": 86400, "день": 86400, "дня": 86400, "дней": 86400,
            "days": 86400, "d": 86400}
WEEKDAYS = {"понедельник": 0, "вторник": 1, "среда": 2, "четверг": 3, "пятница": 4,
            "суббота": 5, "воскресенье": 6,
            "среду": 2, "пятницу": 4, "субботу": 5,          # «в пятницу» и т.п.
            "пн": 0, "вт": 1, "ср": 2, "чт": 3, "пт": 4, "сб": 5, "вс": 6}
HOURS_WORDS = {"полчаса": 1800, "час": 3600, "полтора часа": 5400}


class WhenError(ValueError):
    pass


def parse_when(text: str, now: float | None = None) -> tuple[float, Optional[float], Optional[int]]:
    """(due_epoch, interval_sec|None, times|None). Бросает WhenError с подсказкой."""
    now = time.time() if now is None else now
    s = (text or "").strip().lower().replace("ё", "е")
    if not s:
        raise WhenError("пусто; примеры: «300», «5 минут», «1ч30м», «14:30», «завтра 9:00»")
    interval, times = None, None

    # «каждые N ... [K раз]» — повторный таймер
    m = re.match(r"^каждые\s+(.+?)(?:\s+(\d+)\s*(раз|раза))?$", s)
    if m:
        base, due = _parse_delta_or_clock(m.group(1), now)
        if base is None:
            raise WhenError(f"не понял период: «{m.group(1)}»")
        interval = base
        times = int(m.group(2)) if m.group(2) else None
        return now + interval, interval, times

    # «N раз каждые ...» / «повторять каждые ...»
    m = re.match(r"^(?:повторять\s+)?(.+?)\s+каждые\s+(.+)$", s)
    if m:
        k = re.match(r"^(\d+)\s*(раз|раза)$", m.group(1))
        base, _ = _parse_delta_or_clock(m.group(2), now)
        if base is None or not k:
            raise WhenError(f"не понял повторы: «{text}»")
        return now + base, base, int(k.group(1))

    delta, due = _parse_delta_or_clock(s, now)
    if delta is not None:                       # «через 5 минут» = одноразовый
        return now + delta, None, None
    if due is not None:
        return due, None, None
    raise WhenError(f"не понял время: «{text}». Примеры: «300», «5 минут», «1ч30м», "
                    f"«14:30», «завтра 9:00», «в пятницу 18:00», «каждые 10 минут»")


def _parse_delta_or_clock(s: str, now: float) -> tuple[Optional[float], Optional[float]]:
    """(delta_sec, due_epoch) — что-то одно или (None, None)."""
    s = s.strip()
    for pref in ("через ", "в ", "на "):
        if s.startswith(pref) and pref != "в " or (pref == "в " and re.match(r"^в\s+\d", s)):
            s = s[len(pref):].strip()
    if s in HOURS_WORDS:
        return HOURS_WORDS[s], None
    # чистое число секунд: «300», «0.5»
    if re.match(r"^\d+(\.\d+)?$", s):
        return float(s), None
    # «1ч30м», «1h30m», «2h», «45m», «90s», «30с»
    m = re.match(r"^(?:(\d+)\s*(?:часов|часа|час|ч|h))?\s*"
                 r"(?:(\d+)\s*(?:минут|мин|м|min|m))?\s*"
                 r"(?:(\d+)\s*(?:секунд|сек|с|sec|s))?$", s)
    if m and any(m.groups()):
        hh, mm, ss = (int(g or 0) for g in m.groups())
        return hh * 3600 + mm * 60 + ss, None
    # «5 минут», «2 часа», «30 секунд»
    m = re.match(r"^(\d+(?:\.\d+)?)\s*([a-zа-я]+)$", s)
    if m:
        unit = RU_UNITS.get(m.group(2).rstrip("."))
        if unit:
            return float(m.group(1)) * unit, None
    # «HH:MM» / «завтра HH:MM» / «в пятницу HH:MM» / «в 9 вечера»
    day_shift, target = 0, None
    rest = s
    if rest.startswith("завтра"):
        day_shift, rest = 1, rest[len("завтра"):].strip()
    wd = None
    m = re.match(r"^(?:в\s+)?([а-я]+)\s+(.*)$", rest)
    if m and m.group(1) in WEEKDAYS:
        wd, rest = WEEKDAYS[m.group(1)], m.group(2).strip()
    ampm = None
    m = re.match(r"^(.*?)\s*(утра|вечера|дня|ночи)$", rest)
    if m:
        rest, ampm = m.group(1).strip(), m.group(2)
    m = re.match(r"^(\d{1,2})[:.](\d{2})$", rest) or re.match(r"^(\d{1,2})$", rest)
    if m:
        g = m.groups()
        hh = int(g[0])
        mi = int(g[1]) if len(g) > 1 and g[1] else 0
        if ampm in ("вечера", "ночи") and hh < 12:
            hh += 12
        if ampm == "утра" and hh == 12:
            hh = 0
        dt = datetime.fromtimestamp(now)
        if wd is not None:
            delta_days = (wd - dt.weekday()) % 7 or 7
            day_shift = delta_days
        cand = dt.replace(hour=hh, minute=mi, second=0, microsecond=0) + timedelta(days=day_shift)
        ts = cand.timestamp()
        if ts <= now and day_shift == 0 and wd is None:
            ts += 86400          # «14:30» после 14:30 = завтра
        return None, ts
    return None, None


class TimerStore:
    def __init__(self, path: str | None = None):
        self.path = path or os.path.join(app_dir(), "data", "timers.json")
        self.lock = threading.RLock()
        self.timers: list[dict] = []
        self._seq = 0
        self.load()

    # --- персистентность -----------------------------------------------------
    def load(self) -> None:
        with self.lock:
            self.timers = []
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                for t in raw.get("timers", []):
                    self.timers.append(t)
                    n = int(str(t.get("id", "t0"))[1:] or 0)
                    self._seq = max(self._seq, n)
            except Exception:
                pass
            # восстановление после рестарта
            now = time.time()
            for t in self.timers:
                if t.get("fired") or t.get("paused"):
                    continue
                if t["due"] <= now:
                    if now - t["due"] <= RESTORE_WINDOW_S:
                        t["restored"] = True          # сработает на первом тике
                    else:
                        t["missed"] = True
                        if not t.get("interval"):
                            t["fired"] = True         # одноразовый просто помечаем

    def save(self) -> None:
        with self.lock:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"timers": self.timers}, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.path)

    # --- CRUD -----------------------------------------------------------------
    def add(self, due: float, label: str, interval: float | None = None,
            times: int | None = None) -> dict:
        with self.lock:
            self._seq += 1
            t = {"id": f"t{self._seq}", "label": label or "напоминание",
                 "due": due, "interval": interval, "times": times,
                 "left": times, "created": time.time(), "fired": False,
                 "fired_count": 0, "paused": False}
            self.timers.append(t)
            self.save()
            return dict(t)

    def list(self, include_done: bool = False) -> list:
        with self.lock:
            out = [dict(t) for t in self.timers if include_done or not t.get("fired")]
            return sorted(out, key=lambda t: t["due"])

    def find(self, ref: str) -> list:
        """По id, префиксу id или части подписи."""
        ref = (ref or "").strip().lower()
        with self.lock:
            act = [t for t in self.timers if not t.get("fired")]
            exact = [t for t in act if t["id"] == ref]
            if exact:
                return exact
            pref = [t for t in act if t["id"].startswith(ref)] if ref else []
            if len(pref) == 1:
                return pref
            sub = [t for t in act if ref and ref in t["label"].lower()]
            return pref if pref and not sub else sub

    def cancel(self, ref: str) -> tuple[bool, str]:
        with self.lock:
            hits = self.find(ref)
            if not hits:
                return False, f"таймер «{ref}» не найден"
            if len(hits) > 1:
                var = "; ".join(f"{t['id']}: {t['label'][:40]}" for t in hits)
                return False, f"неоднозначно: {var} — уточни id"
            t = hits[0]
            t["fired"] = True
            t["cancelled"] = True
            self.save()
            return True, t["id"]

    def patch(self, ref: str, **fields) -> tuple[bool, str]:
        with self.lock:
            hits = self.find(ref)
            if len(hits) != 1:
                return False, "таймер не найден или неоднозначен"
            hits[0].update(fields)
            self.save()
            return True, hits[0]["id"]

    def snooze(self, ref: str, seconds: float) -> tuple[bool, str]:
        return self.patch(ref, due=time.time() + seconds, paused=False, missed=False)

    # --- тик планировщика -------------------------------------------------------
    def due_now(self, now: float | None = None) -> list:
        now = time.time() if now is None else now
        with self.lock:
            out = []
            for t in self.timers:
                if t.get("fired") or t.get("paused"):
                    continue
                if t["due"] <= now:
                    out.append(t)
            return [dict(t) for t in out]

    def mark_fired(self, tid: str) -> None:
        """Повтор: due += interval без дрейфа; одноразовый: fired."""
        with self.lock:
            t = next((x for x in self.timers if x["id"] == tid), None)
            if not t:
                return
            t["fired_count"] = t.get("fired_count", 0) + 1
            t.pop("restored", None)
            if t.get("interval"):
                if t.get("left") is not None:
                    t["left"] -= 1
                    if t["left"] <= 0:
                        t["fired"] = True
                        self.save()
                        return
                while t["due"] <= time.time():
                    t["due"] += t["interval"]
            else:
                t["fired"] = True
            self.save()


STORE = TimerStore()


class Scheduler(threading.Thread):
    daemon = True

    def __init__(self, store: TimerStore = STORE, tick: float = 0.1):
        super().__init__(name="flux-timers")
        self.store = store
        self.tick = tick
        self._stop = threading.Event()
        self._wake = threading.Event()
        self.last_fire: dict | None = None

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()

    def wake(self) -> None:
        self._wake.set()

    def run(self) -> None:
        while not self._stop.is_set():
            self._wake.wait(self.tick)
            self._wake.clear()
            if self._stop.is_set():
                break
            for t in self.store.due_now():
                self._fire(t)

    def _fire(self, t: dict) -> None:
        self.last_fire = t
        self.store.mark_fired(t["id"])
        for hook in ON_FIRE:
            try:
                hook(t)
            except Exception:
                pass


SCHEDULER: Scheduler | None = None


def start_scheduler() -> Scheduler:
    global SCHEDULER
    if SCHEDULER is None or not SCHEDULER.is_alive():
        SCHEDULER = Scheduler()
        SCHEDULER.start()
    return SCHEDULER


def stop_scheduler() -> None:
    global SCHEDULER
    if SCHEDULER is not None:
        SCHEDULER.stop()
        SCHEDULER = None


def human_left(seconds: float) -> str:
    seconds = max(0, int(seconds))
    d, rem = divmod(seconds, 86400)
    h, rem = divmod(rem, 3600)
    m, s = divmod(rem, 60)
    parts = []
    if d:
        parts.append(f"{d}д")
    if h:
        parts.append(f"{h}ч")
    if m:
        parts.append(f"{m}м")
    parts.append(f"{s}с")
    return " ".join(parts)
