"""HTTP-сервер FLUX 2.0: UI, SSE-чат, STT/TTS, CRUD подключений, CDP-хелперы."""
from __future__ import annotations

import asyncio
import json
import os
import time

from aiohttp import web

from . import agent, bridge, events, notify, timers, voicelab, winbridge
from .config import CONFIG, app_dir
from .tools import REG

UI_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ui")

HISTORIES: dict[str, list] = {}


def _mask(conn: dict) -> dict:
    c = dict(conn)
    k = c.get("api_key") or ""
    c["api_key_masked"] = (k[:4] + "…" + k[-4:]) if len(k) > 10 else ("*" * len(k) if k else "")
    c["api_key"] = k  # локально ключ виден только своему UI
    return c


async def index(request):
    return web.FileResponse(os.path.join(UI_DIR, "index.html"))


async def favicon(request):
    return web.FileResponse(os.path.join(UI_DIR, "flux.ico"))


async def api_state(request):
    mics = await asyncio.to_thread(voicelab.list_mics)
    return web.json_response({
        "settings": CONFIG.settings,
        "voice": CONFIG.voice,
        "connections": [_mask(c) for c in CONFIG.connections],
        "mics": mics,
        "tools_count": len(REG.tools),
        "tools_categories": REG.categories(),
    })


async def api_settings(request):
    data = await request.json()
    for k, v in (data.get("settings") or {}).items():
        CONFIG.settings[k] = v
    for k, v in (data.get("voice") or {}).items():
        CONFIG.voice[k] = v
    CONFIG.save()
    return web.json_response({"ok": True})


async def api_conn_save(request):
    conn = await request.json()
    saved = CONFIG.upsert_connection(conn)
    return web.json_response({"ok": True, "id": saved["id"]})


async def api_conn_delete(request):
    cid = (await request.json()).get("id")
    CONFIG.delete_connection(cid)
    return web.json_response({"ok": True})


async def api_conn_models(request):
    conn = await request.json()
    from . import providers
    try:
        models = await providers.fetch_models(conn)
        return web.json_response({"ok": True, "models": models})
    except Exception as e:
        return web.json_response({"ok": False, "error": str(e)})


async def api_conn_test(request):
    conn = await request.json()
    from . import providers
    res = await providers.test_connection(conn)
    return web.json_response(res)


async def api_voices(request):
    vs = await voicelab.voice_list_async()
    return web.json_response({"ok": True, "voices": vs})


async def api_chat(request):
    data = await request.json()
    text = (data.get("text") or "").strip()
    sid = data.get("sid", "default")
    hist = HISTORIES.setdefault(sid, [])
    if data.get("reset"):
        hist.clear()
        return web.json_response({"ok": True})
    if not text:
        return web.json_response({"ok": False, "error": "пусто"})

    resp = web.StreamResponse(headers={"Content-Type": "text/event-stream",
                                       "Cache-Control": "no-cache"})
    await resp.prepare(request)

    async def on_event(ev: dict):
        await resp.write(("data: " + json.dumps(ev, ensure_ascii=False) + "\n\n").encode())

    try:
        await agent.run_turn(text, hist, on_event, cookies=data.get("cookies"))
    except Exception as e:
        await on_event({"type": "error", "text": f"{type(e).__name__}: {e}"})
    await resp.write(b"data: {\"type\": \"stream_end\"}\n\n")
    return resp


async def api_stt(request):
    audio = await request.read()
    txt = await voicelab.transcribe_auto(audio)
    if txt is None:
        return web.json_response({"ok": False, "error": "STT недоступен на бэкенде; используй браузерное распознавание"},
                                 status=501)
    return web.json_response({"ok": True, "text": txt})


async def api_tts(request):
    text = request.query.get("text", "")[:2000]
    voice = request.query.get("voice") or CONFIG.voice.get("voice")
    rate, pitch = CONFIG.voice.get("rate", 0), CONFIG.voice.get("pitch", 0)
    engine = CONFIG.voice.get("tts_engine", "winget")
    if engine in ("winget", "auto"):
        url = await voicelab.winget_url(text, voice, rate, pitch)
        if url:
            asyncio.create_task(voicelab._save_copy(url))
            raise web.HTTPFound(url)   # плеер стримит mp3 напрямую, без перекачки
        if engine == "winget":
            return web.json_response({"ok": False, "error": "wingetgui недоступен"}, status=502)
    path = await voicelab.synth_to_file(text, voice)
    if not path:
        return web.json_response({"ok": False, "error": "edge-tts не установлен"}, status=501)
    return web.FileResponse(path, headers={"Content-Type": "audio/mpeg"})


async def api_shots(request):
    name = os.path.basename(request.match_info["name"])
    return web.FileResponse(os.path.join(app_dir(), "data", "shots", name))


async def api_audio(request):
    name = os.path.basename(request.match_info["name"])
    return web.FileResponse(os.path.join(app_dir(), "data", "audio", name))


async def api_cdp(request):
    """Жив ли браузер-мост: расширение FLUX Bridge, 9222 или DevToolsActivePort."""
    from . import browser_cdp as cdp
    if bridge.online():
        try:
            tabs = await bridge.call({"cmd": "targets"})
            return web.json_response({"ok": True, "browser": "Chrome (расширение FLUX Bridge, живой)", "tabs": len(tabs)})
        except Exception as e:
            return web.json_response({"ok": False, "error": str(e)[:120]})
    if await cdp.discover():
        try:
            v = await cdp.version()
            tabs = await cdp.targets()
            return web.json_response({"ok": True, "browser": v.get("Browser", ""), "tabs": len(tabs)})
        except Exception as e:
            return web.json_response({"ok": False, "error": str(e)[:120]})
    if cdp.chrome_running():
        return web.json_response({"ok": False, "error": cdp.FRIENDLY_HINT})
    return web.json_response({"ok": False, "error": "браузер не запущен; FLUX поднимет его при первом browser-тулзе"})


async def api_browser_launch(request):
    from . import browser_cdp as cdp
    ok = await cdp.ensure_ready()
    return web.json_response({"ok": ok})


async def api_tools(request):
    q = request.query.get("q", "")
    specs = REG.search(q, int(request.query.get("k", 20))) if q else list(REG.tools.values())[:50]
    return web.json_response({"count": len(REG.tools),
                              "tools": [{"name": s.name, "desc": s.description, "cat": s.category} for s in specs]})


async def api_runcode(request):
    """Интерпретатор кода для кнопок «▶ запустить» у код-блоков в чате."""
    from .tools import codrun
    data = await request.json()
    res = await asyncio.to_thread(codrun.run_code, data.get("engine", "python"),
                                  data.get("code", ""), data.get("stdin", ""), 25)
    return web.json_response(res)


# --- Windows Automation: мост win_bridge.py (ws://127.0.0.1:8643/win-bridge) ---
async def api_win_status(request):
    """Жив ли Windows-мост: состояние сокета + status() сервера (фон-опрос, без записи в лог)."""
    st = winbridge.status()
    out = {"ok": st["online"], **st}
    if st["online"]:
        try:
            out["server"] = await winbridge.call({"cmd": "status"}, timeout=8, log=False)
            apps = await winbridge.apps(ttl=5.0)
            out["apps_count"] = len(apps)
        except Exception as e:
            out["error"] = str(e)[:160]
    return web.json_response(out)


async def api_win_reconnect(request):
    """Кнопка «Переподключить» в UI: форсируем новый коннект к win_bridge.py."""
    ok = await winbridge.reconnect()
    for _ in range(50):        # до ~2.5с ждём, чтобы UI сразу показал зелёный
        if winbridge.online():
            ok = True
            break
        await asyncio.sleep(0.05)
    return web.json_response({"ok": winbridge.online(), "requested": ok,
                              **winbridge.status()})


async def api_win_apps(request):
    """Список приложений через мост (для вкладки Windows Automation)."""
    force = bool(request.query.get("force"))
    try:
        apps = await winbridge.apps(ttl=0.0 if force else 5.0, force=force, log=force)
        return web.json_response({"ok": True, "apps": apps})
    except winbridge.WinBridgeDown as e:
        return web.json_response({"ok": False, "error": str(e)[:200]})


async def api_win_log(request):
    """Лог последних команд моста (id, cmd, ok, мс, превью) — для вкладки UI."""
    return web.json_response({"ok": True, "log": winbridge.last_log(
        int(request.query.get("n", 40)))})


WIN_CMD_ALLOWED = {"status", "apps", "windows", "activate", "children", "read", "wait"}


async def api_win_cmd(request):
    """Прямая команда мосту из UI (кнопка «Фокус» и т.п.).

    Разрешён только безопасный поднабор: клик/ввод/eval — прерогатива агента
    (тулзы windows_*), а не кнопок в настройках.
    """
    data = await request.json()
    cmd = str(data.get("cmd") or "")
    if cmd not in WIN_CMD_ALLOWED:
        return web.json_response({"ok": False,
                                  "error": f"команда {cmd or '(пусто)'} не разрешена из UI"},
                                 status=403)
    try:
        r = await winbridge.call({**data, "cmd": cmd}, timeout=30)
        if isinstance(r, dict):
            r = {k: v for k, v in r.items() if k != "dataBase64"}  # base64 в UI не тащим
        return web.json_response({"ok": True, "result": r})
    except winbridge.WinBridgeDown as e:
        return web.json_response({"ok": False, "error": str(e)[:200]})


# --- v2.8: события вне хода чата (таймеры, уведомления) -> SSE в окно ------------
async def api_events(request):
    """SSE-шина: таймер сработал -> тост и сирена в окне БЕЗ хода чата."""
    resp = web.StreamResponse(headers={"Content-Type": "text/event-stream",
                                       "Cache-Control": "no-cache"})
    await resp.prepare(request)
    q = events.subscribe()
    try:
        for ev in events.recent(6):
            await resp.write(("data: " + json.dumps(ev, ensure_ascii=False) + "\n\n").encode())
        while True:
            ev = await q.get()
            await resp.write(("data: " + json.dumps(ev, ensure_ascii=False) + "\n\n").encode())
    except (asyncio.CancelledError, ConnectionResetError, ConnectionError):
        pass
    finally:
        events.unsubscribe(q)
    return resp


async def api_timers_list(request):
    return web.json_response({"ok": True, "timers": timers.STORE.list(),
                              "now": time.time()})


async def api_timers_add(request):
    d = await request.json()
    try:
        due, interval, times = timers.parse_when(d.get("when", ""))
    except timers.WhenError as e:
        return web.json_response({"ok": False, "error": str(e)})
    t = timers.STORE.add(due, d.get("label", ""), interval or d.get("interval"),
                         times or d.get("times"))
    sched = timers.SCHEDULER
    if sched:
        sched.wake()
    return web.json_response({"ok": True, "timer": t})


async def api_timers_action(request):
    act = request.match_info["act"]
    tid = request.match_info["id"]
    try:
        d = await request.json()
    except Exception:
        d = {}
    if act == "cancel":
        ok, msg = timers.STORE.cancel(tid)
        events.publish("timer_changed", id=tid, action="cancel")
    elif act == "snooze":
        ok, msg = timers.STORE.snooze(tid, float(d.get("minutes", 5)) * 60)
        notify.stop_sound()
        events.publish("timer_changed", id=tid, action="snooze")
    elif act == "pause":
        ok, msg = timers.STORE.patch(tid, paused=True, paused_at=time.time())
        events.publish("timer_changed", id=tid, action="pause")
    elif act == "resume":
        hits = timers.STORE.find(tid)
        if len(hits) == 1:
            t = hits[0]
            if t.get("paused_at"):
                t["due"] += time.time() - t["paused_at"]
            t["paused"] = False
            t.pop("paused_at", None)
            timers.STORE.save()
            ok, msg = True, t["id"]
        else:
            ok, msg = False, "не найден"
        events.publish("timer_changed", id=tid, action="resume")
    else:
        return web.json_response({"ok": False, "error": f"действие {act} неизвестно"}, status=404)
    return web.json_response({"ok": ok, "detail": msg})


async def api_notify_stop(request):
    notify.stop_sound()
    events.publish("sound_stop")
    return web.json_response({"ok": True})


async def api_notify_test(request):
    backend = await asyncio.to_thread(notify.play_sound, "test")
    return web.json_response({"ok": backend != "none", "backend": backend})


async def _wire_timers(app_):
    """Планировщик + три канала доставки: ОС-звук, SSE в окно, очередь модели."""
    events.set_loop(asyncio.get_running_loop())

    def on_fire(t: dict):
        missed = bool(t.get("missed"))
        events.publish("timer_fired", id=t["id"], label=t["label"],
                       missed=missed, restored=bool(t.get("restored")))
        if not missed:
            notify.play_async("timer")
            notify.toast("FLUX: таймер", t["label"])
        agent.UNACKED.append(t)

    if on_fire not in timers.ON_FIRE:
        timers.ON_FIRE.append(on_fire)
    timers.start_scheduler()



def build_app() -> web.Application:
    app = web.Application(client_max_size=40 * 1024 * 1024)
    app.router.add_get("/", index)
    app.router.add_get("/favicon.ico", favicon)
    app.router.add_get("/api/state", api_state)
    app.router.add_post("/api/settings", api_settings)
    app.router.add_post("/api/conn/save", api_conn_save)
    app.router.add_post("/api/conn/delete", api_conn_delete)
    app.router.add_post("/api/conn/models", api_conn_models)
    app.router.add_post("/api/conn/test", api_conn_test)
    app.router.add_get("/api/voices", api_voices)
    app.router.add_post("/api/chat", api_chat)
    app.router.add_post("/api/stt", api_stt)
    app.router.add_get("/api/tts", api_tts)
    app.router.add_get("/api/shots/{name}", api_shots)
    app.router.add_get("/api/audio/{name}", api_audio)
    app.router.add_post("/api/browser/launch", api_browser_launch)
    app.router.add_get("/api/cdp", api_cdp)
    app.router.add_get("/bridge", bridge.ws_bridge)
    app.router.add_get("/api/tools", api_tools)
    app.router.add_post("/api/runcode", api_runcode)
    # Windows Automation (мост 8643)
    app.router.add_get("/api/events", api_events)
    app.router.add_get("/api/timers", api_timers_list)
    app.router.add_post("/api/timers", api_timers_add)
    app.router.add_post("/api/timers/{id}/{act}", api_timers_action)
    app.router.add_post("/api/notify/stop", api_notify_stop)
    app.router.add_post("/api/notify/test", api_notify_test)
    app.router.add_get("/api/win/status", api_win_status)
    app.router.add_post("/api/win/reconnect", api_win_reconnect)
    app.router.add_get("/api/win/apps", api_win_apps)
    app.router.add_get("/api/win/log", api_win_log)
    app.router.add_post("/api/win/cmd", api_win_cmd)

    async def _start_winbridge(app_):
        """Фоновый коннект к win_bridge.py: переподключение каждые 3с, как у расширения."""
        try:
            await winbridge.start()
        except Exception as e:
            print(f"[FLUX2] win-мост: старт не удался ({e}) — продолжим без него")

    async def _stop_winbridge(app_):
        try:
            await winbridge.stop()
        except Exception:
            pass

    app.on_startup.append(_wire_timers)
    app.on_startup.append(_start_winbridge)
    app.on_cleanup.append(_stop_winbridge)
    return app
