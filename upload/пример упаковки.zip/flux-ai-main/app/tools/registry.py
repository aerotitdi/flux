"""Реестр инструментов: 300+ тулзов, retrieval top-k для экономии токенов.

Каждый инструмент — ToolSpec с JSON-схемой параметров (стиль OpenAI tools).
В запрос модели уходит не весь каталог, а top-k релевантных + ядро (core).
"""
from __future__ import annotations

import asyncio
import inspect
import math
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

STOP = set("""
и в во не что он на я с со как а то все она так его но да ты к у же вы за бы по
только ее мне было вот от меня еще нет о из ему теперь когда уже зачем где
the a an and or of to in for on with is are be do does how what which why when
""".split())


@dataclass
class Param:
    name: str
    type: str = "string"
    desc: str = ""
    required: bool = True
    default: Any = None
    enum: Optional[list] = None


@dataclass
class ToolResult:
    ok: bool
    text: str = ""
    images: list = field(default_factory=list)
    data: dict = field(default_factory=dict)

    def as_content(self) -> str:
        return f"[{'OK' if self.ok else 'ОШИБКА'}] {self.text}"


@dataclass
class ToolSpec:
    name: str
    description: str
    params: list
    handler: Callable
    category: str = "misc"
    core: bool = False

    def schema(self) -> dict:
        props, req = {}, []
        for p in self.params:
            pr: dict[str, Any] = {"type": p.type, "description": p.desc}
            if p.enum:
                pr["enum"] = p.enum
            props[p.name] = pr
            if p.required:
                req.append(p.name)
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {"type": "object", "properties": props, "required": req},
            },
        }


class Registry:
    def __init__(self):
        self.tools: dict[str, ToolSpec] = {}
        self._docs: dict[str, str] = {}
        self._idf: dict[str, float] = {}

    def add(self, spec: ToolSpec) -> ToolSpec:
        if spec.name in self.tools:
            raise ValueError(f"дубликат инструмента: {spec.name}")
        self.tools[spec.name] = spec
        self._docs[spec.name] = (spec.name.replace("_", " ") + " " + spec.description).lower()
        return spec

    def tool(self, name, description, params=None, category="misc", core=False):
        """Декоратор регистрации."""
        def deco(fn):
            self.add(ToolSpec(name, description, params or [], fn, category, core))
            return fn
        return deco

    # --- retrieval ---------------------------------------------------------
    def _tokens(self, text: str) -> list[str]:
        return [t for t in re.findall(r"[a-zа-яё0-9]{3,}", text.lower()) if t not in STOP]

    def build_idf(self) -> None:
        n = max(1, len(self._docs))
        df: dict[str, int] = {}
        for doc in self._docs.values():
            for t in set(self._tokens(doc)):
                df[t] = df.get(t, 0) + 1
        self._idf = {t: math.log((n + 1) / (d + 0.5)) for t, d in df.items()}

    def search(self, query: str, k: int = 14) -> list[ToolSpec]:
        if not self._idf:
            self.build_idf()
        qt = self._tokens(query)
        scores: dict[str, float] = {}
        for name, doc in self._docs.items():
            dt = self._tokens(doc)
            if not dt:
                continue
            tf: dict[str, int] = {}
            for t in dt:
                tf[t] = tf.get(t, 0) + 1
            score = 0.0
            for t in qt:
                if t in tf:
                    score += self._idf.get(t, 1.0) * (tf[t] / (tf[t] + 1.2))
            # бонус за точное вхождение токена в имя инструмента
            for t in qt:
                if t in name:
                    score += 1.5
            if score > 0:
                scores[name] = score
        order = sorted(scores.items(), key=lambda kv: -kv[1])
        picked = [self.tools[n] for n, _ in order[:k]]
        for spec in self.tools.values():
            if spec.core and spec not in picked:
                picked.append(spec)
        return picked

    def categories(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for s in self.tools.values():
            out[s.category] = out.get(s.category, 0) + 1
        return out

    # --- dispatch ----------------------------------------------------------
    async def dispatch(self, name: str, args: dict, ctx: dict) -> ToolResult:
        spec = self.tools.get(name)
        if not spec:
            return ToolResult(False, f"неизвестный инструмент: {name}")
        kwargs = {}
        for p in spec.params:
            if p.name in args:
                kwargs[p.name] = args[p.name]
            elif p.required:
                return ToolResult(False, f"не хватает параметра {p.name}")
            else:
                kwargs[p.name] = p.default
        try:
            res = spec.handler(ctx=ctx, **kwargs)
            if inspect.isawaitable(res):
                res = await res
            if isinstance(res, ToolResult):
                return res
            if isinstance(res, (dict, list)):
                import json as _j
                return ToolResult(True, _j.dumps(res, ensure_ascii=False, default=str)[:6000])
            return ToolResult(True, str(res)[:6000])
        except Exception as e:
            return ToolResult(False, f"{type(e).__name__}: {e}")


REG = Registry()


def P(name, type="string", desc="", required=True, default=None, enum=None):
    return Param(name, type, desc, required, default, enum)


def run_sync(fn, *a, **kw):
    return fn(*a, **kw)
