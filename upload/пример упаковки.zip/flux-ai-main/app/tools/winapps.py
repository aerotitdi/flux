"""Тулзы Windows Automation: приложения ОС через UIA-мост (windows_bridge/win_bridge.py).

Зеркало семейства browser (app/tools/browser.py), но для уровня Windows 10/11:
  FLUX -> ws://127.0.0.1:8643/win-bridge -> pywinauto (backend="uia") + mss.
Клики/ввод — через UI Automation (по title/auto_id/control_type), БЕЗ координат мыши:
надёжнее, не зависит от разрешения экрана и положения окна (pyautogui не используется).

Типовой сценарий агента:
  windows_apps -> windows_children(app) -> windows_click/type/send_keys -> windows_screenshot.
Сложные сценарии — windows_eval (Python-код с объектом окна win, как browser_tab_eval).
"""
from __future__ import annotations

import base64
import json
import os
import time

from .. import winbridge as wb
from ..config import app_dir
from .registry import P, REG, ToolResult

C = "windows"
T = REG.tool

DOWN_HINT = ("Windows-мост не подключён: запусти `python windows_bridge/win_bridge.py` "
             "(ws://127.0.0.1:8643/win-bridge, см. README_windows.md)")

# Единый набор параметров поиска UIA-элемента (control) для всех тулзов
CTL_PARAMS = [
    P("title", desc="имя элемента, напр. «Сохранить» (подстрока)", required=False, default=""),
    P("auto_id", desc="AutomationId элемента, напр. «15»", required=False, default=""),
    P("control_type", desc="тип: Button/Edit/MenuItem/CheckBox/ListItem/Text/Document...",
      required=False, default=""),
    P("class_name", desc="Win32-класс элемента (редко нужен)", required=False, default=""),
    P("found_index", "integer", desc="какое по счёту совпадение брать (1 = первое)",
      required=False, default=0),
]


def _control(title: str, auto_id: str, control_type: str, class_name: str, found_index: int):
    """Собрать словарь control для моста; None если критериев нет (= само окно)."""
    q = {}
    if title:
        q["title"] = title
    if auto_id:
        q["auto_id"] = str(auto_id)
    if control_type:
        q["control_type"] = control_type
    if class_name:
        q["class_name"] = class_name
    if found_index:
        q["found_index"] = int(found_index)
    return q or None


async def _call(cmd: dict, timeout: float = wb.CALL_TIMEOUT):
    """Вызов моста; офлайн -> понятная ToolResult-ошибка (не исключение)."""
    if not wb.online():
        wb.ensure_started()
    try:
        return await wb.call(cmd, timeout=timeout)
    except wb.WinBridgeDown as e:
        raise ToolBridgeDown(str(e))


class ToolBridgeDown(Exception):
    pass


def _fmt_ctl(c: dict | None) -> str:
    if not c:
        return "(окно целиком)"
    return " ".join(f"{k}={v!r}" for k, v in c.items())


# --------------------------------------------------------------------------- #
#  Состояние и обзор                                                            #
# --------------------------------------------------------------------------- #
@T("windows_status", "Статус Windows-моста (win_bridge.py, порт 8643): подключён ли, backend (uia/mock), версия. Вызывай ПЕРЕД остальными windows_* при сомнениях", [], C, core=True)
async def _(ctx):
    st = wb.status()
    if not st["online"]:
        return ToolResult(False, f"{DOWN_HINT}. Статус: {json.dumps(st, ensure_ascii=False)}")
    try:
        r = await wb.call({"cmd": "status"}, timeout=10)
        return (f"мост ЖИВ: {st['url']} · backend={r.get('backend')} · win_bridge {r.get('version')} · "
                f"pywinauto {r.get('pywinauto')} · {r.get('os')} · uptime {st['uptime_s']}с")
    except wb.WinBridgeDown as e:
        return ToolResult(False, str(e))


@T("windows_apps", "Список запущенных Windows-приложений (окна верхнего уровня): title, process, pid, hwnd. Пример: увидев «Безымянный — Блокнот» используй app='Блокнот' в windows_click/type", [], C, core=True)
async def _(ctx):
    try:
        r = await _call({"cmd": "apps"}, timeout=15)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    apps = (r or {}).get("apps", [])
    if not apps:
        return "видимых окон нет"
    return "\n".join(f"hwnd={a['hwnd']} pid={a['pid']} {a['process'] or '?'} :: {a['title'][:80]}"
                     for a in apps)


@T("windows_list", "Окна Windows с координатами и размерами (rect left/top/width/height, visible, enabled)", [], C)
async def _(ctx):
    try:
        r = await _call({"cmd": "windows"}, timeout=15)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    out = []
    for w in (r or {}).get("windows", []):
        rc = w.get("rect") or {}
        out.append(f"{w['title'][:60] or '(без заголовка)'} | {w['process']} pid={w['pid']} hwnd={w['hwnd']} | "
                   f"rect=({rc.get('left')},{rc.get('top')} {rc.get('width')}x{rc.get('height')})")
    return "\n".join(out) or "окон нет"


@T("windows_children", "Дочерние UI-элементы окна приложения (title, control_type, auto_id, class_name, rect) — разведка ПЕРЕД кликом/вводом. Пример: windows_children(app='Блокнот') покажет кнопки и меню",
   [P("app", desc="приложение/окно: часть заголовка, имя процесса (notepad) или hwnd"),
    P("title", desc="родительский элемент (подстрока имени), пусто = корень окна", required=False, default=""),
    P("control_type", desc="тип родительского элемента (MenuBar, ToolBar...)", required=False, default=""),
    P("auto_id", desc="AutomationId родительского элемента", required=False, default="")], C, core=True)
async def _(ctx, app, title, control_type, auto_id):
    ctl = _control(title, auto_id, control_type, "", 0)
    try:
        r = await _call({"cmd": "children", "app": app, "control": ctl}, timeout=30)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    els = (r or {}).get("children", [])
    if not els:
        return "дочерних элементов нет (или окно пустое)"
    lines = []
    for el in els:
        rc = el.get("rect") or {}
        lines.append(f"{el.get('control_type', '?'):12} | title={el.get('title', '')[:50]!r} | "
                     f"auto_id={el.get('auto_id', '')} | class={el.get('class_name', '')[:30]} | "
                     f"({rc.get('left')},{rc.get('top')} {rc.get('width')}x{rc.get('height')})")
    total = r.get("total", len(els))
    tail = f"\n...и ещё {total - len(els)}" if total > len(els) else ""
    return "\n".join(lines) + tail


# --------------------------------------------------------------------------- #
#  Действия с окнами                                                            #
# --------------------------------------------------------------------------- #
@T("windows_activate", "Вывести окно приложения на передний план (активировать). Пример: windows_activate(app='Chrome')",
   [P("app", desc="часть заголовка / процесс / hwnd")], C, core=True)
async def _(ctx, app):
    try:
        r = await _call({"cmd": "activate", "app": app}, timeout=15)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    return f"окно активно: {r.get('title')} (hwnd={r.get('hwnd')})"


@T("windows_launch", "Запустить приложение по пути/команде и вернуть pid+заголовок. Пример: windows_launch(path='notepad.exe') или path='C:\\\\Windows\\\\System32\\\\calc.exe'",
   [P("path", desc="путь к exe или команда (notepad, calc, msedge https://...)")], C, core=True)
async def _(ctx, path):
    try:
        r = await _call({"cmd": "launch", "path": path}, timeout=40)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    return f"запущено: pid={r.get('pid')} title={r.get('title') or '(окно ещё не появилось — подожди windows_wait)'}"


@T("windows_close", "Закрыть окно приложения (WM_CLOSE; сохранение НЕ форсируется). Пример: windows_close(app='Блокнот')",
   [P("app", desc="часть заголовка / процесс / hwnd")], C)
async def _(ctx, app):
    try:
        r = await _call({"cmd": "close", "app": app}, timeout=15)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    return f"окно закрыто: {r.get('title')}"


# --------------------------------------------------------------------------- #
#  Клики / ввод (UIA, без координат)                                            #
# --------------------------------------------------------------------------- #
@T("windows_click", "Клик по элементу интерфейса приложения через UI Automation (НЕ по координатам). "
   "Пример: windows_click(app='Блокнот', title='Сохранить', control_type='Button'). "
   "Элемент ищи через windows_children. method='invoke' — программное нажатие без мыши (для фоновых окон)",
   [P("app", desc="приложение: часть заголовка / процесс / hwnd"),
    *CTL_PARAMS,
    P("method", desc="input = реальный клик мышью (по умолчанию), invoke = UIA-паттерн без курсора",
      required=False, default="input", enum=["input", "invoke"]),
    P("button", desc="кнопка мыши", required=False, default="left", enum=["left", "right"]),
    P("double", "boolean", desc="двойной клик", required=False, default=False),
    P("timeout_s", "integer", desc="сколько секунд искать элемент", required=False, default=10)], C, core=True)
async def _(ctx, app, title, auto_id, control_type, class_name, found_index,
            method, button, double, timeout_s):
    ctl = _control(title, auto_id, control_type, class_name, found_index)
    if not ctl:
        return ToolResult(False, "не указан элемент: передай title и/или auto_id и/или control_type")
    try:
        r = await _call({"cmd": "click", "app": app, "control": ctl, "method": method,
                         "button": button, "double": bool(double),
                         "timeout": int(timeout_s) * 1000}, timeout=int(timeout_s) + 15)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    c = r.get("clicked") or {}
    return f"клик ({method}): {c.get('control_type')} «{c.get('title')}» auto_id={c.get('auto_id')}"


@T("windows_type", "Ввести текст в поле приложения через UIA. Пример: windows_type(app='Блокнот', auto_id='15', text='привет'). "
   "replace=true — заменить содержимое поля (иначе допечатывает в позиции курсора)",
   [P("app", desc="приложение: часть заголовка / процесс / hwnd"),
    *CTL_PARAMS,
    P("text", desc="текст для ввода (unicode поддерживается)"),
    P("replace", "boolean", desc="очистить поле перед вводом", required=False, default=False),
    P("timeout_s", "integer", desc="секунд на поиск поля", required=False, default=10)], C, core=True)
async def _(ctx, app, title, auto_id, control_type, class_name, found_index,
            text, replace, timeout_s):
    ctl = _control(title, auto_id, control_type, class_name, found_index)
    try:
        r = await _call({"cmd": "type", "app": app, "control": ctl, "text": text,
                         "replace": bool(replace), "timeout": int(timeout_s) * 1000},
                        timeout=int(timeout_s) + 15)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    return f"введено {r.get('typed')} симв. ({r.get('mode')}) в {_fmt_ctl(ctl)}"


@T("windows_send_keys", "Отправить клавиши/горячие клавиши в окно (синтаксис pywinauto: ^s = Ctrl+S, {ENTER}, {TAB}, %{F4} = Alt+F4, ^a = Ctrl+A). "
   "Пример: windows_send_keys(app='Блокнот', keys='^s') — откроет диалог сохранения",
   [P("app", desc="приложение: часть заголовка / процесс / hwnd"),
    P("keys", desc="строка клавиш pywinauto")], C, core=True)
async def _(ctx, app, keys):
    try:
        r = await _call({"cmd": "send_keys", "app": app, "keys": keys}, timeout=20)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    return f"отправлены клавиши: {r.get('keys')}"


@T("windows_read", "Прочитать текст/значение элемента приложения (кнопка, поле, пункт списка). "
   "Пример: windows_read(app='Блокнот', auto_id='15') — содержимое редактора",
   [P("app", desc="приложение: часть заголовка / процесс / hwnd"),
    *CTL_PARAMS,
    P("timeout_s", "integer", desc="секунд на поиск элемента", required=False, default=10)], C, core=True)
async def _(ctx, app, title, auto_id, control_type, class_name, found_index, timeout_s):
    ctl = _control(title, auto_id, control_type, class_name, found_index)
    try:
        r = await _call({"cmd": "read", "app": app, "control": ctl,
                         "timeout": int(timeout_s) * 1000}, timeout=int(timeout_s) + 15)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    val = r.get("value")
    txt = r.get("text") or ""
    texts = r.get("texts") or []
    body = val if val not in (None, "") else (txt or ("; ".join(texts) if texts else ""))
    return (f"{r.get('control_type')} «{txt[:60]}» auto_id={r.get('auto_id')}: "
            f"{str(body)[:4000]}") if body not in ("", None) else "элемент пуст (нет текста/значения)"


@T("windows_wait", "Ждать появления элемента в приложении (диалог, кнопка загрузки). "
   "Пример: windows_wait(app='Блокнот', title='Сохранение', timeout_s=10)",
   [P("app", desc="приложение: часть заголовка / процесс / hwnd"),
    *CTL_PARAMS[:3],
    P("timeout_s", "integer", desc="максимум секунд ожидания", required=False, default=10)], C, core=True)
async def _(ctx, app, title, auto_id, control_type, found_index=0, timeout_s=10):
    ctl = _control(title, auto_id, control_type, "", 0)
    try:
        r = await _call({"cmd": "wait", "app": app, "control": ctl,
                         "timeout": int(timeout_s) * 1000}, timeout=int(timeout_s) + 15)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    c = r.get("control") or {}
    return f"появился через {r.get('waited_ms')} мс: {c.get('control_type')} «{c.get('title')}»"


@T("windows_screenshot", "Скриншот окна приложения (или монитора, если app не задан: monitor=0 — весь экран). "
   "PNG сохраняется в data/shots и приходит картинкой в чат. Пример: windows_screenshot(app='Блокнот')",
   [P("app", desc="приложение (пусто = снимок экрана)", required=False, default=""),
    P("monitor", "integer", desc="номер монитора для полноэкранного снимка (0 = всё виртуальное полотно)",
      required=False, default=0)], C, core=True)
async def _(ctx, app, monitor):
    try:
        r = await _call({"cmd": "screenshot", "app": app or None, "monitor": int(monitor)},
                        timeout=40)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    data = (r or {}).get("dataBase64") or ""
    if not data:
        return ToolResult(False, "мост вернул пустой скриншот")
    path = os.path.join(app_dir(), "data", "shots", f"win_{int(time.time() * 1000)}.png")
    with open(path, "wb") as f:
        f.write(base64.b64decode(data))
    src = r.get("source", "?")
    return ToolResult(True, f"скриншот ({src}, {r.get('width')}x{r.get('height')}): {path}",
                      images=[path])


@T("windows_eval", "Выполнить Python-код в контексте окна приложения (pywinauto UIA) — аналог browser_tab_eval. "
   "В коде доступен win (окно), Desktop, pywinauto, keyboard. Возвращает значение последнего выражения и stdout. "
   "Пример: windows_eval(app='Блокнот', code=\"win.child_window(title='Файл', control_type='MenuItem').click_input()\") "
   "или code=\"[c.window_text() for c in win.children()]\"",
   [P("app", desc="приложение (пусто = win=None, но Desktop доступен)", required=False, default=""),
    P("code", desc="Python-код (pywinauto UIA)"),
    P("timeout_s", "integer", desc="секунд на выполнение", required=False, default=30)], C)
async def _(ctx, app, code, timeout_s):
    try:
        r = await _call({"cmd": "eval", "app": app or None, "code": code,
                         "timeout": int(timeout_s) * 1000}, timeout=int(timeout_s) + 15)
    except ToolBridgeDown as e:
        return ToolResult(False, str(e))
    parts = []
    if r.get("stdout"):
        parts.append("stdout: " + str(r["stdout"])[:2000])
    parts.append("result: " + json.dumps(r.get("result"), ensure_ascii=False, default=str)[:3500])
    return "\n".join(parts)
