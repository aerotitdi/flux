"""Конвертеры величин (18)."""
from __future__ import annotations

import json

from .registry import P, REG, ToolSpec

C = "convert"
T = REG.tool

LINEAR = {
    "length": ("м", {"мм": 0.001, "см": 0.01, "м": 1, "км": 1000, "in": 0.0254, "ft": 0.3048,
                     "yd": 0.9144, "mi": 1609.344, "nmi": 1852, "mil": 0.0000254, "мкм": 0.000001,
                     "парсек": 3.0857e16, "световой_год": 9.4607e15}),
    "mass": ("кг", {"мг": 1e-6, "г": 0.001, "кг": 1, "т": 1000, "oz": 0.0283495, "lb": 0.45359237,
                    "stone": 6.35029318, "центнер": 100, "карат": 0.0002}),
    "volume": ("л", {"мл": 0.001, "л": 1, "м3": 1000, "см3": 0.001, "gal_us": 3.785411784,
                     "qt": 0.946352946, "pt": 0.473176473, "cup": 0.2365882365, "floz": 0.0295735295625,
                     "tbsp": 0.01478676478125, "tsp": 0.00492892159375, "баррель": 158.987294928}),
    "area": ("м2", {"мм2": 1e-6, "см2": 1e-4, "м2": 1, "км2": 1e6, "га": 1e4, "сотка": 100,
                    "in2": 0.00064516, "ft2": 0.09290304, "yd2": 0.83612736, "acre": 4046.8564224, "mi2": 2589988.110336}),
    "speed": ("м/с", {"м/с": 1, "км/ч": 0.2777777778, "mph": 0.44704, "ft/s": 0.3048, "узел": 0.514444444, "мах": 340.29}),
    "duration": ("с", {"мс": 0.001, "с": 1, "мин": 60, "ч": 3600, "день": 86400, "неделя": 604800,
                       "месяц": 2629800, "год": 31557600}),
    "data": ("байт", {"бит": 0.125, "байт": 1, "КБ": 1024, "МБ": 1024 ** 2, "ГБ": 1024 ** 3,
                      "ТБ": 1024 ** 4, "ПБ": 1024 ** 5, "Kbit": 128, "Mbit": 128 * 1024}),
    "pressure": ("Па", {"Па": 1, "кПа": 1000, "бар": 1e5, "атм": 101325, "mmHg": 133.322387415,
                        "psi": 6894.757293168}),
    "energy": ("Дж", {"Дж": 1, "кДж": 1000, "кал": 4.184, "ккал": 4184, "Вт*ч": 3600, "кВт*ч": 3.6e6,
                      "эВ": 1.602176634e-19, "BTU": 1055.05585262}),
    "power": ("Вт", {"Вт": 1, "кВт": 1000, "МВт": 1e6, "л.с.": 735.49875, "hp": 745.6998715823}),
    "force": ("Н", {"Н": 1, "кН": 1000, "кгс": 9.80665, "lbf": 4.4482216153}),
    "angle": ("рад", {"рад": 1, "град": 0.017453292519943295, "оборот": 6.283185307179586,
                      "угл_мин": 0.0002908882086657216}),
    "frequency": ("Гц", {"Гц": 1, "кГц": 1e3, "МГц": 1e6, "ГГц": 1e9, "об/мин": 1 / 60.0}),
    "density": ("кг/м3", {"кг/м3": 1, "г/см3": 1000, "г/л": 1, "lb/ft3": 16.01846337396}),
}

DESCR = {
    "length": "длины (мм, см, м, км, in, ft, yd, mi, nmi, mil, мкм, парсек, световой_год)",
    "mass": "массы (мг, г, кг, т, oz, lb, stone, центнер, карат)",
    "volume": "объёма (мл, л, м3, см3, gal_us, qt, pt, cup, floz, tbsp, tsp, баррель)",
    "area": "площади (мм2, см2, м2, км2, га, сотка, in2, ft2, yd2, acre, mi2)",
    "speed": "скорости (м/с, км/ч, mph, ft/s, узел, мах)",
    "duration": "времени (мс, с, мин, ч, день, неделя, месяц, год)",
    "data": "данных (бит, байт, КБ, МБ, ГБ, ТБ, ПБ, Kbit, Mbit)",
    "pressure": "давления (Па, кПа, бар, атм, mmHg, psi)",
    "energy": "энергии (Дж, кДж, кал, ккал, Вт*ч, кВт*ч, эВ, BTU)",
    "power": "мощности (Вт, кВт, МВт, л.с., hp)",
    "force": "силы (Н, кН, кгс, lbf)",
    "angle": "углов (рад, град, оборот, угл_мин)",
    "frequency": "частоты (Гц, кГц, МГц, ГГц, об/мин)",
    "density": "плотности (кг/м3, г/см3, г/л, lb/ft3)",
}


def _mk(key):
    base, units = LINEAR[key]

    def handler(ctx, value, src, dst):
        if src not in units or dst not in units:
            return f"единицы должны быть из: {', '.join(units)}"
        v = value * units[src] / units[dst]
        return f"{value} {src} = {v:g} {dst}"

    units_list = list(units)
    REG.add(ToolSpec(
        name=f"convert_{key}",
        description=f"Конвертер {DESCR[key]}",
        params=[P("value", "number", desc="значение"),
                P("src", desc="исходная единица", enum=units_list),
                P("dst", desc="целевая единица", enum=units_list)],
        handler=handler, category=C))


for _k in LINEAR:
    _mk(_k)


@T("convert_temperature", "Конвертер температуры (C, F, K)", [
    P("value", "number", desc="значение"),
    P("src", desc="откуда", enum=["C", "F", "K"]),
    P("dst", desc="куда", enum=["C", "F", "K"])], C)
def _(ctx, value, src, dst):
    c = value if src == "C" else (value - 32) * 5 / 9 if src == "F" else value - 273.15
    r = c if dst == "C" else c * 9 / 5 + 32 if dst == "F" else c + 273.15
    return f"{value} {src} = {r:g} {dst}"


@T("convert_number_base", "Число между системами счисления (2..36)", [
    P("value", desc="число строкой"), P("src_base", "integer", desc="основание от"), P("dst_base", "integer", desc="основание в")], C)
def _(ctx, value, src_base, dst_base):
    n = int(value, src_base)
    digits = "0123456789abcdefghijklmnopqrstuvwxyz"
    if n == 0:
        return "0"
    neg = n < 0
    n = abs(n)
    out = ""
    while n:
        out = digits[n % dst_base] + out
        n //= dst_base
    return ("-" if neg else "") + out


@T("convert_roman", "Число <-> римская запись", [P("value", desc="число или римская строка")], C)
def _(ctx, value):
    vals = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"),
            (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]
    if value.strip().isdigit():
        n = int(value)
        out = ""
        for v, s in vals:
            while n >= v:
                out += s; n -= v
        return out
    rev = {"M": 1000, "D": 500, "C": 100, "L": 50, "X": 10, "V": 5, "I": 1}
    tot = 0
    up = value.upper()
    for i, ch in enumerate(up):
        if i + 1 < len(up) and rev[ch] < rev[up[i + 1]]:
            tot -= rev[ch]
        else:
            tot += rev[ch]
    return tot


async def _cur(ctx, value, src, dst):
    import aiohttp
    src, dst = src.upper(), dst.upper()
    async with aiohttp.ClientSession() as s:
        async with s.get(f"https://open.er-api.com/v6/latest/{src}") as r:
            data = await r.json()
    rate = (data.get("rates") or {}).get(dst)
    if not rate:
        return f"нет курса {dst}"
    return f"{value} {src} = {value * rate:g} {dst}"


REG.add(ToolSpec(
    name="convert_currency",
    description="Конвертер валют по актуальному курсу (open.er-api.com)",
    params=[P("value", "number", desc="сумма"), P("src", desc="код валюты от", required=False, default="USD"),
            P("dst", desc="код валюты в", required=False, default="RUB")],
    handler=_cur, category=C))
