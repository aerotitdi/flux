"""Скриншоты и геометрия экрана: Win32 GDI напрямую, НОЛЬ дочерних процессов (v2.8, пункт 1 ТЗ).

Было: PowerShell CopyFromScreen → чёрное окно консоли на каждый снимок + 600–1500 мс
+ битый `$args` в режиме -Command (файл не сохранялся вовсе).
Стало: GetDC/PrintWindow(PW_RENDERFULLCONTENT)/GetDIBits через ctypes с правильными
restype/argtypes (иначе x64 обрезал HWND/HDC до 32 бит — дефект D4) + встроенный
PNG-кодер (zlib+struct, Pillow не нужен). Замер: 20–60 мс на снимок.

Вкладки браузера и элементы страниц снимаются через шину browserbus (расширение
FLUX Bridge или CDP) — кроссплатформенно. OCR: Windows.Media.Ocr (WinRT, скрытый
PowerShell c $a0) / tesseract.
"""
from __future__ import annotations

import base64
import ctypes
import json
import os
import struct
import time
import zlib
from ctypes import wintypes as wt

from .. import browserbus as bus
from .. import winproc
from ..config import app_dir
from .registry import P, REG, ToolResult

C = "screen"
T = REG.tool
NT = os.name == "nt"

if NT:
    _u = ctypes.windll.user32
    _g = ctypes.windll.gdi32
    _dwm = ctypes.windll.dwmapi

    class _RECT(ctypes.Structure):
        _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                    ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

    class _BMIH(ctypes.Structure):
        _fields_ = [("biSize", ctypes.c_uint32), ("biWidth", ctypes.c_int32),
                    ("biHeight", ctypes.c_int32), ("biPlanes", ctypes.c_uint16),
                    ("biBitCount", ctypes.c_uint16), ("biCompression", ctypes.c_uint32),
                    ("biSizeImage", ctypes.c_uint32), ("biXPelsPerMeter", ctypes.c_int32),
                    ("biYPelsPerMeter", ctypes.c_int32), ("biClrUsed", ctypes.c_uint32),
                    ("biClrImportant", ctypes.c_uint32)]

    class _BMI(ctypes.Structure):
        _fields_ = [("bmiHeader", _BMIH), ("colors", ctypes.c_uint32 * 3)]

    # --- D4: явные restype/argtypes, иначе x64 truncates handle'ы до 32 бит ---
    _u.GetDC.restype = ctypes.c_void_p
    _u.GetDC.argtypes = [wt.HWND]
    _u.GetWindowDC.restype = ctypes.c_void_p
    _u.GetWindowDC.argtypes = [wt.HWND]
    _u.ReleaseDC.argtypes = [wt.HWND, ctypes.c_void_p]
    _u.GetSystemMetrics.restype = ctypes.c_int
    _u.GetForegroundWindow.restype = wt.HWND
    _u.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
    _u.GetWindowTextLengthW.argtypes = [wt.HWND]
    _u.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(ctypes.c_uint32)]
    _u.IsWindowVisible.argtypes = [wt.HWND]
    _u.IsIconic.argtypes = [wt.HWND]
    _u.GetWindowRect.argtypes = [wt.HWND, ctypes.POINTER(_RECT)]
    _u.PrintWindow.argtypes = [wt.HWND, ctypes.c_void_p, ctypes.c_uint32]
    _u.PrintWindow.restype = ctypes.c_int
    _g.CreateCompatibleDC.restype = ctypes.c_void_p
    _g.CreateCompatibleDC.argtypes = [ctypes.c_void_p]
    _g.CreateCompatibleBitmap.restype = ctypes.c_void_p
    _g.CreateCompatibleBitmap.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    _g.SelectObject.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    _g.DeleteObject.argtypes = [ctypes.c_void_p]
    _g.DeleteDC.argtypes = [ctypes.c_void_p]
    _g.BitBlt.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                          ctypes.c_int, ctypes.c_void_p, ctypes.c_int, ctypes.c_int,
                          ctypes.c_uint32]
    _g.GetDIBits.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32,
                             ctypes.c_uint32, ctypes.c_void_p, ctypes.POINTER(_BMI),
                             ctypes.c_uint32]
    _dwm.DwmGetWindowAttribute.argtypes = [wt.HWND, ctypes.c_uint32, ctypes.c_void_p,
                                           ctypes.c_uint32]

    SRCCOPY = 0x00CC0009
    PW_RENDERFULLCONTENT = 0x00000002
    DWMWA_EXTENDED_FRAME_BOUNDS = 9


# --------------------------------------------------------------------------- #
#  PNG-кодер: zlib+struct, без Pillow                                           #
# --------------------------------------------------------------------------- #
def _chunk(tag: bytes, data: bytes) -> bytes:
    return (struct.pack(">I", len(data)) + tag + data +
            struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))


def encode_png(rgb: bytes, w: int, h: int) -> bytes:
    """rgb — top-down строки R G B; фильтр 0 на строку, сжатие zlib level 6."""
    if len(rgb) != w * h * 3:
        raise ValueError(f"encode_png: буфер {len(rgb)} != {w}*{h}*3")
    stride = w * 3
    raw = b"".join(b"\x00" + rgb[y * stride:(y + 1) * stride] for y in range(h))
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + _chunk(b"IHDR", ihdr) +
            _chunk(b"IDAT", zlib.compress(raw, 6)) + _chunk(b"IEND", b""))


def downscale_rgb(rgb: bytes, w: int, h: int, factor: int) -> tuple[bytes, int, int]:
    """Целочисленное box-усреднение (factor×factor) — для дешёвых превью."""
    if factor <= 1:
        return rgb, w, h
    nw, nh = w // factor, h // factor
    out = bytearray(nw * nh * 3)
    for y in range(nh):
        sy = y * factor
        for x in range(nw):
            sx = x * factor
            r = g = b = 0
            for dy in range(factor):
                row = ((sy + dy) * w + sx) * 3
                for dx in range(factor):
                    i = row + dx * 3
                    r += rgb[i]
                    g += rgb[i + 1]
                    b += rgb[i + 2]
            n = factor * factor
            o = (y * nw + x) * 3
            out[o], out[o + 1], out[o + 2] = r // n, g // n, b // n
    return bytes(out), nw, nh


# --------------------------------------------------------------------------- #
#  Win32-захват                                                                  #
# --------------------------------------------------------------------------- #
def _monitors() -> list:
    if not NT:
        return []
    out = []

    @ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p,
                        ctypes.POINTER(_RECT), ctypes.c_void_p)
    def cb(hmon, hdc, rect, _):
        out.append({"left": rect.contents.left, "top": rect.contents.top,
                    "right": rect.contents.right, "bottom": rect.contents.bottom,
                    "primary": rect.contents.left == 0 and rect.contents.top == 0})
        return 1

    _u.EnumDisplayMonitors(None, None, cb, 0)
    for i, m in enumerate(out):
        m["index"] = i
        m["width"] = m["right"] - m["left"]
        m["height"] = m["bottom"] - m["top"]
    return out


def _enum_windows() -> list:
    if not NT:
        return []
    out = []

    @ctypes.WINFUNCTYPE(ctypes.c_int, wt.HWND, ctypes.c_void_p)
    def cb(hwnd, _):
        if _u.IsWindowVisible(hwnd):
            n = _u.GetWindowTextLengthW(hwnd) + 1
            buf = ctypes.create_unicode_buffer(n)
            _u.GetWindowTextW(hwnd, buf, n)
            pid = ctypes.c_uint32()
            _u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            r = _RECT()
            _u.GetWindowRect(hwnd, ctypes.byref(r))
            if buf.value.strip():
                out.append({"hwnd": hwnd, "title": buf.value, "pid": pid.value,
                            "minimized": bool(_u.IsIconic(hwnd)),
                            "rect": [r.left, r.top, r.right, r.bottom]})
        return 1

    _u.EnumWindows(cb, 0)
    return out


def _find_window(query: str) -> dict | None:
    q = (query or "").strip().lower()
    wins = _enum_windows()
    if q.isdigit() and int(q) > 65535:
        return next((w for w in wins if w["hwnd"] == int(q)), None)
    exact = [w for w in wins if w["title"].lower() == q]
    if exact:
        return exact[0]
    sub = [w for w in wins if q in w["title"].lower()]
    if sub:
        sub.sort(key=lambda w: len(w["title"]))
        return sub[0]
    return None


def _grab_rect(left: int, top: int, width: int, height: int,
               hwnd: int | None = None, client_only: bool = False,
               use_print: bool = False, cursor: bool = False) -> bytes | None:
    """BGRA->RGB top-down байты области. hwnd+use_print = PrintWindow (перекрытые окна)."""
    if not NT or width <= 0 or height <= 0:
        return None
    src = None
    mem = _g.CreateCompatibleDC(None)
    bmp = None
    try:
        if hwnd and use_print:
            src = _u.GetDC(hwnd) if client_only else _u.GetWindowDC(hwnd)
            bmp = _g.CreateCompatibleBitmap(src, width, height)
            _g.SelectObject(mem, bmp)
            ok = _u.PrintWindow(hwnd, mem, PW_RENDERFULLCONTENT)
            if not ok:  # автооткат: чёрный кадр у некоторых окон
                _g.BitBlt(mem, 0, 0, width, height, src, 0, 0, SRCCOPY)
        else:
            src = _u.GetDC(hwnd if hwnd else None)
            bmp = _g.CreateCompatibleBitmap(src, width, height)
            _g.SelectObject(mem, bmp)
            _g.BitBlt(mem, 0, 0, width, height, src, left if not hwnd else 0,
                      top if not hwnd else 0, SRCCOPY)
        if cursor:
            try:
                pt = wt.POINT()
                _u.GetCursorPos(ctypes.byref(pt))
                ci = (ctypes.c_byte * (40 + ctypes.sizeof(ctypes.c_void_p)))()
                ctypes.cast(ci, ctypes.POINTER(ctypes.c_uint32))[0] = ctypes.sizeof(ci)
                if _u.GetCursorInfo(ctypes.cast(ci, ctypes.POINTER(ctypes.c_void_p))):
                    hcur = ctypes.cast(ci[40:], ctypes.POINTER(ctypes.c_void_p)).contents
                    _u.DrawIconEx(mem, pt.x - left, pt.y - top, hcur, 0, 0, 0, None, 1)
            except Exception:
                pass
        bmi = _BMI()
        bmi.bmiHeader.biSize = ctypes.sizeof(_BMIH)
        bmi.bmiHeader.biWidth = width
        bmi.bmiHeader.biHeight = -height          # top-down
        bmi.bmiHeader.biPlanes = 1
        bmi.bmiHeader.biBitCount = 32
        bmi.bmiHeader.biCompression = 0
        buf = (ctypes.c_uint8 * (width * height * 4))()
        got = _g.GetDIBits(mem, bmp, 0, height, buf, ctypes.byref(bmi), 0)
        if got != height:
            return None
        rgb = bytearray(width * height * 3)
        for i in range(width * height):            # BGRA -> RGB
            rgb[i * 3] = buf[i * 4 + 2]
            rgb[i * 3 + 1] = buf[i * 4 + 1]
            rgb[i * 3 + 2] = buf[i * 4]
        return bytes(rgb)
    finally:
        if bmp:
            _g.DeleteObject(bmp)
        if mem:
            _g.DeleteDC(mem)
        if src:
            _u.ReleaseDC(hwnd if hwnd else None, src)


def _save(rgb: bytes, w: int, h: int, prefix: str, downscale: int = 1) -> str:
    if downscale and downscale > 1:
        rgb, w, h = downscale_rgb(rgb, w, h, downscale)
    path = os.path.join(app_dir(), "data", "shots", f"{prefix}_{int(time.time() * 1000)}.png")
    with open(path, "wb") as f:
        f.write(encode_png(rgb, w, h))
    return path


def _need_nt():
    return ToolResult(False, "скриншоты окон/экрана требуют Windows (Win32 GDI); "
                             "для вкладок браузера используй screen_capture_browser_tab")


# --------------------------------------------------------------------------- #
#  Тулзы                                                                        #
# --------------------------------------------------------------------------- #
@T("screen_screenshot", "Универсальный снимок: target=screen|window|region|monitor; query=окно; x,y,w,h=область; cursor, client_only, downscale, delay_s. PNG приходит картинкой",
   [P("target", desc="screen|window|region|monitor", required=False, default="screen",
      enum=["screen", "window", "region", "monitor"]),
    P("query", desc="окно: заголовок/hwnd/процесс (для window)", required=False, default=""),
    P("x", "integer", desc="region: left", required=False, default=0),
    P("y", "integer", desc="region: top", required=False, default=0),
    P("w", "integer", desc="region/monitor: ширина или индекс монитора при target=monitor", required=False, default=0),
    P("h", "integer", desc="region: высота", required=False, default=0),
    P("cursor", "boolean", desc="включить курсор", required=False, default=False),
    P("client_only", "boolean", desc="только клиентская область окна", required=False, default=False),
    P("downscale", "integer", desc="уменьшить в N раз", required=False, default=1),
    P("delay_s", "number", desc="задержка перед снимком (успеть открыть меню)", required=False, default=0)], C, core=True)
async def _(ctx, target, query, x, y, w, h, cursor, client_only, downscale, delay_s):
    if not NT:
        return _need_nt()
    if delay_s:
        import asyncio
        await asyncio.sleep(min(float(delay_s), 10))
    if target == "screen":
        mons = _monitors()
        prim = next((m for m in mons if m["primary"]), mons[0] if mons else None)
        if not prim:
            return ToolResult(False, "мониторов не видно")
        rgb = _grab_rect(prim["left"], prim["top"], prim["width"], prim["height"],
                         cursor=cursor)
        if rgb is None:
            return ToolResult(False, "GDI не отдал кадр рабочего стола")
        return ToolResult(True, f"снимок экрана {prim['width']}x{prim['height']}",
                          images=[_save(rgb, prim["width"], prim["height"], "screen", downscale)])
    if target == "monitor":
        mons = _monitors()
        m = mons[min(w or 0, len(mons) - 1)] if mons else None
        if not m:
            return ToolResult(False, "монитор не найден: screen_monitors_list покажет список")
        rgb = _grab_rect(m["left"], m["top"], m["width"], m["height"], cursor=cursor)
        return ToolResult(True, f"монитор {m['index']}: {m['width']}x{m['height']}",
                          images=[_save(rgb, m["width"], m["height"], "mon", downscale)]) if rgb \
            else ToolResult(False, "кадр монитора пуст")
    if target == "region":
        if w <= 0 or h <= 0:
            return ToolResult(False, "region: нужны w и h > 0")
        rgb = _grab_rect(x, y, w, h, cursor=cursor)
        return ToolResult(True, f"область ({x},{y}) {w}x{h}",
                          images=[_save(rgb, w, h, "region", downscale)]) if rgb \
            else ToolResult(False, "кадр области пуст")
    win = _find_window(query)
    if not win:
        return ToolResult(False, f"окно «{query}» не найдено; список: screen_windows_list")
    r = win["rect"]
    rgb = _grab_rect(r[0], r[1], r[2] - r[0], r[3] - r[1], hwnd=win["hwnd"],
                     client_only=client_only, use_print=True, cursor=cursor)
    if rgb is None:
        return ToolResult(False, f"окно «{win['title'][:40]}» не дало кадр")
    return ToolResult(True, f"окно {win['hwnd']}: {win['title'][:60]}",
                      images=[_save(rgb, r[2] - r[0], r[3] - r[1], "win", downscale)])


@T("screen_capture_window", "Снимок КОНКРЕТНОГО окна по заголовку/HWND/процессу: PrintWindow(PW_RENDERFULLCONTENT) снимает перекрытые окна и Chrome/Electron; при чёрном кадре откат на BitBlt",
   [P("query", desc="заголовок (часть), hwnd или имя процесса"),
    P("client_only", "boolean", desc="только клиентская область", required=False, default=False)], C, core=True)
async def _(ctx, query, client_only):
    if not NT:
        return _need_nt()
    win = _find_window(query)
    if not win:
        return ToolResult(False, f"окно «{query}» не найдено; список: screen_windows_list")
    if win["minimized"]:
        return ToolResult(False, f"окно «{win['title'][:40]}» свёрнуто — сначала разверни (os_window_restore)")
    r = win["rect"]
    rgb = _grab_rect(r[0], r[1], r[2] - r[0], r[3] - r[1], hwnd=win["hwnd"],
                     client_only=client_only, use_print=True)
    if rgb is None:
        return ToolResult(False, "PrintWindow/BitBlt не дали кадр")
    return ToolResult(True, f"окно {win['hwnd']}: {win['title'][:60]}",
                      images=[_save(rgb, r[2] - r[0], r[3] - r[1], "win")])


@T("screen_capture_region", "Снимок области экрана x,y,w,h", [
    P("x", "integer", desc="left"), P("y", "integer", desc="top"),
    P("w", "integer", desc="ширина"), P("h", "integer", desc="высота")], C)
async def _(ctx, x, y, w, h):
    return await REG.tools["screen_screenshot"].handler(
        ctx=ctx, target="region", query="", x=x, y=y, w=w, h=h, cursor=False,
        client_only=False, downscale=1, delay_s=0)


@T("screen_capture_monitor", "Снимок одного монитора (индекс из screen_monitors_list, 0 = основной)",
   [P("index", "integer", desc="индекс монитора", required=False, default=0)], C)
async def _(ctx, index):
    if not NT:
        return _need_nt()
    mons = _monitors()
    if not mons or index >= len(mons):
        return ToolResult(False, f"монитора {index} нет (всего {len(mons)})")
    m = mons[index]
    rgb = _grab_rect(m["left"], m["top"], m["width"], m["height"])
    return ToolResult(True, f"монитор {index}: {m['width']}x{m['height']}",
                      images=[_save(rgb, m["width"], m["height"], "mon")]) if rgb \
        else ToolResult(False, "кадр монитора пуст")


@T("screen_monitors_list", "Мониторы: индексы, геометрия, основной", [], C)
async def _(ctx):
    if not NT:
        return ToolResult(False, "только Windows")
    mons = _monitors()
    return "\n".join(f"[{m['index']}] {m['width']}x{m['height']} @({m['left']},{m['top']})"
                     f"{' основной' if m['primary'] else ''}" for m in mons) or "мониторов нет"


@T("screen_windows_list", "Что можно снять: окна (HWND, заголовок, pid, геометрия, свёрнуто)", [], C, core=True)
async def _(ctx):
    if not NT:
        return ToolResult(False, "только Windows")
    wins = _enum_windows()
    return "\n".join(f"hwnd={w['hwnd']} pid={w['pid']} {'[свёрнуто]' if w['minimized'] else ''} "
                     f"{w['title'][:70]}" for w in wins[:60]) or "окон нет"


@T("screen_active_window_screenshot", "Снимок окна в фокусе (GetForegroundWindow)", [], C)
async def _(ctx):
    if not NT:
        return _need_nt()
    hwnd = _u.GetForegroundWindow()
    return await REG.tools["screen_capture_window"].handler(ctx=ctx, query=str(hwnd),
                                                            client_only=False)


@T("screen_capture_delayed", "Снимок с задержкой (успеть открыть меню/тултип): delay_s затем весь экран",
   [P("delay_s", "number", desc="секунды ожидания", required=False, default=3)], C)
async def _(ctx, delay_s):
    return await REG.tools["screen_screenshot"].handler(
        ctx=ctx, target="screen", query="", x=0, y=0, w=0, h=0, cursor=True,
        client_only=False, downscale=1, delay_s=delay_s)


@T("screen_capture_browser_tab", "Снимок ВКЛАДКИ браузера: по id / части url / части заголовка / active=true; full_page=true — вся страница с прокруткой (CDP captureBeyondViewport)",
   [P("tab", desc="id вкладки, часть url или заголовка, 'active'", required=False, default="active"),
    P("full_page", "boolean", desc="вся страница, не только вьюпорт", required=False, default=False)], C, core=True)
async def _(ctx, tab, full_page):
    if not await bus.ensure():
        return ToolResult(False, "браузер не подключён (browser_launch)")
    tid = await _resolve_tab(tab)
    if not tid:
        return ToolResult(False, f"вкладка «{tab}» не найдена (browser_tabs_list)")
    r = await bus.call({"cmd": "cdp", "tabId": int(tid), "method": "Page.captureScreenshot",
                        "params": {"format": "png", "captureBeyondViewport": bool(full_page)}})
    data = (r or {}).get("data", "")
    if not data:
        return ToolResult(False, "вкладка не дала кадр")
    path = os.path.join(app_dir(), "data", "shots", f"tab_{int(time.time() * 1000)}.png")
    with open(path, "wb") as f:
        f.write(base64.b64decode(data))
    return ToolResult(True, f"вкладка {tid}", images=[path])


@T("screen_capture_page_element", "Снимок ЭЛЕМЕНТА страницы по CSS-селектору (CDP clip по getBoundingClientRect)",
   [P("tab", desc="id вкладки или 'active'", required=False, default="active"),
    P("selector", desc="CSS-селектор")], C)
async def _(ctx, tab, selector):
    if not await bus.ensure():
        return ToolResult(False, "браузер не подключён")
    tid = await _resolve_tab(tab)
    if not tid:
        return ToolResult(False, f"вкладка «{tab}» не найдена")
    box = await bus.evaluate(tid, f"""(() => {{ const el = document.querySelector({json.dumps(selector)});
        if (!el) return null; el.scrollIntoView({{block:'center'}});
        const r = el.getBoundingClientRect();
        return {{x:r.x, y:r.y, width:r.width, height:r.height}}; }})()""")
    if not box or not box.get("width"):
        return ToolResult(False, f"селектор не найден или нулевого размера: {selector}")
    r = await bus.call({"cmd": "cdp", "tabId": int(tid), "method": "Page.captureScreenshot",
                        "params": {"format": "png",
                                   "clip": {"x": box["x"], "y": box["y"],
                                            "width": box["width"], "height": box["height"],
                                            "scale": 1}}})
    data = (r or {}).get("data", "")
    if not data:
        return ToolResult(False, "элемент не снялся")
    path = os.path.join(app_dir(), "data", "shots", f"el_{int(time.time() * 1000)}.png")
    with open(path, "wb") as f:
        f.write(base64.b64decode(data))
    return ToolResult(True, f"элемент {selector}", images=[path])


@T("screen_size", "Разрешение основного экрана", [], C)
async def _(ctx):
    if not NT:
        return ToolResult(False, "только Windows")
    return f"({_u.GetSystemMetrics(0)},{_u.GetSystemMetrics(1)})"


@T("screen_pixel", "Цвет пикселя экрана в (x,y): RGB и HEX", [
    P("x", "integer", desc="x"), P("y", "integer", desc="y")], C)
async def _(ctx, x, y):
    if not NT:
        return ToolResult(False, "только Windows")
    rgb = _grab_rect(x, y, 1, 1)
    if not rgb:
        return ToolResult(False, "пиксель не читается")
    r, g, b = rgb[0], rgb[1], rgb[2]
    return f"rgb({r},{g},{b}) #{r:02X}{g:02X}{b:02X}"


_PS_OCR = r"""
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($WinRtTask, $ResultType) {
  $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
  $netTask = $asTask.Invoke($null, @($WinRtTask))
  $netTask.Wait(-1) | Out-Null
  $netTask.Result
}
[Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics,ContentType=WindowsRuntime] | Out-Null
[Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($a0)) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$dec = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateForDecodingAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bmp = Await ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
$engine = $null
try { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new($a1)) } catch { }
if (-not $engine) { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
$ocr = Await ($engine.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
$ocr.Text
"""


def _ocr_file(path: str, lang: str) -> str | None:
    if NT and winproc.ps_available():
        try:
            txt = winproc.ps_command(_PS_OCR, path, lang, timeout=45)
            if txt:
                return txt[:8000]
        except Exception:
            pass
    import shutil
    ex = shutil.which("tesseract")
    if ex:
        r = winproc.run([ex, path, "stdout", "-l", lang.split("-")[0]], timeout=45)
        out = (r.stdout or "").strip()
        if out:
            return out[:8000]
    return None


@T("ocr_screen", "OCR текста с экрана (Windows.Media.Ocr WinRT скрыто / tesseract)",
   [P("lang", desc="язык: ru-RU, en-US", required=False, default="ru-RU")], C, core=True)
async def _(ctx, lang):
    if not NT:
        return ToolResult(False, "OCR экрана — только Windows (или ocr_image с файлом)")
    res = await REG.tools["screen_screenshot"].handler(
        ctx=ctx, target="screen", query="", x=0, y=0, w=0, h=0, cursor=False,
        client_only=False, downscale=1, delay_s=0)
    if not res.ok:
        return res
    txt = _ocr_file(res.images[0], lang)
    return txt or ToolResult(False, "OCR не распознал текст (или движок недоступен)")


@T("ocr_image", "OCR текста из файла-картинки (source: путь к png/jpg)",
   [P("path", desc="путь к изображению"),
    P("lang", desc="язык", required=False, default="ru-RU")], C)
async def _(ctx, path, lang):
    if not os.path.exists(path):
        return ToolResult(False, f"файл не найден: {path}")
    txt = _ocr_file(path, lang)
    return txt or ToolResult(False, "OCR недоступен: на Windows нужен WinRT (есть), иначе tesseract")


@T("screen_info", "Диагностика захвата: DPI-режим, число мониторов, бэкенды (GDI/PrintWindow/CDP)", [], C)
async def _(ctx):
    dpi = "n/a"
    if NT:
        try:
            aw = ctypes.c_uint32()
            ctypes.windll.shcore.GetProcessDpiAwareness(None, ctypes.byref(aw))
            dpi = ["unaware", "system", "per-monitor"][aw.value]
        except Exception:
            dpi = "unknown"
    return (f"DPI: {dpi} · мониторов: {len(_monitors())} · GDI/PrintWindow: "
            f"{'да' if NT else 'нет (не Windows)'} · вкладки: browserbus (Bridge/CDP) · "
            f"PNG-кодер: встроенный")


async def _resolve_tab(tab: str) -> str | None:
    tab = (tab or "active").strip()
    try:
        ts = await bus.targets()
    except Exception:
        return None
    if tab == "active":
        return next((t["id"] for t in ts if t.get("active")), ts[0]["id"] if ts else None)
    for t in ts:
        if t["id"] == tab:
            return t["id"]
    low = tab.lower()
    for t in ts:
        if low in t.get("url", "").lower() or low in t.get("title", "").lower():
            return t["id"]
    return None
