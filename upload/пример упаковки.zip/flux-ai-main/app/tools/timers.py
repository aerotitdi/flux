"""Тулзы таймеров и уведомлений (13, категория timers) — v2.8, пункт 3 ТЗ.

Таймер срабатывает ВНЕ хода чата: планировщик app/timers.py тикает в daemon-потоке,
звук идёт через app/notify (ОС), событие — через app/events (SSE в окно),
а модель на следующем ходе получает явную инструкцию сообщить пользователю.
"""
from __future__ import annotations

import time

from .. import events, notify, timers
from .registry import P, REG, ToolResult

C = "timers"
T = REG.tool


def _fmt(t: dict) -> str:
    left = timers.human_left(t["due"] - time.time())
    extra = ""
    if t.get("interval"):
        extra = f", каждые {timers.human_left(t['interval'])}"
        if t.get("left"):
            extra += f" (осталось {t['left']})"
    if t.get("paused"):
        extra += ", НА ПАУЗЕ"
    return f"{t['id']} через {left}{extra}: {t['label']}"


@T("timer_set", "Поставить таймер/напоминание: «300», «5 минут», «1ч30м», «14:30», «завтра 9:00», «в пятницу 18:00», «в 9 вечера». Сработает даже если пользователь молчит",
   [P("when", desc="когда: длительность или момент"), P("label", desc="текст напоминания")], C, core=True)
async def _(ctx, when, label):
    try:
        due, interval, times = timers.parse_when(when)
    except timers.WhenError as e:
        return ToolResult(False, str(e))
    t = timers.STORE.add(due, label, interval, times)
    timers.SCHEDULER and timers.SCHEDULER.wake()
    return f"таймер {t['id']} заведён: {_fmt(t)}"


@T("timer_at", "Таймер на точный момент («14:30», «завтра 9:00») — синоним timer_set с явным временем",
   [P("when", desc="момент"), P("label", desc="текст напоминания")], C)
async def _(ctx, when, label):
    return await REG.tools["timer_set"].handler(ctx=ctx, when=when, label=label)


@T("timer_every", "Повторный таймер: «10 минут», «1 час» + сколько раз (times). Без дрейфа интервала",
   [P("period", desc="период: «10 минут», «1ч»"), P("label", desc="текст"),
    P("times", "integer", desc="сколько повторов (0 = бесконечно)", required=False, default=0)], C)
async def _(ctx, period, label, times):
    delta, _ = timers._parse_delta_or_clock(period.strip().lower(), time.time())
    if not delta:
        return ToolResult(False, f"не понял период «{period}»; примеры: «10 минут», «1ч»")
    t = timers.STORE.add(time.time() + delta, label, delta, int(times) or None)
    return f"повторный таймер {t['id']}: {_fmt(t)}"


@T("timer_list", "Список активных таймеров с обратным отсчётом", [], C, core=True)
async def _(ctx):
    ts = timers.STORE.list()
    return "\n".join(_fmt(t) for t in ts) or "активных таймеров нет"


@T("timer_next", "Ближайший таймер: когда и что напомнит", [], C)
async def _(ctx):
    ts = timers.STORE.list()
    return _fmt(ts[0]) if ts else "таймеров нет"


@T("timer_cancel", "Отменить таймер по id (t3), префиксу или части подписи",
   [P("target", desc="id или часть подписи")], C, core=True)
async def _(ctx, target):
    ok, msg = timers.STORE.cancel(target)
    if ok:
        events.publish("timer_changed", id=msg, action="cancel")
        return f"таймер {msg} отменён"
    return ToolResult(False, msg)


@T("timer_snooze", "Отложить сработавший/активный таймер на N минут (по умолчанию 5)",
   [P("target", desc="id или часть подписи"),
    P("minutes", "number", desc="на сколько минут", required=False, default=5)], C)
async def _(ctx, target, minutes):
    ok, msg = timers.STORE.snooze(target, float(minutes) * 60)
    if ok:
        notify.stop_sound()
        events.publish("timer_changed", id=msg, action="snooze", minutes=minutes)
        return f"таймер {msg} отложен на {minutes} мин"
    return ToolResult(False, msg)


@T("timer_pause", "Поставить таймер на паузу (не срабатывает, отсчёт стоит)",
   [P("target", desc="id или часть подписи")], C)
async def _(ctx, target):
    hits = timers.STORE.find(target)
    if len(hits) != 1:
        return ToolResult(False, "таймер не найден или неоднозначен")
    t = hits[0]
    t["paused"] = True
    t["paused_at"] = time.time()
    timers.STORE.save()
    events.publish("timer_changed", id=t["id"], action="pause")
    return f"таймер {t['id']} на паузе"


@T("timer_resume", "Снять таймер с паузы (дедлайн сдвигается на время паузы)",
   [P("target", desc="id или часть подписи")], C)
async def _(ctx, target):
    hits = timers.STORE.find(target)
    if len(hits) != 1:
        return ToolResult(False, "таймер не найден или неоднозначен")
    t = hits[0]
    if t.get("paused_at"):
        t["due"] += time.time() - t["paused_at"]
    t["paused"] = False
    t.pop("paused_at", None)
    timers.STORE.save()
    timers.SCHEDULER and timers.SCHEDULER.wake()
    events.publish("timer_changed", id=t["id"], action="resume")
    return f"таймер {t['id']} снова идёт: {_fmt(t)}"


@T("timer_stop_sound", "Выключить сирену уведомления (и системную, и в окне)", [], C, core=True)
async def _(ctx):
    notify.stop_sound()
    events.publish("sound_stop")
    return "звук выключен"


@T("timer_test_sound", "Проверить звук уведомления: сгенерировать WAV и проиграть", [], C)
async def _(ctx):
    backend = notify.play_sound("test")
    if backend == "none":
        return ToolResult(False, "звукового бэкенда нет (ни winsound, ни paplay/aplay/ffplay/mpv)")
    return f"звук играет через {backend}"


@T("notify_show", "Показать уведомление в окне FLUX (тост) + опционально системный тост ОС",
   [P("title", desc="заголовок"), P("text", desc="текст"),
    P("sound", "boolean", desc="со звуком", required=False, default=False)], C)
async def _(ctx, title, text, sound):
    events.publish("notify", title=title, text=text)
    if sound:
        notify.play_async("notify")
    notify.toast(title, text)
    return "уведомление отправлено в окно"


@T("timer_status", "Статус службы таймеров: жив ли планировщик, бэкенд звука, сколько таймеров", [], C)
async def _(ctx):
    sch = timers.SCHEDULER
    return (f"планировщик: {'жив' if sch and sch.is_alive() else 'НЕ ЗАПУЩЕН'} · "
            f"звук: {notify.sound_backend()} · активных таймеров: {len(timers.STORE.list())} · "
            f"подписчиков SSE: {events.subscribers_count()}")
