"""Память, заметки, todo, kv, таймеры (21)."""
from __future__ import annotations

import json
import time
import uuid

from ..memory import MEM
from .registry import P, REG

C = "memory"
T = REG.tool


@T("mem_remember", "Запомнить факт надолго", [P("fact", desc="что запомнить"), P("tag", desc="тег", required=False, default="general")], C, core=True)
def _(ctx, fact, tag):
    MEM.add_memory(fact, tag)
    return "запомнил"


@T("mem_recall", "Вспомнить факты по ключевым словам", [P("query", desc="запрос")], C, core=True)
def _(ctx, query):
    items = MEM.recall(query)
    return "\n".join(f"- [{i.get('tag')}] {i['text']}" for i in items) or "ничего не помню по этому поводу"


@T("mem_forget", "Забыть факт по id", [P("mem_id", desc="id записи")], C)
def _(ctx, mem_id):
    return "удалено" if MEM.forget(mem_id) else "не найдено"


@T("mem_list", "Все запомненные факты", [], C)
def _(ctx):
    return "\n".join(f"{i['id']} [{i.get('tag')}] {i['text']}" for i in MEM.memories()) or "пусто"


@T("note_add", "Добавить заметку", [P("title", desc="заголовок"), P("body", desc="текст")], C)
def _(ctx, title, body):
    return MEM.add_note(title, body)


@T("note_list", "Список заметок", [], C)
def _(ctx):
    return "\n".join(f"{n['id']} {n['title']}" for n in MEM.notes()) or "пусто"


@T("note_get", "Прочитать заметку по id", [P("note_id", desc="id")], C)
def _(ctx, note_id):
    n = MEM.get_note(note_id)
    return f"{n['title']}\n{n['body']}" if n else "не найдена"


@T("note_delete", "Удалить заметку", [P("note_id", desc="id")], C)
def _(ctx, note_id):
    return "удалено" if MEM.delete_note(note_id) else "не найдена"


@T("todo_add", "Добавить задачу в todo", [P("text", desc="задача")], C)
def _(ctx, text):
    return MEM.todo_add(text)


@T("todo_list", "Список задач todo", [], C)
def _(ctx):
    return "\n".join(f"{'[x]' if t['done'] else '[ ]'} {t['id']} {t['text']}" for t in MEM.todos()) or "пусто"


@T("todo_done", "Отметить задачу выполненной", [P("todo_id", desc="id")], C)
def _(ctx, todo_id):
    return "ok" if MEM.todo_done(todo_id) else "не найдена"


@T("todo_remove", "Удалить задачу", [P("todo_id", desc="id")], C)
def _(ctx, todo_id):
    return "ok" if MEM.todo_remove(todo_id) else "не найдена"


@T("kv_set", "KV-хранилище: положить значение", [P("key", desc="ключ"), P("value", desc="значение")], C)
def _(ctx, key, value):
    MEM.kv_set(key, value)
    return "ok"


@T("kv_get", "KV-хранилище: прочитать значение", [P("key", desc="ключ")], C)
def _(ctx, key):
    v = MEM.kv_get(key)
    return v if v is not None else "(нет ключа)"


@T("kv_delete", "KV-хранилище: удалить ключ", [P("key", desc="ключ")], C)
def _(ctx, key):
    return "ok" if MEM.kv_delete(key) else "не найдено"


@T("kv_list", "KV-хранилище: список ключей", [], C)
def _(ctx):
    return ", ".join(MEM.kv_keys()) or "пусто"


@T("session_stats", "Статистика сессии: сообщений, тулзов, время", [], C)
def _(ctx):
    s = ctx.get("session_stats", {})
    return json.dumps(s, ensure_ascii=False) or "пусто"


@T("chat_history_last", "Последние сообщения диалога (для самопроверки)", [P("n", "integer", desc="сколько", required=False, default=6)], C)
def _(ctx, n):
    msgs = ctx.get("history", [])[-n:]
    return "\n".join(f"{m['role']}: {str(m.get('content'))[:200]}" for m in msgs) or "пусто"
