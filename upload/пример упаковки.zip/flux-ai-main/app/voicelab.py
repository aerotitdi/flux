"""Голосовой тракт: микрофоны, TTS-движки (wingetgui / Edge TTS), STT-маршрутизация.

Микрофон — ТОЛЬКО браузерный (getUserMedia в окне/.exe или браузере):
консоль Flux для микрофона больше не открывается (пункт 2 ТЗ).

TTS-движки (voice.tts_engine):
  winget  — https://text-to-speech.wingetgui.com: POST /api/synthesize -> {audioUrl} (mp3, скачивание)
  edge    — локальная библиотека edge-tts
  browser/off — озвучка на стороне UI (speechSynthesis) / выключена
"""
from __future__ import annotations

import asyncio
import json
import os
import time

import aiohttp

from .config import CONFIG, app_dir

WINGET = "https://text-to-speech.wingetgui.com"

# --- микрофоны (бэкенд-энумерация опциональна, для консоли) ------------------
def list_mics() -> list[dict]:
    try:
        import sounddevice as sd
        devs = sd.query_devices()
        return [{"id": str(i), "name": d["name"]} for i, d in enumerate(devs) if d["max_input_channels"] > 0]
    except Exception:
        return []


# --- голоса ------------------------------------------------------------------
FALLBACK_VOICES = [
    {"short": "ru-RU-DmitryNeural", "gender": "Male"},
    {"short": "ru-RU-SvetlanaNeural", "gender": "Female"},
    {"short": "ru-RU-DariyaNeural", "gender": "Female"},
    {"short": "en-US-GuyNeural", "gender": "Male"},
    {"short": "en-US-JennyNeural", "gender": "Female"},
]

_voice_cache: list[dict] | None = None


def _cache_path(name: str) -> str:
    return os.path.join(app_dir(), "data", name)


def voice_list() -> list[dict]:
    global _voice_cache
    if _voice_cache:
        return _voice_cache
    cache = _cache_path("voices_cache.json")
    if os.path.exists(cache) and time.time() - os.path.getmtime(cache) < 86400 * 7:
        try:
            with open(cache, "r", encoding="utf-8") as f:
                _voice_cache = json.load(f)
                return _voice_cache
        except Exception:
            pass
    return FALLBACK_VOICES


async def winget_voices(force: bool = False) -> list[dict]:
    cache = _cache_path("winget_voices.json")
    if not force and os.path.exists(cache) and time.time() - os.path.getmtime(cache) < 86400 * 7:
        with open(cache, "r", encoding="utf-8") as f:
            return json.load(f)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(WINGET + "/api/voices", timeout=aiohttp.ClientTimeout(total=25)) as r:
                if r.status != 200:
                    raise RuntimeError(str(r.status))
                raw = await r.json()
        out = [{"short": v.get("shortName", ""), "gender": v.get("gender", ""),
                "locale": v.get("locale", "")} for v in raw if v.get("shortName")]
        with open(cache, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False)
        return out
    except Exception:
        if os.path.exists(cache):
            with open(cache, "r", encoding="utf-8") as f:
                return json.load(f)
        return FALLBACK_VOICES


async def edge_voices() -> list[dict]:
    cache = _cache_path("edge_voices.json")
    if os.path.exists(cache) and time.time() - os.path.getmtime(cache) < 86400 * 7:
        try:
            with open(cache, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    try:
        import edge_tts
        vs = await edge_tts.list_voices()
        out = [{"short": v["ShortName"], "gender": v["Gender"], "locale": v["Locale"]} for v in vs]
        with open(cache, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False)
        return out
    except Exception:
        return FALLBACK_VOICES


async def voice_list_async() -> list[dict]:
    global _voice_cache
    engine = CONFIG.voice.get("tts_engine", "winget")
    if engine == "edge":
        out = await edge_voices()
    elif engine in ("winget", "auto"):
        out = await winget_voices()
    else:
        out = voice_list()
    _voice_cache = out
    return out


# --- синтез -------------------------------------------------------------------
_UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) FluxDesktop/2.0"}
_TTS_CACHE: dict[str, dict] = {}      # key -> {"url":..., "ts":...}
_TTS_INFLIGHT: dict[str, asyncio.Future] = {}
_SAVED_URLS: set = set()
_TTS_TTL = 6 * 3600


def _tts_key(text: str, voice: str, rate: int, pitch: int) -> str:
    import hashlib
    return hashlib.md5(f"{voice}|{rate}|{pitch}|{text}".encode()).hexdigest()


async def _winget_once(s: aiohttp.ClientSession, payload: dict) -> str:
    async with s.post(WINGET + "/api/synthesize", json=payload,
                      timeout=aiohttp.ClientTimeout(total=60)) as r:
        if r.status != 200:
            raise RuntimeError(f"synth {r.status}")
        d = await r.json()
    url = d.get("audioUrl") or ""
    if not url:
        raise RuntimeError("нет audioUrl")
    return WINGET + url if url.startswith("/") else url


async def _winget_hedge(payload: dict) -> str | None:
    """Hedged-запрос: второй параллельно через 1.2с, первый успех побеждает.

    Сервис троттлит/флажит - так p95-задержка падает вдвое-втрое.
    """
    async with aiohttp.ClientSession(headers=_UA) as s:
        t1 = asyncio.create_task(_winget_once(s, payload))
        await asyncio.sleep(1.2)
        if t1.done() and not t1.exception() and t1.result():
            return t1.result()
        t2 = asyncio.create_task(_winget_once(s, payload))
        tasks = {t1, t2}
        import time as _t
        deadline = _t.time() + 30
        while tasks and _t.time() < deadline:
            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED, timeout=30)
            for t in done:
                tasks.discard(t)
                if not t.exception() and t.result():
                    for p in pending:
                        p.cancel()
                    return t.result()
        for t in (t1, t2):
            t.cancel()
        return None


async def winget_url(text: str, voice: str, rate: int = 0, pitch: int = 0) -> str | None:
    """URL готового mp3 на wingetgui: кэш -> inflight -> hedged-синтез."""
    key = _tts_key(text, voice, rate, pitch)
    c = _TTS_CACHE.get(key)
    if c and time.time() - c["ts"] < _TTS_TTL:
        return c["url"]
    infl = _TTS_INFLIGHT.get(key)
    if infl is not None:
        try:
            return await asyncio.shield(infl)
        except Exception:
            pass
    payload = {"text": text, "voice": voice, "rate": int(rate), "pitch": int(pitch)}
    fut = asyncio.get_event_loop().create_task(_winget_hedge(payload))
    _TTS_INFLIGHT[key] = fut
    try:
        url = await fut
    finally:
        _TTS_INFLIGHT.pop(key, None)
    if url:
        if len(_TTS_CACHE) > 200:
            _TTS_CACHE.clear()
        _TTS_CACHE[key] = {"url": url, "ts": time.time()}
    return url


async def _save_copy(url: str) -> None:
    """Фоновая копия mp3 в data/audio (не блокирует озвучку)."""
    if url in _SAVED_URLS:
        return
    _SAVED_URLS.add(url)
    try:
        path = os.path.join(app_dir(), "data", "audio", f"say_{int(time.time()*1000)}.mp3")
        async with aiohttp.ClientSession(headers=_UA) as s:
            async with s.get(url, timeout=aiohttp.ClientTimeout(total=60)) as r:
                if r.status == 200:
                    with open(path, "wb") as f:
                        f.write(await r.read())
    except Exception:
        pass


async def synth_winget(text: str, voice: str, rate: int = 0, pitch: int = 0) -> bytes | None:
    """mp3 байтами (для voice_speak-тулза и фолбэков)."""
    url = await winget_url(text, voice, rate, pitch)
    if not url:
        return None
    try:
        async with aiohttp.ClientSession(headers=_UA) as s:
            async with s.get(url, timeout=aiohttp.ClientTimeout(total=60)) as r:
                if r.status == 200:
                    return await r.read()
    except Exception:
        pass
    return None


async def synth_edge(text: str, voice: str, rate: int, pitch: int, path: str) -> str | None:
    try:
        import edge_tts
    except Exception:
        return None
    comm = edge_tts.Communicate(text, voice,
                                rate=f"{rate:+d}%" if rate else "+0%",
                                pitch=f"{pitch:+d}Hz" if pitch else "+0Hz")
    for _ in range(3):
        try:
            await comm.save(path)
            if os.path.getsize(path) > 500:
                return path
        except Exception:
            await asyncio.sleep(0.7)
    return None


async def synth_to_file(text: str, voice: str | None = None,
                        rate: int | None = None, pitch: int | None = None) -> str | None:
    """Синтез голоса Flux в mp3; возвращает путь или None."""
    voice = voice or CONFIG.voice.get("voice", "ru-RU-DmitryNeural")
    rate = rate if rate is not None else CONFIG.voice.get("rate", 0)
    pitch = pitch if pitch is not None else CONFIG.voice.get("pitch", 0)
    engine = CONFIG.voice.get("tts_engine", "winget")
    path = os.path.join(app_dir(), "data", "audio", f"say_{int(time.time()*1000)}.mp3")

    if engine in ("winget", "auto"):
        mp3 = await synth_winget(text, voice, rate, pitch)
        if mp3:
            with open(path, "wb") as f:
                f.write(mp3)
            return path
        if engine == "winget":
            return None
    if engine in ("edge", "auto"):
        return await synth_edge(text, voice, rate, pitch, path)
    return None


# --- STT ----------------------------------------------------------------------
async def transcribe_provider(audio_bytes: bytes, filename: str = "audio.webm") -> str | None:
    """OpenAI-совместимое /audio/transcriptions на активном подключении."""
    conn = CONFIG.active_connection()
    if not conn:
        return None
    url = (conn.get("base_url") or "").rstrip("/") + "/audio/transcriptions"
    headers = {}
    key = conn.get("api_key") or ""
    if key:
        headers["Authorization"] = f"Bearer {key}"
    data = aiohttp.FormData()
    data.add_field("file", audio_bytes, filename=filename, content_type="application/octet-stream")
    data.add_field("model", CONFIG.active_model() or "whisper-1")
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(url, data=data, headers=headers, timeout=aiohttp.ClientTimeout(total=90)) as r:
                if r.status != 200:
                    return None
                d = await r.json()
                return d.get("text")
    except Exception:
        return None


async def transcribe_whisper_local(audio_path: str) -> str | None:
    try:
        from faster_whisper import WhisperModel
    except Exception:
        return None
    model = WhisperModel("base", device="cpu", compute_type="int8")
    segs, _ = model.transcribe(audio_path)
    return " ".join(s.text for s in segs).strip() or None


async def transcribe_auto(audio_bytes: bytes) -> str | None:
    mode = CONFIG.settings.get("stt_mode", "auto")
    if mode in ("auto", "provider"):
        txt = await transcribe_provider(audio_bytes)
        if txt:
            return txt
    if mode in ("auto", "whisper"):
        path = os.path.join(app_dir(), "data", "audio", f"mic_{int(time.time()*1000)}.webm")
        with open(path, "wb") as f:
            f.write(audio_bytes)
        return await transcribe_whisper_local(path)
    return None
