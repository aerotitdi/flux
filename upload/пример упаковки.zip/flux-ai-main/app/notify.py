"""Звук уведомлений БЕЗ бинарных ассетов: WAV генерируется процедурно (v2.8).

Воспроизведение по платформам:
  Windows — winsound.PlaySound (WinAPI, БЕЗ дочернего процесса);
  Linux   — paplay / aplay / ffplay / mpv (скрытый subprocess);
  macOS   — afplay;
  фолбэк  — winsound.MessageBeep / тишина.
Плюс опциональный системный тост Windows (best effort, PowerShell-снипет).
"""
from __future__ import annotations

import array
import os
import shutil
import subprocess
import sys
import threading
import time
import wave

from . import winproc
from .config import app_dir

NT = os.name == "nt"
MAC = hasattr(os, "uname") and os.uname().sysname == "Darwin"

_PLAYER: dict = {"proc": None, "lock": threading.Lock()}


def wav_path() -> str:
    p = os.path.join(app_dir(), "data", "alarm.wav")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return p


def make_wav(path: str | None = None, freq_a: int = 740, freq_b: int = 1180,
             dur: float = 0.42, repeats: int = 3, rate: int = 22050) -> str:
    """Двухтонная сирена: синусоиды с огибающей, без зависимостей и ассетов."""
    import math
    path = path or wav_path()
    n = int(rate * dur)
    samples = array.array("h")
    for r in range(repeats):
        f = freq_a if r % 2 == 0 else freq_b
        for i in range(n):
            t = i / rate
            env = min(1.0, t / 0.02) * min(1.0, (dur - t) / 0.05)   # атака/затухание
            v = math.sin(2 * math.pi * f * t) * env
            v += 0.35 * math.sin(2 * math.pi * f * 2 * t) * env     # обертон яркости
            samples.append(int(max(-1.0, min(1.0, v)) * 30000))
        for _ in range(int(rate * 0.09)):                           # пауза между гудками
            samples.append(0)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(samples.tobytes())
    return path


def _players() -> list:
    if NT:
        return []
    if MAC:
        return [["afplay"]]
    out = []
    for tool in ("paplay", "aplay", "ffplay", "mpv"):
        if shutil.which(tool):
            out.append([tool])
    return out


def _win_play(path: str) -> bool:
    try:
        import winsound
        winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP)
        return True
    except Exception:
        return False


def _ext_play(path: str) -> bool:
    for base in _players():
        exe = shutil.which(base[0])
        if not exe:
            continue
        cmd = [exe]
        if base[0] == "ffplay":
            cmd += ["-nodisp", "-autoexit", "-loglevel", "quiet"]
        elif base[0] == "mpv":
            cmd += ["--no-video", "--really-quiet"]
        cmd.append(path)
        try:
            proc = subprocess.Popen(
                cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL, creationflags=winproc.CREATE_NO_WINDOW,
                startupinfo=winproc._startupinfo())
            with _PLAYER["lock"]:
                _PLAYER["proc"] = proc
            return True
        except Exception:
            continue
    return False


def play_sound(kind: str = "timer") -> str:
    """Завести сирену. Возвращает имя бэкенда ('winsound'/'paplay'/…/'none')."""
    path = wav_path()
    if not os.path.exists(path):
        try:
            make_wav(path)
        except Exception:
            return "none"
    stop_sound()
    if NT and _win_play(path):
        return "winsound"
    if _ext_play(path):
        with _PLAYER["lock"]:
            p = _PLAYER["proc"]
        return os.path.basename(p.args[0]) if p else "none"
    try:  # последний фолбэк
        import winsound
        winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
        return "beep"
    except Exception:
        return "none"


def stop_sound() -> bool:
    stopped = False
    if NT:
        try:
            import winsound
            winsound.PlaySound(None, winsound.SND_PURGE)
            stopped = True
        except Exception:
            pass
    with _PLAYER["lock"]:
        p = _PLAYER["proc"]
        _PLAYER["proc"] = None
    if p is not None:
        try:
            p.terminate()
            stopped = True
        except Exception:
            pass
    return stopped


def sound_backend() -> str:
    if NT:
        return "winsound"
    for base in _players():
        return base[0]
    return "none"


def toast(title: str, text: str) -> bool:
    """Системный тост Windows (best effort):BurntToast не требуем, чистый WinRT."""
    if not NT or not winproc.ps_available():
        return False
    script = r"""
try {
  [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
  $xml = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
  $nodes = $xml.GetElementsByTagName('text')
  $nodes.Item(0).AppendChild($xml.CreateTextNode($a0)) | Out-Null
  $nodes.Item(1).AppendChild($xml.CreateTextNode($a1)) | Out-Null
  $n = [Windows.UI.Notifications.ToastNotification]::new($xml)
  [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('FLUX 2.0').Show($n)
  'ok'
} catch { '' }
"""
    try:
        out = winproc.ps_command(script, title, text, timeout=15)
        return "ok" in out
    except Exception:
        return False


def play_async(kind: str = "timer") -> None:
    threading.Thread(target=play_sound, args=(kind,), daemon=True).start()
