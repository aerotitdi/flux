"""Единая шина браузер-операций: расширение FLUX Bridge (живой Chrome) или классический CDP.

Все browser-тулзы вызывают только bus.*; транспорт выбирается автоматически:
bridge.online() -> мост chrome.debugger; иначе CDP (9222 / DevToolsActivePort).
Форматы данных нормализованы:
  targets()  -> [{id, windowId, title, url, active}]
  windows_map() -> [{windowId, bounds, focused, tabs:[{id,title,url,active}]}]
"""
from __future__ import annotations

import base64
import json

from . import bridge, browser_cdp as cdp

EVAL_BOX = """(() => { const el = document.querySelector(%s);
  if (!el) return null; el.scrollIntoView({block:'center'});
  const r = el.getBoundingClientRect(); return {x: r.x + r.width/2, y: r.y + r.height/2}; })()"""


async def ensure() -> bool:
    """Мост жив? Иначе CDP-дискавери. НИЧЕГО не закрываем."""
    if bridge.online():
        return True
    return await cdp.ensure_ready()


def transport() -> str:
    return "bridge" if bridge.online() else "cdp"


async def targets() -> list:
    if bridge.online():
        return await bridge.call({"cmd": "targets"})
    await cdp.ensure_ready()
    wm = await cdp.windows_map()
    out = []
    for w in wm.values():
        for t in w["tabs"]:
            out.append({"id": t["targetId"], "windowId": w["windowId"],
                        "title": t.get("title", ""), "url": t.get("url", ""), "active": False})
    return out


async def windows_map() -> list:
    if bridge.online():
        return await bridge.call({"cmd": "windows"})
    await cdp.ensure_ready()
    wm = await cdp.windows_map()
    return [{"windowId": wid, "bounds": w.get("bounds"), "focused": False,
             "tabs": [{"id": t["targetId"], "title": t.get("title", ""),
                       "url": t.get("url", ""), "active": False} for t in w["tabs"]]}
            for wid, w in wm.items()]


async def activate(tab: str) -> None:
    if bridge.online():
        await bridge.call({"cmd": "activate", "tabId": int(tab)})
        return
    await cdp.ensure_ready()
    await cdp.activate_tab(tab)


async def close(tab: str) -> None:
    if bridge.online():
        await bridge.call({"cmd": "close", "tabId": int(tab)})
        return
    await cdp.ensure_ready()
    await cdp.close_tab(tab)


async def new_tab(url: str) -> str:
    if bridge.online():
        r = await bridge.call({"cmd": "new", "url": url})
        return str(r["id"])
    await cdp.ensure_ready()
    t = await cdp.new_tab(url)
    return t.get("id", "")


async def navigate(tab: str, url: str) -> None:
    if bridge.online():
        await bridge.call({"cmd": "navigate", "tabId": int(tab), "url": url})
        return
    ws = await _cdp_ws(tab)
    await cdp.cmd_target(ws, "Page.navigate", {"url": url})


async def reload(tab: str) -> None:
    if bridge.online():
        await bridge.call({"cmd": "reload", "tabId": int(tab)})
        return
    ws = await _cdp_ws(tab)
    await cdp.cmd_target(ws, "Page.reload", {})


async def back(tab: str) -> str:
    if bridge.online():
        await bridge.call({"cmd": "back", "tabId": int(tab)})
        return "назад"
    ws = await _cdp_ws(tab)
    hist = await cdp.cmd_target(ws, "Page.getNavigationHistory")
    idx, entries = hist.get("currentIndex", 0), hist.get("entries", [])
    if idx > 0:
        await cdp.cmd_target(ws, "Page.navigateToHistoryEntry", {"entryId": entries[idx - 1]["id"]})
        return "назад"
    return "нет предыдущей страницы"


async def forward(tab: str) -> str:
    if bridge.online():
        await bridge.call({"cmd": "forward", "tabId": int(tab)})
        return "вперёд"
    ws = await _cdp_ws(tab)
    hist = await cdp.cmd_target(ws, "Page.getNavigationHistory")
    idx, entries = hist.get("currentIndex", 0), hist.get("entries", [])
    if idx + 1 < len(entries):
        await cdp.cmd_target(ws, "Page.navigateToHistoryEntry", {"entryId": entries[idx + 1]["id"]})
        return "вперёд"
    return "нет следующей страницы"


async def screenshot_b64(tab: str) -> str:
    if bridge.online():
        r = await bridge.call({"cmd": "cdp", "tabId": int(tab),
                               "method": "Page.captureScreenshot", "params": {"format": "png"}})
        return r.get("data", "")
    ws = await _cdp_ws(tab)
    return await cdp.screenshot(ws)


async def evaluate(tab: str, expression: str) -> any:
    if bridge.online():
        r = await bridge.call({"cmd": "cdp", "tabId": int(tab), "method": "Runtime.evaluate",
                               "params": {"expression": expression, "returnByValue": True, "awaitPromise": True}})
        if r and r.get("exceptionDetails"):
            raise cdp.CDPError(str(r["exceptionDetails"].get("text")))
        return (r or {}).get("result", {}).get("value")
    ws = await _cdp_ws(tab)
    return await cdp.evaluate(ws, expression)


async def click_selector(tab: str, selector: str) -> None:
    box = await evaluate(tab, EVAL_BOX % json.dumps(selector))
    if not box:
        raise cdp.CDPError(f"селектор не найден: {selector}")
    if bridge.online():
        for kind in ("mousePressed", "mouseReleased"):
            await bridge.call({"cmd": "cdp", "tabId": int(tab), "method": "Input.dispatchMouseEvent",
                               "params": {"type": kind, "x": box["x"], "y": box["y"],
                                          "button": "left", "clickCount": 1}})
        return
    ws = await _cdp_ws(tab)
    for kind in ("mousePressed", "mouseReleased"):
        await cdp.cmd_target(ws, "Input.dispatchMouseEvent",
                             {"type": kind, "x": box["x"], "y": box["y"], "button": "left", "clickCount": 1})


async def type_text(tab: str, selector: str | None, text: str) -> None:
    if selector:
        await evaluate(tab, f"(() => {{ const el = document.querySelector({json.dumps(selector)});"
                            f" if (!el) throw 'нет селектора'; el.focus(); }})()")
    if bridge.online():
        await bridge.call({"cmd": "cdp", "tabId": int(tab), "method": "Input.insertText", "params": {"text": text}})
        return
    ws = await _cdp_ws(tab)
    await cdp.type_text(ws, None, text)


async def scroll(tab: str, dy: int) -> None:
    await evaluate(tab, f"window.scrollBy(0, {dy})")


async def key(tab: str, key: str) -> None:
    vk = ord(key[0].upper()) if len(key) == 1 else 13
    if bridge.online():
        for kind in ("keyDown", "keyUp"):
            await bridge.call({"cmd": "cdp", "tabId": int(tab), "method": "Input.dispatchKeyEvent",
                               "params": {"type": kind, "key": key, "windowsVirtualKeyCode": vk}})
        return
    ws = await _cdp_ws(tab)
    await cdp.key_press(ws, key)


async def cookies(tab: str) -> list:
    if bridge.online():
        r = await bridge.call({"cmd": "cdp", "tabId": int(tab), "method": "Network.getCookies", "params": {}})
        return (r or {}).get("cookies", [])
    ws = await _cdp_ws(tab)
    return await cdp.cookies(ws)


async def pdf(tab: str) -> str:
    if bridge.online():
        r = await bridge.call({"cmd": "cdp", "tabId": int(tab), "method": "Page.printToPDF",
                               "params": {"printBackground": True}})
        return (r or {}).get("data", "")
    ws = await _cdp_ws(tab)
    res = await cdp.cmd_target(ws, "Page.printToPDF", {"printBackground": True})
    return res.get("data", "")


async def _cdp_ws(tab: str) -> str:
    await cdp.ensure_ready()
    for t in await cdp.targets():
        if t["id"] == tab or tab in t.get("title", "") or t.get("url", "").startswith(tab):
            return t["webSocketDebuggerUrl"]
    raise cdp.CDPError(f"вкладка не найдена: {tab} (используй browser_tabs_list)")
