"""Контроль браузера через CDP (Chrome/Edge с --remote-debugging-port=9222).

Модель видит КАЖДОЕ окно и КАЖДУЮ вкладку отдельно (targetId), может
переключать вкладки, работать с любой из них независимо. Пункты 6-7 ТЗ.
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import subprocess
import time
from urllib.parse import urlparse

import aiohttp

try:
    import websockets
except Exception:  # pragma: no cover
    websockets = None

CDP_HTTP = os.environ.get("FLUX_CDP_HTTP", "http://127.0.0.1:9222")
_EP = {"http": CDP_HTTP}

FRIENDLY_HINT = (
    "Твой Chrome запущен, но без debug-эндпоинта, а закрывать его нельзя. Лучший способ (один раз, "
    "без портов и рестартов): установи расширение FLUX Bridge - chrome://extensions -> режим "
    "разработчика -> 'Загрузить распакованное расширение' -> папка Flux2\\extension; оно само "
    "подключится к FLUX и откроет доступ к живым вкладкам (chrome.debugger). Альтернатива: галка "
    "'Allow remote debugging for this browser instance' на chrome://inspect/#remote-debugging. "
    "Перезапуск Chrome с вкладками - только если ТЫ сам попросишь (browser_restart_user).")


def _http_base() -> str:
    return _EP["http"]


def _devtools_active_port_files() -> list:
    home = os.path.expanduser("~")
    if os.name == "nt":
        la = os.environ.get("LOCALAPPDATA", "")
        return [os.path.join(la, "Google", "Chrome", "User Data", "DevToolsActivePort"),
                os.path.join(la, "Microsoft", "Edge", "User Data", "DevToolsActivePort"),
                os.path.join(la, "Chromium", "User Data", "DevToolsActivePort")]
    if os.uname().sysname == "Darwin":
        return [os.path.join(home, "Library", "Application Support", "Google", "Chrome", "DevToolsActivePort")]
    return [os.path.join(home, ".config", "google-chrome", "DevToolsActivePort")]


def chrome_running() -> bool:
    try:
        if os.name == "nt":
            for name in ("chrome.exe", "msedge.exe"):
                r = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {name}", "/NH"],
                                   capture_output=True, text=True)
                if name in (r.stdout or "").lower():
                    return True
            return False
        r = subprocess.run(["pgrep", "-x", "chrome"], capture_output=True, text=True)
        return bool((r.stdout or "").strip())
    except Exception:
        return False


class CDPError(Exception):
    pass


async def http_json(path: str) -> any:
    async with aiohttp.ClientSession() as s:
        async with s.get(_http_base() + path, timeout=aiohttp.ClientTimeout(total=8)) as r:
            if r.status != 200:
                raise CDPError(f"CDP {path} -> {r.status}")
            return await r.json()


async def version() -> dict:
    return await http_json("/json/version")


async def targets() -> list[dict]:
    ts = await http_json("/json/list")
    return [t for t in ts if t.get("type") == "page"]


async def browser_ws() -> str:
    v = await version()
    return v["webSocketDebuggerUrl"]


async def _cmd_ws(ws_url: str, method: str, params: dict | None = None, timeout: float = 20.0) -> dict:
    if websockets is None:
        raise CDPError("нет пакета websockets: pip install websockets")
    async with websockets.connect(ws_url, max_size=50 * 1024 * 1024) as ws:
        mid = 1
        await ws.send(json.dumps({"id": mid, "method": method, "params": params or {}}))
        deadline = time.time() + timeout
        while time.time() < deadline:
            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout))
            if msg.get("id") == mid:
                if msg.get("error"):
                    raise CDPError(f"{method}: {msg['error'].get('message')}")
                return msg.get("result", {})
    raise CDPError(f"{method}: timeout")


async def cmd_target(target_ws: str, method: str, params: dict | None = None, timeout: float = 20.0) -> dict:
    return await _cmd_ws(target_ws, method, params, timeout)


async def window_for_target(browser_id: str) -> dict:
    bw = await browser_ws()
    return await _cmd_ws(bw, "Browser.getWindowForTarget", {"targetId": browser_id})


async def windows_map() -> dict:
    """windowId -> {bounds, tabs:[...]}"""
    bw = await browser_ws()
    pages = await targets()
    out: dict[int, dict] = {}
    for t in pages:
        try:
            w = await _cmd_ws(bw, "Browser.getWindowForTarget", {"targetId": t["id"]})
        except CDPError:
            continue
        wid = w.get("windowId", 0)
        slot = out.setdefault(wid, {"windowId": wid, "bounds": w.get("bounds"), "tabs": []})
        slot["tabs"].append({"targetId": t["id"], "title": t.get("title"), "url": t.get("url")})
    return out


async def new_tab(url: str = "about:blank") -> dict:
    async with aiohttp.ClientSession() as s:
        async with s.put(_http_base() + f"/json/new?{url}", timeout=aiohttp.ClientTimeout(total=10)) as r:
            if r.status != 200:
                raise CDPError(f"/json/new -> {r.status}")
            return await r.json()


async def close_tab(target_id: str) -> None:
    async with aiohttp.ClientSession() as s:
        async with s.get(_http_base() + f"/json/close/{target_id}") as r:
            await r.text()


async def activate_tab(target_id: str) -> None:
    async with aiohttp.ClientSession() as s:
        async with s.get(_http_base() + f"/json/activate/{target_id}") as r:
            await r.text()


def find_chrome_exe() -> str | None:
    # 0) реестр: если дефолтный браузер - Chrome, берём его exe
    if os.name == "nt":
        try:
            import winreg, re as _re
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice") as k:
                prog_id, _ = winreg.QueryValueEx(k, "ProgId")
            if "chrome" in prog_id.lower():
                with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, rf"{prog_id}\shell\open\command") as k:
                    cmd, _ = winreg.QueryValueEx(k, "")
                m = _re.search(r'"([^"]+\.exe)"', cmd or "")
                exe = m.group(1) if m else None
                if exe and os.path.exists(exe):
                    return exe
        except Exception:
            pass
    cands = []
    if os.name == "nt":
        for env in ("LOCALAPPDATA", "PROGRAMFILES", "PROGRAMFILES(X86)"):
            base = os.environ.get(env, "")
            if base:
                cands.append(os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"))
        cands.append(os.path.expanduser(r"~\AppData\Local\Google\Chrome\Application\chrome.exe"))
    else:
        cands += ["/usr/bin/google-chrome", "/usr/bin/chromium",
                  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return None


def find_browser_exe() -> str | None:
    """СНАЧАЛА Chrome во всех расположениях, потом Edge (у пользователя Google!)."""
    chrome = find_chrome_exe()
    if chrome:
        return chrome
    cands = []
    if os.name == "nt":
        for env in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA"):
            base = os.environ.get(env, "")
            if base:
                cands.append(os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
    else:
        cands += ["/usr/bin/microsoft-edge"]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return None


def launch_debug_browser(port: int = 9222, use_user_profile: bool = False) -> str:
    exe = find_chrome_exe() or find_browser_exe()
    if not exe:
        raise CDPError("браузер не найден; запусти Chrome/Edge вручную: --remote-debugging-port=9222")
    args = [exe, f"--remote-debugging-port={port}", "--no-first-run", "--no-default-browser-check"]
    if use_user_profile:
        # твой профиль: восстанавливаем прошлую сессию (твои вкладки), БЕЗ about:blank
        args.append("--restore-last-session")
    else:
        profile = os.path.join(os.path.expanduser("~"), ".flux2", "cdp-profile")
        os.makedirs(profile, exist_ok=True)
        args.append(f"--user-data-dir={profile}")
    # URL-аргумент НЕ передаём: иначе Chrome открывает лишнюю пустую вкладку about:blank
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return exe


async def discover() -> bool:
    """Найти живой CDP-эндпоинт БЕЗ закрытия браузера:

    1) порт 9222; 2) файл DevToolsActivePort в профиле Chrome/Edge (появляется,
    когда в chrome://inspect/#remote-debugging включён 'Allow remote debugging').
    """
    try:
        await version()
        return True
    except Exception:
        pass
    for pf in _devtools_active_port_files():
        try:
            with open(pf, "r", encoding="utf-8") as f:
                ls = [l.strip() for l in f if l.strip()]
            if not ls:
                continue
            port = int(ls[0])
            _EP["http"] = f"http://127.0.0.1:{port}"
            await version()
            return True
        except Exception:
            continue
    _EP["http"] = CDP_HTTP
    return False


async def ensure_ready(port: int = 9222) -> bool:
    """Подключиться к браузеру, НЕ закрывая его.

    1) живой CDP (9222 или DevToolsActivePort) -> ок;
    2) Chrome НЕ запущен -> поднять его с дефолтным профилем + порт (ничего не закрываем);
    3) Chrome запущен без порта -> НЕ трогаем: вернём False, тулзы покажут FRIENDLY_HINT.
    """
    if await discover():
        return True
    if not chrome_running():
        try:
            launch_debug_browser(port, use_user_profile=True)
            if await wait_ready(12):
                return True
        except Exception:
            pass
        try:
            launch_debug_browser(port, use_user_profile=False)
            return await wait_ready(10)
        except Exception:
            return False
    return False


def _default_chromium_exe() -> str | None:
    """Exe дефолтного Chromium-браузера из реестра, иначе Chrome, иначе Edge."""
    if os.name == "nt":
        try:
            import winreg, re as _re
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice") as k:
                prog_id, _ = winreg.QueryValueEx(k, "ProgId")
            with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, rf"{prog_id}\shell\open\command") as k:
                cmd, _ = winreg.QueryValueEx(k, "")
            m = _re.search(r'"([^"]+\.exe)"', cmd or "")
            exe = m.group(1) if m else None
            if exe and os.path.exists(exe) and any(x in exe.lower() for x in ("chrome", "msedge", "chromium")):
                return exe
        except Exception:
            pass
    return find_chrome_exe() or find_browser_exe()


async def restart_user_browser(port: int = 9222) -> bool:
    """Аккуратно перезапустить Chrome пользователя с debug-портом и реставрацией вкладок.

    ВАЖНО: убиваем ТОЛЬКО процессы браузера пользователя и НЕ трогаем окно самого FLUX
    (app-mode chrome с профилем chrome-app-profile) - иначе FLUX крашится.
    """
    from .config import app_dir
    exe = _default_chromium_exe()
    if not exe:
        return False
    name = os.path.basename(exe)
    marker = app_dir()   # в cmdline UI-окна FLUX есть этот путь - такие процессы не трогаем
    if os.name == "nt":
        q = (f"Get-CimInstance Win32_Process -Filter \"Name='{name}'\" | "
             f"Where-Object {{ $_.CommandLine -notlike '*{marker}*' }}")
        subprocess.run(["powershell", "-NoProfile", "-Command",
                        f"{q} | ForEach-Object {{ Stop-Process -Id $_.ProcessId -ErrorAction SilentlyContinue }}"],
                       capture_output=True)
        for _ in range(20):
            r = subprocess.run(["powershell", "-NoProfile", "-Command", f"({q} | Measure-Object).Count"],
                               capture_output=True, text=True)
            if (r.stdout or "").strip() in ("0", ""):
                break
            time.sleep(0.5)
    else:
        import signal
        r = subprocess.run(["pgrep", "-f", name], capture_output=True, text=True)
        for pid in (r.stdout or "").split():
            try:
                with open(f"/proc/{pid}/cmdline", "rb") as f:
                    cmd = f.read().decode("utf-8", "ignore")
                if marker in cmd:
                    continue
                os.kill(int(pid), signal.SIGTERM)
            except Exception:
                pass
        time.sleep(2)
    subprocess.Popen([exe, f"--remote-debugging-port={port}", "--restore-last-session",
                      "--no-first-run", "--no-default-browser-check"],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return await wait_ready(20)


async def wait_ready(timeout: float = 10.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            await version()
            return True
        except Exception:
            await asyncio.sleep(0.4)
    return False


async def screenshot(target_ws: str) -> str:
    res = await cmd_target(target_ws, "Page.captureScreenshot", {"format": "png"})
    return res.get("data", "")


async def evaluate(target_ws: str, expression: str) -> any:
    res = await cmd_target(target_ws, "Runtime.evaluate",
                           {"expression": expression, "returnByValue": True, "awaitPromise": True})
    if res.get("exceptionDetails"):
        raise CDPError(str(res["exceptionDetails"].get("text")))
    return res.get("result", {}).get("value")


async def click_selector(target_ws: str, selector: str) -> None:
    box = await evaluate(target_ws, f"""
        (() => {{ const el = document.querySelector({json.dumps(selector)});
          if (!el) return null; el.scrollIntoView({{block:'center'}});
          const r = el.getBoundingClientRect();
          return {{x: r.x + r.width/2, y: r.y + r.height/2}}; }})()""")
    if not box:
        raise CDPError(f"селектор не найден: {selector}")
    for kind in ("mousePressed", "mouseReleased"):
        await cmd_target(target_ws, "Input.dispatchMouseEvent",
                         {"type": kind, "x": box["x"], "y": box["y"], "button": "left", "clickCount": 1})


async def type_text(target_ws: str, selector: str | None, text: str) -> None:
    if selector:
        await evaluate(target_ws, f"""
            (() => {{ const el = document.querySelector({json.dumps(selector)});
              if (!el) throw 'нет селектора'; el.focus(); }})()""")
    await cmd_target(target_ws, "Input.insertText", {"text": text})


async def scroll(target_ws: str, dy: int) -> None:
    await evaluate(target_ws, f"window.scrollBy(0, {dy})")


async def key_press(target_ws: str, key: str) -> None:
    await cmd_target(target_ws, "Input.dispatchKeyEvent",
                     {"type": "keyDown", "key": key, "windowsVirtualKeyCode": ord(key[0].upper()) if len(key) == 1 else 13})
    await cmd_target(target_ws, "Input.dispatchKeyEvent", {"type": "keyUp", "key": key})


async def cookies(target_ws: str) -> list:
    res = await cmd_target(target_ws, "Network.getCookies", {})
    return res.get("cookies", [])
