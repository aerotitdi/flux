"""ThinkRouter: режим think-auto — сам решаю, думать ли, как долго и гуглить ли.

Пункт 3 ТЗ: auto решает (а) нужен ли thinking и какой бюджет, (б) нужен ли
поиск в вебе до ответа модели. Явные пользовательские маркеры переопределяют.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from .config import CONFIG

SEARCH_MARKERS = re.compile(
    r"(погугли|поищи|найди в интернет|в интернет|актуальн|сегодня|сейчас|последни|новост|курс валют|"
    r"погод|кто сейчас|сколько стоит|цена на|вышел ли|опубликован|за этот год|в этом году|fresh|latest|news|search the web)", re.I)
DEEP_MARKERS = re.compile(
    r"(докажи|спроектируй|оптимизируй|архитектур|рефактор|миграци|сложн|алгоритм|уравн|системн|"
    r"план реализ|сравни вариант|почему так|разбер|детальн|think hard|deep|step by step|рассужд)", re.I)
BRIEF_MARKERS = re.compile(r"(быстро|коротко|без раздум|сразу ответ|one line|кратко)", re.I)
CODE_MARKERS = re.compile(r"(код|функци|скрипт|баг|ошибк|exception|traceback|def |import |class )", re.I)


@dataclass
class ThinkDecision:
    mode: str          # off | brief | deep
    search: bool
    why: str


def decide(user_text: str, history_len: int = 0) -> ThinkDecision:
    cfg_mode = CONFIG.settings.get("think_mode", "auto")
    search = bool(SEARCH_MARKERS.search(user_text))
    deep = bool(DEEP_MARKERS.search(user_text))
    brief_only = bool(BRIEF_MARKERS.search(user_text))
    code = bool(CODE_MARKERS.search(user_text))

    if cfg_mode == "off":
        return ThinkDecision("off", False, "think выключен в настройках")
    if cfg_mode == "brief":
        return ThinkDecision("brief", search, "фиксированный brief")
    if cfg_mode == "medium":
        return ThinkDecision("medium", search, "фиксированный средне-тяжёлый режим")
    if cfg_mode == "deep":
        return ThinkDecision("deep", search, "фиксированный deep")

    # auto
    if brief_only and not deep:
        return ThinkDecision("off", search, "просят кратко/без раздумий")
    if deep or len(user_text) > 400 or user_text.count("?") >= 2:
        return ThinkDecision("deep", search, "сложная/многосоставная задача")
    if code or "?" in user_text or len(user_text) > 80:
        return ThinkDecision("brief", search, "средняя сложность")
    if search:
        return ThinkDecision("brief", True, "нужен свежий веб-контекст")
    return ThinkDecision("off", search, "простой запрос — отвечаю сразу")
