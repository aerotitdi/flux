"""Единая точка запуска дочерних процессов без мигания консоли (пункт 1 ТЗ, v2.8).

Все PowerShell/subprocess-вызовы FLUX идут через этот модуль:
  CREATE_NO_WINDOW            — дочерней консоли не создаётся вовсе;
  STARTUPINFO(SW_HIDE)        — GUI-окна процессов тоже прячем;
  stdin=DEVNULL               — ребёнок не ждёт ввода и не висит;
  -NonInteractive -NoProfile  — PowerShell стартует быстрее и не грузит профиль;
  полный путь к powershell.exe — не зависит от PATH.

Аргументы пользовательских данных инлайнятся как $a0,$a1,… (никаких $args:
в режиме -Command они НЕ заполняются — именно это ломало сохранение скриншотов),
никаких -EncodedCommand и временных .ps1 (это триггеры антивирусов).
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
import tempfile

NT = os.name == "nt"

if NT:
    CREATE_NO_WINDOW = 0x08000000
else:
    CREATE_NO_WINDOW = 0


def _startupinfo() -> subprocess.STARTUPINFO | None:
    if not NT:
        return None
    si = subprocess.STARTUPINFO()
    si.dwFlags = subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0  # SW_HIDE
    return si


def run(cmd: list[str], timeout: float = 30, input: str | None = None,
        shell: bool = False) -> subprocess.CompletedProcess:
    """Любой дочерний процесс — скрыто и без интерактива."""
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        stdin=subprocess.DEVNULL,
        shell=shell,
        creationflags=CREATE_NO_WINDOW,
        startupinfo=_startupinfo(),
    )


def powershell_exe() -> str:
    root = os.environ.get("SystemRoot", r"C:\Windows")
    return os.path.join(root, "System32", "WindowsPowerShell", "v1.0", "powershell.exe")


def ps_quote(value: str) -> str:
    """PowerShell-литерал: одинарные кавычки, внутренние ' удваиваются."""
    return "'" + str(value).replace("'", "''") + "'"


def ps_command(script: str, *args: str, timeout: float = 30) -> str:
    """Выполнить script скрыто; args доступны ВНУТРИ как $a0,$a1,… (НЕ $args).

    Возвращает stdout+stderr одной строкой (пусто при успехе многих команд).
    """
    prelude = "\n".join(f"${f'a{i}'} = {ps_quote(a)}" for i, a in enumerate(args))
    full = (prelude + "\n" + script) if prelude else script
    r = run([powershell_exe(), "-NoProfile", "-NonInteractive", "-Command", full],
            timeout=timeout)
    return (r.stdout or r.stderr or "").strip()


def ps_available() -> bool:
    return NT and os.path.exists(powershell_exe())


def open_invisible_python(code: str, timeout: float = 30) -> subprocess.CompletedProcess:
    """Скрытый python -c (для WinRT-OCR и прочих внутренних нужд)."""
    return run([sys.executable, "-c", code], timeout=timeout)


def temp_path(suffix: str = ".png") -> str:
    """Стабильный по правилам путь во временной папке (имена читаемые — меньше AV FP)."""
    fd, path = tempfile.mkstemp(prefix="flux_", suffix=suffix)
    os.close(fd)
    return path


_SAFE_ID = re.compile(r"[^A-Za-z0-9_]")


def safe_id(text: str, maxlen: int = 24) -> str:
    return _SAFE_ID.sub("_", text or "")[:maxlen] or "x"
