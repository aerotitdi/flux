"""Шина событий: публикация из ЛЮБОГО потока -> asyncio-подписчики (SSE в UI).

Нужна, чтобы уведомления жили ВНЕ хода чата: таймер сработал в daemon-потоке
планировщика -> events.publish() -> SSE /api/events -> окно рисует тост и воет сиреной.
"""
from __future__ import annotations

import asyncio
import threading
import time
from collections import deque
from typing import Any

_RING: deque = deque(maxlen=256)
_LOCK = threading.Lock()
_SUBS: set = set()          # asyncio.Queue подписчиков
_LOOP: asyncio.AbstractEventLoop | None = None


def set_loop(loop: asyncio.AbstractEventLoop | None) -> None:
    """Главный event loop (вызывается из on_startup сервера)."""
    global _LOOP
    _LOOP = loop


def publish(kind: str, **data: Any) -> dict:
    """Потокобезопасно разослать событие всем подписчикам и в кольцо истории."""
    ev = {"type": kind, "t": time.time(), **data}
    with _LOCK:
        _RING.append(ev)
        subs = list(_SUBS)
    for q in subs:
        try:
            if _LOOP is not None and _LOOP.is_running():
                _LOOP.call_soon_threadsafe(q.put_nowait, ev)
            else:
                q.put_nowait(ev)
        except Exception:
            pass
    return ev


def subscribe() -> asyncio.Queue:
    q: asyncio.Queue = asyncio.Queue()
    with _LOCK:
        _SUBS.add(q)
    return q


def unsubscribe(q: asyncio.Queue) -> None:
    with _LOCK:
        _SUBS.discard(q)


def recent(n: int = 32) -> list:
    with _LOCK:
        return list(_RING)[-n:]


def subscribers_count() -> int:
    with _LOCK:
        return len(_SUBS)
