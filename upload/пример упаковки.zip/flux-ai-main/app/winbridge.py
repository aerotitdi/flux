"""Клиент Windows-моста: FLUX -> ws://127.0.0.1:8643/win-bridge -> win_bridge.py (pywinauto/UIA).

Зеркало app/bridge.py (браузерный мост), но роли перевёрнуты: там расширение само
подключается к FLUX, здесь FLUX подключается к внешнему Python-серверу windows_bridge/.
Протокол тот же:
  flu -> {type:'req', id, cmd, ...}
  srv -> {type:'resp', id, result, error} | {type:'ping'} (отвечаем pong)

Переподключение каждые 3с (как у extension/background.js): падение win_bridge.py
не роняет FLUX — тулзы вернут понятную ошибку, а сокет поднимется сам.
"""
from __future__ import annotations

import asyncio
import json
import os
import time
from collections import deque
from typing import Any, Optional

from .config import CONFIG

DEFAULT_URL = "ws://127.0.0.1:8643/win-bridge"
RECONNECT_S = 3.0
CALL_TIMEOUT = 25.0          # как у браузерного моста
PING_INTERVAL = 20.0         # keepalive: не даём серверу считать нас мёртвыми
LOG_MAXLEN = 200

_WB: dict[str, Any] = {
    "ws": None, "seq": 0, "futs": {}, "task": None, "stop": False, "loop": None,
    "log": deque(maxlen=LOG_MAXLEN), "apps_cache": [], "apps_at": 0.0,
    "last_error": "", "connected_at": None, "session": None, "hello": None,
    "wake": None,
}


def _wake_event() -> asyncio.Event:
    """Событие «переподключись сейчас» — кнопка UI не ждёт 3-секундный цикл."""
    ev = _WB.get("wake")
    if ev is None:
        ev = _WB["wake"] = asyncio.Event()
    return ev


class WinBridgeDown(Exception):
    """Мост не подключён / вернул ошибку."""


def bridge_url() -> str:
    return (CONFIG.settings.get("win_bridge_url") or os.environ.get("FLUX_WIN_BRIDGE_URL")
            or DEFAULT_URL)


def online() -> bool:
    ws = _WB.get("ws")
    return bool(ws and not ws.closed)


def status() -> dict:
    """Сводка для UI/тулзов (без сети)."""
    ws = _WB.get("ws")
    return {
        "online": online(),
        "url": bridge_url(),
        "hello": _WB.get("hello"),
        "last_error": _WB.get("last_error") or None,
        "uptime_s": round(time.time() - _WB["connected_at"], 1) if online() and _WB.get("connected_at") else 0,
        "reconnecting": bool(_WB.get("task")) and not online(),
        "closed": bool(ws and ws.closed),
    }


# --------------------------------------------------------------------------- #
#  Соединение: один фоновый таск, авто-переподключение каждые 3с                #
# --------------------------------------------------------------------------- #
async def _connect_loop():
    """Держит сокет живым. Любая ошибка -> лог + повтор через RECONNECT_S."""
    import aiohttp
    _WB["loop"] = asyncio.get_running_loop()
    while not _WB["stop"]:
        url = bridge_url()
        try:
            async with aiohttp.ClientSession() as sess:
                async with sess.ws_connect(url, heartbeat=None, max_msg_size=64 * 1024 * 1024,
                                           autoping=True) as ws:
                    _WB["ws"] = ws
                    _WB["session"] = sess
                    _WB["last_error"] = ""
                    _WB["connected_at"] = time.time()
                    await ws.send_json({"type": "hello", "name": "flux2"})
                    _log("sys", "connect", True, f"подключено к {url}")
                    await _read_loop(ws)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            _WB["last_error"] = f"{type(e).__name__}: {e}"
        finally:
            _WB["ws"] = None
            _WB["session"] = None
            _WB["connected_at"] = None
            _fail_pending("мост отключён")
        if _WB["stop"]:
            break
        try:  # спим 3с, но кнопка «Переподключить» будит мгновенно
            await asyncio.wait_for(_wake_event().wait(), RECONNECT_S)
            _WB["wake"].clear()
        except asyncio.TimeoutError:
            pass


async def _read_loop(ws):
    import aiohttp
    ping_task = asyncio.create_task(_keepalive(ws))
    try:
        async for msg in ws:
            if msg.type == aiohttp.WSMsgType.TEXT:
                try:
                    d = json.loads(msg.data)
                except Exception:
                    continue
                t = d.get("type")
                if t == "resp":
                    fut = _WB["futs"].pop(d.get("id"), None)
                    if fut and not fut.done():
                        fut.set_result(d)
                elif t == "ping":
                    await ws.send_json({"type": "pong"})
                elif t == "hello_ok":
                    _WB["hello"] = d.get("result")
                elif t == "event":
                    _WB["log"].appendleft({"t": time.time(), "id": None, "cmd": "event",
                                           "ok": True, "ms": 0,
                                           "text": json.dumps(d, ensure_ascii=False)[:300]})
            elif msg.type in (aiohttp.WSMsgType.CLOSE, aiohttp.WSMsgType.CLOSING,
                              aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                break
    finally:
        ping_task.cancel()


async def _keepalive(ws):
    """Пинг раз в 20с — паттерн браузерного моста (там он будит MV3 service worker)."""
    try:
        while not ws.closed:
            await asyncio.sleep(PING_INTERVAL)
            if not ws.closed:
                await ws.send_json({"type": "ping"})
    except Exception:
        pass


def _fail_pending(reason: str):
    for fut in list(_WB["futs"].values()):
        if not fut.done():
            fut.set_exception(WinBridgeDown(reason))
    _WB["futs"].clear()


def _log(cmd: str, mid: Any, ok: bool, text: str = "", ms: int = 0):
    _WB["log"].appendleft({"t": time.time(), "id": mid, "cmd": cmd, "ok": ok,
                           "ms": ms, "text": (text or "")[:300]})


async def start() -> bool:
    """Запустить фоновое подключение (идемпотентно). Вызывается из server.build_app()."""
    _WB["stop"] = False
    task = _WB.get("task")
    if task and not task.done():
        return online()
    _WB["task"] = asyncio.get_running_loop().create_task(_connect_loop())
    for _ in range(40):            # до 2с ждём первый коннект
        if online():
            return True
        await asyncio.sleep(0.05)
    return online()


async def stop():
    _WB["stop"] = True
    if _WB.get("wake") is not None:
        _WB["wake"].set()
    task = _WB.get("task")
    if task:
        task.cancel()
    ws = _WB.get("ws")
    if ws is not None:
        try:
            await ws.close()
        except Exception:
            pass
    _WB["ws"] = None
    _fail_pending("мост остановлен")


async def reconnect() -> bool:
    """Кнопка «Переподключить»: роняем текущий сокет и сразу поднимаем новый."""
    ws = _WB.get("ws")
    if ws is not None:
        try:
            await ws.close()
        except Exception:
            pass
    _WB["ws"] = None
    _fail_pending("переподключение")
    started = await start()
    _wake_event().set()      # не ждать RECONNECT_S — коннектиться немедленно
    return started


# --------------------------------------------------------------------------- #
#  Вызов команд                                                                 #
# --------------------------------------------------------------------------- #
def ensure_started():
    """Поднять фоновый таск, если его нет (например, тулзы дёрнули до server.start)."""
    task = _WB.get("task")
    if not task or task.done():
        try:
            loop = asyncio.get_running_loop()
            _WB["stop"] = False
            _WB["task"] = loop.create_task(_connect_loop())
        except RuntimeError:
            pass


async def _call_home(cmd: dict, timeout: float, log: bool = True) -> Any:
    """Вызов из чужого потока/цикла: консоль-режим живёт вне цикла HTTP-сервера."""
    home = _WB.get("loop")
    if home is None or home.is_closed():
        raise WinBridgeDown("Windows-мост не запущен в этом процессе")
    fut = asyncio.run_coroutine_threadsafe(_call(cmd, timeout, log), home)
    try:
        return await asyncio.wait_for(asyncio.wrap_future(fut), timeout + 5)
    except asyncio.TimeoutError:
        fut.cancel()
        raise WinBridgeDown(f"таймаут команды {cmd.get('cmd')} (домашний цикл моста не отвечает)")


async def call(cmd: dict, timeout: float = CALL_TIMEOUT, log: bool = True) -> Any:
    """Отправить команду и дождаться {result}. Ошибка моста -> WinBridgeDown.

    log=False — не писать в журнал команд (фоновые опросы статуса не должны
    засорять «Последние команды» во вкладке Windows Automation).
    """
    home = _WB.get("loop")
    if home is not None and home is not asyncio.get_running_loop():
        return await _call_home(cmd, timeout, log)
    return await _call(cmd, timeout, log)


async def _call(cmd: dict, timeout: float, log: bool = True) -> Any:
    ws = _WB.get("ws")
    if not ws or ws.closed:
        ensure_started()
        hint = _WB.get("last_error") or "соединение не установлено"
        raise WinBridgeDown(
            "Windows-мост не подключён: запусти python windows_bridge/win_bridge.py "
            f"(слушает {bridge_url()}). Причина: {hint}")
    _WB["seq"] += 1
    mid = _WB["seq"]
    fut = asyncio.get_running_loop().create_future()
    _WB["futs"][mid] = fut
    t0 = time.time()
    name = str(cmd.get("cmd", "?"))
    try:
        try:
            await ws.send_json({**cmd, "type": "req", "id": mid})
        except WinBridgeDown:
            raise
        except Exception as e:
            raise WinBridgeDown(f"мост оборвался при отправке {name}: {e}")
        d = await asyncio.wait_for(fut, timeout)
    except asyncio.TimeoutError:
        if log:
            _log(name, mid, False, f"таймаут {timeout:.0f}с", int((time.time() - t0) * 1000))
        raise WinBridgeDown(f"таймаут команды {name} ({timeout:.0f}с)")
    finally:
        _WB["futs"].pop(mid, None)
    err = d.get("error")
    ms = int((time.time() - t0) * 1000)
    if err:
        if log:
            _log(name, mid, False, str(err), ms)
        raise WinBridgeDown(str(err))
    result = d.get("result")
    if log:
        _log(name, mid, True, _preview(name, result), ms)
    return result


def _preview(cmd: str, result: Any) -> str:
    if not isinstance(result, dict):
        return str(result)[:200]
    r = dict(result)
    if "dataBase64" in r:                       # скриншот: не тащим мегабайты в лог
        r["dataBase64"] = f"<{len(result['dataBase64'])} символов base64>"
    return json.dumps(r, ensure_ascii=False, default=str)[:200]


def last_log(n: int = 30) -> list:
    return list(_WB["log"])[:n]


async def apps(ttl: float = 3.0, force: bool = False, log: bool = False) -> list:
    """Список приложений с коротким кэшем (UI опрашивает его часто)."""
    if not force and _WB["apps_cache"] and time.time() - _WB["apps_at"] < ttl:
        return _WB["apps_cache"]
    r = await call({"cmd": "apps"}, timeout=15, log=log)
    _WB["apps_cache"] = (r or {}).get("apps", [])
    _WB["apps_at"] = time.time()
    return _WB["apps_cache"]
