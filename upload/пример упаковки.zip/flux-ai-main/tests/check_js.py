"""Страж UI: встроенный JS обязан быть валидным, а все $('id') — существовать (v2.8+).

Появился после инцидента: осиротевшие `}`/`requestAnimationFrame(sceneLoop);` убили
весь <script> — кнопки меню молча умерли. Этот тест ловит такое на этапе коммита:
  1) каждый <script> из ui/index.html проходит node --check (синтаксис);
  2) каждый id из $('...') и getElementById присутствует в разметке;
  3) нет мёртвых идентификаторов старых сцен (sceneLoop, drawSpace, drawUranus…);
  4) кнопки сцен соответствуют ключам SCENES.

Запуск: python tests/check_js.py   (нужен node; без него — только проверки 2-4)
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HTML = os.path.join(ROOT, "ui", "index.html")
N = {"checks": 0}


def ok(cond, msg=""):
    assert cond, f"ПРОВЕРКА НЕ ПРОШЛА: {msg}"
    N["checks"] += 1


html = open(HTML, encoding="utf-8").read()
scripts = re.findall(r"<script>(.*?)</script>", html, re.S)
ok(scripts, "в ui/index.html есть <script>")

# 1) синтаксис через node --check
node = shutil.which("node") or shutil.which("nodejs")
if node:
    for i, js in enumerate(scripts):
        with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False,
                                         encoding="utf-8") as f:
            f.write(js)
            path = f.name
        r = subprocess.run([node, "--check", path], capture_output=True, text=True)
        ok(r.returncode == 0, f"script#{i} синтаксис: {r.stderr[:400]}")
        os.unlink(path)
    print("node --check: все <script> валидны")
else:
    print("node не найден — синтаксис не проверяется (проверки 2-4 ниже)")

# 2) все id-ссылки из JS существуют в разметке
ids = set(re.findall(r'id="([^"]+)"', html))
refs = set(re.findall(r"\$\('([A-Za-z0-9_-]+)'\)", html)) | \
       set(re.findall(r"getElementById\('([^']+)'\)", html))
missing = refs - ids
ok(not missing, f"битые id-ссылки: {sorted(missing)}")

# 3) каждая кнопка сцены имеет обработчик и известна скрипту
btns = set(re.findall(r'data-sc="([^"]+)"', html))
js_all = "\n".join(scripts)
ok(btns, "кнопки сцен присутствуют")
for b in btns:
    ok(f"'{b}'" in js_all or f'"{b}"' in js_all, f"сцена {b} известна скрипту")
ok("setScene(b.dataset.sc)" in js_all or "setScene(" in js_all, "обработчик кнопок сцен")

# 4) меню: каждая вкладка настроек имеет панель и обработчик
tabs = set(re.findall(r'data-tab="([^"]+)"', html))
for t in tabs:
    ok(f'id="tab-{t}"' in html, f"панель вкладки {t}")
ok("dataset.tab" in js_all, "обработчик вкладок меню")

# 5) nav-кнопки меню связаны с обработчиками
for nb in ("navHome", "navChat", "navSet", "navTheme"):
    ok(f"$('{nb}').onclick" in js_all or f"getElementById('{nb}')" in js_all, f"nav {nb}")

print(f"check_js: {N['checks']} проверок — OK")
