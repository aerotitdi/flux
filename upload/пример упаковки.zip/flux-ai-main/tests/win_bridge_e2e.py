"""E2E Windows-моста: win_bridge.py --mock ↔ app.winbridge ↔ тулзы windows_* ↔ HTTP API ↔ UI.

Работает на любой ОС (pywinauto не нужен — мост в mock-режиме симулирует окна).
Проверяет:
  1) протокол браузерного моста: {type:req,id,cmd} -> {type:resp,id,result,error}, ping/pong;
  2) все команды: status/apps/windows/activate/children/click/type/send_keys/read/wait/
     screenshot/eval/launch/close;
  3) авто-переподключение FLUX каждые 3с после падения сервера;
  4) тулзы реестра windows_* (включая скриншот в data/shots);
  5) /api/win/* (меню UI — эталон пользователя, без правок).

Запуск:  python tests/win_bridge_e2e.py
"""
import asyncio
import base64
import json
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ.setdefault("FLUX2_HOME", "/tmp/flux2win")
BRIDGE_PORT = int(os.environ.get("WINBRIDGE_TEST_PORT", "8653"))
FLUX_PORT = int(os.environ.get("FLUX_TEST_PORT", "8661"))
os.environ["FLUX_WIN_BRIDGE_URL"] = f"ws://127.0.0.1:{BRIDGE_PORT}/win-bridge"

try:
    from websockets.asyncio.client import connect as ws_connect  # websockets >= 13
except ImportError:
    from websockets.client import connect as ws_connect           # legacy

BRIDGE = [sys.executable, os.path.join(ROOT, "windows_bridge", "win_bridge.py"),
          "--mock", "--port", str(BRIDGE_PORT)]

PNG_MAGIC = b"\x89PNG\r\n\x1a\n"


def start_bridge():
    return subprocess.Popen(BRIDGE, cwd=ROOT, stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)


async def wait_port(proc, timeout=12):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if proc.poll() is not None:
            raise RuntimeError(f"win_bridge.py умер с кодом {proc.returncode}")
        try:
            async with ws_connect(os.environ["FLUX_WIN_BRIDGE_URL"], open_timeout=1):
                return True
        except Exception:
            await asyncio.sleep(0.25)
    raise RuntimeError("win_bridge.py не поднял порт")


async def raw_protocol_check():
    """Протокол 1-в-1 как браузерный мост: req/resp + id эхом + error-формат + ping->pong."""
    async with ws_connect(os.environ["FLUX_WIN_BRIDGE_URL"]) as ws:
        await ws.send(json.dumps({"type": "req", "id": "abc", "cmd": "apps"}))
        d = json.loads(await ws.recv())
        assert d["type"] == "resp" and d["id"] == "abc" and d["error"] is None, d
        assert isinstance(d["result"], dict) and d["result"]["ok"] is True, d
        titles = [a["title"] for a in d["result"]["apps"]]
        assert any("Блокнот" in t for t in titles), titles
        # неизвестная команда -> error, соединение живо
        await ws.send(json.dumps({"type": "req", "id": 2, "cmd": "нет_такой"}))
        d = json.loads(await ws.recv())
        assert d["id"] == 2 and d["error"] and "неизвестная команда" in d["error"], d
        # клиентский ping -> pong от сервера
        await ws.send(json.dumps({"type": "ping"}))
        d = json.loads(await ws.recv())
        assert d["type"] == "pong", d
    print("raw-протокол: req/resp, error, ping/pong — OK")


async def main():
    proc = start_bridge()
    try:
        await wait_port(proc)
        print(f"win_bridge.py --mock запущен (порт {BRIDGE_PORT})")
        await raw_protocol_check()

        # --- клиент FLUX: автоконнект + все команды ---------------------------
        from app import winbridge as wb
        ok = await wb.start()
        for _ in range(60):
            if wb.online():
                break
            await asyncio.sleep(0.1)
        assert wb.online(), f"клиент не подключился: {wb.status()}"
        print("app.winbridge: подключён,", wb.status())

        st = await wb.call({"cmd": "status"})
        assert st["backend"] == "mock" and st["ok"], st

        apps = await wb.call({"cmd": "apps"})
        assert apps["count"] >= 3, apps
        notepad = next(a for a in apps["apps"] if "Блокнот" in a["title"])
        print(f"apps: {apps['count']} окон; блокнот hwnd={notepad['hwnd']}")

        wins = await wb.call({"cmd": "windows"})
        nw = next(w for w in wins["windows"] if w["hwnd"] == notepad["hwnd"])
        assert nw["rect"]["width"] == 800 and nw["rect"]["height"] == 540, nw

        act = await wb.call({"cmd": "activate", "app": "Блокнот"})
        assert act["ok"] and act["hwnd"] == notepad["hwnd"], act

        ch = await wb.call({"cmd": "children", "app": "Блокнот"})
        kinds = {(c["title"], c["control_type"]) for c in ch["children"]}
        assert ("Сохранить", "Button") in kinds and ("Текстовый редактор", "Edit") in kinds, kinds

        cl = await wb.call({"cmd": "click", "app": "Блокнот",
                            "control": {"title": "Сохранить", "control_type": "Button"}})
        assert cl["ok"] and cl["clicked"]["title"] == "Сохранить", cl

        tp = await wb.call({"cmd": "type", "app": "Блокнот",
                            "control": {"auto_id": "15"}, "text": "привет от FLUX"})
        assert tp["ok"] and tp["typed"] == len("привет от FLUX"), tp

        rd = await wb.call({"cmd": "read", "app": "Блокнот", "control": {"auto_id": "15"}})
        assert rd["ok"] and "привет от FLUX" in str(rd.get("value") or rd.get("texts")), rd

        sk = await wb.call({"cmd": "send_keys", "app": "Блокнот", "keys": "^s"})
        assert sk["ok"] and sk["keys"] == "^s", sk

        wt = await wb.call({"cmd": "wait", "app": "Блокнот",
                            "control": {"title": "Файл"}, "timeout": 3000})
        assert wt["ok"] and wt["found"] and wt["waited_ms"] >= 0, wt
        # таймаут ожидания -> error (формат моста)
        try:
            await wb.call({"cmd": "wait", "app": "Блокнот",
                           "control": {"title": "чего_нет_в_окне"}, "timeout": 800}, timeout=15)
            raise AssertionError("wait должен был упасть по таймауту")
        except wb.WinBridgeDown as e:
            assert "таймаут" in str(e).lower() or "не найден" in str(e).lower(), e

        shot = await wb.call({"cmd": "screenshot", "app": "Блокнот"})
        assert shot["ok"] and shot["dataBase64"], "нет dataBase64"
        raw = base64.b64decode(shot["dataBase64"])
        assert raw.startswith(PNG_MAGIC) and shot["width"] > 100, (len(raw), shot)
        print(f"screenshot: PNG {shot['width']}x{shot['height']}, {len(raw)//1024} КБ base64->bytes")

        ev = await wb.call({"cmd": "eval", "app": "Блокнот", "code": "win.window_text()"})
        assert ev["ok"] and "Блокнот" in str(ev["result"]), ev
        ev2 = await wb.call({"cmd": "eval", "app": "Блокнот",
                             "code": "print('лог');\nlen(win.children())"})
        assert ev2["ok"] and ev2["result"] == 4 and "лог" in ev2["stdout"], ev2

        ln = await wb.call({"cmd": "launch", "path": "notepad.exe /mock"})
        assert ln["ok"] and ln["pid"], ln
        apps2 = await wb.call({"cmd": "apps"})
        fresh = next(a for a in apps2["apps"] if "mock" in a["title"] and a["pid"] == ln["pid"])
        cls = await wb.call({"cmd": "close", "app": fresh["hwnd"]})
        assert cls["ok"], cls
        apps3 = await wb.call({"cmd": "apps"})
        assert fresh["hwnd"] not in [a["hwnd"] for a in apps3["apps"]], "окно не закрылось"
        print("команды моста: status/apps/windows/activate/children/click/type/read/"
              "send_keys/wait/screenshot/eval/launch/close — OK")

        # --- тулзы FLUX (реестр, категория windows) ---------------------------
        os.makedirs(os.path.join(os.environ["FLUX2_HOME"], "data", "shots"), exist_ok=True)
        from app.tools import REG
        cats = REG.categories()
        assert cats.get("windows", 0) >= 14, cats
        r = await REG.dispatch("windows_apps", {}, {})
        assert r.ok and "Блокнот" in r.text, r
        r = await REG.dispatch("windows_click", {"app": "Блокнот", "title": "Сохранить",
                                                 "control_type": "Button"}, {})
        assert r.ok and "клик" in r.text.lower(), r
        r = await REG.dispatch("windows_type", {"app": "Блокнот", "auto_id": "15",
                                                "text": " через тулз"}, {})
        assert r.ok and "введено" in r.text, r
        r = await REG.dispatch("windows_screenshot", {"app": "Блокнот"}, {})
        assert r.ok and r.images and os.path.getsize(r.images[0]) > 500, r
        r = await REG.dispatch("windows_eval", {"app": "Блокнот",
                                                "code": "win.window_text()"}, {})
        assert r.ok and "Блокнот" in r.text, r
        r = await REG.dispatch("windows_wait", {"app": "Блокнот", "title": "Файл",
                                                "timeout_s": 3}, {})
        assert r.ok and "появился" in r.text, r
        r = await REG.dispatch("windows_status", {}, {})
        assert r.ok and "ЖИВ" in r.text, r
        # поиск реестра находит семейство по запросу агента
        names = {s.name for s in REG.search("кликни кнопку сохранить в блокноте windows", k=10)}
        assert "windows_click" in names, names
        print(f"тулзы windows_*: {cats['windows']} шт., dispatch+retrieval — OK, скриншот сохранён")

        # --- авто-переподключение: убиваем и поднимаем сервер ------------------
        proc.terminate()
        proc.wait(timeout=5)
        t0 = time.time()
        while wb.online() and time.time() - t0 < 5:
            await asyncio.sleep(0.1)
        assert not wb.online(), "клиент не заметил падение сервера"
        try:
            await wb.call({"cmd": "apps"}, timeout=3)
            raise AssertionError("call должен был вернуть WinBridgeDown")
        except wb.WinBridgeDown as e:
            assert "win_bridge.py" in str(e), e
        print("падение сервера: онлайн=False, тулзы дают понятную ошибку — OK")

        proc = start_bridge()
        await wait_port(proc)
        t0 = time.time()
        while not wb.online() and time.time() - t0 < 12:
            await asyncio.sleep(0.2)
        assert wb.online(), "FLUX не переподключился автоматически"
        apps = await wb.call({"cmd": "apps"})
        assert apps["count"] >= 3, apps
        print(f"переподключение: автоматом за {time.time() - t0:.1f}с (цикл 3с) — OK")

        # --- HTTP API + UI ------------------------------------------------------
        import aiohttp
        from app.config import CONFIG
        from app.server import build_app
        CONFIG.settings["win_bridge_url"] = os.environ["FLUX_WIN_BRIDGE_URL"]
        runner = aiohttp.web.AppRunner(build_app())
        await runner.setup()
        await aiohttp.web.TCPSite(runner, "127.0.0.1", FLUX_PORT).start()
        await asyncio.sleep(0.8)
        base = f"http://127.0.0.1:{FLUX_PORT}"
        async with aiohttp.ClientSession() as s:
            async with s.get(base + "/api/win/status") as rr:
                d = await rr.json()
                assert d["ok"] is True and d["server"]["backend"] == "mock", d
            async with s.get(base + "/api/win/apps?force=1") as rr:
                d = await rr.json()
                assert d["ok"] and len(d["apps"]) >= 3, d
            async with s.post(base + "/api/win/cmd",
                              json={"cmd": "activate", "app": "Блокнот"}) as rr:
                d = await rr.json()
                assert d["ok"] and d["result"]["title"], d
            async with s.post(base + "/api/win/cmd",
                              json={"cmd": "click", "app": "x",
                                    "control": {"title": "y"}}) as rr:
                assert rr.status == 403, "click из UI должен быть запрещён"
            async with s.post(base + "/api/win/reconnect") as rr:
                d = await rr.json()
                assert d["ok"] is True, d
            async with s.get(base + "/api/win/log?n=50") as rr:
                d = await rr.json()
                cmds = [e["cmd"] for e in d["log"]]
                assert "activate" in cmds and any(c == "apps" for c in cmds), cmds
            async with s.get(base + "/api/state") as rr:
                d = await rr.json()
                assert d["tools_categories"].get("windows", 0) >= 14, d["tools_categories"]
            async with s.get(base + "/") as rr:
                html = await rr.text()
                # меню — эталон пользователя (без правок); win-функциональность живёт
                # в API и тулзах, поэтому проверяем серверные маршруты, а не разметку
                for needle in ("settingsOv", "sceneBtns", "connOv"):
                    assert needle in html, f"в UI нет: {needle}"
        print("HTTP API (/api/win/*) + эталонное меню UI — OK")
        await runner.cleanup()

        print("\nE2E Windows-моста OK: протокол, 14 команд, реконнект, тулзы, API, UI")
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except Exception:
                proc.kill()


asyncio.run(main())
