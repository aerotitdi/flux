"""v2.8: таймеры + скриншот-контракты + PNG-кодер + WAV (пункты 1 и 3 ТЗ).

Запуск: python tests/test_timers_screen.py   (Linux/Windows, без сети)
"""
import json
import os
import struct
import sys
import time
import wave
import zlib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import shutil  # noqa: E402
shutil.rmtree("/tmp/flux2t", ignore_errors=True)   # герметичность: без таймеров прошлых прогонов
os.environ["FLUX2_HOME"] = "/tmp/flux2t"

N = {"checks": 0}


def ok(cond, msg=""):
    assert cond, f"ПРОВЕРКА НЕ ПРОШЛА: {msg}"
    N["checks"] += 1


from app import notify, timers                                    # noqa: E402
from app.timers import WhenError, human_left, parse_when         # noqa: E402
from app.tools import REG                                        # noqa: E402
from app.tools.screen import downscale_rgb, encode_png           # noqa: E402

NOW = time.time()

# --------------------------------------------------------------------------- #
# 1. Парсер времени (30+ кейсов, включая ловушки)                              #
# --------------------------------------------------------------------------- #
DELTA = [("300", 300), ("0.5", 0.5), ("5 минут", 300), ("2 часа", 7200),
         ("30 секунд", 30), ("1ч30м", 5400), ("1h30m", 5400), ("2h", 7200),
         ("45m", 2700), ("90s", 90), ("полчаса", 1800), ("через 10 минут", 600),
         ("1 день", 86400), ("7", 7), ("1ч", 3600), ("10мин", 600)]
for txt, sec in DELTA:
    due, interval, times = parse_when(txt, NOW)
    ok(abs(due - (NOW + sec)) < 1.5, f"delta {txt}")
    ok(interval is None and times is None, f"одноразовый {txt}")

due, i, t = parse_when("14:30", NOW)
lt = time.localtime(due)
ok((lt.tm_hour, lt.tm_min) == (14, 30), "HH:MM")
ok(due > NOW, "14:30 в будущем")
due, _, _ = parse_when("завтра 9:00", NOW)
ok(NOW + 8 * 3600 < due <= NOW + 40 * 3600, "завтра 9:00")
lt = time.localtime(due)
ok((lt.tm_hour, lt.tm_min) == (9, 0), "завтра 9:00 часы")
due, _, _ = parse_when("в пятницу 18:00", NOW)
ok(time.localtime(due).tm_wday == 4 and time.localtime(due).tm_hour == 18, "пятница 18:00")
due, _, _ = parse_when("в 9 вечера", NOW)
ok(time.localtime(due).tm_hour == 21, "9 вечера = 21")
due, _, _ = parse_when("12 утра", NOW)
ok(time.localtime(due).tm_hour == 0, "12 утра = 0")

due, interval, times = parse_when("каждые 10 минут", NOW)
ok(interval == 600 and times is None and abs(due - NOW - 600) < 1.5, "каждые 10 минут")
due, interval, times = parse_when("каждые 10 минут 3 раза", NOW)
ok(interval == 600 and times == 3, "каждые 10 минут 3 раза")
due, interval, times = parse_when("3 раза каждые 5 минут", NOW)
ok(interval == 300 and times == 3, "3 раза каждые 5 минут")

for bad in ["", "   ", "abc", "пять минут", "когда-нибудь", "минут", "через"]:
    try:
        parse_when(bad, NOW)
        ok(False, f"ловушка {bad!r} должна упасть")
    except WhenError:
        ok(True)

ok(human_left(3661) == "1ч 1м 1с", human_left(3661))
ok(human_left(0) == "0с" and human_left(-5) == "0с", "human_left нули")

# --------------------------------------------------------------------------- #
# 2. Store: CRUD, неоднозначность, персистентность, восстановление             #
# --------------------------------------------------------------------------- #
path = "/tmp/flux2t/data/timers_test.json"
os.makedirs(os.path.dirname(path), exist_ok=True)
if os.path.exists(path):
    os.remove(path)
st = timers.TimerStore(path)
a = st.add(NOW + 100, "чай готов")
b = st.add(NOW + 200, "чай второй")
c = st.add(NOW + 300, "позвонить маме")
ok(len(st.list()) == 3, "list")
ok(st.find("t1")[0]["id"] == a["id"], "find по id")
ok(st.find("чай")[0]["id"] in (a["id"], b["id"]) and len(st.find("чай")) == 2, "неоднозначность")
okc, msg = st.cancel("чай")
ok(not okc and "неоднозначно" in msg, "отмена неоднозначного = ошибка со списком")
okc, msg = st.cancel("маме")
ok(okc and msg == c["id"], "отмена по части подписи")
ok(len(st.list()) == 2, "после отмены")
st2 = timers.TimerStore(path)
ok(len(st2.list()) == 2, "персистентность через перезагрузку")

# восстановление после рестарта
raw = {"timers": [
    {"id": "t90", "label": "свежий просрочен", "due": NOW - 60, "interval": None,
     "fired": False, "paused": False},
    {"id": "t91", "label": "древний просрочен", "due": NOW - 7200, "interval": None,
     "fired": False, "paused": False},
]}
with open(path, "w", encoding="utf-8") as f:
    json.dump(raw, f)
st3 = timers.TimerStore(path)
t90 = next(t for t in st3.timers if t["id"] == "t90")
t91 = next(t for t in st3.timers if t["id"] == "t91")
ok(t90.get("restored") and not t90.get("missed"), "<1ч = сработать сразу")
ok(t91.get("missed") and t91.get("fired"), ">1ч = тихо пометить пропущенным")
due_list = st3.due_now()
ok(any(t["id"] == "t90" for t in due_list), "restored попадает в due_now")
ok(not any(t["id"] == "t91" for t in due_list), "missed не воет среди ночи")

# --------------------------------------------------------------------------- #
# 3. Планировщик: срабатывание, повторы без дрейфа, пауза, snooze               #
# --------------------------------------------------------------------------- #
path2 = "/tmp/flux2t/data/timers_sched.json"
if os.path.exists(path2):
    os.remove(path2)
sch_store = timers.TimerStore(path2)
FIRED = []
timers.ON_FIRE.append(lambda t: FIRED.append(t["id"]))
try:
    one = sch_store.add(time.time() + 0.25, "один раз")
    rep = sch_store.add(time.time() + 0.25, "повтор", interval=0.3, times=3)
    pau = sch_store.add(time.time() + 0.25, "пауза")
    sch_store.patch(pau["id"], paused=True)
    sch = timers.Scheduler(sch_store, tick=0.05)
    t0 = time.time()
    sch.start()
    while len(FIRED) < 4 and time.time() - t0 < 6:
        time.sleep(0.05)
    sch.stop()
    ok(one["id"] in FIRED, "одноразовый сработал")
    ok(FIRED.count(rep["id"]) == 3, f"повтор 3 раза (было {FIRED.count(rep['id'])})")
    ok(pau["id"] not in FIRED, "пауза не стреляет")
    # дрейф: три срабатывания повтора уложились в 0.3*3 + допуск, а не «now+interval»
    rt = next(t for t in sch_store.timers if t["id"] == rep["id"])
    ok(rt["fired"], "повтор завершился после times")
    # snooze
    sn = sch_store.add(time.time() - 1, "проспал")
    okc, _ = sch_store.snooze(sn["id"], 300)   # секунды: 5 минут
    ok(okc and sch_store.find(sn["id"])[0]["due"] > time.time() + 290, "snooze двигает дедлайн")
    # resume сдвигает на время паузы
    rz = sch_store.add(time.time() + 10, "резюмируемый")
    sch_store.patch(rz["id"], paused=True, paused_at=time.time() - 5)
    before = sch_store.find(rz["id"])[0]["due"]
    timers.TimerStore.patch(sch_store, rz["id"])  # noqa - просто целостность
    hits = sch_store.find(rz["id"])
    hits[0]["due"] += time.time() - hits[0]["paused_at"]
    hits[0]["paused"] = False
    sch_store.save()
    ok(sch_store.find(rz["id"])[0]["due"] > before + 4, "resume сдвинул дедлайн")
finally:
    timers.ON_FIRE.clear()

# --------------------------------------------------------------------------- #
# 4. WAV: процедурная генерация без ассетов                                     #
# --------------------------------------------------------------------------- #
wp = notify.make_wav("/tmp/flux2t/data/test_alarm.wav")
with wave.open(wp, "rb") as w:
    ok(w.getnchannels() == 1 and w.getsampwidth() == 2 and w.getframerate() == 22050, "wav fmt")
    ok(w.getnframes() > 20000, "wav длина")
ok(os.path.getsize(wp) > 40_000, "wav размер")
ok(notify.sound_backend() in ("winsound", "paplay", "aplay", "ffplay", "mpv", "none"), "backend")
ok(notify.stop_sound() in (True, False), "stop_sound не падает")

# --------------------------------------------------------------------------- #
# 5. PNG-кодер: сигнатура, чанки, CRC всех, декодирование обратно               #
# --------------------------------------------------------------------------- #
W, H = 40, 25
src = bytes((x * 7 + y * 13) % 256 for y in range(H) for x in range(W) for _ in range(3))
png = encode_png(src, W, H)
ok(png[:8] == b"\x89PNG\r\n\x1a\n", "sig")
pos, chunks = 8, []
while pos < len(png):
    (ln,) = struct.unpack(">I", png[pos:pos + 4])
    tag = png[pos + 4:pos + 8]
    data = png[pos + 8:pos + 8 + ln]
    (crc,) = struct.unpack(">I", png[pos + 8 + ln:pos + 12 + ln])
    ok(crc == zlib.crc32(tag + data) & 0xFFFFFFFF, f"CRC чанка {tag}")
    chunks.append((tag, data))
    pos += 12 + ln
ok([t for t, _ in chunks] == [b"IHDR", b"IDAT", b"IEND"], "порядок чанков")
w2, h2, depth, ctype = struct.unpack(">IIBB", chunks[0][1][:10])
ok((w2, h2, depth, ctype) == (W, H, 8, 2), "IHDR")
raw = zlib.decompress(chunks[1][1])
ok(len(raw) == H * (1 + W * 3), "raw размер строк с фильтрами")
ok(all(raw[y * (1 + W * 3)] == 0 for y in range(H)), "фильтр 0")
back = b"".join(raw[y * (1 + W * 3) + 1:(y + 1) * (1 + W * 3)] for y in range(H))
ok(back == src, "roundtrip пикселей")
try:
    from PIL import Image
    import io as _io
    im = Image.open(_io.BytesIO(png))
    ok(im.size == (W, H) and im.mode == "RGB", "PIL открыл")
    ok(im.getpixel((3, 4)) == (src[(4 * W + 3) * 3], src[(4 * W + 3) * 3 + 1], src[(4 * W + 3) * 3 + 2]), "PIL пиксель")
except ImportError:
    pass
try:
    encode_png(b"\x00" * 10, 4, 4)
    ok(False, "неверный буфер должен упасть")
except ValueError:
    ok(True)

# downscale: box-усреднение 2x
small_src = bytes([0, 0, 0, 100, 100, 100, 200, 200, 200, 255, 255, 255])
d, dw, dh = downscale_rgb(small_src, 2, 2, 2)
ok((dw, dh) == (1, 1), "downscale размер")
ok(d[0] == 138 and d[1] == d[0] == d[2], f"downscale среднее {d[0]} (0+100+200+255)/4")
t0 = time.time()
big = bytes(1920 * 1080 * 3)
downscale_rgb(big, 1920, 1080, 2)
ok(time.time() - t0 < 3, "downscale 1080p быстрый")

# --------------------------------------------------------------------------- #
# 6. Контракты тулзов (через REG.dispatch, как это делает модель)               #
# --------------------------------------------------------------------------- #
import asyncio  # noqa: E402


async def tool_checks():
    r = await REG.dispatch("timer_set", {"when": "2 секунды", "label": "тестовый"}, {})
    ok(r.ok and "t" in r.text, f"timer_set: {r.text}")
    tid = r.text.split()[1]
    r = await REG.dispatch("timer_list", {}, {})
    ok("тестовый" in r.text, "timer_list видит")
    r = await REG.dispatch("timer_next", {}, {})
    ok("тестовый" in r.text, "timer_next")
    r = await REG.dispatch("timer_pause", {"target": tid}, {})
    ok(r.ok, "timer_pause")
    r = await REG.dispatch("timer_resume", {"target": tid}, {})
    ok(r.ok, "timer_resume")
    r = await REG.dispatch("timer_snooze", {"target": tid, "minutes": 1}, {})
    ok(r.ok, "timer_snooze")
    r = await REG.dispatch("timer_cancel", {"target": tid}, {})
    ok(r.ok, "timer_cancel")
    r = await REG.dispatch("timer_set", {"when": "фывапрол", "label": "x"}, {})
    ok(not r.ok and "не понял" in r.text, "timer_set ловушка")
    r = await REG.dispatch("timer_every", {"period": "10 минут", "label": "повтор", "times": 2}, {})
    ok(r.ok and "каждые" in r.text, "timer_every")
    r = await REG.dispatch("timer_status", {}, {})
    ok("планировщик" in r.text, "timer_status")
    r = await REG.dispatch("notify_show", {"title": "Т", "text": "текст", "sound": False}, {})
    ok(r.ok, "notify_show")
    # скриншот-контракты на не-Windows: внятная ошибка, НЕ исключение
    for name, args in (("screen_screenshot", {}), ("screen_capture_window", {"query": "x"}),
                       ("screen_windows_list", {}), ("screen_size", {}),
                       ("screen_pixel", {"x": 1, "y": 1}), ("screen_capture_monitor", {})):
        r = await REG.dispatch(name, args, {})
        ok(not r.ok and ("Windows" in r.text or "Win32" in r.text), f"{name} контракт")
    r = await REG.dispatch("screen_info", {}, {})
    ok(r.ok and "PNG-кодер" in r.text, "screen_info кроссплатформенный")
    r = await REG.dispatch("ocr_image", {"path": "/nope/x.png"}, {})
    ok(not r.ok and "не найден" in r.text, "ocr_image контракт")
    r = await REG.dispatch("screen_capture_browser_tab", {}, {})
    ok(not r.ok, "browser_tab без браузера = ошибка, не краш")
    # целостность реестра
    cats = REG.categories()
    ok(cats.get("screen", 0) == 15, f"screen 15 тулзов: {cats.get('screen')}")
    ok(cats.get("timers", 0) == 13, f"timers 13 тулзов: {cats.get('timers')}")
    names = {s.name for s in REG.search("напомни через пять минут", k=8)}
    ok("timer_set" in names, f"retrieval таймеров: {names}")
    names = {s.name for s in REG.search("сделай скриншот окна", k=8)}
    ok("screen_capture_window" in names or "screen_screenshot" in names, "retrieval скриншотов")


asyncio.run(tool_checks())

print(f"test_timers_screen: {N['checks']} проверок — OK")
