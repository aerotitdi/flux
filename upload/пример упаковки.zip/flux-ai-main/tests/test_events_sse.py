"""v2.8: сквозной канал событий — SSE /api/events доставляет таймер БЕЗ хода чата.

Запуск: python tests/test_events_sse.py   (нужен aiohttp)
"""
import asyncio
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import shutil  # noqa: E402
shutil.rmtree("/tmp/flux2sse", ignore_errors=True)
os.environ["FLUX2_HOME"] = "/tmp/flux2sse"

import aiohttp  # noqa: E402

PORT = 8663
BASE = f"http://127.0.0.1:{PORT}"
N = {"checks": 0}


def ok(cond, msg=""):
    assert cond, f"ПРОВЕРКА НЕ ПРОШЛА: {msg}"
    N["checks"] += 1


async def read_sse(resp, want: str, timeout: float = 8.0):
    """Читает SSE-поток до события типа want."""
    deadline = asyncio.get_event_loop().time() + timeout
    async for raw in resp.content:
        if asyncio.get_event_loop().time() > deadline:
            break
        line = raw.decode().strip()
        if line.startswith("data:"):
            d = json.loads(line[5:])
            if d.get("type") == want:
                return d
    raise AssertionError(f"не дождались события {want}")


async def main():
    from app.config import CONFIG  # noqa: F401  (создаёт домашний каталог)
    from app.server import build_app

    runner = aiohttp.web.AppRunner(build_app())
    await runner.setup()
    await aiohttp.web.TCPSite(runner, "127.0.0.1", PORT).start()
    await asyncio.sleep(0.6)

    async with aiohttp.ClientSession() as s:
        # два клиента одновременно — оба должны получить событие
        async with s.get(BASE + "/api/events") as e1, s.get(BASE + "/api/events") as e2:
            ok(e1.status == 200 and e2.status == 200, "SSE открылся")
            ok(e1.headers["Content-Type"].startswith("text/event-stream"), "content-type")

            # таймер создаётся REST'ом, ход чата НЕ происходит
            async with s.post(BASE + "/api/timers",
                              json={"when": "1 секунда", "label": "sse-проверка"}) as r:
                d = await r.json()
                ok(d["ok"], f"POST /api/timers: {d}")
                tid = d["timer"]["id"]

            ev1 = await read_sse(e1, "timer_fired")
            ev2 = await read_sse(e2, "timer_fired")
            ok(ev1["id"] == tid and ev1["label"] == "sse-проверка", "клиент 1 получил fired")
            ok(ev2["id"] == tid, "клиент 2 получил fired")
            ok(not ev1.get("missed"), "не пропущен")

            # модель получила очередь unacked (обязана сообщить на следующем ходе)
            from app import agent
            for _ in range(50):   # append идёт в scheduler-потоке сразу после publish
                if any(t.get("id") == tid for t in agent.UNACKED):
                    break
                await asyncio.sleep(0.02)
            ok(any(t.get("id") == tid for t in agent.UNACKED), "unacked пополнен")

            # управление таймером через REST
            async with s.post(BASE + "/api/timers",
                              json={"when": "5 минут", "label": "управляемый"}) as r:
                d = await r.json()
                tid2 = d["timer"]["id"]
            for act in ("pause", "resume", "snooze"):
                async with s.post(BASE + f"/api/timers/{tid2}/{act}",
                                  json={"minutes": 1}) as r:
                    d = await r.json()
                    ok(d["ok"], f"act {act}: {d}")
            async with s.post(BASE + f"/api/timers/{tid2}/cancel", json={}) as r:
                d = await r.json()
                ok(d["ok"], "cancel через REST")
            ev = await read_sse(e1, "timer_changed", timeout=4)
            ok(ev.get("action") in ("pause", "resume", "snooze", "cancel"), "событие изменения")

            # невалидное время -> 200 с ok:false и подсказкой
            async with s.post(BASE + "/api/timers", json={"when": "абракадабра"}) as r:
                d = await r.json()
                ok(not d["ok"] and "не понял" in d.get("error", ""), "валидация when")

        # звук: стоп всегда 200; тест на Linux может не иметь бэкенда
        async with s.post(BASE + "/api/notify/stop") as r:
            d = await r.json()
            ok(d["ok"], "notify/stop")
        async with s.post(BASE + "/api/notify/test") as r:
            d = await r.json()
            ok("backend" in d, "notify/test")

        # UI — эталон пользователя без правок: проверяем его маркеры, а не свои
        async with s.get(BASE + "/") as r:
            html = await r.text()
            for needle in ("settingsOv", "sceneBtns", 'data-tab="conns"', "sendBtn"):
                ok(needle in html, f"UI эталон: {needle}")

    await runner.cleanup()
    print(f"test_events_sse: {N['checks']} проверок — OK")


asyncio.run(main())
