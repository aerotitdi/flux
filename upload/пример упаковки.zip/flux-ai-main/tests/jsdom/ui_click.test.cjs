/* DOM-тест кликов: меню FLUX обязано работать (инцидент с мёртвыми кнопками, v2.8).
 * Запуск: node tests/jsdom/ui_click.test.cjs   (npm i jsdom в tests/jsdom)
 * Проверяет кликами: навигация, тема, вкладки настроек (включая Windows Automation),
 * кнопки сцен, точка winDot, кнопки вкладки win, тосты таймеров, cdpDot.
 * Любой необработанный exception страницы = провал теста.
 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const HTML = path.join(__dirname, '..', '..', 'ui', 'index.html');
let checks = 0;
const ok = (cond, msg) => { if (!cond) { console.error('ПРОВЕРКА НЕ ПРОШЛА:', msg); process.exit(1); } checks++; };

const errors = [];
const vc = new VirtualConsole();
vc.on('jsdomError', e => errors.push('jsdomError: ' + e.message));
vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')));

function anyProxy() {
  const f = function () { return p; };
  const p = new Proxy(f, {
    get: (t, k) => (k === Symbol.toPrimitive ? () => 0 : p),
    set: () => true,
    apply: () => p,
  });
  return p;
}

const fetchCalls = [];
const dom = new JSDOM(fs.readFileSync(HTML, 'utf-8'), {
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  url: 'http://127.0.0.1:8642/',
  virtualConsole: vc,
  beforeParse(window) {
    window.HTMLCanvasElement.prototype.getContext = () => anyProxy();
    window.fetch = async (url, opts) => {
      fetchCalls.push(String(url));
      const u = String(url);
      const json = async () => {
        if (u.includes('/api/state')) return { settings: {}, voice: {}, connections: [], mics: [], tools_count: 1, tools_categories: {} };
        if (u.includes('/api/cdp')) return { ok: false, error: 'mock' };
        if (u.includes('/api/win/status')) return { ok: false, url: 'ws://mock', last_error: null };
        if (u.includes('/api/win/apps')) return { ok: false, error: 'mock' };
        if (u.includes('/api/win/log')) return { ok: true, log: [] };
        if (u.includes('/api/voices')) return { ok: true, voices: [] };
        if (u.includes('/api/tools')) return { count: 0, tools: [] };
        return { ok: true };
      };
      return { status: 200, json, text: async () => '', headers: { get: () => null },
               body: { getReader: () => ({ read: async () => ({ done: true }) }) } };
    };
    window.EventSource = class { constructor(u) { this.url = u; } close() {} };
    window.addEventListener('error', e => errors.push('window.onerror: ' + e.message));
  },
});

const { window } = dom;
const { document } = window;
const $ = id => document.getElementById(id);
const click = el => el.dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
const tick = () => new Promise(r => setTimeout(r, 30));

(async () => {
  await tick(); await tick();
  ok(errors.length === 0, 'ошибки при загрузке: ' + errors.join(' | '));

  // навигация
  click($('navChat'));
  ok($('view-chat').classList.contains('on'), 'чат открылся');
  click($('navHome'));
  ok(!$('view-chat').classList.contains('on'), 'домой вернулись');

  // тема
  click($('navTheme'));
  ok(document.body.classList.contains('light'), 'светлая тема');
  click($('navTheme'));
  ok(!document.body.classList.contains('light'), 'тёмная тема');

  // настройки + все вкладки меню (принцип оригинала: .tabs button -> #tab-*)
  click($('navSet'));
  ok($('settingsOv').classList.contains('show'), 'модалка настроек открылась');
  const tabs = [...document.querySelectorAll('.tabs button')];
  ok(tabs.length >= 4, 'вкладок меню: ' + tabs.length);
  for (const b of tabs) {
    click(b);
    const name = b.dataset.tab;
    ok(b.classList.contains('on'), `вкладка ${name} активна`);
    ok(!$('tab-' + name).hidden, `панель tab-${name} видима`);
    for (const other of tabs) if (other !== b) ok($('tab-' + other.dataset.tab).hidden, `остальные скрыты (${other.dataset.tab})`);
  }

  // вкладка подключений: рендер списка и кнопка добавления (принцип эталона)
  click(tabs.find(b => b.dataset.tab === 'conns'));
  click($('addConnBtn'));
  ok($('connOv').classList.contains('show'), 'модалка соединения открылась');
  click(document.querySelector('#connOv .x'));
  ok(!$('connOv').classList.contains('show'), 'модалка соединения закрылась крестиком');

  // сцены: все кнопки переключаются без ошибок
  const sceneBtns = [...document.querySelectorAll('#sceneBtns button')];
  ok(sceneBtns.length >= 4, 'кнопок сцен: ' + sceneBtns.length);
  for (const b of sceneBtns) {
    click(b);
    ok(b.classList.contains('on'), `сцена ${b.dataset.sc} активна`);
    await tick();
  }

  // cdpDot: в эталоне обработчик вешается внутри хендлера ollamaConnect — меню НЕ правим,
  // поэтому проверяем только присутствие элемента и живой ping-маршрут сервера
  ok(!!$('cdpDot'), 'cdpDot присутствует в эталонном меню');
  const before = fetchCalls.length;
  click($('ollamaUrl') ? $('navSet') : $('navSet'));
  await tick();
  ok(fetchCalls.length >= before, 'меню отвечает без ошибок');

  // отправка из футера: эталонный гейт кодового слова (wake_mode=start) сначала
  // отклоняет «привет»…
  $('inp').value = 'привет';
  click($('sendBtn'));
  await tick();
  ok(!fetchCalls.some(u => u.includes('/api/chat')), 'гейт кодового слова держит');
  // …и пропускает «флюкс …» в /api/chat (SSE)
  $('inp').value = 'флюкс привет';
  click($('sendBtn'));
  await tick();
  ok(fetchCalls.some(u => u.includes('/api/chat')), 'sendBtn шлёт в /api/chat');

  ok(errors.length === 0, 'итоговые ошибки страницы: ' + errors.join(' | '));
  console.log(`ui_click.test: ${checks} проверок — OK (меню живо, кнопок мертвых нет)`);
  window.close();
  process.exit(0);
})().catch(e => { console.error('тест упал:', e); process.exit(1); });
