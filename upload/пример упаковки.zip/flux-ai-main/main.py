"""FLUX 2.0 Desktop — точка входа.

Режимы:
  flux2.exe / python main.py            — чат в нативном окне (.exe, pywebview/WebView2)
  python main.py --web                  — чат в браузере (микрофон браузера)
  python main.py --console              — чат в терминале (консолька)
  python main.py --selftest             — отчёт: тулзы/подключения/CDP
"""
from __future__ import annotations

import argparse
import asyncio
import os
import shutil
import subprocess
import sys
import threading
import webbrowser

from aiohttp import web

from app import agent, __version__
from app.config import CONFIG
from app.server import build_app
from app.tools import REG

PORT = 8642


def start_server(port: int = PORT) -> threading.Thread:
    def runner():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        app_runner = web.AppRunner(build_app())
        loop.run_until_complete(app_runner.setup())
        site = web.TCPSite(app_runner, "127.0.0.1", port)
        loop.run_until_complete(site.start())
        loop.run_forever()
    t = threading.Thread(target=runner, daemon=True)
    t.start()
    import time
    time.sleep(0.6)
    return t


def _cdp_boot():
    """Доступ к браузеру пользователя ИЗНАЧАЛЬНО: коннект/подъём/рестарт Chrome с портом 9222."""
    import asyncio as _a
    from app import browser_cdp as cdp
    loop = _a.new_event_loop()
    _a.set_event_loop(loop)
    try:
        from app import bridge
        ok = loop.run_until_complete(cdp.ensure_ready())
        if bridge.online():
            print("[FLUX2] браузер: расширение FLUX Bridge на связи (живой Chrome)")
        elif ok:
            print("[FLUX2] браузер: подключён к ТВОЕМУ Chrome (CDP)")
        else:
            print("[FLUX2] браузер: живой Chrome без debug-доступа. Поставь расширение extension/ "
                  "(chrome://extensions -> загрузить распакованное) или галку в "
                  "chrome://inspect/#remote-debugging - и я подключусь без закрытий")
    except Exception as e:
        print(f"[FLUX2] CDP: {e}")


def console_mode(port: int) -> None:
    """Терминальный чат: тот же агент, события печатаются в консоль."""
    hist: list = []

    async def on_event(ev: dict):
        t = ev.get("type")
        if t == "token":
            print(ev.get("text", ""), end="", flush=True)
        elif t == "think":
            print(f"\n[think: {ev.get('mode')} | поиск: {'да' if ev.get('search') else 'нет'} | {ev.get('why')}]", flush=True)
        elif t == "search":
            print(f"[авто-поиск: {ev.get('engine')} результатов={ev.get('n')}]", flush=True)
        elif t == "skill":
            print(f"[скилл: {ev.get('name')}]", flush=True)
        elif t == "tool_start":
            print(f"\n[tool] {ev.get('name')} {str(ev.get('args'))[:120]}", flush=True)
        elif t == "tool_end":
            print(f"[tool {'ok' if ev.get('ok') else 'ERR'}] {ev.get('preview','')[:160]}", flush=True)
        elif t == "done":
            print(f"\n--- ({ev.get('seconds')}с, тулзов за ход: {ev.get('think','')}) ---", flush=True)
        elif t == "error":
            print(f"\n[ОШИБКА] {ev.get('text')}", flush=True)

    print(f"FLUX {__version__} — консоль. Команды: /model <conn::model> /search <engine> /think <auto|off|brief|medium|deep> "
          f"/tools <запрос> /reset /exit")
    print(f"инструментов: {len(REG.tools)}; модель: {CONFIG.active_connection() and CONFIG.active_connection()['name']} "
          f"/ {CONFIG.active_model() or 'НЕ выбрана'}")
    from app import timers as _tm
    act = _tm.STORE.list()
    if act:
        print(f"таймеров активно: {len(act)}; ближайший: {act[0]['id']} «{act[0]['label']}» "
              f"через {_tm.human_left(act[0]['due'] - __import__('time').time())}")
    loop = asyncio.new_event_loop()
    while True:
        try:
            line = input("\nвы> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not line:
            continue
        if line == "/exit":
            break
        if line == "/reset":
            hist.clear()
            print("история очищена")
            continue
        if line.startswith("/model "):
            CONFIG.settings["model_ref"] = line[7:].strip()
            CONFIG.save()
            print("модель:", CONFIG.settings["model_ref"])
            continue
        if line.startswith("/search "):
            CONFIG.settings["search_engine"] = line[8:].strip()
            CONFIG.save()
            print("поиск:", CONFIG.settings["search_engine"])
            continue
        if line.startswith("/think "):
            CONFIG.settings["think_mode"] = line[7:].strip()
            CONFIG.save()
            print("think:", CONFIG.settings["think_mode"])
            continue
        if line.startswith("/tools"):
            q = line[6:].strip() or ""
            for s in REG.search(q, 15):
                print(f"  {s.name}: {s.description}")
            continue
        print()
        loop.run_until_complete(agent.run_turn(line, hist, on_event))
    print("пока!")


def selftest() -> None:
    from app import notify, timers
    cats = REG.categories()
    print(f"FLUX {__version__} selftest")
    print(f"инструментов: {len(REG.tools)} (уникальных: {len(set(REG.tools))})")
    for k, v in sorted(cats.items()):
        print(f"  {k}: {v}")
    conn = CONFIG.active_connection()
    print(f"подключение: {conn['name'] if conn else 'НЕТ'} / модель: {CONFIG.active_model() or 'НЕТ'}")
    print(f"поиск: {CONFIG.settings.get('search_engine')} | think: {CONFIG.settings.get('think_mode')}")
    sch = timers.SCHEDULER
    print(f"таймеры: {len(timers.STORE.list())} активных · планировщик: "
          f"{'жив' if sch and sch.is_alive() else 'стартует с сервером'} · звук: {notify.sound_backend()}")
    try:
        from app.tools.screen import encode_png
        png = encode_png(b"\xff\x00\x00" * 4, 2, 2)
        print(f"скриншоты: PNG-кодер ok ({len(png)} Б), Win32 GDI: "
              f"{'да' if os.name == 'nt' else 'нет (не Windows)'}")
    except Exception as e:
        print(f"скриншоты: ошибка кодера: {e}")


def main() -> None:
    ap = argparse.ArgumentParser(prog="flux2")
    ap.add_argument("--console", action="store_true", help="терминальный чат")
    ap.add_argument("--web", action="store_true", help="открыть чат в браузере")
    ap.add_argument("--port", type=int, default=PORT)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    if args.selftest:
        selftest()
        return

    start_server(args.port)
    threading.Thread(target=_cdp_boot, daemon=True).start()

    if args.console:
        console_mode(args.port)
        return

    url = f"http://127.0.0.1:{args.port}/"
    if args.web:
        webbrowser.open(url)
        print(f"FLUX 2.0: {url} (Ctrl+C для остановки)")
        try:
            threading.Event().wait()
        except KeyboardInterrupt:
            return
        return

    open_window(url)


def find_chrome() -> str | None:
    """Ищем Google Chrome: сначала реестр (default browser), потом обычные пути."""
    dexe, dname = default_browser_exe()
    if dexe and "chrome" in dname.lower():
        return dexe
    cands = []
    if os.name == "nt":
        for env in ("LOCALAPPDATA", "PROGRAMFILES", "PROGRAMFILES(X86)"):
            base = os.environ.get(env, "")
            if base:
                cands.append(os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"))
        cands += [
            os.path.expanduser(r"~\AppData\Local\Google\Chrome\Application\chrome.exe"),
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
    else:
        cands += ["/usr/bin/google-chrome", "/usr/bin/chromium",
                  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return shutil.which("chrome") or shutil.which("google-chrome")


def default_browser_exe() -> tuple[str | None, str]:
    """Дефолтный браузер Windows из реестра: UserChoice ProgId -> shell/open/command.

    HKCU\\Software\\Microsoft\\Windows\\Shell\\Associations\\UrlAssociations\\http\\UserChoice
    -> HKCR\\<ProgId>\\shell\\open\\command  (например ChromeHTML -> chrome.exe).
    """
    if os.name != "nt":
        return None, ""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice") as k:
            prog_id, _ = winreg.QueryValueEx(k, "ProgId")
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, rf"{prog_id}\shell\open\command") as k:
            cmd, _ = winreg.QueryValueEx(k, "")
        import re as _re
        m = _re.search(r'"([^"]+\.exe)"', cmd or "")
        exe = m.group(1) if m else (cmd or "").split(".exe")[0].strip().strip('"') + ".exe"
        if exe and os.path.exists(exe):
            return exe, prog_id or ""
    except Exception:
        pass
    return None, ""


def find_edge() -> str | None:
    cands = []
    if os.name == "nt":
        for env in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA"):
            base = os.environ.get(env, "")
            if base:
                cands.append(os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
        cands += [r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"]
    else:
        cands += ["/usr/bin/microsoft-edge"]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return shutil.which("msedge")


def _app_mode(exe: str, url: str, tag: str) -> None:
    """Окно-приложение браузера (без вкладок/панелей) + отдельный профиль."""
    from app.config import app_dir
    profile = os.path.join(app_dir(), f"{tag}-app-profile")
    os.makedirs(profile, exist_ok=True)
    print(f"FLUX 2.0: окно {tag} -> {url}")
    proc = subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={profile}",
                             "--no-first-run", "--no-default-browser-check",
                             "--disable-features=EdgeSidebar" if "edge" in exe.lower() else "--no-service-autorun"])
    proc.wait()  # закрыл окно - FLUX завершается


def open_window(url: str) -> None:
    engine = CONFIG.settings.get("window_engine", "auto")
    dexe, dname = default_browser_exe()
    is_chromium = lambda p: bool(p) and any(x in p.lower() for x in ("chrome", "msedge", "chromium"))
    chrome, edge = find_chrome(), find_edge()

    if engine == "web":
        webbrowser.open(url)
        threading.Event().wait()
        return
    if engine == "default":
        if is_chromium(dexe):
            _app_mode(dexe, url, "default")
        else:
            webbrowser.open(url)
            threading.Event().wait()
        return
    if engine == "chrome":
        if chrome:
            _app_mode(chrome, url, "chrome")
            return
    elif engine == "edge":
        if edge:
            _app_mode(edge, url, "edge")
            return
    elif engine == "webview":
        if _start_webview(url):
            return
    else:  # auto: ТВОЙ дефолтный браузер (Chromium) -> Chrome -> Edge -> webview -> вкладка
        if is_chromium(dexe):
            _app_mode(dexe, url, "default")
            return
        if chrome:
            _app_mode(chrome, url, "chrome")
            return
        if edge:
            _app_mode(edge, url, "edge")
            return
        if _start_webview(url):
            return
    # фолбэки
    if chrome:
        _app_mode(chrome, url, "chrome")
        return
    if edge:
        _app_mode(edge, url, "edge")
        return
    if _start_webview(url):
        return
    webbrowser.open(url)
    threading.Event().wait()


def _start_webview(url: str) -> bool:
    try:
        import webview
        webview.create_window("FLUX 2.0", url, width=1180, height=820,
                              min_size=(760, 560), background_color="#0f1115", text_select=True)
        webview.start(debug=False)
        return True
    except Exception as e:
        print(f"webview не завёлся: {e}")
        return False


if __name__ == "__main__":
    main()
